import {Component} from '@angular/core';
import {IDoesFilterPassParams, IFilterParams} from 'ag-grid-community';
import {AgFrameworkComponent, IFilterAngularComp} from 'ag-grid-angular';

export interface IDropdownFilterParams extends IFilterParams {
  type?: string;
  enum: any[];
}

@Component({
    template: `
      <div style="display: flex; height: 100%">
        <div style="flex: 1">
          <p-dropdown
            [style]="{height: '100%', 'width': '100%', border: 0}"
            appendTo="body"
            [options]="params.enum"
            optionLabel="text"
            [(ngModel)]="value"
            (ngModelChange)="valueChanged()">
          </p-dropdown>
        </div>
      </div>`
})
export class DropdownFilterComponent
      implements IFilterAngularComp, AgFrameworkComponent<IDropdownFilterParams> {
  params: IDropdownFilterParams;
  value: any;

  agInit(params: IDropdownFilterParams): void {
    this.params = params;
    this.value = null;
  }

  isFilterActive(): boolean {
    return this.value != null;
  }

  doesFilterPass(params: IDoesFilterPassParams): boolean {
    return (<any>this.params).valueGetter(params.node) === this.value.value;
  }

  getModel(): any {
    return this.value ? {filter: this.value.value, type: this.params.type} : null;
  }

  setModel(model: any): void {
    this.value = model ? this.params.enum.find(e => e.value === model.filter) : null;
    if (model) {
      this.params.type =  model.type;
    }
  }

  onFloatingFilterChanged(type: string, filter: any) {
    this.value = filter != null ? this.params.enum.find(e => e.value == filter) : null;
    this.params.type = type ?? 'equals';
    this.params.filterChangedCallback();
  }

  valueChanged() {
    this.params.filterChangedCallback();
  }
}
