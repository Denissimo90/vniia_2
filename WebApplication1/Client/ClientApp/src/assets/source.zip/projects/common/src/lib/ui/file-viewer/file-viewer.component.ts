import {Component, ElementRef, ViewChild} from '@angular/core';
import {MessageService} from 'primeng/api';
import {DialogComponent} from '../dialog/dialog.component';
import {DomSanitizer, SafeStyle} from '@angular/platform-browser';
import {FileLoadService} from './file-load.service';
import * as FileSaver from 'file-saver';
import * as Tiff from 'browser-tiff.js';

export enum ServeFileType {SAVE = 'SAVE', VIEW = 'VIEW'}

@Component({
  selector: 'app-file-viewer',
  templateUrl: './file-viewer.component.html',
  styleUrls: ['./file-viewer.component.css'],
  providers: []
})

export class FileViewerComponent extends DialogComponent {
  currentTiffPage = 0;
  maxTiffPages = 1;
  tiffImage: Tiff;
  scaleRatio = 1;
  isTiff = false;
  isPDF = false;
  url: any;
  mediaType: string;
  isAvailableToDownload = true;
  protected data: Blob;
  protected fileName: string;

  @ViewChild('tiffContainer') tiffContainer: ElementRef;

  constructor(
    private messageService: MessageService,
    private fileLoadService: FileLoadService,
    private sanitizer: DomSanitizer) {
    super();
  }

  async init(data: Blob, mediaType: string, fileName: string, isAvailableToDownload = true) {
    this.data = data;
    this.fileName = fileName;
    this.mediaType = mediaType;
    this.isAvailableToDownload = isAvailableToDownload;

    const unsafeURL = window.URL.createObjectURL(data);
    const url = this.sanitizer.bypassSecurityTrustResourceUrl(unsafeURL);

    switch (mediaType.toLowerCase()) {
      case 'application/pdf':
        this.isPDF = true;
        this.url = url;
        break;
      case 'image/tif':
      case 'image/tiff':
        this.scaleRatio = 0.5;
        this.isTiff = true;
        const buffer: any = await this.fileLoadService.readFileAsync(data);
        this.tiffImage = new Tiff({buffer: buffer});
        this.maxTiffPages = this.tiffImage.countDirectory();
        this.updateTiffCanvas();
        console.log('TiffPages ' + this.maxTiffPages);
        break;
      default:
        this.isPDF = false;
        this.url = url;
        break;
    }
  }

  updateTiffCanvas() {
    this.tiffImage.setDirectory(this.currentTiffPage);
    const childElements = this.tiffContainer.nativeElement.childNodes;
    for (const child of childElements) {
      child.parentNode.removeChild(child);
    }
    this.tiffContainer.nativeElement.appendChild(this.tiffImage.toCanvas());
  }

  saveFile() {
    FileSaver.saveAs(this.data, decodeURIComponent(this.fileName));
  }

  close() {
    this.visible = false;
  }

  scale(ratio: number) {
    this.scaleRatio = Math.max(0.1, Math.min(2, this.scaleRatio + ratio));
  }

  onWheelScroll(event: WheelEvent) {
    if (event.shiftKey) {
      this.scale(event.deltaY * -0.001);
    }
  }

  onPageChange(event: any) {
    this.currentTiffPage = event.page;
    this.updateTiffCanvas();
  }

  getSanitizedTransform(): SafeStyle {
    return this.sanitizer.bypassSecurityTrustStyle('translate(0px, 0px) scale(' + this.scaleRatio + ')');
  }
}
