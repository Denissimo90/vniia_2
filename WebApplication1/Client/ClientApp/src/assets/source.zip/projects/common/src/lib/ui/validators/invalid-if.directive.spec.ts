import {InvalidIfDirective} from './invalid-if.directive';

describe('InvalidIfDirective', () => {
  it('should create an instance', () => {
    const directive = new InvalidIfDirective();
    expect(directive).toBeTruthy();
  });
});
