import {AfterViewInit, Directive} from '@angular/core';
import {Table} from 'primeng/table';

@Directive({ selector: 'p-table' })
export class TableFrozenFixDirective implements AfterViewInit {
    constructor(private table: Table) { }

    ngAfterViewInit() {
  	    let wrapper = this.table.el.nativeElement.querySelector(".ui-table-scrollable-wrapper");
        let fozen = this.table.el.nativeElement.querySelector(".ui-table-frozen-view");
        if (fozen) {
        	wrapper.appendChild(fozen);
        }
    }
}
