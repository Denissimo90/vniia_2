export class TableExtensionField {
  name: string;
  caption: string;
  type: string;
  comment: string;
  options: {[key: string]: string};

  constructor(json?: any) {
    if (json) {
      Object.assign(this, json);
    }
  }

  get textFieldName(): string {
    if (this.type === 'local-dict') {
      return 'extension.' + this.name + '.value';
    }
    if (this.type === 'dict') {
      return 'extension.' + this.name + '.' + this.options.field;
    }
    return 'extension.' + this.name;
  }
}
