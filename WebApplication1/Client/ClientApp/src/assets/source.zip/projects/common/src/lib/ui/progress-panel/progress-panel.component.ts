import {Component, Input} from '@angular/core';

@Component({
    selector: 'app-progressPanel',
    template: 
        `<p-blockUI [target]="content" [blocked]="blocked">
            <div style="position: absolute; top: 50%; left: 50%; margin-top: -2em; margin-left: -2em; text-align: center;">
                <i class="pi-spin pi pi-spinner" style="font-size: 4em"></i>
            </div>           
        </p-blockUI>
        <p-panel #content [showHeader]="false" [style]="style" [styleClass]="styleClass">
            <ng-content select></ng-content>
        </p-panel>`,
    styles: [
        '::ng-deep app-progressPanel > p-panel > .ui-panel > .ui-panel-content-wrapper > .ui-panel-content { border: none !important; }'
    ]
})
export class ProgressPanelComponent {
    @Input() blocked = false;
    @Input() style: any;
    @Input() styleClass: string;
}
