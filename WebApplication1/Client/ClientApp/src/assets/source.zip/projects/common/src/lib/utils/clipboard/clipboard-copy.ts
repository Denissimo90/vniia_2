export function copyTextToClipboard(text: string) {
  // document.execCommand() позволяет копировать в буфер только из активного текствого поля
  const clipboardTextField = document.createElement('textarea');

  clipboardTextField.style.opacity = '0';
  clipboardTextField.value = text;

  document.body.appendChild(clipboardTextField);

  clipboardTextField.focus();
  clipboardTextField.select();

  try {
    document.execCommand('copy');
  } catch (err) {
    console.log(err);
  } finally {
    document.body.removeChild(clipboardTextField);
  }
}
