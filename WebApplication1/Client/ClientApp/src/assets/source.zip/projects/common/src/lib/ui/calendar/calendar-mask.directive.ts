import {AfterViewInit, Directive, Input} from '@angular/core';
import {Calendar} from 'primeng/calendar';

@Directive({
  selector: 'p-calendar:not([rPCalendarMask])'
})
export class CalenderMaskDirective implements AfterViewInit {
  private mask = 'мм/дд/гггг';

  constructor(private calendar: Calendar) {
  }

  @Input("enableMask")
  enableMask = true;

  ngAfterViewInit(): void {
    if (!this.enableMask || this.calendar.timeOnly || this.calendar.inline || this.calendar.selectionMode != 'single') {
      return;
    }
    if (this.calendar.dateFormat) {
      this.mask = this.calendar.dateFormat
        .replace('yy', 'гггг')
        .replace('mm', 'мм')
        .replace('dd', 'дд');
    }
    const input = this.calendar.el.nativeElement.querySelector('input.ui-inputtext');
    input.addEventListener('focus', e => {
      if (!input.value) {
        input.value = this.mask;
        setTimeout(() => {
          input.setSelectionRange(0, 0);
        });
      }
    });
    input.addEventListener('keydown', (e: KeyboardEvent) => {
      const oldValue = input.value;
      if (e.ctrlKey) {
        // copy/paste
      } else if (e.code == 'Enter' || e.code == 'NumpadEnter' || e.code == 'Tab') {
        //
      } else if (e.code == 'Backspace' && input.selectionStart == input.selectionEnd) {
        const start = input.selectionStart;
        if (start - 1 >= 0) {
          input.value = oldValue.substr(0, start - 1) + this.mask[start - 1] + oldValue.substr(start);
          input.setSelectionRange(start - 1, start - 1);
        }
        e.preventDefault();
      } else if (e.code == 'Delete' && input.selectionStart == input.selectionEnd) {
        e.preventDefault();
      } else if (e.code == 'Backspace' || e.code == 'Delete') {
        const start = input.selectionStart;
        let value = oldValue
        for (let i = input.selectionStart; i < input.selectionEnd; i++) {
          value = value.substr(0, i) + this.mask[i] + value.substr(i + 1);
        }
        input.value = value;
        input.setSelectionRange(start, start);
        e.preventDefault();
      } else if (e.code == 'ArrowLeft') {
        const start = input.selectionStart - 1;
        if (start >= 0) {
          input.setSelectionRange(start, start);
        }
        e.preventDefault();
      } else if (e.code == 'ArrowRight') {
        const start = input.selectionStart + 1;
        if (start <= this.mask.length) {
          input.setSelectionRange(start, start);
        }
        e.preventDefault();
      } else if (/\d/.test(e.key)) {
        let start = input.selectionStart;
        if (/[^дгм]/.test(this.mask[start])) {
          start++;
        }
        if (start < this.mask.length) {
          input.value = oldValue.substr(0, start) + e.key + oldValue.substr(start + 1);
          start++;
          if (/[^дгм]/.test(this.mask[start])) {
            start++;
          }
          input.setSelectionRange(start, start);
        }
        e.preventDefault();
      } else {
        this.calendar.onInputKeydown(e);
        e.preventDefault();
      }

      if (oldValue != input.value) {
        this.calendar.onUserInput(e);
      }
    });
    input.addEventListener('paste', e => {
      const text = e.clipboardData.getData('text');
      if (text) {
        let value = input.value;
        const start = input.selectionStart;
        for (let i = 0; i < this.mask.length - start && i < text.length; i++) {
          if (/[^дгм]/.test(this.mask[start + i])) {
            //
          } else if (/\d/.test(text[i])) {
            value = value.substr(0, start + i) + text[i] + value.substr(start + i + 1);
          }
        }
        input.value = value;
        input.setSelectionRange(start + text.length, start + text.length);
        this.calendar.isKeydown = true;
        this.calendar.onUserInput(e);
      }
      e.preventDefault();
    });
  }
}
