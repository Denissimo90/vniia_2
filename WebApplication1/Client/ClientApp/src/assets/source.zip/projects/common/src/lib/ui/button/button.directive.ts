import {AfterViewInit, Directive, ElementRef} from '@angular/core';

@Directive({
  selector: 'button:not([type]), p-button:not([type])'
})
export class ButtonDirective implements AfterViewInit {

  constructor(private button: ElementRef) {
  }

  ngAfterViewInit(): void {
    if (this.button.nativeElement instanceof HTMLButtonElement) {
      this.button.nativeElement.type = 'button';
    } else {
      this.button.nativeElement.getElementsByTagName('button').item(0).type = 'button';
    }
  }
}
