import {AfterViewInit, Directive} from '@angular/core';
import {TreeTable} from 'primeng/treetable';

@Directive({
    selector: "p-treeTable"
})
export class SizeableTreeDirective implements AfterViewInit {
  iframe: any;
  unfrozenView: any;
  unfrozenBody: any;

  constructor(private treeTable: TreeTable) {
  }

  ngAfterViewInit() {
    if (this.treeTable.resizableColumns && this.treeTable.scrollable) {
      this.treeTable.onColResize.subscribe(() => {
        this.onColumnResize();
      });

      this.unfrozenView = this.treeTable.el.nativeElement.querySelector('.ui-treetable-scrollable-view');
      this.unfrozenBody = this.unfrozenView.querySelector('.ui-treetable-scrollable-body');

      const iframe = document.createElement('iframe');
      iframe.id = 'hacky-scrollbar-resize-listener';
      iframe.style.cssText = 'height: 0; background-color: transparent; margin: 0; padding: 0; overflow: hidden; border-width: 0; position: absolute; width: 100%;';

      const self = this;
      // Register our event when the iframe loads
      iframe.onload = function () {
        // The trick here is that because this iframe has 100% width
        // it should fire a window resize event when anything causes it to
        // resize (even scrollbars on the outer element)
        iframe.contentWindow.addEventListener('resize', function () {
          self.onColumnResize();
        });
      };

      // Stick the iframe somewhere out of the way
      this.unfrozenBody.appendChild(iframe);
      this.iframe = iframe;
      setTimeout(() => {
        this.onColumnResize();
      });
    }
  }

  onColumnResize() {
    const tw = this.treeTable.el.nativeElement.querySelector('div.ui-treetable').offsetWidth;
    const tbls: NodeListOf<HTMLElement> = this.treeTable.el.nativeElement.querySelectorAll('table');
    tbls[0].style.setProperty('width', tw + 'px');
    tbls[1].style.setProperty('width', (this.iframe.offsetWidth - 1) + 'px');
    if (tbls.length === 3) {
      tbls[2].style.setProperty('width', tw + 'px');
    }
  }
}
