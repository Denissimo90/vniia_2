import {InjectionToken} from '@angular/core';

export let APP_ENV = new InjectionToken<string>('env');