import {AfterViewInit, Directive} from '@angular/core';
import {DataView} from 'primeng/dataview';

@Directive({
    selector: 'p-dataView'
  })
export class PDataViewDirective implements AfterViewInit {
    constructor(private view: DataView) {
      this.view.emptyMessage = 'Записи не найдены';
    }

    ngAfterViewInit(): void {
    }
}
