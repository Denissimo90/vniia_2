import {Injectable} from '@angular/core';
import {HttpEvent, HttpHandler, HttpInterceptor, HttpRequest} from '@angular/common/http';
import {ConfigurationService} from '../config/configuration.service';
import {Observable} from 'rxjs';

@Injectable()
export class ApiInterceptorService implements HttpInterceptor {
  constructor(private configService: ConfigurationService) {
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const isApiUrl = this.configService.config && !req.url.trim().toUpperCase().startsWith('HTTP')
      && (!!this.configService.config.offlineMode ||
        (!!this.configService.config.auth && !req.url.trim().toUpperCase().startsWith(this.configService.config.auth.toUpperCase())))
      && !req.url.trim().toUpperCase().startsWith('/API/');
    if (isApiUrl) {
      const url = this.configService.config.api.replace(/\/*$/, '') + '/' + req.url.replace(/^\/*/, '');
      return next.handle(req.clone({url: url}));
    } else {
      return next.handle(req);
    }
  }
}
