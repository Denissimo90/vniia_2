import {
  AfterContentInit,
  ContentChild,
  ContentChildren,
  Directive,
  EventEmitter,
  Input,
  Output,
  QueryList,
  TemplateRef
} from '@angular/core';
import {Cell} from './cell.directive';
import {
  CellClassParams,
  CellValueChangedEvent,
  ICellEditorParams,
  RowSpanParams,
  ValueFormatterParams,
  ValueGetterParams,
  ValueSetterParams
} from 'ag-grid-community';
import {ComponentSelectorResult} from 'ag-grid-community/dist/lib/components/framework/userComponentFactory';
import {GroupCellRendererParams} from 'ag-grid-community/dist/lib/rendering/cellRenderers/groupCellRenderer';

@Directive({
    selector: 'app-table column'
})
export class Column implements AfterContentInit {
  index = -1;
  @Input() field: string;

  private _header: string;
  @Input() get header(): string {
    return this._header;
  }
  set header(val: string) {
    if (this._header !== val) {
      this._header = val;
      this.headerChange.emit(val);
    }
  }
  @Output() headerChange: EventEmitter<string> = new EventEmitter();
  @Output() onGetColumnStyle: EventEmitter<any> = new EventEmitter();
  @Output() cellValueChanged: EventEmitter<CellValueChangedEvent> = new EventEmitter();

  @Input() filterMatchMode: string;
  @Input() textAlign: string;
  @Input() pinned: boolean | string = false;
  @Input() lockPinned = false;
  @Input() calcCellStyle: (cell: Cell) => any;
  @Input() filterAvailable = true;
  @Input() sortAvailable = true;
  @Input() tooltipField: string;
  @Input() headerTooltip: string;
  @Input() editable: boolean | ((params: any) => boolean);
  @Input() cellEditor: string;
  @Input() cellEditorParams: any;
  @Input() valueGetter: ((params: ValueGetterParams) => any) | string;
  @Input() valueFormatter: ((params: ValueFormatterParams) => void) | string;
  @Input() valueSetter: ((params: ValueSetterParams) => boolean) | string;
  @Input() children: Column[];
  @Input() cellEditorSelector: (params: ICellEditorParams) => ComponentSelectorResult;
  @Input() headerComponent: string;
  @Input() headerComponentParams: any;
  @Input() rowSpan: ((params: RowSpanParams) => any) | number;
  @Input() cellClassRules: object;
  @Input() customCellRenderer: ((params: RowSpanParams) => any) | any;
  @Input() customCellRendererStyle: ((params: CellClassParams) => any) | any;

  @Input() enableRowGroup: boolean;
  @Input() rowGroup: boolean;
  @Input() rowGroupIndex: number;
  @Input() enablePivot: boolean;
  @Input() enableValue: boolean;
  @Input() pivot: any;
  @Input() pivotIndex: number;
  @Input() aggFunc: any;
  @Input() isDisableSummaryRowCalculating = false;

  private _type: string;
  @Input() get type(): string {
    return this._type;
  }

  set type(val: string) {
    this._type = val;
    this.calcFilterOptions();
  }

  private _enum: any;
  @Input() get enum(): any {
    return this._enum;
  }
  set enum(val: any) {
    this._enum = val;
    this.calcFilterOptions();
  }

  _width: number;
  @Input() get width(): number {
    return this._width;
  }

  set width(width: number) {
    if (this._width != width) {
      this._width = width;
      this.widthChange.emit(this);
    }
  }


  _minWidth: number;
  @Input() get minWidth(): number {
    return this._minWidth;
  }

  set minWidth(minWidth: number) {
    if (this._minWidth != minWidth) {
      this._minWidth = minWidth;
      if (this.width < this._minWidth) {
        this.width = this._minWidth;
      }
    }
  }

  _maxWidth: number;
  @Input() get maxWidth(): number {
    return this._maxWidth;
  }

  set maxWidth(maxWidth: number) {
    if (this._maxWidth != maxWidth) {
      this._maxWidth = maxWidth;
      if (this.width > this._maxWidth) {
        this.width = this._maxWidth;
      }
    }
  }

  private _flex: number;
  @Input() get flex(): number {
    return this._flex;
  }
  set flex(flex: number) {
    this._flex = flex;
  }

  _available: boolean = true;
  @Input() get available(): boolean {
    return this._available;
  }

  set available(v: boolean) {
    if (this._available != v) {
      this._available = v;
      this.layoutChange.emit(this);
    }
  }

  _visible: boolean = true;
  @Input() get visible(): boolean {
    return this._visible;
  }

  set visible(v: boolean) {
    if (this._visible != v) {
      this._visible = v;
      this.layoutChange.emit(this);
    }
  }

  get frozen() {
    return this.pinned;
  }
  set frozen(frozen: boolean | string) {
    this.pinned = frozen;
  }

  @Output() layoutChange: EventEmitter<Column> = new EventEmitter();
  @Output() widthChange: EventEmitter<Column> = new EventEmitter();

  _filterOptions: any;

  get filterOptions() {
    return this._filterOptions;
  }

  @ContentChild('cell') cellTemplate: TemplateRef<any>;
  @ContentChildren(Column) cols: QueryList<Column>;

  ngAfterContentInit() {
    this.children = this.cols.toArray().filter(c => c != this);
  }

  private calcFilterOptions() {
    if (this.type == 'bool') {
      this._filterOptions = [
        {label: '', value: null},
        {label: 'да', value: true},
        {label: 'нет', value: false}
      ];
    } else {
      const options = [{label: '', value: null}];
      for (const val in this._enum) {
        options.push({label: this._enum[val], value: val});
      }
      this._filterOptions = options;
    }
  }

  static create(field: string, header: string, type: string = null): Column {
    const col: Column = new Column();
    col.field = field;
    col.header = header;
    col.type = type;
    return col;
  }

  @Input() set filterAvalible(val: boolean) {
    console.warn('Use column propery "filterAvailable" instead of "filterAvalible"!');
    this.filterAvailable = val;
  }
  get filterAvalible(): boolean {
    return this.filterAvailable;
  }

  @Input() set sortAvalible(val: boolean) {
    console.warn('Use column propery "sortAvailable" instead of "sortAvalible"!');
    this.sortAvailable = val;
  }
  get sortAvalible(): boolean {
    return this.sortAvailable;
  }
}


