import {Directive} from '@angular/core';
import {Spinner} from 'primeng/spinner';

@Directive({
  selector: 'p-spinner[min]'
})
export class SpinnerDirective {
  constructor(spinner: Spinner) {
    const parseValue = function(val) {
      let value: number;

      if (val.trim() === '') {
        value = null;
      }
      else {
        if (this.precision)
          value = parseFloat(val.replace(',', '.'));
        else
          value = parseInt(val, 10);

        if (!isNaN(value)) {
          if (this.max !== null && value > this.max) {
            value = this.max;
          }

          if (this.min !== null && value < this.min) {
            value = this.min;
          }
        }
        else {
          value = null;
        }
      }

      return value;
    };
    spinner.parseValue = parseValue.bind(spinner);
  }
}
