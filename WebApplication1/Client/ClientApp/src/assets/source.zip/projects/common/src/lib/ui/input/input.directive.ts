import {Directive, HostListener, Input, OnInit} from '@angular/core';
import {InputText} from 'primeng';

@Directive({
  selector: 'input [pInputText]'
})
export class InputDirective implements OnInit {
  @Input() autocomplete = false;
  @Input() emptyStringEqualsNull = true;

  constructor(private input: InputText) {
  }

  @HostListener('change', ['$event'])
  onChange(event) {
    if (this.emptyStringEqualsNull) {
      if (event.target.value === '') {
        this.input.ngModel.valueAccessor.writeValue(null);
        this.input.ngModel.viewToModelUpdate(null);
      }
    }
  }

  ngOnInit(): void {
    this.input.el.nativeElement.setAttribute('autocomplete', this.autocomplete ? '' : 'off');
  }
}
