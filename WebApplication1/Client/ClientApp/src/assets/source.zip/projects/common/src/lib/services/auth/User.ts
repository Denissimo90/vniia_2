export class User {

  private _roles: any;

  constructor(
    private clientId: string,
    public username: string,
    public name: string,
    public employeeId: string,
    public personId: number,
    public depnum: string,
    public description: string,
    public authorities: Array<any>
    ) {

    this._roles = {};
    if (this.authorities[this.clientId] && this.authorities[this.clientId]['roles']) {
      this._roles = { ...this.mapRole(this.authorities[this.clientId]['roles']) };
    }
    if (this.authorities['realm'] && this.authorities['realm']['roles']) {
      this._roles = { ...this._roles, ...this.mapRole(this.authorities['realm']['roles']) };
    }
  }

  public get roles(): any {
    return this._roles;
  }

  public get shortname(): string {
    return this.name || this.username;
  }

  private mapRole(roles: any[]) {
    return roles.reduce((result, cur) => {
      result[cur.replace(' ', '_').replace('-', '_')] = true;
      return result;
    }, {});
  }
}


