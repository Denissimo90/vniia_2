import {Component} from 'ag-grid-community';

export class LoadingCellRenderer extends Component {
  constructor() {
    super(`<div style="width: 100%; height: 100%; display: flex; align-items: center; justify-content: center">
            <div>
                <i class="fa fa-spinner fa-spin"></i>
            </div>
        </div>`);
  }
}
