import {AfterContentInit, AfterViewInit, Directive, Input} from '@angular/core';
import {AgGridColumn} from 'ag-grid-angular';
import {Column} from '../table/column';

@Directive({
  selector: 'ag-grid-column'
})
export class AgGridColumnDirective {
  @Input() col: Column;

  constructor(column: AgGridColumn) {
    const toColDef = column.toColDef.bind(column);
    column.toColDef = () => {
      const colDef = toColDef();
      colDef.col = this.col;
      return colDef;
    };
  }
}
