import {Component, ContentChild, forwardRef, Input, OnInit, TemplateRef, ViewChild} from '@angular/core';
import {ControlValueAccessor, NG_VALUE_ACCESSOR} from '@angular/forms';
import {LookupBaseComponent} from './lookup-base.componet';
import {Dialog} from 'primeng/dialog';

@Component({
  selector: 'app-lookup',
  templateUrl: 'lookup.component.html',
  styleUrls: ['lookup.component.css'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => LookupComponent),
      multi: true
    }
  ]
})
export class LookupComponent implements OnInit, ControlValueAccessor {
  value: any;
  disabled: boolean;
  onChange: any;
  onTouched: any;
  invalid = true;
  text: string;

  @Input() field: string;
  @Input() header: any;
  @Input() readonly: boolean;
  @Input() display: boolean;
  @Input() style: any;
  @Input() required = false;

  @ViewChild('input') input;
  @ViewChild('autoCompleteWrapper') autoCompleteWrapper;
  @ContentChild(TemplateRef) dialogContent: TemplateRef<any>;
  @ContentChild('lookupTable') lookupTable: TemplateRef<any>;
  @ContentChild('lookupAutoComplete') lookupAutoComplete: TemplateRef<any>;
  @ContentChild(LookupBaseComponent) lookupComponent: LookupBaseComponent;
  @ViewChild('dialog') dialog: Dialog;

  constructor() {
  }

  onresize(e) {
    if (this.dialog.maximized) {
      return;
    }
    setTimeout(() => {
      if (this.dialog.container) {
        this.dialog.container.style.left = 'unset';
        this.dialog.container.style.top = 'unset';
      }
    });
  }

  ngOnInit() {
  }

  writeValue(obj: any): void {
    this.value = obj;
    this.text = this.getText();
  }

  registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  setDisabledState?(isDisabled: boolean): void {
    this.disabled = isDisabled;
  }

  showForm() {
    this.display = true;
  }

  get selection(): any {
    return this.lookupComponent ? this.lookupComponent.selectedValue : null;
  }

  get formHeader(): any {
    return this.lookupComponent ? this.lookupComponent.header : null;
  }

  select() {
    this.value = this.lookupComponent.selectedValue;
    this.text = this.getText();
    this.onChange(this.value);
    this.onTouched();
    this.display = false;
  }

  onHide() {
    if (this.input) {
      setTimeout(() => this.input.focus());
    } else {
      this.autoCompleteWrapper.nativeElement.querySelector('input').focus();
    }
  }

  onDialogKeyDown(e) {
    if (e.key === 'Enter' && this.selection) {
      this.select();
      e.preventDefault();
      e.stopPropagation();
    }
  }

  private getText(): string {
    let textValue = this.value;
    if (this.field) {
      textValue = this.value ? this.field.split('.').reduce((object, index) => !!object && object[index], this.value) : null;
    }
    return textValue ? textValue.toString() : '';
  }
}
