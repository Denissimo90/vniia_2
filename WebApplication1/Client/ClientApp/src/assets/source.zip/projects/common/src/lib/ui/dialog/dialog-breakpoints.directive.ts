import {OnInit, HostListener, Directive, Input} from '@angular/core';
import {Dialog} from 'primeng/dialog';

@Directive({
  selector: 'p-dialog[breakpoints]'
})
export class DialogBreakpointsDirective implements OnInit  {
  private _breakpoints: string[];

  constructor(private dialog: Dialog) {
  }

  @Input() set breakpoints(breakpoints: string[]) {
    this._breakpoints = breakpoints;
    this.updateSize();
  }

  ngOnInit() {
    this.updateSize();
  }

  @HostListener('window:resize')
  onWindowResize() {
    this.updateSize();
  }

  private updateSize() {
    if (!this._breakpoints || !this._breakpoints.length) {
      return;
    }
    if (!this.dialog.style) {
      this.dialog.style = {};
    }
    let baseWidth = this._breakpoints[0];
    this.dialog.style.width = baseWidth;
    this.dialog.breakpoint = this.getPixelWidth(baseWidth);
    if (window.innerWidth < this.dialog.breakpoint) {
      this.dialog.style.width = '100%';
      this.dialog.style.left = '0px';
    } else {
      for (let width of this._breakpoints.slice(1)) {      
        if (window.innerWidth > this.getPixelWidth(width)) {
          this.dialog.style.width = width;
          break;
        }
      }
    }
    if (this.dialog.container) {
      this.dialog.container.style.left = 'unset';
      this.dialog.container.style.top = 'unset';
    }
  }

  private getPixelWidth(width: string) {
    let widthNum = Number.parseFloat(width);
    let pixelWidth = widthNum;
    if (width.indexOf('em')) {
      const fontSize = getComputedStyle(this.dialog.el.nativeElement).getPropertyValue('font-size');
      let fontSizeNum = Number.parseFloat(fontSize);
      if (fontSize.indexOf('pt') > 0) {
        fontSizeNum = fontSizeNum * 4 / 3;
      }
      pixelWidth = fontSizeNum * widthNum;
    }
    return pixelWidth;
  }
}