import {Directive, EventEmitter, Input, Output} from '@angular/core';
import {MenuItem} from 'primeng/api';

@Directive({
  selector: 'p-menu-item'
})
export class MenuItemDirective {
  item: MenuItem = { command: event => this.onCommand(event) };

  get label(): string { return this.item.label; }
  @Input() set label(val: string) { this.item.label = val; }

  get icon(): string { return this.item.icon; }
  @Input() set icon(val: string) { this.item.icon = val; }

  get url(): string { return this.item.url; }
  @Input() set url(val: string) { this.item.url = val; }

  get routerLink(): any { return this.item.routerLink; }
  @Input() set routerLink(val: any) { this.item.routerLink = val; }

  get queryParams(): { [k: string]: any; } { return this.item.queryParams; }
  @Input() set queryParams(val: { [k: string]: any; }) { this.item.queryParams = val; }

  get expanded(): boolean { return this.item.expanded; }
  @Input() set expanded(val: boolean) { this.item.expanded = val; }

  get disabled(): boolean { return this.item.disabled; }
  @Input() set disabled(val: boolean) { this.item.disabled = val; }

  get visible(): boolean { return this.item.visible; }
  @Input() set visible(val: boolean) { this.item.visible = val; }

  get target(): string { return this.item.target; }
  @Input() set target(val: string) { this.item.target = val; }

  get routerLinkActiveOptions(): any { return this.item.routerLinkActiveOptions; }
  @Input() set routerLinkActiveOptions(val: any) { this.item.routerLinkActiveOptions = val; }

  get separator(): boolean { return this.item.separator; }
  @Input() set separator(val: boolean) { this.item.separator = val; }

  get badge(): string { return this.item.badge; }
  @Input() set badge(val: string) { this.item.badge = val; }

  get badgeStyleClass(): string { return this.item.badgeStyleClass; }
  @Input() set badgeStyleClass(val: string) { this.item.badgeStyleClass = val; }

  get style(): any { return this.item.style; }
  @Input() set style(val: any) { this.item.style = val; }

  get styleClass(): string { return this.item.styleClass; }
  @Input() set styleClass(val: string) { this.item.styleClass = val; }

  get title(): string { return this.item.title; }
  @Input() set title(val: string) { this.item.title = val; }

  get id(): string { return this.item.id; }
  @Input() set id(val: string) { this.item.id = val; }

  get automationId(): any { return this.item.automationId; }
  @Input() set automationId(val: any) { this.item.automationId = val; }

  @Output() command = new EventEmitter<any>();

  onCommand(event) {
    this.command.emit(event);
  };
}
