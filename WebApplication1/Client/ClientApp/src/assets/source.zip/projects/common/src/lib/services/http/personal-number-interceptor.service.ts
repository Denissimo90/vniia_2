import {Injectable, Injector} from '@angular/core';
import {HttpEvent, HttpHandler, HttpInterceptor, HttpRequest} from '@angular/common/http';
import {Observable} from 'rxjs';
import {ConfigurationService} from '../config/configuration.service';
import {UserService} from '../auth/user.service';

@Injectable()
export class PersonalNumberInterceptorService implements HttpInterceptor {

  constructor(private injector: Injector) {
  }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const configService: ConfigurationService = this.injector.get(ConfigurationService);
    const userService: UserService = this.injector.get(UserService);
    const authUrl = configService.config ? configService.config.auth : '';
    if (request.url.indexOf(authUrl || '') === -1 && userService.personalNumber) {
      request = request.clone({ setHeaders: { 'User-Personal-Number':  userService.personalNumber }});
    }
    return next.handle(request);
  }
}
