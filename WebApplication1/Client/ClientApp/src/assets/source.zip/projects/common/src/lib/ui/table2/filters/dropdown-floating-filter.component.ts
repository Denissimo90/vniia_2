import {Component} from '@angular/core';
import {IFloatingFilter, IFloatingFilterParams, TextFilterModel} from 'ag-grid-community';
import {AgFrameworkComponent} from 'ag-grid-angular';
import {DropdownFilterComponent} from './dropdown-filter.component';
import {localeColumnFilterModes, columnTypeFilterMatchModes, getFilterModesTitle} from '../table2.component';
import {FilterMatchModes} from 'ag-grid-community/dist/lib/main';

export interface DropdownFloatingFilterParams extends IFloatingFilterParams {
  type?: string;
  enum: any[];
}

@Component({
  template: `
    <div style="display: flex; height: 100%">
      <div style="flex: 1; min-width: 0; overflow: hidden">
        <p-dropdown
          [style]="{height: '100%', 'width': '100%', border: 0}"
          appendTo="body"
          [options]="params.enum"
          optionLabel="label"
          [(ngModel)]="value"
          (ngModelChange)="valueChanged()"
          [disabled]="type.key == 'isNull' || type.key == 'isNotNull'">
        </p-dropdown>
      </div>
      <button
        class="filter-button"
        (click)="filterMenu.toggle($event)"
      >
        {{ type.sign || types['equails'].sign }}
      </button>
      <p-menu #filterMenu
              [popup]="true"
              appendTo="body"
      >
        <p-menu-item *ngFor="let type of this.types"
                     [label]="getFilterModesTitle(type)"
                     (command)="applyFilterMode(type.key)"
        ></p-menu-item>
      </p-menu>
    </div>`,
  styles: [`
    .filter-button {
      padding: 1px;
      font-size: 10.5px;
      width: 38px;
      white-space: normal;
      word-wrap: break-word;
      line-height: 11px;
      border: 0;
      border-left: 1px solid #c8c8c8;
      background-color: transparent;
      color: #3d60a1;
    }

    .filter-button:hover {
      background-color: #83b9ff;
      cursor: pointer;
    }
  `]
})
export class DropdownFloatingFilterComponent
  implements IFloatingFilter, AgFrameworkComponent<DropdownFloatingFilterParams> {
  params: DropdownFloatingFilterParams;
  isEnum = false;
  public currentValue: any;
  value: any;
  type: { key: FilterMatchModes, title: string, sign: string };
  types: { key: FilterMatchModes, title: string, sign: string }[];
  getFilterModesTitle = getFilterModesTitle;

  agInit(params: DropdownFloatingFilterParams): void {
    this.params = params;
    this.currentValue = null;
    this.value = null;
    this.type = {key: 'equals', ...localeColumnFilterModes.equals};
    const colType = params.column.getColDef().type as string;
    this.types = [];
    if (colType) {
      const matchTypes: FilterMatchModes[] = columnTypeFilterMatchModes[colType];
      this.types = matchTypes.map((type: FilterMatchModes) => {
        return {key: type, title: localeColumnFilterModes[type].title, sign: localeColumnFilterModes[type].sign};
      });
    }
  }

  isFilterActive(): boolean {
    return this.value != null;
  }

  valueChanged() {
    if (this.value != this.currentValue) {
      this.apply();
    }
  }

  applyFilterMode(type) {
    const oldType = {...this.type};
    const newType = this.types.find(findType => findType.key === type);
    this.type = newType;
    const newWithValue = newType.key != 'isNull' && newType.key != 'isNotNull';
    const oldWithValue = oldType.key != 'isNull' && oldType.key != 'isNotNull';
    if (!newWithValue) {
      this.value = '-';
      this.apply();
    } else if (!oldWithValue) {
      this.value = '';
      this.apply();
    } else if (this.value != '' || this.value != this.currentValue) {
      this.apply();
    }
  }

  apply() {
    this.currentValue = this.value;
    this.params.parentFilterInstance(filterInstance => {
      if (filterInstance) {
        const simpleFilter = (<any>filterInstance) as DropdownFilterComponent;
        simpleFilter.onFloatingFilterChanged(this.type.key || 'equals', this.currentValue?.value);
      }
    });
  }

  onParentModelChanged(parentModel: TextFilterModel): void {
    if (!parentModel) {
      this.value = null;
      this.currentValue = null;
    } else {
      this.value = this.params.enum.find(e => e.value === parentModel.filter);
      this.currentValue = parentModel.filter;
      this.type = this.types.find(findType => findType.key === parentModel.type);
    }
  }
}
