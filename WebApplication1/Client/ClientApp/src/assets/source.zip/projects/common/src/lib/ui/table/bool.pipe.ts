import {Inject, LOCALE_ID, Pipe, PipeTransform} from '@angular/core';

@Pipe({
    name: 'bool'
})
export class BoolPipe implements PipeTransform {
  constructor(@Inject(LOCALE_ID) private _local: string) {
  }

  transform(value: any, args?: any): any {
    return value == null || value == undefined ? "" : value ? "&#xF00C;" : "&#xF00D;";
  }

}
