export abstract class UriHelper {
  static removeRedundantSlashes(uri: string) {
    return uri.replace(new RegExp('([^:]\/)\/+'), "$1");
  }
}