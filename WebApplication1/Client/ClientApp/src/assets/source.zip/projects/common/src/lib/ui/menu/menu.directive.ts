import {AfterContentInit, ContentChildren, Directive, QueryList} from '@angular/core';
import {MenuItemDirective} from './menu-item.directive';
import {Menu} from 'primeng/menu';

@Directive({
  selector: 'p-menu'
})
export class MenuDirective implements AfterContentInit {
  @ContentChildren(MenuItemDirective) menuItems: QueryList<MenuItemDirective>;

  constructor(private menu: Menu) {
  }

  ngAfterContentInit() {
    this.menu.model = this.menuItems.toArray().map(m => m.item);
    this.menuItems.changes.subscribe(ch => {
      this.menu.model = this.menuItems.toArray().map(m => m.item);
    });
  }
}
