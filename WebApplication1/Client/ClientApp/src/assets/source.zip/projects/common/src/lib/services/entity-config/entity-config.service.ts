import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {AuthService} from '../auth/auth.service';
import {EventBusService} from '../events/eventbus.service';
import {FieldConfig} from '../../ui/entity/config/FieldConfig';
import {TableExtensionField} from '../../ui/entity/extension/TableExtensionField';
import {EntityFieldConfig} from '../../ui/entity/config/EntityFieldConfig';
import {BaseService} from '../http/base.service';
import {ConfigurationService} from '../config/configuration.service';

@Injectable({providedIn: 'root'})
export class EntityConfigService extends BaseService {
  private extensions: {[key: string]: TableExtensionField[]};
  private configs: {[key: string]: EntityFieldConfig[]};

  constructor(
    protected httpClient: HttpClient,
    protected authService: AuthService,
    protected bus: EventBusService,
    protected configurationService: ConfigurationService) {
    super(httpClient, authService, bus);
  }

  async init() {
      this.extensions = !!this.configurationService.config.offlineMode ? {} : await this.getExtensions();
      this.configs = !!this.configurationService.config.offlineMode ? {} : await this.getConfigs();
  }

  // Загрузка настроек сущности
  getEntityConfig(entityName: string, domain: any): {[key: string]: FieldConfig} {
    const fieldConfigs: {[key: string]: FieldConfig} = {};
    const fields = this.configs[entityName];

    if (fields) {
      fields.forEach(f => {
        fieldConfigs[f.name] = {
          name: f.name,
          required: new Function('return ' + f.required).bind(domain),
          visible: new Function('return ' + f.visible).bind(domain),
          readonly: new Function('return ' + (f.readonly || 'false')).bind(domain),
        };
      });
    }

    return fieldConfigs;
  }

  getEntityExtension(entityName: string): TableExtensionField[] {
     return this.extensions[entityName].map(e => new TableExtensionField(e));
  }

  async getExtensions(): Promise<{[key: string]: TableExtensionField[]}> {
    return this.httpClient
      .get<{[key: string]: TableExtensionField[]}>('entities/extensions', this.httpOptions)
      .toPromise();
  }

  async getConfigs(): Promise<{[key: string]: EntityFieldConfig[]}> {
    return this.httpClient
      .get<{[key: string]: EntityFieldConfig[]}>('entities/configs', this.httpOptions)
      .toPromise();
  }
}
