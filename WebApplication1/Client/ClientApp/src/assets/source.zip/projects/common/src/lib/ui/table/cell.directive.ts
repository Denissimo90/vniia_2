import {Directive, Inject, Input, LOCALE_ID} from '@angular/core';
import {DatePipe} from '@angular/common';
import {TableComponent} from './table.component';
import {Column} from './column';
import {SumPipe} from './sum.pipe';

@Directive({
  selector: 'app-table td[cellContext]',
  host: {
    '[style.textAlign]': 'col.textAlign ? col.textAlign : null',
    '[class.cell-no-color]': 'isSelected',
    '[style.height]': '"1.25em"',
    '[style.overflow]': '"hidden"',
    '[style.white-space]': '"nowrap"',
    '[style.text-overflow]': '"ellipsis"'
  },
  exportAs: 'cell'
})
export class Cell {
  constructor(
    private table: TableComponent,
    @Inject(LOCALE_ID) private local: string) {
  }

  @Input() cellContext: { col: Column, rowData: any, rowIndex: number, isSelected: boolean};

  get col(): Column {
    return this.cellContext.col;
  }

  get rowData(): any {
    return this.cellContext.rowData;
  }

  get rowIndex(): number {
    return this.cellContext.rowIndex;
  }

  get value(): any {
    const nestedProps: string[] = this.col.field.split('.');
    let value: any = this.rowData;
    for (const prop of nestedProps) {
        value = value[prop];
        if (value == null) {
          value = ''
        }
    }
    return value;
  }

  get isSelected(): boolean {
    return this.cellContext.isSelected;
  }

  get text(): string {
    const value = this.value;
    switch (this.col.type) {
      case 'bool': return null;
      case 'sum': return new SumPipe(this.local).transform(value);
      case 'date': return new DatePipe(this.local).transform(value, 'dd.MM.yyyy');
      case 'dateTime': return new DatePipe(this.local).transform(value, 'dd.MM.yyyy HH:mm:ss');
      case 'dateYear': return new DatePipe(this.local).transform(value, 'yyyy');
      case 'enum': {
        return value ? (this.col.enum && this.col.enum[value] ? this.col.enum[value] : ("[" + value + "]")) : ""
      }
      case 'enum_bool': {
        return value != null ? (this.col.enum && this.col.enum[value] ? this.col.enum[value] : ("[" + value + "]")) : ""
      }
    }
    return value == null ? null : value.toString();
  }

  get icon(): string {
    if (this.col.type == 'bool') {
      const value = this.value;
      return value == null ? "" : value ? "&#xF00C;" : "&#xF00D;"
    }
    return null;
  }
}
