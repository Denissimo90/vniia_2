import {Injectable} from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {BaseService} from '../http/base.service';
import {AuthService} from '../auth/auth.service';
import {EventBusService} from '../events/eventbus.service';
import {Dictionary} from '../../ui/dictionary/Dictionary';
import {PageResponse} from '../PageResponse';
import {PageQuery} from '../PageQuery';

@Injectable({providedIn: 'root'})
export class DictionaryService extends BaseService {
  constructor(
    protected httpClient: HttpClient,
    protected authService: AuthService,
    protected bus: EventBusService) {
    super(httpClient, authService, bus);
  }

  // Поиск справочника по конкретному коду
  async searchLocalDictionary(pageQuery: PageQuery, key: string, url?: string): Promise<PageResponse<Dictionary>> {
    const dictionary = await this.httpClient.post<PageResponse<Dictionary>>(url || `/local-dictionaries/${key}/items/search`,
      pageQuery, {}
    ).toPromise();
    console.log('fetched dictionary');
    return dictionary;
  }

  async searchDictionary(pageQuery: PageQuery, key: string,
                         filter: string, filterParams: { [key: string]: string },
                         url?: string): Promise<PageResponse<Dictionary>> {
    let httpParams = new HttpParams();
    if (filter) {
      httpParams = httpParams.append('filter', filter);
      if (filterParams) {
        for (let key of Object.keys(filterParams)) {
          if (filterParams[key]) {
            httpParams = httpParams.append(key, filterParams[key]);
          }
        }
      }
    }
    const dictionary = await this.httpClient.post<PageResponse<Dictionary>>(url || `/dictionaries/${key}/items/search`,
      pageQuery,
      {
        params: httpParams
      }
    ).toPromise();
    console.log('fetched dictionary');
    return dictionary;
  }

  async getMetaInf(key: string): Promise<any> {
    return await this.httpClient.get<any>(`/dictionaries/${key}/metainf`).toPromise();
  }

  async getViewValue(id: number, key: string): Promise<any> {
    return await this.httpClient.get<any>(`/dictionaries/views/${key}/${id}`).toPromise();
  }
}
