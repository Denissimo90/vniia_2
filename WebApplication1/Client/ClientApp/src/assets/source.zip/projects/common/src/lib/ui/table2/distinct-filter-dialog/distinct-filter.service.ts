import {Column as AgColumn, GridApi} from 'ag-grid-community';

export abstract class DistinctFilterService {
  get isEnabled(): boolean { return true; }
  abstract showFilterDialog(api: GridApi, agColumn: AgColumn);
}
