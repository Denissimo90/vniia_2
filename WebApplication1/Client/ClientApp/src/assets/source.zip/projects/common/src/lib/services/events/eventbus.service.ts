export interface Event {
  type: string;
}

/**
 * An event handler.
 */
export type EventHandler<T extends Event> = (event: T) => void;

/**
 * Registration objects returned when an event handler is added,
 * used to deregister.
 */
export interface HandlerRegistration {
  unregister(): void;
}

export class EventBusService {

  id: number;

  constructor() {
    this.id = Math.random();
  }

  private handlers = new Map<string, EventHandler<Event>[]>();

  on<T extends Event>(event: T, handler: EventHandler<T>): HandlerRegistration {

    let h = this.handlers.get(event.type);
    if (h == null) {
      h = [];
      this.handlers.set(event.type, h);
    }

    h.push(handler);

    return {
      unregister: () => {
        const lh = this.handlers.get(event.type) || [];
        const index = lh.indexOf(handler);
        if (index === -1) { throw new Error('Event handler not registered.'); }
        lh.splice(index, 1);
        if (lh.length === 0) {
          this.handlers.delete(event.type);
        }
      }
    };
  }

  emit(event: Event) {
    const handlers = this.handlers.get(event.type) || [];
    handlers.forEach(h => {
      h(event);
    });
  }
}
