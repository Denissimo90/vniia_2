import {AbstractControl, AsyncValidatorFn, ValidationErrors} from '@angular/forms';

export function debounceValidation(
  control: AbstractControl, validatorFn: AsyncValidatorFn,
  options: {debounceTime?: number, resolveOnEmpty?: boolean} = null): Promise<ValidationErrors | null> {
  clearTimeout((<any>control).$debounceValidationIntervalId);
  return new Promise((resolve, reject) => {
    if (!control.value && (options?.resolveOnEmpty ?? true)) {
      resolve(null);
    }
    (<any>control).$debounceValidationIntervalId = setTimeout(async () => {
      try {
        if (!control.value && (options?.resolveOnEmpty ?? true)) {
          resolve(null);
        } else {
          resolve(validatorFn(control));
        }
      } catch (e) {
        reject(e);
        throw e;
      }
    }, options?.debounceTime ?? 500);
  });
}
