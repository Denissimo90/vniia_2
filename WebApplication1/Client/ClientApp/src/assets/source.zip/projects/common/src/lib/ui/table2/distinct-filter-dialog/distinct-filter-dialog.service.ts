import {Injectable} from '@angular/core';
import {DialogService} from '../../dialog/dialog.service';
import {DataSource} from '../table2.component';
import {DistinctFilterDialogComponent} from './distinct-filter-dialog.component';
import {Column as AgColumn, GridApi, IServerSideGetRowsParams} from 'ag-grid-community';
import {DistinctFilterService} from './distinct-filter.service';

@Injectable()
export class DistinctFilterDialogService extends DistinctFilterService {
  constructor(private dialogService: DialogService) {
    super();
  }

  showFilterDialog(api: GridApi, agColumn: AgColumn) {
    const field = agColumn.getColDef().field;
    const dialog = this.dialogService.createDialog(DistinctFilterDialogComponent);
    const ds = <DataSource>(<any>api.getModel()).datasource;

    const filterComponent = api.getFilterInstance(agColumn.getColId());
    let initFilter = null;
    if (filterComponent.getModel() && filterComponent.getModel().type == 'in') {
      initFilter = filterComponent.getModel().filter;
    }
    dialog.init(
      agColumn.getColDef().col,
      (e: IServerSideGetRowsParams) => {
        const clone = {...api.getFilterModel()};
        delete clone[field];
        e.request.filterModel = {...clone, ...e.request.filterModel};
        ds.getRows(e);
      },
      initFilter
    );
    dialog.result.subscribe(values => {
      const filterComponent2 = api.getFilterInstance(agColumn.getColId());
      filterComponent2.setModel({
        type: 'in',
        filter: values.join(',')
      });
      api.onFilterChanged();
    });
  }
}
