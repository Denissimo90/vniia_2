import {Directive, DoCheck, EventEmitter, Input, KeyValueDiffer, KeyValueDiffers} from '@angular/core';
import {FieldConfig} from './FieldConfig';
import {EntityConfigService} from '../../../services/entity-config/entity-config.service';

@Directive({
  selector: 'form[appEntityConfigName], form[appEntityConfig]'
})
export class EntityConfigDirective implements DoCheck {
  private _fieldConfigs: {[key: string]: FieldConfig} = {};
  private configName: string;
  private entity: any;
  private differ: KeyValueDiffer<string, any>;
  private differ2: KeyValueDiffer<string, any>;

  constructor(private entityConfigService: EntityConfigService,
    private keyValueDiffers: KeyValueDiffers) { }

  get fieldConfigs(): {[key: string]: FieldConfig} {
    return this._fieldConfigs;
  }

  @Input() set appEntityConfigName(configName: any) {
    this.configName = configName;
    this.loadConfig();
  }

  @Input() set appEntityConfig(config: any) {
    this._fieldConfigs = config;
  }

  get appEntity(): any {
    return this.entity;
  }

  @Input() set appEntity(entity: any) {
    this.entity = entity;
    this.differ = this.keyValueDiffers.find(this.entity).create();
    this.differ2 = this.keyValueDiffers.find(this.entity.extension).create();
    if (this.configName) {
      this.loadConfig();
    }
    setTimeout(() => {
      this.entityChanged.emit(this.entity);
    });
  }

  entityChanged = new EventEmitter<any>();

  ngDoCheck(): void {
    if (this.differ) {
       if (this.differ.diff(this.entity) || this.differ2.diff(this.entity.extension)) {
        this.entityChanged.emit(this.entity);
       }
    }
  }

  private loadConfig() {
    this._fieldConfigs = this.entityConfigService.getEntityConfig(this.configName, this.entity);
  }
}
