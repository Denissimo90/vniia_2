import {Component, EventEmitter, Output} from '@angular/core';
import {IHeaderParams} from 'ag-grid-community';
import {IHeaderAngularComp} from 'ag-grid-angular';

@Component({
  template: `
    <div style="width: 100%; height: 100%; text-align: center">
      <p-checkbox [(ngModel)]="isChecked" binary="true" (onChange)="onChange($event)"
                  [pTooltip]="isChecked ? 'Снять все отметки' : 'Отметить все записи'">
      </p-checkbox>
    </div>`
})
export class CheckboxHeaderComponent implements IHeaderAngularComp {
  params: IHeaderParams;
  isChecked = false;
  colId: string;
  type;

  @Output() checkboxClick = new EventEmitter();

  agInit(params: IHeaderParams): void {
    this.params = params;
    this.colId = params.column.getColId();
    this.type = params.column.getColDef().type;
  }

  onChange(value) {
    if (this.type !== 'bool') {
      console.warn(`Column ${this.colId} must be bool`);
    } else {
      this.params.api.forEachNodeAfterFilterAndSort(node => {
        node.data[this.colId] = value;
        node.setData(node.data);
      });
    }
  }
}
