import {Directive, DoCheck, Input, OnDestroy, OnInit, TemplateRef, ViewContainerRef} from '@angular/core';
import {NgForm, ValidatorFn, Validators} from '@angular/forms';
import {Subscription} from 'rxjs';
import {EntityConfigDirective} from '../config/entity-config.directive';

@Directive({
  selector: '[appFieldConfig]'
})
export class FieldConfigDirective implements OnInit, OnDestroy, DoCheck {
  private visible = false;
  private required = false;
  private readOnly = false;
  private fieldName: string;
  private valuesChangeSubscription: Subscription;
  private validator: ValidatorFn;
  private changed = false;
  private label: HTMLLabelElement;

  constructor(
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
    private ngForm: NgForm,
    private entityConfigDirective: EntityConfigDirective
  ) { }

  @Input() set appFieldConfig(fieldName: string) {
    this.fieldName = fieldName;
  }

  ngOnInit() {
    if (this.entityConfigDirective) {
      this.valuesChangeSubscription = this.entityConfigDirective.entityChanged.subscribe(() => {
        this.update();
      });
    }
    this.update();
  }

  ngOnDestroy() {
    if (this.valuesChangeSubscription) {
      this.valuesChangeSubscription.unsubscribe();
    }
  }

  ngDoCheck() {
    if (this.changed) {
      this.update();
    }
  }

  update() {
    const fieldConfig = this.entityConfigDirective
      ? this.entityConfigDirective.fieldConfigs[this.fieldName]
      : null;


    let visible;
    try {
      visible = !fieldConfig || this.bindEntity(fieldConfig.visible)();
    } catch (e) {
      visible = false;
      console.log('Entity-config visible expression error = ' + e);
    }
    if (this.visible !== visible) {
      if (this.visible) {
        this.visible = false;
        this.required = false;
        this.validator = null;
        this.label = null;
        this.viewContainer.clear();
      } else {
        this.visible = true;
        const ref = this.viewContainer.createEmbeddedView(this.templateRef);
        const node = <HTMLElement>ref.rootNodes[0];
        const labels = node.getElementsByTagName('label');
        if (labels && labels.length > 0) {
          this.label = <HTMLLabelElement>labels[0];
        }
      }
    }

    setTimeout(() => {
      const control = this.visible && fieldConfig && this.ngForm.controls[fieldConfig.name];
      if (control) {
        if (!this.validator) {
          this.validator = this.bindEntity(control.validator || (_ => null));
        }

        let required: boolean;
        try {
          required = this.bindEntity(fieldConfig.required)();
        } catch (e) {
          required = false;
          console.log('Entity-config required expression error = ' + e);
        }

        let changed = false;

        if (this.required !== required) {
          if (this.required) {
            this.required = false;
            control.clearValidators();
            if (this.label) {
              this.label.classList.remove('required');
            }
          } else {
            this.required = true;
            control.setValidators([this.validator, Validators.required]);
            if (this.label) {
              this.label.classList.add('required');
            }
          }
          changed = true;
        }

        let readOnly: boolean;
        try {
          readOnly = fieldConfig.readonly();
        } catch (e) {
          readOnly = false;
          console.log('Entity-config readonly expression error = ' + e);
        }

        if (this.readOnly != readOnly) {
          if (readOnly) {
            control.disable({emitEvent: false});
          } else {
            control.enable({emitEvent: false});
          }
          this.readOnly = readOnly;
          changed = true;
        }

        if (changed) {
          control.updateValueAndValidity();
        }
      }
    });
  }

  private bindEntity(func: Function): any {
    if (this.entityConfigDirective && this.entityConfigDirective.appEntity) {
      return func.bind({...this.entityConfigDirective.appEntity.extension, ...this.entityConfigDirective.appEntity});
    }
    return func;
  }
}
