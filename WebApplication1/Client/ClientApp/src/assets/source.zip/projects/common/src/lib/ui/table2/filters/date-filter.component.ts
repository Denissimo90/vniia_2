import {AgFrameworkComponent, IFilterAngularComp} from 'ag-grid-angular';
import {IDoesFilterPassParams, IFilterParams} from 'ag-grid-community';
import {Component, Inject, LOCALE_ID} from '@angular/core';
import {FilterMatchModes} from 'ag-grid-community/dist/lib/main';

export interface IDateFilterParams extends IFilterParams {
  type?: FilterMatchModes;
}

@Component({template: ``})

export class DateFilterComponent
  implements IFilterAngularComp, AgFrameworkComponent<IDateFilterParams> {

  constructor(@Inject(LOCALE_ID) private local: string) {
  }

  calendarValue: Date | Date[];
  params: IDateFilterParams;

  agInit(params: IDateFilterParams): void {
    this.params = params;
  }

  doesFilterPass(params: IDoesFilterPassParams): boolean {
    const nodeDateUtc = ((<any>this.params).valueGetter(params.node) as Date)?.valueOf();
    if (!nodeDateUtc) {
      return false;
    }
    switch (this.params.type) {
      case 'gt': {
        return nodeDateUtc > (this.calendarValue as Date).valueOf();
      }
      case 'goe': {
        return nodeDateUtc >= (this.calendarValue as Date).valueOf();
      }
      case 'lt': {
        return nodeDateUtc < (this.calendarValue as Date).valueOf();
      }
      case 'loe': {
        return nodeDateUtc <= (this.calendarValue as Date).valueOf();
      }
      case 'between': {
        return nodeDateUtc >= this.calendarValue[0].valueOf() && (nodeDateUtc <= (this.calendarValue[1]?.valueOf() || nodeDateUtc));
      }
      default: {
        return nodeDateUtc === (this.calendarValue as Date).valueOf();
      }
    }
  }

  getModel(): any {
    if (!this.calendarValue) {
      return null;
    }
    if (this.calendarValue instanceof Array) {
      if (this.params.type === 'between') {
        return {
          filter: this.calendarValue.map(date => {
            if (date === null) {
              return null;
            }
            return date.toJSON();
          }).join(','),
          type: this.params.type
        };
      }
    } else {
      return {filter: this.calendarValue.toJSON(), type: this.params.type};
    }
  }

  isFilterActive(): boolean {
    return !!this.calendarValue;
  }

  setModel(model: any): void {
    if (!model) {
      this.calendarValue = null;
    } else {
      this.params.type = model.type;
      this.calendarValue = model.filter;
    }
  }


  onFloatingFilterChanged(type: FilterMatchModes, calendarValue: Date | Date[]) {
    this.calendarValue = calendarValue;
    this.params.type = type;
    this.params.filterChangedCallback();
  }

}
