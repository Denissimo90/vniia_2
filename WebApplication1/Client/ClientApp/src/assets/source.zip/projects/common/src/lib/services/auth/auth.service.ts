import {Injectable} from '@angular/core';
import {Location} from '@angular/common';
import {AuthConfig, JwksValidationHandler, OAuthService, OAuthStorage} from 'angular-oauth2-oidc';
import {OAuthEvent} from 'angular-oauth2-oidc/events';
import {User} from './User';
import {AuthEventbusEvent} from '../events/auth.eventbus.event';
import {EventBusService} from '../events/eventbus.service';
import {JwtHelperService} from '@auth0/angular-jwt';
import {ConfigurationService} from '../config/configuration.service';
import {LoggerConfig, NGXLogger} from 'ngx-logger';

@Injectable()
export class AuthService {
  private _user: User;
  private storage: OAuthStorage;

  constructor(private oauthService: OAuthService,
              private configurationService: ConfigurationService,
              protected bus: EventBusService,
              private location: Location,
              private _logger: NGXLogger) {
  }

  public get logger(): any {
    return !!this._logger ? this._logger : console;
  }

  public async init(): Promise<void> {
    if (!this.configurationService.config.auth) {
      return;
    }

    // https://stackoverflow.com/questions/50810424/typeerror-cannot-read-property-noncestateseparator
    // we can't use config values individually, only with this.oauthService.configure
    // or config will be null

    const autoConfig = this.getAutoConfig(this.configurationService, this.location);

    this.oauthService.configure(autoConfig);
    this.oauthService.tokenValidationHandler = new JwksValidationHandler();

    this.storage = this.getStorage(autoConfig);

    this.oauthService.setStorage(this.storage);

    this.oauthService.events.subscribe(({type}: OAuthEvent) => {
      if (type === 'token_received') {
        this.bus.emit(new AuthEventbusEvent(AuthEventbusEvent.TYPE_AUTH_SERVICE_ON_TOKEN_RECIVED));
      }
    });

    if (!!this.storage) {
      this.storage.removeItem('access_token');

    }
    this.initLogger();
    try {
      await this.oauthService.loadDiscoveryDocumentAndTryLogin();
      if (this.oauthService.getAccessToken()) {
        this.readToken();
        this.logger.log('Login to ' + this.configurationService.config.clientId + ' user: ', this.user);
      } else {
        try {
          await this.oauthService.silentRefresh();
        } catch (e) {
          // user is not logged-in, do nothing
        }
        if (this.oauthService.getAccessToken()) {
          this.readToken();
          this.logger.log('Login to ' + this.configurationService.config.clientId + ' user: ', this.user);
        }
      }
    } catch (e) {
      this.logger.error(e);
      this.logout();
      return new Promise<void>(r => setTimeout(r, 1000)); // wait for redirect
    }
  }

  getAutoConfig(configurationService: ConfigurationService, location: Location): AuthConfig {
    const autoConfig = new AuthConfig();
    autoConfig.requireHttps = false;
    if (!!configurationService.config?.auth && configurationService.config.auth.toUpperCase().startsWith('HTTP')) {
      autoConfig.issuer = configurationService.config.auth;
    } else {
      autoConfig.issuer = window.location.origin + (configurationService.config?.auth || '');
    }
    autoConfig.clientId = configurationService.config.clientId;
    autoConfig.oidc = true;
    autoConfig.requestAccessToken = true;
    autoConfig.silentRefreshRedirectUri = window.location.origin + location.prepareExternalUrl('/assets/silent-refresh.html');
    autoConfig.silentRefreshTimeout = 2000;
    return autoConfig;
  }

  getStorage(autoConfig: any) {
    return {
      getItem: (key: string) => localStorage.getItem(autoConfig.clientId + '-' + key),
      removeItem: (key: string) => localStorage.removeItem(autoConfig.clientId + '-' + key),
      setItem: (key: string, data: string) => localStorage.setItem(autoConfig.clientId + '-' + key, data)
    };

  }

  initLogger() {
    const loggingConfig = new LoggerConfig();
    loggingConfig.serverLoggingUrl = this.configurationService.config.api + this.configurationService.config.serverLoggingUrl;
    loggingConfig.serverLogLevel = this.configurationService.config.serverLogLevel;
    loggingConfig.level = this.configurationService.config.logLevel;
    this._logger.updateConfig(loggingConfig);
  }

  async login(tryRefreshToken: boolean = true, redirectUri?: string): Promise<boolean> {
    if (!this.storage) {
      this.storage = this.getStorage(this.getAutoConfig(this.configurationService, this.location));
    }
    this.storage.removeItem('access_token');
    let tokenRefreshed = false;
    if (tryRefreshToken) {
      try {
        this.logger.trace('Trying silent refresh');
        await this.oauthService.silentRefresh();
        this.readToken();
        tokenRefreshed = true;
        this.logger.trace('Token refreshed');
      } catch (e) {
        this.logger.trace(e);
      }
    }
    if (tokenRefreshed) {
      return true;
    }
    this.oauthService.redirectUri = redirectUri || window.location.href;
    this.oauthService.initImplicitFlow();
    return new Promise<boolean>(r => setTimeout(r, 1000)); // wait for redirect
  }

  private readToken() {
    const token = new JwtHelperService().decodeToken(this.oauthService.getAccessToken());
    const clientId = this.configurationService.config.clientId;
    const authorities = {...token['resource_access'], realm: token.realm_access};

    this._user = new User(
      clientId,
      token['preferred_username'],
      token['name'],
      token['employee_id'],
      token['person_id'],
      token['department'],
      token['description'],
      authorities
    );

    this.bus.emit(new AuthEventbusEvent(AuthEventbusEvent.TYPE_AUTH_SERVICE_ON_TOKEN_READ));
  }

  getAccessToken() {
    return this.oauthService.getAccessToken();
  }

  get user(): User {
    return this._user;
  }

  isLoggedIn() {
    return this.oauthService.getAccessToken() != null;
  }

  async logout(postLogoutRedirectUri?: string) {
    this.oauthService.postLogoutRedirectUri = postLogoutRedirectUri
      || (window.location.origin + this.location.prepareExternalUrl('/'));
    this.oauthService.logOut();
  }
}
