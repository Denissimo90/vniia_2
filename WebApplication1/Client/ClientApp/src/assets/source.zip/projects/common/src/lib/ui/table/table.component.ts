import {
  AfterContentChecked,
  AfterContentInit,
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  ContentChildren,
  EventEmitter, Inject,
  Input, LOCALE_ID,
  OnInit,
  Output,
  QueryList,
  TemplateRef,
  ViewChild,
  ViewChildren
} from '@angular/core';
import {Table} from 'primeng/table';
import {Paginator} from 'primeng/paginator';
import {LazyLoadEvent, MenuItem} from 'primeng/api';
import {DomHandler} from 'primeng/dom';
import {Column} from './column';
import scrollIntoView from 'scroll-into-view-if-needed';
import {Cell} from './cell.directive';

export function tableProviderFactory(table: TableComponent) {
  return table.dataTable;
}

@Component({
    selector: 'app-table',
    templateUrl: 'table.component.html',
    styleUrls: ['table.component.css'],
    providers: [
      DomHandler,
      { provide: Table, useFactory: tableProviderFactory, deps: [TableComponent] }
    ]
})
export class TableComponent implements OnInit, AfterContentInit, AfterViewInit, AfterContentChecked {
  private layoutChanged = false;
  private frozenLayoutChanged = false;
  private reloadSettings = false;
  private _initValue: any[] = [];
  private _value: any[] = [];
  get value(): any[] {
    return this._value;
  }

  @Input() set value(val: any[]) {
    this._value = val;
    if (val) {
      this._initValue = val.slice();
    } else {
      this._initValue = [];
    }
    this.selectAfterLoad();
  }

  @Input() autoHeight = false;
  @Input() totalRecords: number;
  @Input() selectionMode = 'single';
  @Input() paginator: boolean;
  @Input() paginatorPosition: string;
  @Input() externalPaginator: Paginator;
  @Input() rows: number;
  @Input() filter: boolean;
  @Input() footer: boolean;
  @Input() lazy: boolean;
  @Input() loading: boolean;
  @Input() metaKeySelection: boolean;
  @Input() sortMode = 'multiple';
  @Input() calcRowStyle: (rowData: any) => any;

  @Output() onRowSelect: EventEmitter<any> = new EventEmitter();
  @Output() onLazyLoad: EventEmitter<LazyLoadEvent> = new EventEmitter(true);

  _selection: any;
  @Output() selectionChange: EventEmitter<any> = new EventEmitter();

  @Input() get selection() {
    return this._selection;
  }

  set selection(val) {
    this._selection = val;
    this.selectionChange.emit(val);
  }

  private _settingsKey: string;
  @Input() get settingsKey(): string {
    return this._settingsKey;
  }
  set settingsKey(value: string) {
    this._settingsKey = value;
    if (this.initialSettings) {
      this.reloadSettings = true;
    }
  }

  @ViewChild('dt', {static: true}) dataTable: Table;
  @ViewChildren(TemplateRef) tds: QueryList<any>;
  @ContentChildren(Column) cols: QueryList<Column>;
  iframe: any;
  frozenView: any;
  unfrozenView: any;
  frozenBody: any;
  unfrozenBody: any;

  allColumns: any[];
  visibleColumns: any[];
  frozenColumns: any[];
  emptyColumn = new Column();
  initialSettings: any[];
  filterString: string;
  filterDelayTemp: number;
  resizing = false;

  showColumnsDialog: boolean = false;
  columnsDialogVisibleColumns: any[] = null;
  columnsDialogInvisibleColumns: any[] = null;

  items: MenuItem[];

  private selectFirstAfterLoad = false;
  private selectLastAfterLoad = false;
  constructor(private cdr: ChangeDetectorRef,  private domHandler: DomHandler,
              @Inject(LOCALE_ID) private local: string) {
  }

  ngOnInit() {
    const self = this;
    const onColumnResizeBegin = this.dataTable.onColumnResizeBegin.bind(this.dataTable);
    const onColumnResizeEnd = this.dataTable.onColumnResizeEnd.bind(this.dataTable);
    this.dataTable.onColumnResizeBegin = function (event) {
      onColumnResizeBegin(event);
      self.resizing = true;
    };
    this.dataTable.onColumnResizeEnd = function (event, column) {
      onColumnResizeEnd(event, column);
      self.resizing = false;
    };
    this.dataTable.bindDocumentEditListener = function() {};
  }

  ngAfterContentInit() {
    const allColumns = this.cols.toArray();
    const columns = allColumns.filter(c => !c.frozen);

    let ind = 0;
    for (const col of columns) {
      (<any>col).index = ind;
      ind++;
      if (col.type === 'sum' || col.type === 'number') {
        col.textAlign = 'right';
      } else if (col.type === 'bool') {
        col.textAlign = 'center';
      }
    }
    this.allColumns = columns;
    this.frozenColumns = allColumns.filter(c => !!c.frozen);
    this.layout();

    this.loadSettings();

    for (const col of this.allColumns) {
      col.layoutChange.subscribe(() => {
        this.layoutChanged = true;
      });
    }

    if (this.frozenColumns) {
      for (const col of this.frozenColumns) {
        col.layoutChange.subscribe(() => {
          this.frozenLayoutChanged = true;
        });
        col.widthChange.subscribe(() => {
          this.frozenLayoutChanged = true;
        });
      }
    }
  }

  public loadSettings() {
    if (this.initialSettings) {
      this.applySettings(this.initialSettings);
    }
    this.initialSettings = this.getSettings(this.allColumns);
    let savedSettings = null;
    if (this.settingsKey && window.localStorage.getItem('Tabel_' + this.settingsKey)) {
      savedSettings = JSON.parse(window.localStorage.getItem('Tabel_' + this.settingsKey));
    }
    if (savedSettings) {
      this.applySettings(savedSettings);
    }
  }

  ngAfterViewInit() {
    this.frozenView = this.dataTable.el.nativeElement.querySelector('.ui-table-frozen-view');
    this.unfrozenView = this.dataTable.el.nativeElement.querySelector('.ui-table-unfrozen-view');
    this.frozenBody = this.frozenView.querySelector('.ui-table-scrollable-body');
    this.unfrozenBody = this.unfrozenView.querySelector('.ui-table-scrollable-body');

    this.dataTable.frozenColGroupTemplate = this.dataTable.colGroupTemplate;
    this.dataTable.frozenHeaderTemplate = this.dataTable.headerTemplate;
    this.dataTable.frozenBodyTemplate = this.dataTable.bodyTemplate;
    this.dataTable.frozenFooterTemplate = this.dataTable.footerTemplate;

    this.frozenLayout();

    this.dataTable.el.nativeElement.querySelector('.ui-table-scrollable-wrapper')
      .appendChild(this.frozenView);

    const iframe = document.createElement('iframe');
    iframe.id = 'hacky-scrollbar-resize-listener';
    iframe.style.cssText = 'height: 0; background-color: transparent; margin: 0; padding: 0; overflow: hidden; border-width: 0; position: absolute; width: 100%;';

    const self = this;
    // Register our event when the iframe loads
    iframe.onload = function () {
      // The trick here is that because this iframe has 100% width
      // it should fire a window resize event when anything causes it to
      // resize (even scrollbars on the outer element)
      iframe.contentWindow.addEventListener('resize', function () {
        self.onColumnResize();
      });
    };

    // Stick the iframe somewhere out of the way
    this.unfrozenBody.appendChild(iframe);
    this.iframe = iframe;
    setTimeout(() => {
      this.onColumnResize();
    });
  }

  ngAfterContentChecked() {
    if (this.reloadSettings) {
      this.loadSettings();
      this.reloadSettings = false;
    }
    if (this.layoutChanged) {
      //console.log('check')
      this.layout();
    }
    if (this.frozenLayoutChanged) {
      this.frozenLayout();
    }
  }

  layout() {
    this.visibleColumns = this.allColumns
      .filter(c => c.visible && c.available)
      .sort((c1, c2) => c1.index - c2.index);
    this.layoutChanged = false;
  }

  frozenLayout() {
    const frozenColumns = this.frozenColumns.slice() || [];
    const frozenWidth = +frozenColumns.filter(c => c.visible && c.available)
      .reduce((a, c) => a + (c.width || 200), 0);
    this.dataTable.frozenColumns = this.frozenColumns;
    if (frozenWidth) {
      this.dataTable.frozenWidth = (frozenWidth + 1) + 'px';
    } else {
      this.dataTable.frozenWidth = '0px';
    }
    this.frozenView.style.width = this.dataTable.frozenWidth;
    this.unfrozenView.style.left = this.dataTable.frozenWidth;
    this.unfrozenView.style.width = 'calc(100% - ' + this.dataTable.frozenWidth + ')';
    if (this.dataTable.frozenColumns.length) {
      this.unfrozenView.style.position = 'absolute';
      this.frozenView.style.display = null;
    } else {
      this.unfrozenView.style.position = 'static';
      this.frozenView.style.display = 'none';
    }

    this.cdr.detectChanges();

    setTimeout(() => {
      this.scrollSelectedIntoView();
      this.frozenBody.scrollTop = this.unfrozenBody.scrollTop;
    });

    this.frozenLayoutChanged = false;
  }

  showColumnsForm() {
    this.showColumnsDialog = true;
    this.columnsDialogVisibleColumns = this.visibleColumns;
    this.columnsDialogInvisibleColumns = this.allColumns
      .filter(c => c.available && this.visibleColumns.indexOf(c) < 0);
  }

  reload() {
    this.dataTable.onLazyLoad.emit(this.dataTable.createLazyLoadMetadata());
  }

  getCellStyle(col: Column, rowData: any) {
    const rowStyle = Object.assign({}, this.calcRowStyle && this.calcRowStyle(rowData));
    const cellStyle = col.calcCellStyle && col.calcCellStyle(rowData);
    return Object.assign(rowStyle, cellStyle);
  }

  scrollSelectedIntoView() {
    const tr = this.unfrozenView.querySelector('tr.ui-state-highlight');
    if (tr) {
      if (scrollIntoView) {
        scrollIntoView(tr, {
          scrollMode: 'if-needed',
          block: 'nearest',
          inline: 'nearest',
        });
      }
    }
  }

  onPageChange(event) {
    this.dataTable.onPageChange(event);
  }

  onColumnResize() {
    const tableHeadRow: HTMLElement = this.dataTable.el.nativeElement.querySelector('colgroup');
    const tableHeads: NodeListOf<HTMLElement> = tableHeadRow.querySelectorAll('col');
    const vColumns = this.visibleColumns;
    for (let i = 0; i < tableHeads.length; i++) {
      const colWidth = parseInt(tableHeads[i].style.width.replace('px', ''));
      vColumns[i].width = colWidth;
    }
    const tw = this.dataTable.el.nativeElement.querySelector('div.ui-table').offsetWidth;
    const tbls: NodeListOf<HTMLElement> = this.dataTable.el.nativeElement.querySelectorAll('table');
    tbls[0].style.setProperty('width', tw + 'px');
    tbls[1].style.setProperty('width', (this.iframe.offsetWidth - 1) + 'px');
    if (tbls.length === 3) {
      tbls[2].style.setProperty('width', tw + 'px');
    }

    const ws = this.unfrozenBody.scrollWidth > this.unfrozenBody.clientWidth;
    if (ws) {
      this.frozenBody.style.marginBottom = (this.frozenBody.clientHeight - this.unfrozenBody.clientHeight) + 'px';
    } else {
      this.frozenBody.style.marginBottom = null;
    }

    this.saveSettings();
  }

  onKeydown(e) {
    if (this.loading || !this.selectionMode) {
      return;
    }
    if (e.which === 38) { //UP
      const arr = this.dataTable.filteredValue || this.dataTable.value;
      if (arr.length > 0) {
        let i = this.focusedRowIndex;
        if (i - 1 >= 0) {
          this.selection = this.dataTable.isSingleSelectionMode()
            ? arr[i - 1] : [arr[i - 1]];
          this.emitRowSelect(arr[i - 1]);
        } else {
          this.prevPage(e);
        }
      }
    } else if (e.which === 40) { //DOWN
      const arr = this.dataTable.filteredValue || this.dataTable.value;
      if (arr.length > 0) {
        let i = this.focusedRowIndex;
        if (i + 1 < arr.length) {
          this.selection = this.dataTable.isSingleSelectionMode()
            ? arr[i + 1] : [arr[i + 1]];
          this.emitRowSelect(arr[i + 1]);
        } else {
          this.nextPage(e);
        }
      }
    } else if (e.which === 34) { //PAGE UP
      this.nextPage(e);
    } else if (e.which === 33) { //PAGE DOWN
      this.prevPage(e);
    }
  }

  private get focusedRowIndex(): number {
    const arr = this.dataTable.filteredValue || this.dataTable.value;
    if (this.dataTable.isSingleSelectionMode()) {
      return this.selection ? arr.indexOf(this.selection) : -1;
    } else {
      return this.selection && this.selection[0] ? arr.indexOf(this.selection[0]) : -1;
    }
  }

  private nextPage(e) {
    if (this.externalPaginator
      && this.externalPaginator.getPage() != this.externalPaginator.getPageCount() - 1) {
      this.selectFirstAfterLoad = true;
      this.externalPaginator.changePageToNext(e);
    }
  }

  private prevPage(e) {
    if (this.externalPaginator
      && this.externalPaginator.getPage() != 0) {
      this.selectLastAfterLoad = true;
      this.externalPaginator.changePageToPrev(e);
    }
  }

  private emitRowSelect(rowData: any) {
    const arr = this.dataTable.filteredValue || this.dataTable.value;
    this.dataTable.onRowSelect.emit({ data: rowData, type: 'row', index: arr.indexOf(rowData) });
    setTimeout(() => {
      this.scrollSelectedIntoView();
    });
  }

  private selectAfterLoad() {
    if (this._value && this._value.length > 0) {
      if (this.selectFirstAfterLoad) {
        setTimeout(() => {
          this.selection = this.dataTable.isSingleSelectionMode()
            ? this._value[0] : [this._value[0]];
          this.emitRowSelect(this._value[0]);
        });
      } else if (this.selectLastAfterLoad) {
        setTimeout(() => {
          this.selection = this.dataTable.isSingleSelectionMode()
            ? this._value[this._value.length - 1] : [this._value[this._value.length - 1]];
          this.emitRowSelect(this._value[this._value.length - 1]);
        });
      }
    }
    this.selectFirstAfterLoad = false;
    this.selectLastAfterLoad = false;
  }

  contextMenu(data) {
    const isColumn: boolean = data instanceof Column;
    let order = 0;
    if (isColumn && this.dataTable._multiSortMeta) {
      for (const sm of this.dataTable._multiSortMeta) {
        if (sm.field === data.field) {
          order = sm.order;
        }
      }
    }
    if (isColumn) {
      this.items = [
        {
          label: 'По возрастанию',
          icon: 'fa fa-caret-up',
          disabled: !data.field || order === 1,
          command: e => this.sort(data.field, 1)
        },
        {
          label: 'По убыванию',
          icon: 'fa fa-caret-down',
          disabled: !data.field || order === -1,
          command: e => this.sort(data.field, -1)
        },
        {
          label: 'Очистить сортировку',
          icon: 'fa fa-sort',
          disabled: !data.field || order === 0,
          command: e => this.clearSort(data.field)
        },
        {
          separator: true
        },
        {
          label: 'Очистить фильтр',
          icon: 'fa fa-filter',
          command: e => this.clearFilter(data.field)
        },
        {
          separator: true
        },
        {
          label: 'Колонки',
          icon: 'fa fa-columns',
          command: e => this.showColumnsForm()
        },
        {
          label: 'Сбросить настройки',
          icon: 'na',
          command: e => this.clearSettings()
        }
      ];
    } else {
      this.items = [];
    }
  }

  sort(field: string, order: number) {
    const sortMeta = this.dataTable.getSortMeta(field);
    if (sortMeta) {
      sortMeta.order = order;
    } else {
      if (!this.dataTable.multiSortMeta) {
        this.dataTable._multiSortMeta = [];
      }
      this.dataTable.multiSortMeta.push({field: field, order: order});
    }
    this.dataTable.sortMultiple();
  }

  clearSort(field: string) {
    if (this.dataTable._multiSortMeta) {
      const newMeta = [];
      for (const sm of this.dataTable._multiSortMeta) {
        if (sm.field !== field) {
          newMeta.push(sm);
        }
      }
      if (newMeta.length == 0) {
        this.dataTable._multiSortMeta = null;
      } else {
        this.dataTable._multiSortMeta = newMeta;
      }
    }

    if (this.dataTable.lazy) {
      this.dataTable.tableService.onSort(this.dataTable._multiSortMeta);
      this.dataTable.onLazyLoad.emit(this.dataTable.createLazyLoadMetadata());
    } else {
      if (this.dataTable._multiSortMeta) {
        this.dataTable.sortMultiple();
      } else {
        this.dataTable._multiSortMeta = null;
        this.dataTable.tableService.onSort(null);
      }
      const sortingArr = this._initValue;
      this.value.sort(function (a, b) {
        return sortingArr.indexOf(a) - sortingArr.indexOf(b);
      });
    }
  }

  onFilter(event) {
    if (this.externalPaginator) {
      this.externalPaginator.first = 0;
    }
    let filterString = '';
    for (const prop in event.filters) {
      if (event.filters.hasOwnProperty(prop)) {
        if (filterString) {
          filterString += ' и ';
        }
        filterString +=
          `'${this.getColumnHeader(prop)}' ${this.getMatchModeString(event.filters[prop].matchMode)}`;
        const mode = event.filters[prop].matchMode;
        const withValue = mode != 'isNull' && mode != 'isNotNull';
        if (withValue) {
          filterString += ` '${event.filters[prop].value}'`;
        }
      }
    }
    this.filterString = filterString;
  }

  getColumnHeader(field: string) {
    for (let col of this.allColumns) {
      if (col.field == field) {
        return col.header || col.field;
      }
    }
    return null;
  }

  getMatchModeString(matchMode: string): string {
    switch (matchMode) {
      case 'contains':
        return 'содержит'
      case 'startsWith':
        return 'начинается с'
      case 'equals':
        return '='
      case 'in':
        return 'одно из'
      case 'isNotNull':
        return 'задано'
       case 'isNull':
        return 'не задано'
    }
    return '';
  }

  clearFilterAll() {
    this.dataTable.filters = {};
    if (this.externalPaginator) {
      this.externalPaginator.first = 0;
    }
    for (const col of this.allColumns) {
      this.resetFilterMode(col);
    }
    this.dataTable._filter();
  }

  clearFilter(field: string) {
    if (this.dataTable.filters[field]) {
      delete this.dataTable.filters[field];
    }
    if (this.externalPaginator) {
      this.externalPaginator.first = 0;
    }
    this.resetFilterMode(this.allColumns.filter(c => c.field == field)[0]);
    this.dataTable._filter();
  }

  resetFilterMode(col: Column) {
    const withValue = col.filterMatchMode != 'isNull' && col.filterMatchMode != 'isNotNull';
    if (!withValue) {
      col.filterMatchMode = null;
      this.setDefualtFilterMode(col);
    }
  }

  updateColumns() {
    this.visibleColumns = [...this.visibleColumns];
    this.saveSettings();
  }

  updateColumnsFromDialog() {
    this.visibleColumns = [...this.columnsDialogVisibleColumns];
    this.saveSettings();
  }

  clearSettings() {
    this.applySettings(this.initialSettings);
    this.saveSettings();
  }

  getSettings(columns: any[], initialSettings: any[] = null): any[] {
    let settings = [];
    let ind = 0;
    for (let col of columns) {
      let width = col.width;
      if (initialSettings
        && initialSettings.find(s => s.field == col.field && s.width == width)) {
        width = null;
      }
      settings.push({
        field: col.field,
        index: ind,
        width: width,
        visible: col.visible
      });
      ind++;
    }
    return settings;
  }

  saveSettings() {
    for (let col of this.allColumns) {
      if (col.available) {
        col._visible = false;
        col.index = null;
      }
    }
    let ind = 0;
    for (let col of this.visibleColumns) {
      col._visible = true;
      col.index = ind;
      ind++;
    }
    if (this.settingsKey) {
      let settings = this.getSettings(
        this.allColumns.sort((a, b) => {
          if (a.index == null) {
            return -1;
          }
          if (a.index < b.index) {
            return -1;
          }
          if (b.index == null) {
            return 1;
          }
          if (a.index > b.index) {
            return 1;
          }
          return 0;
        }),
        this.initialSettings);
      window.localStorage.setItem('Tabel_' + this.settingsKey, JSON.stringify(settings));
    }
  }

  applySettings(settings: any[]) {
    let ind = 0;
    for (let col of this.allColumns) {
      if (col.available) {
        col.index = ind;
        col._visible = true;
        if (settings) {
          for (let colSettings of settings) {
            if (colSettings.field == col.field) {
              col._visible = colSettings.visible == null ? true : colSettings.visible;
              col.index = colSettings.index;
              if (colSettings.width) {
                col.width = colSettings.width;
              }
              break;
            }
          }
        }
        ind++;
      }
    }
    this.layout();
  }

  applyFilter(delayed: boolean, value: any, col: Column) {
    this.setDefualtFilterMode(col);
    const filterDelayTemp = this.dataTable.filterDelay;
    if (!delayed) {
      this.dataTable.filterDelay = 0;
    }
    const withValue = col.filterMatchMode != 'isNull' && col.filterMatchMode != 'isNotNull';
    this.dataTable.filter(withValue ? value : '-', col.field, col.filterMatchMode);
    this.dataTable.filterDelay = filterDelayTemp;
  }

  applyFilterMode(mode: string, col: Column) {
    this.setDefualtFilterMode(col);
    if (col.filterMatchMode != mode) {
      const newWithValue = mode != 'isNull' && mode != 'isNotNull';
      const oldWithValue = col.filterMatchMode != 'isNull' && col.filterMatchMode != 'isNotNull';
      col.filterMatchMode = mode;
      if (!newWithValue) {
        this.applyFilter(false, '-', col);
      } else if (!oldWithValue) {
        this.applyFilter(false, '', col);
      } else if (this.dataTable.filters[col.field]) {
        this.applyFilter(false, this.dataTable.filters[col.field].value, col);
      }
    }
  }

  setDefualtFilterMode(col: Column) {
    if (col.filterMatchMode) {
      return;
    }
    const isSelect = col.type == 'bool' || col.type == 'enum';
    col.filterMatchMode = isSelect ? 'equals' : 'contains';
  }

  getText(cellContext): string {
    const cell = new Cell(this, this.local);
    cell.cellContext = cellContext;
    return cell.text;
  }

  getIcon(cellContext): string {
    const cell = new Cell(this, this.local);
    cell.cellContext = cellContext;
    return cell.icon;
  }
}
