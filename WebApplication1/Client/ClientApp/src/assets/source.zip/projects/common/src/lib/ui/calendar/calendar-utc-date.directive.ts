import {Directive} from '@angular/core';
import {Calendar} from 'primeng/calendar';

@Directive({
  selector: 'p-calendar[utcDate]'
})
export class CalendarUtcDateDirective {
  constructor(calendar: Calendar) {

    const updateDate = (value, inc) => {
      if (value === null) {
        return null;
      }
      const date = new Date(value);
      date.setTime(date.getTime() + (!!inc ? 1 : -1) * date.getTimezoneOffset() * 60000);
      return date;
    };

    const oldWriteValue = calendar.writeValue.bind(calendar);
    calendar.writeValue = function (value) {
      if (!!value) {
        if (value instanceof Array) {
          const res = [];
          value.forEach(date => {
            res.push(updateDate(date, true));
          });
          oldWriteValue(res);
        } else {
          oldWriteValue(updateDate(value, true));
        }
      } else {
        oldWriteValue(value);
      }
    };

    const oldRegisterOnChange = calendar.registerOnChange.bind(calendar);
    calendar.registerOnChange = function (fn) {
      oldRegisterOnChange(value => {
        if (!!value) {
          if (value instanceof Array) {
            const res = [];
            value.forEach(date => {
              res.push(updateDate(date, false));
            });
            fn(res);
          } else {
            fn(updateDate(value, false));
          }
        } else {
          fn(value);
        }
      });
    };
  }
}
