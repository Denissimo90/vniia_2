import {Directive, forwardRef, Input} from '@angular/core';
import {AbstractControl, NG_VALIDATORS, ValidationErrors, Validator} from '@angular/forms';

@Directive({
  selector: '[pKeyFilter]',
  providers: [
    { provide: NG_VALIDATORS, useExisting: forwardRef(() => PKeyFilterNumDirective), multi: true }
  ]
})
export class PKeyFilterNumDirective implements Validator {
  private _filter: string | RegExp;
  private onValidatorChange: () => void;

  private _mayBeEmpty: boolean;

  numberMatchRegExp: RegExp = /(^-?\d{0,9}$)|(^-?\d{1,9}\.\d{1,10}$)/;
  positiveNumberMatchRegExp: RegExp = /(^\d{0,9}$)|(^\d{1,9}\.\d{1,10}$)/;

  constructor() { }

  @Input()
  get pKeyFilter(): string | RegExp {
    return this._filter;
  }
  set pKeyFilter(value: string | RegExp) {
    this._filter = value;
    setTimeout(() => {
      if (this.onValidatorChange) {
        this.onValidatorChange();
      }
    });
  }

  @Input()
  get pMayBeEmpty(): boolean {
    return this._mayBeEmpty;
  }
  set pMayBeEmpty(value: boolean){
    this._mayBeEmpty = value;
    setTimeout(() => {
      if (this.onValidatorChange) {
        this.onValidatorChange();
      }
    });
  }

  validate(control: AbstractControl): ValidationErrors | null {

    if(this._mayBeEmpty === true && (control.value === null || control.value === undefined)){
      return null;
    }

    if ((this._filter === 'num' && !this.numberMatchRegExp.test(control.value))
        || (this._filter === 'pnum' && !this.positiveNumberMatchRegExp.test(control.value))) {
      return { 'pKeyFilter': 'Неверное число' };
    }
    return null;
  }

  registerOnValidatorChange(fn: () => void): void {
    this.onValidatorChange = fn;
  }
  
}
