import {Component, OnDestroy, ViewChild} from '@angular/core';
import {IHeaderParams, RowNode} from 'ag-grid-community';
import {IHeaderAngularComp} from 'ag-grid-angular';
import {TriStateCheckbox} from 'primeng';

@Component({
  template: `
    <div style="width: 100%; height: 100%; text-align: center">
      <p-triStateCheckbox #checkbox [(ngModel)]="isChecked" (onChange)="onChange($event)"
                  [pTooltip]="(isChecked == null || !isChecked) ? 'Отметить все записи' : 'Снять все отметки'">
      </p-triStateCheckbox>
    </div>`
})
export class TriStateCheckboxHeaderComponent implements IHeaderAngularComp, OnDestroy {
  private params: IHeaderParams;
  private nodesFilter: (node: RowNode) => boolean;
  private updateCheckedStateListener: any;
  private updateTimerId;

  isChecked = false;

  @ViewChild('checkbox', {static: true}) checkbox: TriStateCheckbox;

  agInit(params: IHeaderParams): void {
    this.checkbox.toggle = event => {
      if (this.checkbox.value == null) {
        this.checkbox.value = false;
      } else {
        this.checkbox.value = !this.checkbox.value;
      }
      this.checkbox.onModelChange(this.checkbox.value);
      this.checkbox.onChange.emit({
        originalEvent: event,
        value: this.checkbox.value
      });
    };

    this.updateCheckedStateListener = this.updateCheckedStateWithDebounce.bind(this);

    this.params = params;
    this.nodesFilter = (<any>params).nodesFilter;

    this.bindEvents();

    this.updateCheckedStateWithDebounce();
  }

  bindEvents() {
    this.params.api.addEventListener('modelUpdated', this.updateCheckedStateListener);
    this.params.api.addEventListener('cellValueChanged', this.updateCheckedStateListener);
  }

  unbindEvents() {
    this.params.api.removeEventListener('modelUpdated', this.updateCheckedStateListener);
    this.params.api.removeEventListener('cellValueChanged', this.updateCheckedStateListener);
  }

  ngOnDestroy() {
    if (this.updateTimerId) {
      clearTimeout(this.updateTimerId);
    }
    this.unbindEvents();
  }

  updateCheckedStateWithDebounce() {
    if (this.updateTimerId) {
      clearTimeout(this.updateTimerId);
    }
    this.updateTimerId = setTimeout(() => {
      this.updateCheckedState();
    }, 20);
  }

  updateCheckedState() {
    let checkedCount = 0;
    let allCount = 0;
    this.params.api.forEachNodeAfterFilterAndSort(node => {
      if (!this.nodesFilter || this.nodesFilter(node)) {
        const checked = this.params.api.getValue(this.params.column, node);
        if (checked) {
          checkedCount++;
        }
        allCount++;
      }
    });
    let allChecked = null;
    if (allCount > 0) {
      if (checkedCount == allCount) {
        allChecked = true;
      } else if (checkedCount == 0) {
        allChecked = false;
      }
    } else {
      allChecked = false;
    }

    this.isChecked = allChecked;
  }

  onChange(event) {
    if (this.params.column.getColDef().type !== 'bool') {
      console.warn(`Column ${this.params.column.getColId()} must be bool`);
    } else {
      this.unbindEvents();
      this.params.api.forEachNodeAfterFilterAndSort(node => {
        if (!this.nodesFilter || this.nodesFilter(node)) {
          node.setDataValue(this.params.column, this.isChecked);
        }
      });
      this.bindEvents();
      this.updateCheckedState();
    }
  }
}
