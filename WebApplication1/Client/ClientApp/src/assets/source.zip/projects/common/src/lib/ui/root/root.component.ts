import {Component, ContentChild, ElementRef, Input, OnDestroy, OnInit, TemplateRef} from '@angular/core';
import {NavigationCancel, NavigationEnd, NavigationError, NavigationStart, Router} from '@angular/router';
import {ConfirmationService, MenuItem, MessageService} from 'primeng/api';
import {EventBusService, HandlerRegistration} from '../../services/events/eventbus.service';
import {AuthService} from '../../services/auth/auth.service';
import {UserService} from '../../services/auth/user.service';
import {UserEmployment} from '../../services/auth/UserEmployment';
import {EntityConfigService} from '../../services/entity-config/entity-config.service';
import {HTTPErrors, HttpEventbusEvent} from '../../services/events/http.eventbus.event';
import {MessageServiceKey} from '../../services/message/MessageServiceKey';
import {ToolbarTemplate} from '../toolbar/ToolbarTemplate';
import {ConfigurationService} from '../../services/config/configuration.service';

@Component({
  selector: 'app-common-root',
  templateUrl: './root.component.html',
  styleUrls: ['./root.component.css']
})

export class RootComponent implements OnInit, OnDestroy {
  MessageServiceKey = MessageServiceKey;

  private handlers: HandlerRegistration[] = [];

  initialized = false;
  loading = false;
  employmentsDialogVisible = false;
  employments: UserEmployment[];
  userPersonalNumber: string;

  @Input() showToolbar = true;
  @Input() name: String;
  @Input() showVersion = true;
  @Input() logoSrc: String = 'assets/logo.svg';
  @Input() mainMenu: MenuItem[];
  @Input() informationMenuEx: MenuItem[];
  @Input() contentNoPadding = false;
  @Input() toolbarTemplate: ToolbarTemplate;

  @ContentChild('content') contentTemplate: TemplateRef<ElementRef>;
  @ContentChild('loading') loadingTemplate: TemplateRef<ElementRef>;

  constructor(private authService: AuthService,
              private router: Router,
              private confirmationService: ConfirmationService,
              private configurationService: ConfigurationService,
              private bus: EventBusService,
              private messageService: MessageService,
              public user: UserService,
              private entityConfigService: EntityConfigService) {
    router.events.subscribe(event => {
      if (event instanceof NavigationStart) {
        this.loading = true;
      } else if (event instanceof NavigationEnd
        || event instanceof NavigationCancel
        || event instanceof NavigationError) {
        this.loading = false;
      }
    });
  }

  async ngOnInit() {

    if (!!this.configurationService.config.restConfig && !this.configurationService.config.auth) {
      console.log('Не известен URL авторизации');
      this.reconnectPopup();
      return;
    }

    this.handlers.push(this.bus.on(new HttpEventbusEvent(), (event: HttpEventbusEvent) => {
      switch (event.httpError) {
        case HTTPErrors.TYPE_NETWROK_IO_ERROR:
        case HTTPErrors.TYPE_BAD_GATEWAY:
          this.reconnectPopup();
          break;
        case HTTPErrors.TYPE_UNAUTHORIZED:
          this.popup(
            event.message,
            () => this.logoutUser());
          break;
        case HTTPErrors.TYPE_UNPROCESSABLE_ENTITY:
          this.logoutUser();
          break;
        case HTTPErrors.TYPE_FORBIDDEN:
          this.messageService.add({
            sticky: true, severity: 'error', summary: 'Ошибка',
            detail: 'У вас недостаточно прав для выполнения этого запроса.\nОбратитесь к администратору'
          });
          break;
        case HTTPErrors.TYPE_PAYLOAD_TOO_LARGE:
          this.messageService.add({sticky: true, severity: 'error', summary: 'Ошибка', detail: 'Файл слишком большой для загрузки'});
          break;
        case HTTPErrors.TYPE_INTERNAL_SERVER_ERROR:
          this.messageService.add({sticky: true, severity: 'error', summary: 'Ошибка', detail: 'Произошла ошибка на сервере'});
          break;
        case HTTPErrors.TYPE_EXPECTATION_FAILED:
          this.messageService.add({
            key: MessageServiceKey.OK,
            sticky: true, severity: 'warn', summary: 'Информация', detail: event.message
          });
          break;
        default:
          this.messageService.add({key: MessageServiceKey.OK, sticky: true, severity: 'error', summary: 'Ошибка', detail: event.message});
          break;
      }
    }));


    this.user.personalNumberChange.subscribe(val => {
      this.userPersonalNumber = val;
      this.employmentsDialogVisible = false;
    });

    await this.user.init();


    if (this.authService.getAccessToken()) {
      await this.entityConfigService.init();
    }

    this.employments = this.user.employments;
    this.userPersonalNumber = this.user.personalNumber;
    this.employmentsDialogVisible = this.user.personalNumberEmptyAndRequired;

    this.initialized = !this.employmentsDialogVisible;
  }

  ngOnDestroy() {
    this.unsuscribeHandlers();
  }

  unsuscribeHandlers() {
    this.handlers.forEach(handlerRegistration => handlerRegistration.unregister());
  }

  reconnectPopup() {
    this.popup(
      'Сервис недоступен!<br></br> Нажмите "ОК" что-бы переподключиться или попробуйте позднее...',
      () => this.logoutUser());
  }

  popup(message?: string, callback?: any) {
    this.confirmationService.confirm({
      header: 'ОШИБКА',
      icon: 'fa fa-exclamation-circle',
      message: message || 'undefined message',
      rejectVisible: false,
      acceptLabel: 'OK',
      accept: callback != null ? callback : () => {
      }
    });
  }

  async logoutUser() {
    // await this.authService.login(false);
    window.location.reload();
  }

  selectPersonal(personal: any) {
    this.initialized = true;
    this.user.select(personal);
  }

  checkRouter() {
    if (this.router.url === '/login') {
      return false;
    } else {
      return true;
    }
  }

  onToastMessageOkButtonClick(event: MouseEvent) {
    const closeButton = <HTMLElement>(<HTMLElement>event.target)
      .closest('.ui-toast-message-content')
      .querySelector('.ui-toast-close-icon');
    closeButton.click();
  }

  getDialogIconClassByMessage(message: any) {
    if (!message || !message.hasOwnProperty('severity')) {
      return 'pi pi-check';
    }
    switch (message.severity) {
      case 'success':
        return 'pi pi-check-circle';
      case 'warn':
        return 'pi pi-exclamation-triangle';
      case 'error':
        return 'pi pi-ban';
      case 'info':
        return 'pi pi-info-circle';
      default:
        return 'pi pi-check';
    }
  }

  getDialogButtonClassByMessage(message: any) {
    if (!message || !message.hasOwnProperty('severity')) {
      return 'ui-button-secondary';
    }
    switch (message.severity) {
      case 'success':
        return 'ui-button-success';
      case 'warn':
        return 'ui-button-warning';
      case 'error':
        return 'ui-button-danger';
      case 'info':
        return 'ui-button-info';
      default:
        return 'ui-button-secondary';
    }
  }

  maxNumber() {
    return Number.MAX_SAFE_INTEGER - 10000;
  }
}
