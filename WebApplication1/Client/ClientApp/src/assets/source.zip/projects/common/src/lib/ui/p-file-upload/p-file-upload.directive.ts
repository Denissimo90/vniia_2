import {Directive, Input, OnInit} from '@angular/core';
import {FileUpload} from 'primeng/fileupload';
import {AuthService} from '../../services/auth/auth.service';
import {HTTPErrors, HttpEventbusEvent} from '../../services/events/http.eventbus.event';
import {EventBusService} from '../../services/events/eventbus.service';

@Directive({
  selector: 'p-fileUpload'
})
export class PFileUploadDirective implements OnInit {

  static MAX_UPLOAD_FILESIZE = 20 * 1024 * 1024;

  @Input() accept = '.jpg,.txt,.pdf,.tiff,.tif,.jpeg,.png,.bmp,.gif,.doc,.docx,.xls,.xlsx';
  @Input() customUpload = false;

  constructor(private fileUpload: FileUpload, private authService: AuthService, private bus: EventBusService) {
    this.fileUpload.chooseLabel = 'Выберите файл(ы)';
    this.fileUpload.uploadLabel = 'Загрузить';
    this.fileUpload.cancelLabel = 'Отмена';
    this.fileUpload.invalidFileSizeMessageSummary = '{0}: Неправильный размер файла, ';
    this.fileUpload.invalidFileSizeMessageDetail = 'максимальный размер {0}.';
    this.fileUpload.invalidFileTypeMessageSummary = '{0}: Неправильный тип файла, ';
    this.fileUpload.invalidFileTypeMessageDetail = 'разрешенные типы: {0}.';
    this.fileUpload.withCredentials = true;
    this.fileUpload.name = 'uploadingFiles[]';
    this.fileUpload.maxFileSize = PFileUploadDirective.MAX_UPLOAD_FILESIZE;
    this.fileUpload.accept = this.accept;
    this.fileUpload.customUpload = this.customUpload;
    this.fileUpload.showUploadButton = false;
    this.fileUpload.showCancelButton = false;
  }

  ngOnInit(): void {
    this.fileUpload.files = [];

    this.fileUpload.onError.subscribe(async event => {
      if (!!event.xhr) {
        switch (event.xhr.status) {
          case HTTPErrors.TYPE_INSUFFICIENT_STORAGE: {
            const response: any = JSON.parse(event.xhr.responseText);
            const message = response != null ? (response['message']) : 'unknown';
            this.bus.emit(new HttpEventbusEvent(event.xhr.status, message));
            break;
          }
        }
      } else {
        const message: any = 'Не удалось загрузить файл: ' + event.error?.message || event.error;
        this.bus.emit(new HttpEventbusEvent(HTTPErrors.TYPE_PRECONDITION_FAILED, message));
      }
    });
  }
}
