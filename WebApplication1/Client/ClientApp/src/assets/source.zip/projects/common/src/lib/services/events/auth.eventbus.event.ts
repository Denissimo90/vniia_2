import {Event} from './eventbus.service';


export class AuthEventbusEvent implements Event {

  public static TYPE_AUTH_SERVICE_ON_TOKEN_READ             = 'typeAuthServiceOnTokenRead';

  public static TYPE_AUTH_SERVICE_ON_TOKEN_RECIVED             = 'typeAuthServiceOnTokenRecived';

  public static TYPE_AUTH_SERVICE_ON_NEW_USER_CHANGE             = 'typeAuthServiceOnUserChange';


  type: string;

  constructor(typeArg: string) {
    this.type = typeArg;
  }

}
