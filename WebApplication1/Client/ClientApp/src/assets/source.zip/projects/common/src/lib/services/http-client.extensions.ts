import {HttpClient, HttpEventType, HttpHeaders, HttpParams, HttpRequest, HttpResponse} from '@angular/common/http';
import {Observable} from 'rxjs';
import {map, filter} from 'rxjs/operators';
import * as FileSaver from 'file-saver';
import {PageQuery} from './PageQuery';
import {PageResponse} from './PageResponse';

declare module '@angular/common/http/' {
  interface HttpClient {
    /**
     * Execute request and return body
     */
    requestData<R>(req: HttpRequest<any>): Observable<R>;

    /**
     * Add export parameters to request, execute and return blob
     */
    requestExport(req: HttpRequest<any>, exportColumns: any[]): Observable<Blob>;

    postPageQuery<R>(url: string, query: PageQuery, options?: {
      headers?: HttpHeaders;
      params?: HttpParams;
      withCredentials?: boolean;
    }): Observable<PageResponse<R>>;
  }
}

HttpClient.prototype.postPageQuery = function(url: string, query: PageQuery, options?: {
  headers?: HttpHeaders;
  params?: HttpParams;
  withCredentials?: boolean;
}): Observable<PageResponse<any>> {
  let request = new HttpRequest(
    'POST',
    url,
    query, 
    options);
  if (query.exportColumns) {
    return (<HttpClient>this).requestExport(request, query.exportColumns)
      .pipe(
        map(blob => {
          const file = new File([blob], 'export.xlsx');
          FileSaver.saveAs(file, 'export.xlsx');
          return { items: [], total: 0 };
        })
      );
  } else {
    return (<HttpClient>this).requestData<PageResponse<any>>(request);
  }
}

HttpClient.prototype.requestData = function(req: HttpRequest<any>): Observable<any> {
  return (<HttpClient>this).request(req)
    .pipe(
      filter(resp => resp.type == HttpEventType.Response),
      map(resp => (<HttpResponse<any>>resp).body)
    );
};

HttpClient.prototype.requestExport = function(req: HttpRequest<any>, 
    exportColumns: any[]): Observable<Blob> {
  return (<HttpClient>this).request(
      req.clone({
        body: {...req.body, columns: exportColumns},
        responseType: 'blob',
        setHeaders: {'Accept': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}
      })
    )
    .pipe(
      filter(resp => resp.type == HttpEventType.Response),
      map(resp => (<HttpResponse<any>>resp).body)
    );
};
