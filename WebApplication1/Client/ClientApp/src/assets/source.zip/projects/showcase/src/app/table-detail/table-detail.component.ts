import {Component, OnInit, ViewChild} from '@angular/core';
import {LazyLoadEvent, Table2Component} from '@prism/common';

@Component({
  selector: 'app-table-detail',
  templateUrl: './table-detail.component.html',
  styleUrls: ['./table-detail.component.css']
})
export class TableDetailComponent implements OnInit {
  data: any[];
  embedFullWidthRows = false;

  @ViewChild('t') htmlTable: Table2Component;

  constructor() { }

  ngOnInit(): void {
    this.embedFullWidthRows = localStorage.getItem('table-detail_embedFullWidthRows') == 'true';
  }

  onLoad(event: LazyLoadEvent) {
    const data = [];
    for (let i = 0; i < 100; i++) {
      const col2Id = Math.floor(Math.random() * 4) + 1;
      data.push({
        col1: i,
        col2: 'abc' + col2Id
      });
    }
    this.data = data;
    event.successCallback(data, 100);
  }

  embedFullWidthRowsChanged() {
    localStorage.setItem('table-detail_embedFullWidthRows', this.embedFullWidthRows ? 'true' : 'false');
    location.reload();
  }
}
