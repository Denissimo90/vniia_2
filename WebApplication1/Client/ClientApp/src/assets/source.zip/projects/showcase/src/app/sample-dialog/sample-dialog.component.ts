import {Component, OnInit} from '@angular/core';
import {DialogComponent} from '@prism/common';
import {MessageService} from 'primeng';


@Component({
  selector: 'app-sample-dialog.component',
  templateUrl: './sample-dialog.component.html',
  styleUrls: ['./sample-dialog.component.css'],
  providers: []
})
export class SampleDialogComponent extends DialogComponent implements OnInit {
  header = 'Тестовый диалог';
  baselineNorm: number;


  constructor(private messageService: MessageService) {
    super();
  }

  ngOnInit(): void {
  }

  async startInitComponent() {
  }


}
