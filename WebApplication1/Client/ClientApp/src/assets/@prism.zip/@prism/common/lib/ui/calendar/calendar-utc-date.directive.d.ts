import { Calendar } from 'primeng/calendar';
import * as i0 from "@angular/core";
export declare class CalendarUtcDateDirective {
    constructor(calendar: Calendar);
    static ɵfac: i0.ɵɵFactoryDef<CalendarUtcDateDirective>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<CalendarUtcDateDirective, "p-calendar[utcDate]", never, {}, {}, never>;
}
