export declare enum DetailCellRenderer {
    CUSTOM = "customDetailComponent"
}
