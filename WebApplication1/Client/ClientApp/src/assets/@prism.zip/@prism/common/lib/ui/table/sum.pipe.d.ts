import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class SumPipe implements PipeTransform {
    private _local;
    constructor(_local: string);
    transform(value: any, args?: any): any;
    static ɵfac: i0.ɵɵFactoryDef<SumPipe>;
    static ɵpipe: i0.ɵɵPipeDefWithMeta<SumPipe, "sum">;
}
