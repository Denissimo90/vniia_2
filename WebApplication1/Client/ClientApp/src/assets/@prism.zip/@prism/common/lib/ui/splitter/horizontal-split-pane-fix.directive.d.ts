import { AfterViewInit } from '@angular/core';
import { HorizontalSplitPaneComponent } from './horizontal-split-pane.component';
import * as i0 from "@angular/core";
export declare class HorizontalSplitPaneFix implements AfterViewInit {
    private pane;
    constructor(pane: HorizontalSplitPaneComponent);
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDef<HorizontalSplitPaneFix>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<HorizontalSplitPaneFix, "horizontal-split-pane", never, {}, {}, never>;
}
