export declare class FieldConfig {
    name: string;
    visible: () => boolean;
    required: () => boolean;
    readonly: () => boolean;
}
