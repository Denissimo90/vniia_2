export interface Event {
    type: string;
}
/**
 * An event handler.
 */
export declare type EventHandler<T extends Event> = (event: T) => void;
/**
 * Registration objects returned when an event handler is added,
 * used to deregister.
 */
export interface HandlerRegistration {
    unregister(): void;
}
export declare class EventBusService {
    id: number;
    constructor();
    private handlers;
    on<T extends Event>(event: T, handler: EventHandler<T>): HandlerRegistration;
    emit(event: Event): void;
}
