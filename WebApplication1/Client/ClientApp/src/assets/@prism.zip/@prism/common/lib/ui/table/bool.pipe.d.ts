import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class BoolPipe implements PipeTransform {
    private _local;
    constructor(_local: string);
    transform(value: any, args?: any): any;
    static ɵfac: i0.ɵɵFactoryDef<BoolPipe>;
    static ɵpipe: i0.ɵɵPipeDefWithMeta<BoolPipe, "bool">;
}
