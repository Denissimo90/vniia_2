import { OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import * as i0 from "@angular/core";
export declare type ExtendedMenuItems = ExtendedMenuItem[];
export interface ExtendedMenuItemGroup {
    title: string;
    color?: string;
}
export interface ExtendedMenuItem extends MenuItem {
    squareMenuLabel?: string;
    squareMenuIcon?: string;
    squareMenuColor?: string;
    squareMenuGroup?: ExtendedMenuItemGroup;
    items?: ExtendedMenuItems;
}
export declare type SquareMenuGroups = SquareMenuGroup[];
export interface SquareMenuGroup {
    title: string;
    lines: SquareMenuItem[][];
    items: SquareMenuItem[];
}
export declare type SquareMenuItems = SquareMenuItem[];
export interface SquareMenuItem {
    label?: string;
    color?: string;
    hoverColor?: string;
    icon?: string;
    url?: string;
}
export declare type SquareMenuNumCol = 1 | 2 | 3 | 4 | 6 | 12;
export declare class MenuSquareComponent implements OnInit {
    items: ExtendedMenuItems;
    colNum: SquareMenuNumCol;
    baseColor: string;
    useRouterLink: boolean;
    hovers: {
        [key: string]: boolean;
    };
    squareMenu: {
        groups: SquareMenuGroup[];
    };
    ngOnInit(): void;
    mouseOver(item: SquareMenuItem): void;
    mouseOut(item: SquareMenuItem): void;
    onClick(item: SquareMenuItem, event: MouseEvent): void;
    getSquareMenuGroups(): SquareMenuGroups;
    getSquareMenuItemLines(items: SquareMenuItems): SquareMenuItems[];
    static ɵfac: i0.ɵɵFactoryDef<MenuSquareComponent>;
    static ɵcmp: i0.ɵɵComponentDefWithMeta<MenuSquareComponent, "app-menu-square", never, { "items": "items"; "colNum": "colNum"; "baseColor": "baseColor"; "useRouterLink": "useRouterLink"; }, {}, never>;
}
