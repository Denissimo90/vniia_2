import { Injector } from '@angular/core';
import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { EventBusService } from '../events/eventbus.service';
import * as i0 from "@angular/core";
export declare class RequestInterceptorService implements HttpInterceptor {
    private injector;
    private bus;
    constructor(injector: Injector, bus: EventBusService);
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    handleError(request: HttpRequest<any>, next: HttpHandler, err: HttpErrorResponse): Observable<HttpEvent<any>>;
    addToken(req: HttpRequest<any>, token: string): HttpRequest<any>;
    login(req: HttpRequest<any>, next: HttpHandler, tryRefreshToken: boolean): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDef<RequestInterceptorService>;
    static ɵprov: i0.ɵɵInjectableDef<RequestInterceptorService>;
}
