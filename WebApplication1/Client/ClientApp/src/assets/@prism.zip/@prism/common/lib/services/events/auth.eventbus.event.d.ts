import { Event } from './eventbus.service';
export declare class AuthEventbusEvent implements Event {
    static TYPE_AUTH_SERVICE_ON_TOKEN_READ: string;
    static TYPE_AUTH_SERVICE_ON_TOKEN_RECIVED: string;
    static TYPE_AUTH_SERVICE_ON_NEW_USER_CHANGE: string;
    type: string;
    constructor(typeArg: string);
}
