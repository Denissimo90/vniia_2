import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { ConfigurationService } from '../config/configuration.service';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class ApiInterceptorService implements HttpInterceptor {
    private configService;
    constructor(configService: ConfigurationService);
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDef<ApiInterceptorService>;
    static ɵprov: i0.ɵɵInjectableDef<ApiInterceptorService>;
}
