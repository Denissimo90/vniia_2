import { ElementRef, EventEmitter } from '@angular/core';
import { MessageService } from 'primeng';
import { NgForm } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class ButtonFormValidateDirective {
    private button;
    private form;
    private messageService;
    constructor(button: ElementRef, form: NgForm, messageService: MessageService);
    appValidateForm: NgForm;
    appValidateMessageService: MessageService;
    appSubmitForm: EventEmitter<Event>;
    onClick($event: Event): void;
    static ɵfac: i0.ɵɵFactoryDef<ButtonFormValidateDirective>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<ButtonFormValidateDirective, "button[appSubmitForm],button[appValidateForm],p-button[appSubmitForm],p-button[appValidateForm]", never, { "appValidateForm": "appValidateForm"; "appValidateMessageService": "appValidateMessageService"; }, { "appSubmitForm": "appSubmitForm"; }, never>;
}
