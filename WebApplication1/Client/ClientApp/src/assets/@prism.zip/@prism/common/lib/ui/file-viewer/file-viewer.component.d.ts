import { ElementRef } from '@angular/core';
import { MessageService } from 'primeng/api';
import { DialogComponent } from '../dialog/dialog.component';
import { DomSanitizer, SafeStyle } from '@angular/platform-browser';
import { FileLoadService } from './file-load.service';
import * as Tiff from 'browser-tiff.js';
import * as i0 from "@angular/core";
export declare enum ServeFileType {
    SAVE = "SAVE",
    VIEW = "VIEW"
}
export declare class FileViewerComponent extends DialogComponent {
    private messageService;
    private fileLoadService;
    private sanitizer;
    currentTiffPage: number;
    maxTiffPages: number;
    tiffImage: Tiff;
    scaleRatio: number;
    isTiff: boolean;
    isPDF: boolean;
    url: any;
    mediaType: string;
    isAvailableToDownload: boolean;
    protected data: Blob;
    protected fileName: string;
    tiffContainer: ElementRef;
    constructor(messageService: MessageService, fileLoadService: FileLoadService, sanitizer: DomSanitizer);
    init(data: Blob, mediaType: string, fileName: string, isAvailableToDownload?: boolean): Promise<void>;
    updateTiffCanvas(): void;
    saveFile(): void;
    close(): void;
    scale(ratio: number): void;
    onWheelScroll(event: WheelEvent): void;
    onPageChange(event: any): void;
    getSanitizedTransform(): SafeStyle;
    static ɵfac: i0.ɵɵFactoryDef<FileViewerComponent>;
    static ɵcmp: i0.ɵɵComponentDefWithMeta<FileViewerComponent, "app-file-viewer", never, {}, {}, never>;
}
