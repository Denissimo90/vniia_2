import { Component } from 'ag-grid-community';
export declare class LoadingCellRenderer extends Component {
    constructor();
}
