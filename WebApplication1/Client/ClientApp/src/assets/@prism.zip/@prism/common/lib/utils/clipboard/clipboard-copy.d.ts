export declare function copyTextToClipboard(text: string): void;
