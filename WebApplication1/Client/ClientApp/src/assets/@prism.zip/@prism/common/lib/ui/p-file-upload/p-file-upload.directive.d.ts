import { OnInit } from '@angular/core';
import { FileUpload } from 'primeng/fileupload';
import { AuthService } from '../../services/auth/auth.service';
import { EventBusService } from '../../services/events/eventbus.service';
import * as i0 from "@angular/core";
export declare class PFileUploadDirective implements OnInit {
    private fileUpload;
    private authService;
    private bus;
    static MAX_UPLOAD_FILESIZE: number;
    accept: string;
    customUpload: boolean;
    constructor(fileUpload: FileUpload, authService: AuthService, bus: EventBusService);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDef<PFileUploadDirective>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<PFileUploadDirective, "p-fileUpload", never, { "accept": "accept"; "customUpload": "customUpload"; }, {}, never>;
}
