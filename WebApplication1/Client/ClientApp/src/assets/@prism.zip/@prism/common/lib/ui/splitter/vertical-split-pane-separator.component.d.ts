import { OnInit } from '@angular/core';
import { SplitSeparatorComponent } from './split-pane-separator.component';
import * as i0 from "@angular/core";
export declare class VerticalSplitSeparatorComponent extends SplitSeparatorComponent implements OnInit {
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDef<VerticalSplitSeparatorComponent>;
    static ɵcmp: i0.ɵɵComponentDefWithMeta<VerticalSplitSeparatorComponent, "vertical-split-separator", never, {}, {}, never>;
}
