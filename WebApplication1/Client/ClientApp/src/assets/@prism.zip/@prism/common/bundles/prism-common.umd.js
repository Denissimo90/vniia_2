(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/common'), require('@angular/common/locales/ru'), require('@angular/common/http'), require('primeng/table'), require('primeng/contextmenu'), require('primeng/inputtext'), require('primeng/button'), require('primeng/dialog'), require('primeng/paginator'), require('primeng/tristatecheckbox'), require('primeng/picklist'), require('primeng/blockui'), require('primeng/panel'), require('primeng/menu'), require('primeng/tieredmenu'), require('primeng/toolbar'), require('primeng/overlaypanel'), require('primeng/card'), require('primeng/fileupload'), require('ngx-logger'), require('angular-oauth2-oidc'), require('ag-grid-angular'), require('primeng/dropdown'), require('primeng/autocomplete'), require('primeng/calendar'), require('primeng/checkbox'), require('primeng/keyfilter'), require('primeng/tooltip'), require('primeng/toast'), require('primeng/api'), require('primeng/confirmdialog'), require('@auth0/angular-jwt'), require('rxjs'), require('rxjs/operators'), require('file-saver'), require('@angular/router'), require('primeng'), require('primeng/dom'), require('scroll-into-view-if-needed'), require('@angular/forms'), require('ag-grid-community'), require('color'), require('calculate-size'), require('browser-tiff.js'), require('@angular/platform-browser'), require('primeng/scrollpanel'), require('primeng/treetable'), require('primeng/dataview'), require('primeng/multiselect'), require('primeng/spinner')) :
    typeof define === 'function' && define.amd ? define('@prism/common', ['exports', '@angular/core', '@angular/common', '@angular/common/locales/ru', '@angular/common/http', 'primeng/table', 'primeng/contextmenu', 'primeng/inputtext', 'primeng/button', 'primeng/dialog', 'primeng/paginator', 'primeng/tristatecheckbox', 'primeng/picklist', 'primeng/blockui', 'primeng/panel', 'primeng/menu', 'primeng/tieredmenu', 'primeng/toolbar', 'primeng/overlaypanel', 'primeng/card', 'primeng/fileupload', 'ngx-logger', 'angular-oauth2-oidc', 'ag-grid-angular', 'primeng/dropdown', 'primeng/autocomplete', 'primeng/calendar', 'primeng/checkbox', 'primeng/keyfilter', 'primeng/tooltip', 'primeng/toast', 'primeng/api', 'primeng/confirmdialog', '@auth0/angular-jwt', 'rxjs', 'rxjs/operators', 'file-saver', '@angular/router', 'primeng', 'primeng/dom', 'scroll-into-view-if-needed', '@angular/forms', 'ag-grid-community', 'color', 'calculate-size', 'browser-tiff.js', '@angular/platform-browser', 'primeng/scrollpanel', 'primeng/treetable', 'primeng/dataview', 'primeng/multiselect', 'primeng/spinner'], factory) :
    (global = global || self, factory((global.prism = global.prism || {}, global.prism.common = {}), global.ng.core, global.ng.common, global.ng.common.locales.ru, global.ng.common.http, global.table, global.contextmenu, global.inputtext, global.button, global.dialog, global.paginator, global.tristatecheckbox, global.picklist, global.blockui, global.panel, global.menu, global.tieredmenu, global.toolbar, global.overlaypanel, global.card, global.fileupload, global.ngxLogger, global.angularOauth2Oidc, global.agGridAngular, global.dropdown, global.autocomplete, global.calendar, global.checkbox, global.keyfilter, global.tooltip, global.toast, global.api, global.confirmdialog, global.angularJwt, global.rxjs, global.rxjs.operators, global.fileSaver, global.ng.router, global.primeng, global.dom, global.scrollIntoView, global.ng.forms, global.agGridCommunity, global.Color, global.FontSize__default, global.Tiff, global.ng.platformBrowser, global.scrollpanel, global.treetable, global.dataview, global.multiselect, global.spinner));
}(this, (function (exports, core, common, localRu, http, table, contextmenu, inputtext, button, dialog, paginator, tristatecheckbox, picklist, blockui, panel, menu, tieredmenu, toolbar, overlaypanel, card, fileupload, ngxLogger, angularOauth2Oidc, agGridAngular, dropdown, autocomplete, calendar, checkbox, keyfilter, tooltip, toast, api, confirmdialog, angularJwt, rxjs, operators, fileSaver, router, primeng, dom, scrollIntoView, forms, agGridCommunity, Color, FontSize__default, Tiff, platformBrowser, scrollpanel, treetable, dataview, multiselect, spinner) { 'use strict';

    localRu = localRu && localRu.hasOwnProperty('default') ? localRu['default'] : localRu;
    scrollIntoView = scrollIntoView && scrollIntoView.hasOwnProperty('default') ? scrollIntoView['default'] : scrollIntoView;
    FontSize__default = FontSize__default && FontSize__default.hasOwnProperty('default') ? FontSize__default['default'] : FontSize__default;

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __exportStar(m, exports) {
        for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    var APP_ENV = new core.InjectionToken('env');

    var ConfigurationService = /** @class */ (function () {
        function ConfigurationService(http, env) {
            this.http = http;
            this.env = env;
        }
        Object.defineProperty(ConfigurationService.prototype, "config", {
            get: function () {
                return this._config;
            },
            enumerable: true,
            configurable: true
        });
        ConfigurationService.prototype.appendConfig = function (config) {
            this._config = __assign(__assign({}, this._config), config);
        };
        ConfigurationService.prototype.getRestConfig = function (uri) {
            return __awaiter(this, void 0, void 0, function () {
                var data, e_1;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            _a.trys.push([0, 2, , 3]);
                            return [4 /*yield*/, this.http.get(uri).toPromise()];
                        case 1:
                            data = _a.sent();
                            this.appendConfig(data);
                            this._config.offlineMode = false;
                            return [3 /*break*/, 3];
                        case 2:
                            e_1 = _a.sent();
                            console.log(e_1);
                            this._config.offlineMode = true;
                            return [3 /*break*/, 3];
                        case 3: return [2 /*return*/];
                    }
                });
            });
        };
        Object.defineProperty(ConfigurationService.prototype, "storagePrefix", {
            get: function () {
                return this.config ? (this.config.clientId + '-') : '';
            },
            enumerable: true,
            configurable: true
        });
        ConfigurationService.prototype.init = function () {
            return __awaiter(this, void 0, void 0, function () {
                var _a;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            _a = this;
                            return [4 /*yield*/, this.http.get('config' + (this.env ? ('.' + this.env) : '') + '.json?' + new Date()).toPromise()];
                        case 1:
                            _a._config = (_b.sent());
                            if (!this._config.api && !this._config.offlineMode) {
                                throw new Error('config file must contain "api" field with api server url or set offlineMode to "true"');
                            }
                            if (this._config.restConfig === null) {
                                throw new Error('config file must contain "restConfig" field');
                            }
                            if (!(!this._config.offlineMode && !!this._config.api && !!this._config.restConfig)) return [3 /*break*/, 3];
                            return [4 /*yield*/, this.getRestConfig(this._config.api + '/config/front-end')];
                        case 2:
                            _b.sent();
                            _b.label = 3;
                        case 3:
                            if (!this._config.offlineMode) {
                                if (!this._config.clientId) {
                                    throw new Error('config file must contain "clientId" field');
                                }
                                if (!this._config.version) {
                                    throw new Error('config file must contain "version" field');
                                }
                                if (this._config.serverLogLevel !== null && this._config.serverLogLevel !== ngxLogger.NgxLoggerLevel.OFF && !this._config.serverLoggingUrl) {
                                    throw new Error('config file must contain "serverLoggingUrl" field if "serverLogLevel" not equals "OFF"');
                                }
                                if (this._config.logLevel === null) {
                                    throw new Error('config file must contain "logLevel" field');
                                }
                                if (this._config.condition === null) {
                                    throw new Error('config file must contain "condition" field');
                                }
                            }
                            return [2 /*return*/];
                    }
                });
            });
        };
        ConfigurationService.ɵfac = function ConfigurationService_Factory(t) { return new (t || ConfigurationService)(core["ɵɵinject"](http.HttpClient), core["ɵɵinject"](APP_ENV)); };
        ConfigurationService.ɵprov = core["ɵɵdefineInjectable"]({ token: ConfigurationService, factory: ConfigurationService.ɵfac, providedIn: 'root' });
        return ConfigurationService;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](ConfigurationService, [{
            type: core.Injectable,
            args: [{ providedIn: 'root' }]
        }], function () { return [{ type: http.HttpClient }, { type: String, decorators: [{
                    type: core.Inject,
                    args: [APP_ENV]
                }] }]; }, null); })();

    var User = /** @class */ (function () {
        function User(clientId, username, name, employeeId, personId, depnum, description, changePassword, authorities) {
            this.clientId = clientId;
            this.username = username;
            this.name = name;
            this.employeeId = employeeId;
            this.personId = personId;
            this.depnum = depnum;
            this.description = description;
            this.changePassword = changePassword;
            this.authorities = authorities;
            this._roles = {};
            if (this.authorities[this.clientId] && this.authorities[this.clientId]['roles']) {
                this._roles = __assign({}, this.mapRole(this.authorities[this.clientId]['roles']));
            }
            if (this.authorities['realm'] && this.authorities['realm']['roles']) {
                this._roles = __assign(__assign({}, this._roles), this.mapRole(this.authorities['realm']['roles']));
            }
            if (this.authorities['roles'] && this.authorities['roles']) {
                this._roles = __assign(__assign({}, this._roles), this.mapRole(this.authorities['roles']));
            }
        }
        Object.defineProperty(User.prototype, "roles", {
            get: function () {
                return this._roles;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(User.prototype, "shortname", {
            get: function () {
                return this.name || this.username;
            },
            enumerable: true,
            configurable: true
        });
        User.prototype.mapRole = function (roles) {
            return roles.reduce(function (result, cur) {
                result[cur.replace(' ', '_').replace('-', '_')] = true;
                return result;
            }, {});
        };
        return User;
    }());

    var AuthEventbusEvent = /** @class */ (function () {
        function AuthEventbusEvent(typeArg) {
            this.type = typeArg;
        }
        AuthEventbusEvent.TYPE_AUTH_SERVICE_ON_TOKEN_READ = 'typeAuthServiceOnTokenRead';
        AuthEventbusEvent.TYPE_AUTH_SERVICE_ON_TOKEN_RECIVED = 'typeAuthServiceOnTokenRecived';
        AuthEventbusEvent.TYPE_AUTH_SERVICE_ON_NEW_USER_CHANGE = 'typeAuthServiceOnUserChange';
        return AuthEventbusEvent;
    }());

    var EventBusService = /** @class */ (function () {
        function EventBusService() {
            this.handlers = new Map();
            this.id = Math.random();
        }
        EventBusService.prototype.on = function (event, handler) {
            var _this = this;
            var h = this.handlers.get(event.type);
            if (h == null) {
                h = [];
                this.handlers.set(event.type, h);
            }
            h.push(handler);
            return {
                unregister: function () {
                    var lh = _this.handlers.get(event.type) || [];
                    var index = lh.indexOf(handler);
                    if (index === -1) {
                        throw new Error('Event handler not registered.');
                    }
                    lh.splice(index, 1);
                    if (lh.length === 0) {
                        _this.handlers.delete(event.type);
                    }
                }
            };
        };
        EventBusService.prototype.emit = function (event) {
            var handlers = this.handlers.get(event.type) || [];
            handlers.forEach(function (h) {
                h(event);
            });
        };
        return EventBusService;
    }());

    var AuthService = /** @class */ (function () {
        function AuthService(oauthService, configurationService, bus, location, _logger) {
            this.oauthService = oauthService;
            this.configurationService = configurationService;
            this.bus = bus;
            this.location = location;
            this._logger = _logger;
        }
        Object.defineProperty(AuthService.prototype, "logger", {
            get: function () {
                return !!this._logger ? this._logger : console;
            },
            enumerable: true,
            configurable: true
        });
        AuthService.prototype.init = function () {
            return __awaiter(this, void 0, void 0, function () {
                var autoConfig, e_1, e_2;
                var _this = this;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            if (!this.configurationService.config.auth) {
                                return [2 /*return*/];
                            }
                            autoConfig = this.getAutoConfig(this.configurationService, this.location);
                            this.oauthService.configure(autoConfig);
                            this.oauthService.tokenValidationHandler = new angularOauth2Oidc.JwksValidationHandler();
                            this.storage = this.getStorage(autoConfig);
                            this.oauthService.setStorage(this.storage);
                            this.oauthService.events.subscribe(function (_a) {
                                var type = _a.type;
                                if (type === 'token_received') {
                                    _this.bus.emit(new AuthEventbusEvent(AuthEventbusEvent.TYPE_AUTH_SERVICE_ON_TOKEN_RECIVED));
                                }
                            });
                            if (!!this.storage) {
                                this.storage.removeItem('access_token');
                            }
                            this.initLogger();
                            _a.label = 1;
                        case 1:
                            _a.trys.push([1, 8, , 9]);
                            return [4 /*yield*/, this.oauthService.loadDiscoveryDocumentAndTryLogin()];
                        case 2:
                            _a.sent();
                            if (!this.oauthService.getAccessToken()) return [3 /*break*/, 3];
                            this.readToken();
                            this.logger.log('Login to ' + this.configurationService.config.clientId + ' user: ', this.user);
                            return [3 /*break*/, 7];
                        case 3:
                            _a.trys.push([3, 5, , 6]);
                            return [4 /*yield*/, this.oauthService.silentRefresh()];
                        case 4:
                            _a.sent();
                            return [3 /*break*/, 6];
                        case 5:
                            e_1 = _a.sent();
                            return [3 /*break*/, 6];
                        case 6:
                            if (this.oauthService.getAccessToken()) {
                                this.readToken();
                                this.logger.log('Login to ' + this.configurationService.config.clientId + ' user: ', this.user);
                            }
                            _a.label = 7;
                        case 7: return [3 /*break*/, 9];
                        case 8:
                            e_2 = _a.sent();
                            this.logger.error(e_2);
                            this.logout();
                            return [2 /*return*/, new Promise(function (r) { return setTimeout(r, 1000); })]; // wait for redirect
                        case 9: return [2 /*return*/];
                    }
                });
            });
        };
        AuthService.prototype.getAutoConfig = function (configurationService, location) {
            var _a, _b;
            var autoConfig = new angularOauth2Oidc.AuthConfig();
            autoConfig.requireHttps = false;
            if (!!((_a = configurationService.config) === null || _a === void 0 ? void 0 : _a.auth) && configurationService.config.auth.toUpperCase().startsWith('HTTP')) {
                autoConfig.issuer = configurationService.config.auth;
            }
            else {
                autoConfig.issuer = window.location.origin + (((_b = configurationService.config) === null || _b === void 0 ? void 0 : _b.auth) || '');
            }
            autoConfig.clientId = configurationService.config.clientId;
            autoConfig.oidc = true;
            autoConfig.requestAccessToken = true;
            autoConfig.silentRefreshRedirectUri = window.location.origin + location.prepareExternalUrl('/assets/silent-refresh.html');
            autoConfig.silentRefreshTimeout = 2000;
            return autoConfig;
        };
        AuthService.prototype.getStorage = function (autoConfig) {
            return {
                getItem: function (key) { return localStorage.getItem(autoConfig.clientId + '-' + key); },
                removeItem: function (key) { return localStorage.removeItem(autoConfig.clientId + '-' + key); },
                setItem: function (key, data) { return localStorage.setItem(autoConfig.clientId + '-' + key, data); }
            };
        };
        AuthService.prototype.initLogger = function () {
            var loggingConfig = new ngxLogger.LoggerConfig();
            loggingConfig.serverLoggingUrl = this.configurationService.config.api + this.configurationService.config.serverLoggingUrl;
            loggingConfig.serverLogLevel = this.configurationService.config.serverLogLevel;
            loggingConfig.level = this.configurationService.config.logLevel;
            this._logger.updateConfig(loggingConfig);
        };
        AuthService.prototype.login = function (tryRefreshToken, redirectUri) {
            if (tryRefreshToken === void 0) { tryRefreshToken = true; }
            return __awaiter(this, void 0, void 0, function () {
                var tokenRefreshed, e_3;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            if (!this.storage) {
                                this.storage = this.getStorage(this.getAutoConfig(this.configurationService, this.location));
                            }
                            this.storage.removeItem('access_token');
                            tokenRefreshed = false;
                            if (!tryRefreshToken) return [3 /*break*/, 4];
                            _a.label = 1;
                        case 1:
                            _a.trys.push([1, 3, , 4]);
                            this.logger.trace('Trying silent refresh');
                            return [4 /*yield*/, this.oauthService.silentRefresh()];
                        case 2:
                            _a.sent();
                            this.readToken();
                            tokenRefreshed = true;
                            this.logger.trace('Token refreshed');
                            return [3 /*break*/, 4];
                        case 3:
                            e_3 = _a.sent();
                            this.logger.trace(e_3);
                            return [3 /*break*/, 4];
                        case 4:
                            if (tokenRefreshed) {
                                return [2 /*return*/, true];
                            }
                            this.oauthService.redirectUri = redirectUri || window.location.href;
                            this.oauthService.initImplicitFlow();
                            return [2 /*return*/, new Promise(function (r) { return setTimeout(r, 1000); })]; // wait for redirect
                    }
                });
            });
        };
        AuthService.prototype.readToken = function () {
            var token = new angularJwt.JwtHelperService().decodeToken(this.oauthService.getAccessToken());
            var clientId = this.configurationService.config.clientId;
            var authorities = __assign(__assign({}, token['resource_access']), { realm: token.realm_access, roles: (token.roles || '').split(',').map(function (r) { return r.replace(/\s/g, ''); }) });
            this._user = new User(clientId, token['preferred_username'], token['name'], token['employee_id'], token['person_id'], token['department'], token['description'], !!token['change_password'], authorities);
            this.bus.emit(new AuthEventbusEvent(AuthEventbusEvent.TYPE_AUTH_SERVICE_ON_TOKEN_READ));
        };
        AuthService.prototype.getAccessToken = function () {
            return this.oauthService.getAccessToken();
        };
        Object.defineProperty(AuthService.prototype, "user", {
            get: function () {
                return this._user;
            },
            enumerable: true,
            configurable: true
        });
        AuthService.prototype.isLoggedIn = function () {
            return this.oauthService.getAccessToken() != null;
        };
        AuthService.prototype.logout = function (postLogoutRedirectUri) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    this.oauthService.postLogoutRedirectUri = postLogoutRedirectUri
                        || (window.location.origin + this.location.prepareExternalUrl('/'));
                    this.oauthService.logOut();
                    return [2 /*return*/];
                });
            });
        };
        AuthService.ɵfac = function AuthService_Factory(t) { return new (t || AuthService)(core["ɵɵinject"](angularOauth2Oidc.OAuthService), core["ɵɵinject"](ConfigurationService), core["ɵɵinject"](EventBusService), core["ɵɵinject"](common.Location), core["ɵɵinject"](ngxLogger.NGXLogger)); };
        AuthService.ɵprov = core["ɵɵdefineInjectable"]({ token: AuthService, factory: AuthService.ɵfac });
        return AuthService;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](AuthService, [{
            type: core.Injectable
        }], function () { return [{ type: angularOauth2Oidc.OAuthService }, { type: ConfigurationService }, { type: EventBusService }, { type: common.Location }, { type: ngxLogger.NGXLogger }]; }, null); })();

    var UserEmployment = /** @class */ (function () {
        function UserEmployment() {
        }
        return UserEmployment;
    }());

    var UserService = /** @class */ (function () {
        function UserService(auth, configService, httpClient) {
            this.auth = auth;
            this.configService = configService;
            this.httpClient = httpClient;
            this._personalNumberChange = new core.EventEmitter();
        }
        Object.defineProperty(UserService.prototype, "exist", {
            get: function () {
                return !!this.auth.user;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserService.prototype, "roles", {
            get: function () {
                return this.user.roles;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserService.prototype, "username", {
            get: function () {
                return this.user.username;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserService.prototype, "name", {
            get: function () {
                return this.user.name;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserService.prototype, "employeeId", {
            get: function () {
                return this.user.employeeId;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserService.prototype, "personId", {
            get: function () {
                return this.user.personId;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserService.prototype, "depnum", {
            get: function () {
                return this.user.depnum;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserService.prototype, "description", {
            get: function () {
                return this.user.description;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserService.prototype, "shortname", {
            get: function () {
                return this.user.shortname;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserService.prototype, "user", {
            get: function () {
                return this.auth.user
                    ? this.auth.user
                    : new User(null, 'nonauthorized', null, null, null, null, null, false, []);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserService.prototype, "roleKeys", {
            get: function () {
                return Object.keys(this.roles);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserService.prototype, "employments", {
            get: function () {
                return this._employments;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserService.prototype, "employment", {
            get: function () {
                var _this = this;
                return this._employments
                    ? this._employments.find(function (p) { return p.personalNumber == _this._personalNumber; })
                    : new UserEmployment();
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserService.prototype, "personalNumber", {
            get: function () {
                return this._personalNumber;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserService.prototype, "personalNumberChange", {
            get: function () {
                return this._personalNumberChange;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserService.prototype, "personalNumberEmptyAndRequired", {
            get: function () {
                return this.exist && this._employments.length > 1 && !localStorage.getItem(this.getStorageKey());
            },
            enumerable: true,
            configurable: true
        });
        UserService.prototype.init = function () {
            return __awaiter(this, void 0, void 0, function () {
                var _a, _b;
                var _this = this;
                return __generator(this, function (_c) {
                    switch (_c.label) {
                        case 0:
                            if (!this.exist) return [3 /*break*/, 4];
                            window.addEventListener('storage', function (e) {
                                if (e.key == _this.getStorageKey()) {
                                    _this._personalNumber = e.newValue;
                                    if (!_this._personalNumber && _this._employments.length > 0) {
                                        _this._personalNumber = _this._employments[0].personalNumber;
                                    }
                                    _this.personalNumberChange.emit(_this._personalNumber);
                                }
                            });
                            this._personalNumber = localStorage.getItem(this.getStorageKey());
                            _a = this;
                            if (!!!this.configService.config.offlineMode) return [3 /*break*/, 1];
                            _b = [];
                            return [3 /*break*/, 3];
                        case 1: return [4 /*yield*/, this.getPersonals()];
                        case 2:
                            _b = _c.sent();
                            _c.label = 3;
                        case 3:
                            _a._employments = _b;
                            if (this._personalNumber) {
                                if (this._employments.findIndex(function (p) { return p.personalNumber == _this._personalNumber; }) < 0) {
                                    this._personalNumber = null;
                                    localStorage.removeItem(this.getStorageKey());
                                }
                            }
                            if (!this._personalNumber && this._employments.length > 0) {
                                this._personalNumber = this._employments[0].personalNumber;
                            }
                            _c.label = 4;
                        case 4: return [2 /*return*/];
                    }
                });
            });
        };
        UserService.prototype.select = function (personal) {
            localStorage.setItem(this.getStorageKey(), personal.personalNumber);
            this._personalNumber = personal.personalNumber;
            this.personalNumberChange.emit(this._personalNumber);
        };
        UserService.prototype.getPersonals = function () {
            return this.httpClient.get('/user/employments').toPromise();
        };
        UserService.prototype.getStorageKey = function () {
            return this.configService.storagePrefix + UserService.STORAGE_KEY + this.personId;
        };
        UserService.STORAGE_KEY = 'User-Personal-Number';
        UserService.ɵfac = function UserService_Factory(t) { return new (t || UserService)(core["ɵɵinject"](AuthService), core["ɵɵinject"](ConfigurationService), core["ɵɵinject"](http.HttpClient)); };
        UserService.ɵprov = core["ɵɵdefineInjectable"]({ token: UserService, factory: UserService.ɵfac, providedIn: 'root' });
        return UserService;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](UserService, [{
            type: core.Injectable,
            args: [{ providedIn: 'root' }]
        }], function () { return [{ type: AuthService }, { type: ConfigurationService }, { type: http.HttpClient }]; }, null); })();

    var ApiInterceptorService = /** @class */ (function () {
        function ApiInterceptorService(configService) {
            this.configService = configService;
        }
        ApiInterceptorService.prototype.intercept = function (req, next) {
            var isApiUrl = this.configService.config && !req.url.trim().toUpperCase().startsWith('HTTP')
                && (!!this.configService.config.offlineMode ||
                    (!!this.configService.config.auth && !req.url.trim().toUpperCase().startsWith(this.configService.config.auth.toUpperCase())))
                && !req.url.trim().toUpperCase().startsWith('/API/');
            if (isApiUrl) {
                var url = this.configService.config.api.replace(/\/*$/, '') + '/' + req.url.replace(/^\/*/, '');
                return next.handle(req.clone({ url: url }));
            }
            else {
                return next.handle(req);
            }
        };
        ApiInterceptorService.ɵfac = function ApiInterceptorService_Factory(t) { return new (t || ApiInterceptorService)(core["ɵɵinject"](ConfigurationService)); };
        ApiInterceptorService.ɵprov = core["ɵɵdefineInjectable"]({ token: ApiInterceptorService, factory: ApiInterceptorService.ɵfac });
        return ApiInterceptorService;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](ApiInterceptorService, [{
            type: core.Injectable
        }], function () { return [{ type: ConfigurationService }]; }, null); })();


    (function (HTTPErrors) {
        HTTPErrors[HTTPErrors["TYPE_INTERNAL_SERVER_ERROR"] = 500] = "TYPE_INTERNAL_SERVER_ERROR";
        HTTPErrors[HTTPErrors["TYPE_NOT_IMPLEMENTED"] = 501] = "TYPE_NOT_IMPLEMENTED";
        HTTPErrors[HTTPErrors["TYPE_BAD_GATEWAY"] = 502] = "TYPE_BAD_GATEWAY";
        HTTPErrors[HTTPErrors["TYPE_SERVICE_UNAVAILABLE"] = 503] = "TYPE_SERVICE_UNAVAILABLE";
        HTTPErrors[HTTPErrors["TYPE_GATEWAY_TIMEOUT"] = 504] = "TYPE_GATEWAY_TIMEOUT";
        HTTPErrors[HTTPErrors["TYPE_HTTP_VERSION_NOT_SUPPORTED"] = 505] = "TYPE_HTTP_VERSION_NOT_SUPPORTED";
        HTTPErrors[HTTPErrors["TYPE_INSUFFICIENT_STORAGE"] = 507] = "TYPE_INSUFFICIENT_STORAGE";
        HTTPErrors[HTTPErrors["TYPE_NOT_EXTENDED"] = 510] = "TYPE_NOT_EXTENDED";
        HTTPErrors[HTTPErrors["TYPE_NETWORK_AUTHENTICATION_REQUIRED"] = 511] = "TYPE_NETWORK_AUTHENTICATION_REQUIRED";
        HTTPErrors[HTTPErrors["TYPE_BAD_REQUEST"] = 400] = "TYPE_BAD_REQUEST";
        HTTPErrors[HTTPErrors["TYPE_UNAUTHORIZED"] = 401] = "TYPE_UNAUTHORIZED";
        HTTPErrors[HTTPErrors["TYPE_FORBIDDEN"] = 403] = "TYPE_FORBIDDEN";
        HTTPErrors[HTTPErrors["TYPE_NOT_FOUND"] = 404] = "TYPE_NOT_FOUND";
        HTTPErrors[HTTPErrors["TYPE_METHOD_NOT_ALLOWED"] = 405] = "TYPE_METHOD_NOT_ALLOWED";
        HTTPErrors[HTTPErrors["TYPE_NOT_ACCEPTABLE"] = 406] = "TYPE_NOT_ACCEPTABLE";
        HTTPErrors[HTTPErrors["TYPE_REQUEST_TIMEOUT"] = 408] = "TYPE_REQUEST_TIMEOUT";
        HTTPErrors[HTTPErrors["TYPE_CONFLICT"] = 409] = "TYPE_CONFLICT";
        HTTPErrors[HTTPErrors["TYPE_PRECONDITION_FAILED"] = 412] = "TYPE_PRECONDITION_FAILED";
        HTTPErrors[HTTPErrors["TYPE_EXPECTATION_FAILED"] = 417] = "TYPE_EXPECTATION_FAILED";
        HTTPErrors[HTTPErrors["TYPE_PAYLOAD_TOO_LARGE"] = 413] = "TYPE_PAYLOAD_TOO_LARGE";
        HTTPErrors[HTTPErrors["TYPE_URI_TOO_LONG"] = 414] = "TYPE_URI_TOO_LONG";
        HTTPErrors[HTTPErrors["TYPE_UNSUPPORTED_MEDIA_TYPE"] = 415] = "TYPE_UNSUPPORTED_MEDIA_TYPE";
        HTTPErrors[HTTPErrors["TYPE_UNPROCESSABLE_ENTITY"] = 422] = "TYPE_UNPROCESSABLE_ENTITY";
        HTTPErrors[HTTPErrors["TYPE_LOCKED"] = 423] = "TYPE_LOCKED";
        HTTPErrors[HTTPErrors["TYPE_FAILED_DEPENDENCY"] = 424] = "TYPE_FAILED_DEPENDENCY";
        HTTPErrors[HTTPErrors["TYPE_UPGRADE_REQUIRED"] = 426] = "TYPE_UPGRADE_REQUIRED";
        HTTPErrors[HTTPErrors["TYPE_PRECONDITION_REQUIRED"] = 428] = "TYPE_PRECONDITION_REQUIRED";
        HTTPErrors[HTTPErrors["TYPE_TOO_MANY_REQUESTS"] = 429] = "TYPE_TOO_MANY_REQUESTS";
        HTTPErrors[HTTPErrors["TYPE_REQUEST_HEADER_FIELDS_TOO_LARGE"] = 431] = "TYPE_REQUEST_HEADER_FIELDS_TOO_LARGE";
        HTTPErrors[HTTPErrors["TYPE_REQUESTED_HOST_UNAVAILABLE"] = 434] = "TYPE_REQUESTED_HOST_UNAVAILABLE";
        HTTPErrors[HTTPErrors["TYPE_RETRY_WITH"] = 449] = "TYPE_RETRY_WITH";
        HTTPErrors[HTTPErrors["TYPE_UNAVAILABLE_FOR_LEGAL_REASONS"] = 451] = "TYPE_UNAVAILABLE_FOR_LEGAL_REASONS";
        HTTPErrors[HTTPErrors["TYPE_UNCKNOW_ERROR"] = 999] = "TYPE_UNCKNOW_ERROR";
        HTTPErrors[HTTPErrors["TYPE_NETWROK_IO_ERROR"] = 10001] = "TYPE_NETWROK_IO_ERROR";
        HTTPErrors[HTTPErrors["TYPE_SEE_OTHER"] = 303] = "TYPE_SEE_OTHER";
    })(exports.HTTPErrors || (exports.HTTPErrors = {}));
    var HTTPError = /** @class */ (function () {
        function HTTPError() {
        }
        HTTPError.getHttpErrorByType = function (code) {
            var e_1, _a;
            try {
                for (var _b = __values(Object.keys(exports.HTTPErrors)), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var field = _c.value;
                    var isValueProperty = parseInt(field, 10) >= 0;
                    if (isValueProperty) {
                        return exports.HTTPErrors[field];
                    }
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_1) throw e_1.error; }
            }
            return exports.HTTPErrors.TYPE_UNCKNOW_ERROR;
        };
        HTTPError.getHttpErrorByName = function (name) {
            if (name in exports.HTTPErrors) {
                return exports.HTTPErrors[name];
            }
            return exports.HTTPErrors.TYPE_UNCKNOW_ERROR;
        };
        return HTTPError;
    }());
    var HttpEventbusEvent = /** @class */ (function () {
        function HttpEventbusEvent(httpError, message, code, callback) {
            this.type = "HttpEventbusEvent";
            this.httpError = httpError;
            this.message = message;
            this.code = code;
            this.callback = callback;
        }
        return HttpEventbusEvent;
    }());

    var RequestInterceptorService = /** @class */ (function () {
        function RequestInterceptorService(injector, bus) {
            this.injector = injector;
            this.bus = bus;
        }
        RequestInterceptorService.prototype.intercept = function (request, next) {
            var _this = this;
            var authService = this.injector.get(AuthService);
            if (authService.getAccessToken()) {
                request = this.addToken(request, authService.getAccessToken());
            }
            return next.handle(request).pipe(operators.catchError(function (err) {
                var subject = new rxjs.Subject();
                if (err.error instanceof Blob) {
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        var clonedErr = __assign({}, err);
                        var el = e.target || e.srcElement;
                        clonedErr.error = err.error.type === "application/json"
                            ? JSON.parse(el['result'])
                            : el['result'];
                        subject.error(new http.HttpErrorResponse(clonedErr));
                    };
                    reader.onerror = function (e) {
                        subject.error(err);
                    };
                    reader.readAsText(err.error);
                    return subject.pipe(operators.catchError(function (err) {
                        return _this.handleError(request, next, err);
                    }));
                }
                else if (err.error instanceof ArrayBuffer) {
                    var clonedErr = __assign({}, err);
                    clonedErr.error = JSON.parse(String.fromCharCode.apply(null, new Uint8Array(err.error)));
                    return _this.handleError(request, next, new http.HttpErrorResponse(clonedErr));
                }
                return _this.handleError(request, next, err);
            }));
        };
        RequestInterceptorService.prototype.handleError = function (request, next, err) {
            if (err.error instanceof ProgressEvent) {
                this.bus.emit(new HttpEventbusEvent(exports.HTTPErrors.TYPE_NETWROK_IO_ERROR, err.message));
            }
            else {
                switch (err.status) {
                    case exports.HTTPErrors.TYPE_BAD_REQUEST: {
                        if (err.error && err.error.error === 'invalid_grant') {
                            return this.login(request, next, false);
                        }
                        break;
                    }
                    case exports.HTTPErrors.TYPE_UNAUTHORIZED: {
                        return this.login(request, next, true);
                    }
                    case exports.HTTPErrors.TYPE_BAD_GATEWAY: {
                        this.bus.emit(new HttpEventbusEvent(exports.HTTPErrors.TYPE_BAD_GATEWAY, err.error.message));
                        break;
                    }
                }
            }
            return rxjs.throwError(err);
        };
        RequestInterceptorService.prototype.addToken = function (req, token) {
            if (!token) {
                return req;
            }
            return req.clone({ setHeaders: { Authorization: 'Bearer ' + token } });
        };
        RequestInterceptorService.prototype.login = function (req, next, tryRefreshToken) {
            var _this = this;
            var authService = this.injector.get(AuthService);
            return rxjs.from(authService.login(tryRefreshToken)).pipe(operators.switchMap(function (res) {
                return next.handle(_this.addToken(req, authService.getAccessToken()));
            }));
        };
        RequestInterceptorService.ɵfac = function RequestInterceptorService_Factory(t) { return new (t || RequestInterceptorService)(core["ɵɵinject"](core.Injector), core["ɵɵinject"](EventBusService)); };
        RequestInterceptorService.ɵprov = core["ɵɵdefineInjectable"]({ token: RequestInterceptorService, factory: RequestInterceptorService.ɵfac });
        return RequestInterceptorService;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](RequestInterceptorService, [{
            type: core.Injectable
        }], function () { return [{ type: core.Injector }, { type: EventBusService }]; }, null); })();

    var PersonalNumberInterceptorService = /** @class */ (function () {
        function PersonalNumberInterceptorService(injector) {
            this.injector = injector;
        }
        PersonalNumberInterceptorService.prototype.intercept = function (request, next) {
            var configService = this.injector.get(ConfigurationService);
            var userService = this.injector.get(UserService);
            var authUrl = configService.config ? configService.config.auth : '';
            if (request.url.indexOf(authUrl || '') === -1 && userService.personalNumber) {
                request = request.clone({ setHeaders: { 'User-Personal-Number': userService.personalNumber } });
            }
            return next.handle(request);
        };
        PersonalNumberInterceptorService.ɵfac = function PersonalNumberInterceptorService_Factory(t) { return new (t || PersonalNumberInterceptorService)(core["ɵɵinject"](core.Injector)); };
        PersonalNumberInterceptorService.ɵprov = core["ɵɵdefineInjectable"]({ token: PersonalNumberInterceptorService, factory: PersonalNumberInterceptorService.ɵfac });
        return PersonalNumberInterceptorService;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](PersonalNumberInterceptorService, [{
            type: core.Injectable
        }], function () { return [{ type: core.Injector }]; }, null); })();

    var DateInterceptorService = /** @class */ (function () {
        function DateInterceptorService() {
            this.dateRegEx = /^((\d{4}-\d\d-\d\d)|(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(\.\d+)?(([+-]\d\d:\d\d)|Z)?))$/;
        }
        DateInterceptorService.prototype.intercept = function (req, next) {
            var _this = this;
            return next.handle(req).pipe(operators.tap(function (event) {
                if (event instanceof http.HttpResponse && req.responseType == 'json') {
                    var body = event.body;
                    _this.convertToDate(body, '', new Map());
                }
            }));
        };
        DateInterceptorService.prototype.convertToDate = function (body, path, typesCache) {
            var e_1, _a;
            if (body === null || body === undefined) {
                return;
            }
            if (typeof body !== 'object') {
                return;
            }
            try {
                for (var _b = __values(Object.keys(body)), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var key = _c.value;
                    var value = body[key];
                    if (value == null) {
                        continue;
                    }
                    var curPath = path + '.' + (Array.isArray(body) ? '' : key);
                    if (typesCache.has(curPath)) {
                        if (typesCache.get(curPath) == 'date') {
                            body[key] = new Date(value);
                        }
                        else if (typesCache.get(curPath) == 'object') {
                            this.convertToDate(value, curPath, typesCache);
                        }
                    }
                    else if (!(key == 'value' && body.type) && this.dateRegEx.test(value)) {
                        body[key] = new Date(value);
                        typesCache.set(curPath, 'date');
                    }
                    else if (typeof value === 'object') {
                        this.convertToDate(value, curPath, typesCache);
                        typesCache.set(curPath, 'object');
                    }
                    else {
                        typesCache.set(curPath, 'other');
                    }
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_1) throw e_1.error; }
            }
        };
        DateInterceptorService.ɵfac = function DateInterceptorService_Factory(t) { return new (t || DateInterceptorService)(); };
        DateInterceptorService.ɵprov = core["ɵɵdefineInjectable"]({ token: DateInterceptorService, factory: DateInterceptorService.ɵfac });
        return DateInterceptorService;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](DateInterceptorService, [{
            type: core.Injectable
        }], null, null); })();

    var LoginGuard = /** @class */ (function () {
        function LoginGuard(authService, location, configurationService) {
            this.authService = authService;
            this.location = location;
            this.configurationService = configurationService;
        }
        LoginGuard.prototype.canActivate = function (route, state) {
            if (!this.authService.isLoggedIn() && !!this.configurationService.config.auth) {
                var redirectUri = window.location.origin + this.location.prepareExternalUrl(state.url);
                return this.authService.login(true, redirectUri);
            }
            return true;
        };
        LoginGuard.ɵfac = function LoginGuard_Factory(t) { return new (t || LoginGuard)(core["ɵɵinject"](AuthService), core["ɵɵinject"](common.Location), core["ɵɵinject"](ConfigurationService)); };
        LoginGuard.ɵprov = core["ɵɵdefineInjectable"]({ token: LoginGuard, factory: LoginGuard.ɵfac });
        return LoginGuard;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](LoginGuard, [{
            type: core.Injectable
        }], function () { return [{ type: AuthService }, { type: common.Location }, { type: ConfigurationService }]; }, null); })();

    function Extension(ctr) {
        return function (target, propertyKey, descriptor) {
            var originalFunc = descriptor.value;
            ctr.prototype[propertyKey] = function () {
                var args = [];
                for (var _i = 0; _i < arguments.length; _i++) {
                    args[_i] = arguments[_i];
                }
                return originalFunc.apply(void 0, __spread([this], args));
            };
        };
    }

    var PromiseCanceled = /** @class */ (function () {
        function PromiseCanceled() {
            this.isPromiseCanceled = true;
            this.name = 'PromiseCanceled';
            this.message = 'PROMISE CANCELLED';
        }
        return PromiseCanceled;
    }());
    var CancellationToken = /** @class */ (function () {
        function CancellationToken() {
        }
        CancellationToken.autoCancel = function (promise, token) {
            return Promise.race([promise, token.next()]);
        };
        CancellationToken.prototype.next = function () {
            var _this = this;
            this.cancel();
            this.promise = new Promise(function (resolve, reject) {
                _this.reject = reject;
            });
            return this.promise;
        };
        CancellationToken.prototype.cancel = function () {
            if (this.reject) {
                this.reject(new PromiseCanceled());
            }
        };
        __decorate([
            Extension(Promise)
        ], CancellationToken, "autoCancel", null);
        return CancellationToken;
    }());

    var GlobalErrorHandler = /** @class */ (function () {
        function GlobalErrorHandler(bus, zone) {
            this.bus = bus;
            this.zone = zone;
        }
        GlobalErrorHandler.prototype.handleError = function (ex) {
            var _this = this;
            if (ex.rejection) {
                ex = ex.rejection;
            }
            if (ex instanceof http.HttpErrorResponse) {
                if (ex.error instanceof ProgressEvent
                    || ex.status == exports.HTTPErrors.TYPE_BAD_GATEWAY) {
                    console.error(ex);
                }
                else {
                    this.zone.run(function () {
                        if (ex.status == exports.HTTPErrors.TYPE_INTERNAL_SERVER_ERROR) {
                            console.error(ex);
                        }
                        if (ex.error) {
                            _this.bus.emit(new HttpEventbusEvent(ex.status, (ex.error.message || ex.error.error_description), ex.error.code));
                        }
                        else {
                            _this.bus.emit(new HttpEventbusEvent(ex.status, ex.message));
                        }
                    });
                }
            }
            else if (ex instanceof PromiseCanceled) {
                // ignore
            }
            else {
                console.error(ex);
            }
        };
        GlobalErrorHandler.ɵfac = function GlobalErrorHandler_Factory(t) { return new (t || GlobalErrorHandler)(core["ɵɵinject"](EventBusService), core["ɵɵinject"](core.NgZone)); };
        GlobalErrorHandler.ɵprov = core["ɵɵdefineInjectable"]({ token: GlobalErrorHandler, factory: GlobalErrorHandler.ɵfac });
        return GlobalErrorHandler;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](GlobalErrorHandler, [{
            type: core.Injectable
        }], function () { return [{ type: EventBusService }, { type: core.NgZone }]; }, null); })();

    var DialogService = /** @class */ (function () {
        function DialogService(componentFactoryResolver, appRef, injector) {
            this.componentFactoryResolver = componentFactoryResolver;
            this.appRef = appRef;
            this.injector = injector;
            this.openDialogs = [];
        }
        DialogService.prototype.createDialog = function (component) {
            var _this = this;
            var factory = this.componentFactoryResolver.resolveComponentFactory(component);
            var componentRef = factory.create(this.injector);
            this.appRef.attachView(componentRef.hostView);
            var domElem = componentRef.hostView.rootNodes[0];
            document.body.appendChild(domElem);
            componentRef.instance.onHide.subscribe(function () {
                _this.appRef.detachView(componentRef.hostView);
                componentRef.destroy();
            });
            componentRef.instance.visible = true;
            this.openDialogs.push(componentRef.instance);
            return componentRef.instance;
        };
        DialogService.ɵfac = function DialogService_Factory(t) { return new (t || DialogService)(core["ɵɵinject"](core.ComponentFactoryResolver), core["ɵɵinject"](core.ApplicationRef), core["ɵɵinject"](core.Injector)); };
        DialogService.ɵprov = core["ɵɵdefineInjectable"]({ token: DialogService, factory: DialogService.ɵfac, providedIn: 'root' });
        return DialogService;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](DialogService, [{
            type: core.Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: core.ComponentFactoryResolver }, { type: core.ApplicationRef }, { type: core.Injector }]; }, null); })();

    http.HttpClient.prototype.postPageQuery = function (url, query, options) {
        var request = new http.HttpRequest('POST', url, query, options);
        if (query.exportColumns) {
            return this.requestExport(request, query.exportColumns)
                .pipe(operators.map(function (blob) {
                var file = new File([blob], 'export.xlsx');
                fileSaver.saveAs(file, 'export.xlsx');
                return { items: [], total: 0 };
            }));
        }
        else {
            return this.requestData(request);
        }
    };
    http.HttpClient.prototype.requestData = function (req) {
        return this.request(req)
            .pipe(operators.filter(function (resp) { return resp.type == http.HttpEventType.Response; }), operators.map(function (resp) { return resp.body; }));
    };
    http.HttpClient.prototype.requestExport = function (req, exportColumns) {
        return this.request(req.clone({
            body: __assign(__assign({}, req.body), { columns: exportColumns }),
            responseType: 'blob',
            setHeaders: { 'Accept': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }
        }))
            .pipe(operators.filter(function (resp) { return resp.type == http.HttpEventType.Response; }), operators.map(function (resp) { return resp.body; }));
    };

    var ButtonDirective = /** @class */ (function () {
        function ButtonDirective(button) {
            this.button = button;
        }
        ButtonDirective.prototype.ngAfterViewInit = function () {
            if (this.button.nativeElement instanceof HTMLButtonElement) {
                this.button.nativeElement.type = 'button';
            }
            else {
                this.button.nativeElement.getElementsByTagName('button').item(0).type = 'button';
            }
        };
        ButtonDirective.ɵfac = function ButtonDirective_Factory(t) { return new (t || ButtonDirective)(core["ɵɵdirectiveInject"](core.ElementRef)); };
        ButtonDirective.ɵdir = core["ɵɵdefineDirective"]({ type: ButtonDirective, selectors: [["button", 3, "type", ""], ["p-button", 3, "type", ""]] });
        return ButtonDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](ButtonDirective, [{
            type: core.Directive,
            args: [{
                    selector: 'button:not([type]), p-button:not([type])'
                }]
        }], function () { return [{ type: core.ElementRef }]; }, null); })();

    var TooltipExtDirective = /** @class */ (function () {
        function TooltipExtDirective(tooltip) {
            this.tooltip = tooltip;
        }
        TooltipExtDirective.prototype.ngDoCheck = function () {
            var _a, _b;
            if (this.tooltip.active && this.tooltip.tooltipEvent === 'hover'
                && ((_b = (_a = this.tooltip.el) === null || _a === void 0 ? void 0 : _a.nativeElement) === null || _b === void 0 ? void 0 : _b.disabled) === true) {
                this.tooltip.hide();
            }
        };
        TooltipExtDirective.ɵfac = function TooltipExtDirective_Factory(t) { return new (t || TooltipExtDirective)(core["ɵɵdirectiveInject"](primeng.Tooltip)); };
        TooltipExtDirective.ɵdir = core["ɵɵdefineDirective"]({ type: TooltipExtDirective, selectors: [["", "pTooltip", ""]] });
        return TooltipExtDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](TooltipExtDirective, [{
            type: core.Directive,
            args: [{
                    selector: '[pTooltip]'
                }]
        }], function () { return [{ type: primeng.Tooltip }]; }, null); })();

    var _c0 = ["userSelectDialog"];
    function ToolbarComponent_ng_container_3_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainer"](0);
    } }
    function ToolbarComponent_ng_template_4_a_0_Template(rf, ctx) { if (rf & 1) {
        var _r415 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "a", 13);
        core["ɵɵelementStart"](1, "img", 14);
        core["ɵɵlistener"]("error", function ToolbarComponent_ng_template_4_a_0_Template_img_error_1_listener($event) { core["ɵɵrestoreView"](_r415); return ($event.target || $event.srcElement).src = "assets/rosatom.svg?v=1.1"; });
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var ctx_r411 = core["ɵɵnextContext"](2);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("src", ctx_r411.logoSrc, core["ɵɵsanitizeUrl"]);
    } }
    var _c1 = function () { return { exact: true }; };
    function ToolbarComponent_ng_template_4_ng_container_2_ng_container_1_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainerStart"](0);
        core["ɵɵelement"](1, "button", 16);
        core["ɵɵelementContainerEnd"]();
    } if (rf & 2) {
        var menu_r416 = core["ɵɵnextContext"]().$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("label", menu_r416.label)("routerLink", menu_r416.routerLink)("queryParams", menu_r416.queryParams)("routerLinkActiveOptions", core["ɵɵpureFunction0"](4, _c1));
    } }
    function ToolbarComponent_ng_template_4_ng_container_2_ng_container_2_Template(rf, ctx) { if (rf & 1) {
        var _r422 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementContainerStart"](0);
        core["ɵɵelementStart"](1, "button", 17);
        core["ɵɵlistener"]("click", function ToolbarComponent_ng_template_4_ng_container_2_ng_container_2_Template_button_click_1_listener($event) { core["ɵɵrestoreView"](_r422); var _r420 = core["ɵɵreference"](3); var menu_r416 = core["ɵɵnextContext"]().$implicit; var ctx_r421 = core["ɵɵnextContext"](2); return ctx_r421.onMenuClick($event, menu_r416, _r420); });
        core["ɵɵelementEnd"]();
        core["ɵɵelement"](2, "p-tieredMenu", 18, 19);
        core["ɵɵelementContainerEnd"]();
    } if (rf & 2) {
        var menu_r416 = core["ɵɵnextContext"]().$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("label", menu_r416.label + (menu_r416.items ? " \u25BC" : ""));
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("model", menu_r416.items);
    } }
    function ToolbarComponent_ng_template_4_ng_container_2_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainerStart"](0);
        core["ɵɵtemplate"](1, ToolbarComponent_ng_template_4_ng_container_2_ng_container_1_Template, 2, 5, "ng-container", 15);
        core["ɵɵtemplate"](2, ToolbarComponent_ng_template_4_ng_container_2_ng_container_2_Template, 4, 2, "ng-container", 15);
        core["ɵɵelementContainerEnd"]();
    } if (rf & 2) {
        var menu_r416 = ctx.$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", menu_r416.routerLink);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", !menu_r416.routerLink);
    } }
    function ToolbarComponent_ng_template_4_ng_container_3_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainer"](0);
    } }
    function ToolbarComponent_ng_template_4_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵtemplate"](0, ToolbarComponent_ng_template_4_a_0_Template, 2, 1, "a", 9);
        core["ɵɵelement"](1, "button", 10);
        core["ɵɵtemplate"](2, ToolbarComponent_ng_template_4_ng_container_2_Template, 3, 2, "ng-container", 11);
        core["ɵɵtemplate"](3, ToolbarComponent_ng_template_4_ng_container_3_Template, 1, 0, "ng-container", 12);
    } if (rf & 2) {
        var ctx_r405 = core["ɵɵnextContext"]();
        core["ɵɵproperty"]("ngIf", !ctx_r405.configService.config.noLogo);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("label", ctx_r405.name);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngForOf", ctx_r405.mainMenuItems);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", ctx_r405.toolbarTemplate == null ? null : ctx_r405.toolbarTemplate.leftExtension)("ngIfThen", ctx_r405.toolbarTemplate == null ? null : ctx_r405.toolbarTemplate.leftExtension);
    } }
    function ToolbarComponent_ng_container_7_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainer"](0);
    } }
    function ToolbarComponent_ng_template_8_ng_container_0_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainer"](0);
    } }
    function ToolbarComponent_ng_template_8_button_1_Template(rf, ctx) { if (rf & 1) {
        var _r435 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "button", 28);
        core["ɵɵlistener"]("click", function ToolbarComponent_ng_template_8_button_1_Template_button_click_0_listener($event) { core["ɵɵrestoreView"](_r435); core["ɵɵnextContext"](2); var _r409 = core["ɵɵreference"](11); return _r409.show($event); });
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var ctx_r426 = core["ɵɵnextContext"](2);
        core["ɵɵpropertyInterpolate"]("label", ctx_r426.user == null ? null : ctx_r426.user.shortname);
    } }
    function ToolbarComponent_ng_template_8_button_2_Template(rf, ctx) { if (rf & 1) {
        var _r437 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "button", 29);
        core["ɵɵlistener"]("click", function ToolbarComponent_ng_template_8_button_2_Template_button_click_0_listener() { core["ɵɵrestoreView"](_r437); var ctx_r436 = core["ɵɵnextContext"](2); return ctx_r436.login(); });
        core["ɵɵelementEnd"]();
    } }
    function ToolbarComponent_ng_template_8_button_3_Template(rf, ctx) { if (rf & 1) {
        var _r439 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "button", 30);
        core["ɵɵlistener"]("click", function ToolbarComponent_ng_template_8_button_3_Template_button_click_0_listener($event) { core["ɵɵrestoreView"](_r439); core["ɵɵnextContext"](); var _r433 = core["ɵɵreference"](10); return _r433.toggle($event); });
        core["ɵɵelementEnd"]();
    } }
    function ToolbarComponent_ng_template_8_button_4_Template(rf, ctx) { if (rf & 1) {
        var _r441 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "button", 31);
        core["ɵɵlistener"]("click", function ToolbarComponent_ng_template_8_button_4_Template_button_click_0_listener($event) { core["ɵɵrestoreView"](_r441); core["ɵɵnextContext"](); var _r432 = core["ɵɵreference"](8); return _r432.toggle($event); });
        core["ɵɵelementEnd"]();
    } }
    function ToolbarComponent_ng_template_8_button_5_Template(rf, ctx) { if (rf & 1) {
        var _r443 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "button", 32);
        core["ɵɵlistener"]("click", function ToolbarComponent_ng_template_8_button_5_Template_button_click_0_listener() { core["ɵɵrestoreView"](_r443); var ctx_r442 = core["ɵɵnextContext"](2); return ctx_r442.logOut(); });
        core["ɵɵelementEnd"]();
    } }
    function ToolbarComponent_ng_template_8_div_6_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementStart"](0, "div", 33);
        core["ɵɵelementStart"](1, "span");
        core["ɵɵtext"](2);
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var ctx_r431 = core["ɵɵnextContext"](2);
        core["ɵɵadvance"](2);
        core["ɵɵtextInterpolate1"](" v.", ctx_r431.version, " ");
    } }
    function ToolbarComponent_ng_template_8_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵtemplate"](0, ToolbarComponent_ng_template_8_ng_container_0_Template, 1, 0, "ng-container", 12);
        core["ɵɵtemplate"](1, ToolbarComponent_ng_template_8_button_1_Template, 1, 1, "button", 20);
        core["ɵɵtemplate"](2, ToolbarComponent_ng_template_8_button_2_Template, 1, 0, "button", 21);
        core["ɵɵtemplate"](3, ToolbarComponent_ng_template_8_button_3_Template, 1, 0, "button", 22);
        core["ɵɵtemplate"](4, ToolbarComponent_ng_template_8_button_4_Template, 1, 0, "button", 23);
        core["ɵɵtemplate"](5, ToolbarComponent_ng_template_8_button_5_Template, 1, 0, "button", 24);
        core["ɵɵtemplate"](6, ToolbarComponent_ng_template_8_div_6_Template, 3, 1, "div", 25);
        core["ɵɵelement"](7, "p-tieredMenu", 18, 26);
        core["ɵɵelement"](9, "p-tieredMenu", 18, 27);
    } if (rf & 2) {
        var ctx_r408 = core["ɵɵnextContext"]();
        core["ɵɵproperty"]("ngIf", ctx_r408.toolbarTemplate == null ? null : ctx_r408.toolbarTemplate.rightExtension)("ngIfThen", ctx_r408.toolbarTemplate == null ? null : ctx_r408.toolbarTemplate.rightExtension);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", ctx_r408.user.exist);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", !ctx_r408.user.exist && !!ctx_r408.configService.config.auth);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", !ctx_r408.configService.config.noInformationMenu);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", ctx_r408.user.roles.admin && !ctx_r408.configService.config.noLogsMenu);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", ctx_r408.user.exist);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", ctx_r408.showVersion);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("model", ctx_r408.logsMenuArr);
        core["ɵɵadvance"](2);
        core["ɵɵproperty"]("model", ctx_r408.getInformationMenu());
    } }
    function ToolbarComponent_div_16_div_12_div_1_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementStart"](0, "div");
        core["ɵɵtext"](1);
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var role_r446 = ctx.$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵtextInterpolate1"](" ", role_r446, " ");
    } }
    function ToolbarComponent_div_16_div_12_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementStart"](0, "div", 42);
        core["ɵɵtemplate"](1, ToolbarComponent_div_16_div_12_div_1_Template, 2, 1, "div", 11);
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var ctx_r444 = core["ɵɵnextContext"](2);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngForOf", ctx_r444.user.roleKeys);
    } }
    function ToolbarComponent_div_16_Template(rf, ctx) { if (rf & 1) {
        var _r448 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "div", 34);
        core["ɵɵelementStart"](1, "div", 35);
        core["ɵɵelementStart"](2, "p", 36);
        core["ɵɵtext"](3, "\u0418\u043C\u044F \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F \u0441\u0438\u0441\u0442\u0435\u043C\u044B: ");
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
        core["ɵɵelementStart"](4, "div", 37);
        core["ɵɵelementStart"](5, "p", 36);
        core["ɵɵtext"](6);
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
        core["ɵɵelement"](7, "div", 38);
        core["ɵɵelementStart"](8, "div");
        core["ɵɵelementStart"](9, "a", 39);
        core["ɵɵlistener"]("click", function ToolbarComponent_div_16_Template_a_click_9_listener($event) { core["ɵɵrestoreView"](_r448); var ctx_r447 = core["ɵɵnextContext"](); $event.preventDefault(); return ctx_r447.showPrivileges = !ctx_r447.showPrivileges; });
        core["ɵɵtext"](10, " \u041F\u0440\u0438\u0432\u0438\u043B\u0435\u0433\u0438\u0438 \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F ");
        core["ɵɵelement"](11, "span", 40);
        core["ɵɵelementEnd"]();
        core["ɵɵtemplate"](12, ToolbarComponent_div_16_div_12_Template, 2, 1, "div", 41);
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var ctx_r410 = core["ɵɵnextContext"]();
        core["ɵɵadvance"](6);
        core["ɵɵtextInterpolate"](ctx_r410.user.username || "-");
        core["ɵɵadvance"](5);
        core["ɵɵclassProp"]("fa-caret-right", !ctx_r410.showPrivileges)("fa-caret-down", ctx_r410.showPrivileges);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", ctx_r410.showPrivileges);
    } }
    var ToolbarComponent = /** @class */ (function () {
        function ToolbarComponent(user, http, authService, configService, bus, dialog) {
            this.user = user;
            this.http = http;
            this.authService = authService;
            this.configService = configService;
            this.bus = bus;
            this.dialog = dialog;
            this.handlers = [];
            this.showPrivileges = false;
            this.showVersion = true;
            this.logoSrc = 'assets/logo.svg';
            this.version = this.configService.config.version;
        }
        ToolbarComponent.prototype.ngOnInit = function () {
            return __awaiter(this, void 0, void 0, function () {
                var _this = this;
                return __generator(this, function (_a) {
                    this.logsMenuArr = [
                        {
                            icon: 'fa fa-download', label: 'Основные',
                            command: function () {
                                _this.saveLogFile('/user/main_log', 'main.log');
                            }
                        },
                        {
                            icon: 'fa fa-download', label: 'PLM',
                            command: function () {
                                _this.saveLogFile('/user/plm_log', 'plm.log');
                            }
                        },
                        {
                            icon: 'fa fa-download', label: 'Пользовательские',
                            command: function () {
                                _this.saveLogFile('/user/users_log', 'users.log');
                            }
                        }
                    ];
                    this.informationMenuArr = [
                        {
                            label: 'Справка',
                            icon: 'fa fa-book',
                            routerLink: 'reference'
                        }
                    ];
                    this.user.personalNumberChange.subscribe(function (val) {
                        _this.userPersonalNumber = val;
                    });
                    this.userPersonalNumber = this.user.personalNumber;
                    this.employments = this.user.employments;
                    return [2 /*return*/];
                });
            });
        };
        ToolbarComponent.prototype.ngOnDestroy = function () {
            this.unsuscribeHandlers();
        };
        ToolbarComponent.prototype.unsuscribeHandlers = function () {
            this.handlers.forEach(function (handlerRegistration) { return handlerRegistration.unregister(); });
        };
        ToolbarComponent.prototype.onMenuClick = function (event, menuItem, subMenu) {
            if (menuItem.command) {
                menuItem.command(menuItem);
            }
            else if (subMenu) {
                subMenu.toggle(event);
            }
        };
        ToolbarComponent.prototype.getInformationMenu = function () {
            return [].concat(this.informationMenuArr).concat(!!this.informationMenuEx ? this.informationMenuEx : []);
        };
        ToolbarComponent.prototype.login = function () {
            this.authService.login();
        };
        ToolbarComponent.prototype.logOut = function () {
            this.authService.logout();
        };
        ToolbarComponent.prototype.saveLogFile = function (uri, fileName) {
            return __awaiter(this, void 0, void 0, function () {
                var data, file;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            if (!!!uri) return [3 /*break*/, 2];
                            return [4 /*yield*/, this.http
                                    .get(uri, { responseType: 'blob' })
                                    .toPromise()];
                        case 1:
                            data = _a.sent();
                            file = new File([data], fileName);
                            fileSaver.saveAs(file, fileName);
                            _a.label = 2;
                        case 2: return [2 /*return*/];
                    }
                });
            });
        };
        ToolbarComponent.prototype.selectPersonal = function (personal) {
            this.user.select(personal);
        };
        ToolbarComponent.ɵfac = function ToolbarComponent_Factory(t) { return new (t || ToolbarComponent)(core["ɵɵdirectiveInject"](UserService), core["ɵɵdirectiveInject"](http.HttpClient), core["ɵɵdirectiveInject"](AuthService), core["ɵɵdirectiveInject"](ConfigurationService), core["ɵɵdirectiveInject"](EventBusService), core["ɵɵdirectiveInject"](DialogService)); };
        ToolbarComponent.ɵcmp = core["ɵɵdefineComponent"]({ type: ToolbarComponent, selectors: [["app-toolbar"]], viewQuery: function ToolbarComponent_Query(rf, ctx) { if (rf & 1) {
                core["ɵɵviewQuery"](_c0, true);
            } if (rf & 2) {
                var _t;
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.userSelectDialog = _t.first);
            } }, inputs: { name: "name", showVersion: "showVersion", logoSrc: "logoSrc", mainMenuItems: "mainMenuItems", informationMenuEx: "informationMenuEx", toolbarTemplate: "toolbarTemplate" }, decls: 17, vars: 9, consts: [[2, "text-align", "left", "margin-left", "10px"], [1, "ui-toolbar-group-left"], [4, "ngIf", "ngIfThen", "ngIfElse"], ["defaultLeftToolbar", ""], [1, "ui-toolbar-group-right"], ["defaultRightToolbar", ""], [3, "dismissable", "showCloseIcon"], ["op", ""], ["style", "padding-top: 15px;", 4, "ngIf"], ["routerLink", "", "style", "display: inline-block;float: left;", 4, "ngIf"], ["pButton", "", "disabled", "", 1, "title", 3, "label"], [4, "ngFor", "ngForOf"], [4, "ngIf", "ngIfThen"], ["routerLink", "", 2, "display", "inline-block", "float", "left"], ["id", "logo", "pTooltip", "\u041D\u0430 \u0433\u043B\u0430\u0432\u043D\u0443\u044E", "showDelay", "500", 3, "src", "error"], [4, "ngIf"], ["pButton", "", "routerLinkActive", "active-item", 1, "toolbarBtn", 3, "label", "routerLink", "queryParams", "routerLinkActiveOptions"], ["pButton", "", 1, "toolbarBtn", 3, "label", "click"], ["popup", "popup", 3, "model"], ["viewMenu", ""], ["pButton", "", "class", "toolbarBtn", "icon", "fa fa-user", 3, "label", "click", 4, "ngIf"], ["pButton", "", "class", "toolbarBtn", "label", "\u0412\u043E\u0439\u0442\u0438", "icon", "fa fa-user", 3, "click", 4, "ngIf"], ["pButton", "", "class", "toolbarBtn", "icon", "fa fa-info", 3, "click", 4, "ngIf"], ["pButton", "", "class", "toolbarBtn", "pTooltip", "\u041B\u043E\u0433\u0438", "icon", "fa fa-file-code", 3, "click", 4, "ngIf"], ["pButton", "", "class", "toolbarBtn", "label", "\u0412\u044B\u0445\u043E\u0434", "icon", "fa fa-sign-out-alt", 3, "click", 4, "ngIf"], ["style", "font-size: 8pt; position: absolute; right: 1px; top: 37px;", 4, "ngIf"], ["logsMenu", ""], ["informationMenu", ""], ["pButton", "", "icon", "fa fa-user", 1, "toolbarBtn", 3, "label", "click"], ["pButton", "", "label", "\u0412\u043E\u0439\u0442\u0438", "icon", "fa fa-user", 1, "toolbarBtn", 3, "click"], ["pButton", "", "icon", "fa fa-info", 1, "toolbarBtn", 3, "click"], ["pButton", "", "pTooltip", "\u041B\u043E\u0433\u0438", "icon", "fa fa-file-code", 1, "toolbarBtn", 3, "click"], ["pButton", "", "label", "\u0412\u044B\u0445\u043E\u0434", "icon", "fa fa-sign-out-alt", 1, "toolbarBtn", 3, "click"], [2, "font-size", "8pt", "position", "absolute", "right", "1px", "top", "37px"], [2, "padding-top", "15px"], [2, "float", "left"], [1, "fields-p"], [2, "float", "left", "margin-left", "10px"], [2, "clear", "both"], ["href", "#", 3, "click"], [1, "fa"], ["style", "width:100%; max-height: 300px; overflow: auto; margin: 7px;", 4, "ngIf"], [2, "width", "100%", "max-height", "300px", "overflow", "auto", "margin", "7px"]], template: function ToolbarComponent_Template(rf, ctx) { if (rf & 1) {
                core["ɵɵelementStart"](0, "p-toolbar");
                core["ɵɵelementStart"](1, "div", 0);
                core["ɵɵelementStart"](2, "div", 1);
                core["ɵɵtemplate"](3, ToolbarComponent_ng_container_3_Template, 1, 0, "ng-container", 2);
                core["ɵɵelementEnd"]();
                core["ɵɵtemplate"](4, ToolbarComponent_ng_template_4_Template, 4, 5, "ng-template", null, 3, core["ɵɵtemplateRefExtractor"]);
                core["ɵɵelementStart"](6, "div", 4);
                core["ɵɵtemplate"](7, ToolbarComponent_ng_container_7_Template, 1, 0, "ng-container", 2);
                core["ɵɵelementEnd"]();
                core["ɵɵtemplate"](8, ToolbarComponent_ng_template_8_Template, 11, 10, "ng-template", null, 5, core["ɵɵtemplateRefExtractor"]);
                core["ɵɵelementEnd"]();
                core["ɵɵelementStart"](10, "p-overlayPanel", 6, 7);
                core["ɵɵelementStart"](12, "label");
                core["ɵɵelementStart"](13, "b");
                core["ɵɵtext"](14, " \u0414\u0430\u043D\u043D\u044B\u0435 \u0442\u0435\u043A\u0443\u0449\u0435\u0433\u043E \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F \u0441\u0438\u0441\u0442\u0435\u043C\u044B");
                core["ɵɵelementEnd"]();
                core["ɵɵelementEnd"]();
                core["ɵɵelement"](15, "hr");
                core["ɵɵtemplate"](16, ToolbarComponent_div_16_Template, 13, 6, "div", 8);
                core["ɵɵelementEnd"]();
                core["ɵɵelementEnd"]();
            } if (rf & 2) {
                var _r404 = core["ɵɵreference"](5);
                var _r407 = core["ɵɵreference"](9);
                core["ɵɵadvance"](3);
                core["ɵɵproperty"]("ngIf", ctx.toolbarTemplate == null ? null : ctx.toolbarTemplate.leftTemplate)("ngIfThen", ctx.toolbarTemplate == null ? null : ctx.toolbarTemplate.leftTemplate)("ngIfElse", _r404);
                core["ɵɵadvance"](4);
                core["ɵɵproperty"]("ngIf", ctx.toolbarTemplate == null ? null : ctx.toolbarTemplate.rightTemplate)("ngIfThen", ctx.toolbarTemplate == null ? null : ctx.toolbarTemplate.rightTemplate)("ngIfElse", _r407);
                core["ɵɵadvance"](3);
                core["ɵɵproperty"]("dismissable", false)("showCloseIcon", true);
                core["ɵɵadvance"](6);
                core["ɵɵproperty"]("ngIf", ctx.user.exist);
            } }, directives: [toolbar.Toolbar, common.NgIf, overlaypanel.OverlayPanel, ButtonDirective, button.ButtonDirective, common.NgForOf, router.RouterLinkWithHref, TooltipExtDirective, tooltip.Tooltip, router.RouterLinkActive, router.RouterLink, tieredmenu.TieredMenu], styles: ["[_nghost-%COMP%] .ui-toolbar{color:#fff;background:#203a77!important;border:none;padding:0}.ui-toolbar-group-left[_ngcontent-%COMP%], .ui-toolbar-group-right[_ngcontent-%COMP%]{display:-webkit-box;display:flex;height:50px}#logo[_ngcontent-%COMP%]{width:50px;height:50px}.title[_ngcontent-%COMP%]{background:#203a77;border-color:#203a77;font-size:16px;font-weight:700;opacity:1!important;cursor:default}.toolbarBtn[_ngcontent-%COMP%]{background:#203a77;border-color:#203a77;font-size:16px;margin-left:0}.toolbarBtn.active-item[_ngcontent-%COMP%], .toolbarBtn.active-item[_ngcontent-%COMP%]:focus{background:#3f5fac;border-color:#3f5fac}#logo[_ngcontent-%COMP%]:hover{-webkit-transform:scale(1.1);transform:scale(1.1)}#logo[_ngcontent-%COMP%], .ui-toolbar-group-left[_ngcontent-%COMP%] > button[_ngcontent-%COMP%], .ui-toolbar-group-right[_ngcontent-%COMP%] > button[_ngcontent-%COMP%], .ui-toolbar-group-right[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{display:inline-block;vertical-align:middle}.fields-p[_ngcontent-%COMP%]{padding-bottom:.5em}.label-logo[_ngcontent-%COMP%]{position:absolute;font-size:larger;left:50%;padding-top:.6em}[_nghost-%COMP%] .ui-panel .ui-panel-titlebar{background-color:inherit;padding-left:0;padding-top:0;border:0}[_nghost-%COMP%] .ui-panel .ui-panel-content{border:0}"] });
        return ToolbarComponent;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](ToolbarComponent, [{
            type: core.Component,
            args: [{
                    selector: 'app-toolbar',
                    templateUrl: './toolbar.component.html',
                    styleUrls: ['./toolbar.component.css']
                }]
        }], function () { return [{ type: UserService }, { type: http.HttpClient }, { type: AuthService }, { type: ConfigurationService }, { type: EventBusService }, { type: DialogService }]; }, { name: [{
                type: core.Input
            }], showVersion: [{
                type: core.Input
            }], logoSrc: [{
                type: core.Input
            }], mainMenuItems: [{
                type: core.Input
            }], informationMenuEx: [{
                type: core.Input
            }], toolbarTemplate: [{
                type: core.Input
            }], userSelectDialog: [{
                type: core.ViewChild,
                args: ['userSelectDialog']
            }] }); })();


    (function (MessageServiceKey) {
        MessageServiceKey["OK"] = "MESSAGE_SERVICE_OK_KEY";
    })(exports.MessageServiceKey || (exports.MessageServiceKey = {}));

    var TableExtensionField = /** @class */ (function () {
        function TableExtensionField(json) {
            if (json) {
                Object.assign(this, json);
            }
        }
        Object.defineProperty(TableExtensionField.prototype, "textFieldName", {
            get: function () {
                if (this.type === 'local-dict') {
                    return 'extension.' + this.name + '.value';
                }
                if (this.type === 'dict') {
                    return 'extension.' + this.name + '.' + this.options.field;
                }
                return 'extension.' + this.name;
            },
            enumerable: true,
            configurable: true
        });
        return TableExtensionField;
    }());

    var BaseService = /** @class */ (function () {
        function BaseService(http, authService, bus) {
            this.http = http;
            this.authService = authService;
            this.bus = bus;
        }
        Object.defineProperty(BaseService.prototype, "httpOptions", {
            get: function () {
                return BaseService.httpOptions;
            },
            enumerable: true,
            configurable: true
        });
        BaseService.prototype.handleError = function (error, operation, result) {
            // console.error(error);
            // console.log(`${operation} failed: ${error.message}`);
            if (operation === void 0) { operation = 'operation'; }
            switch (operation) {
                default:
                    // In this case we can catch HTTPP errors by operation described on each of them like "getDocuments" etc,
                    // or by error.status but wey we catch in RequestInterceptorService
                    break;
            }
            return result;
        };
        BaseService.httpOptions = {
            headers: new http.HttpHeaders({
                'Content-type': 'application/json'
            }),
        };
        BaseService.ɵfac = function BaseService_Factory(t) { return new (t || BaseService)(core["ɵɵinject"](http.HttpClient), core["ɵɵinject"](AuthService), core["ɵɵinject"](EventBusService)); };
        BaseService.ɵprov = core["ɵɵdefineInjectable"]({ token: BaseService, factory: BaseService.ɵfac });
        return BaseService;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](BaseService, [{
            type: core.Injectable
        }], function () { return [{ type: http.HttpClient }, { type: AuthService }, { type: EventBusService }]; }, null); })();

    var EntityConfigService = /** @class */ (function (_super) {
        __extends(EntityConfigService, _super);
        function EntityConfigService(httpClient, authService, bus, configurationService) {
            var _this = _super.call(this, httpClient, authService, bus) || this;
            _this.httpClient = httpClient;
            _this.authService = authService;
            _this.bus = bus;
            _this.configurationService = configurationService;
            return _this;
        }
        EntityConfigService.prototype.init = function () {
            return __awaiter(this, void 0, void 0, function () {
                var _a, _b, _c, _d;
                return __generator(this, function (_e) {
                    switch (_e.label) {
                        case 0:
                            _a = this;
                            if (!!!this.configurationService.config.offlineMode) return [3 /*break*/, 1];
                            _b = {};
                            return [3 /*break*/, 3];
                        case 1: return [4 /*yield*/, this.getExtensions()];
                        case 2:
                            _b = _e.sent();
                            _e.label = 3;
                        case 3:
                            _a.extensions = _b;
                            _c = this;
                            if (!!!this.configurationService.config.offlineMode) return [3 /*break*/, 4];
                            _d = {};
                            return [3 /*break*/, 6];
                        case 4: return [4 /*yield*/, this.getConfigs()];
                        case 5:
                            _d = _e.sent();
                            _e.label = 6;
                        case 6:
                            _c.configs = _d;
                            return [2 /*return*/];
                    }
                });
            });
        };
        // Загрузка настроек сущности
        EntityConfigService.prototype.getEntityConfig = function (entityName, domain) {
            var fieldConfigs = {};
            var fields = this.configs[entityName];
            if (fields) {
                fields.forEach(function (f) {
                    fieldConfigs[f.name] = {
                        name: f.name,
                        required: new Function('return ' + f.required).bind(domain),
                        visible: new Function('return ' + f.visible).bind(domain),
                        readonly: new Function('return ' + (f.readonly || 'false')).bind(domain),
                    };
                });
            }
            return fieldConfigs;
        };
        EntityConfigService.prototype.getEntityExtension = function (entityName) {
            return this.extensions[entityName].map(function (e) { return new TableExtensionField(e); });
        };
        EntityConfigService.prototype.getExtensions = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, this.httpClient
                            .get('entities/extensions', this.httpOptions)
                            .toPromise()];
                });
            });
        };
        EntityConfigService.prototype.getConfigs = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, this.httpClient
                            .get('entities/configs', this.httpOptions)
                            .toPromise()];
                });
            });
        };
        EntityConfigService.ɵfac = function EntityConfigService_Factory(t) { return new (t || EntityConfigService)(core["ɵɵinject"](http.HttpClient), core["ɵɵinject"](AuthService), core["ɵɵinject"](EventBusService), core["ɵɵinject"](ConfigurationService)); };
        EntityConfigService.ɵprov = core["ɵɵdefineInjectable"]({ token: EntityConfigService, factory: EntityConfigService.ɵfac, providedIn: 'root' });
        return EntityConfigService;
    }(BaseService));
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](EntityConfigService, [{
            type: core.Injectable,
            args: [{ providedIn: 'root' }]
        }], function () { return [{ type: http.HttpClient }, { type: AuthService }, { type: EventBusService }, { type: ConfigurationService }]; }, null); })();

    var DialogExtDirective = /** @class */ (function () {
        function DialogExtDirective(dialog, dialogService) {
            this.dialog = dialog;
            this.dialogService = dialogService;
            this._loading = false;
        }
        Object.defineProperty(DialogExtDirective.prototype, "loading", {
            get: function () {
                return this._loading;
            },
            set: function (val) {
                if (this._loading !== val) {
                    this._loading = val;
                    this.updateLoadingElement();
                    if (this.shown) {
                        if (this._loading) {
                            this.disableDialog();
                        }
                        else {
                            this.enableDialog();
                        }
                    }
                }
            },
            enumerable: true,
            configurable: true
        });
        DialogExtDirective.prototype.closeDialogs = function (event) {
            if (event.key === 'Escape') {
                if ((this.dialog.el.nativeElement.parentElement.localName === this.dialogService.openDialogs[this
                    .dialogService.openDialogs.length - 1].dialog.el.nativeElement.parentElement.localName)) {
                    this.dialog.close(event);
                }
            }
        };
        DialogExtDirective.prototype.onHiding = function () {
            this.dialogService.openDialogs.pop();
        };
        DialogExtDirective.prototype.ngOnInit = function () {
            this.dialogClose = this.dialog.close;
            this.dialog.focusOnShow = false;
        };
        DialogExtDirective.prototype.ngAfterViewInit = function () {
            var _this = this;
            this.loadingElem = this.createLoadingElement();
            this.dialog.onShow.subscribe(function () {
                _this.shown = true;
                _this.dialog.contentViewChild.nativeElement.parentNode.appendChild(_this.loadingElem);
                if (_this._loading) {
                    _this.disableDialog();
                }
                else {
                    _this.enableDialog();
                }
                _this.updateLoadingElement();
                _this.bindResizeEventListener();
                setTimeout(function () {
                    _this.setFocus();
                });
            });
            this.dialog.onHide.subscribe(function () {
                _this.shown = false;
                _this.loadingElem.parentNode.removeChild(_this.loadingElem);
                _this.unbindResizeEventListener();
            });
        };
        DialogExtDirective.prototype.setFocus = function () {
            var e_1, _a, e_2, _b, e_3, _c;
            var _d, _e;
            (_d = document.activeElement) === null || _d === void 0 ? void 0 : _d.blur();
            var afElements = this.dialog.contentViewChild.nativeElement.querySelectorAll('[autofocus]');
            if (afElements.length > 0) {
                try {
                    for (var afElements_1 = __values(afElements), afElements_1_1 = afElements_1.next(); !afElements_1_1.done; afElements_1_1 = afElements_1.next()) {
                        var el = afElements_1_1.value;
                        if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
                            if (!el.disabled && !el.hidden) {
                                el.focus();
                                return;
                            }
                        }
                        try {
                            for (var _f = (e_2 = void 0, __values(el.getElementsByTagName('input'))), _g = _f.next(); !_g.done; _g = _f.next()) {
                                var input = _g.value;
                                if (input && !input.disabled && !el.hidden) {
                                    input.focus();
                                    return;
                                }
                            }
                        }
                        catch (e_2_1) { e_2 = { error: e_2_1 }; }
                        finally {
                            try {
                                if (_g && !_g.done && (_b = _f.return)) _b.call(_f);
                            }
                            finally { if (e_2) throw e_2.error; }
                        }
                    }
                }
                catch (e_1_1) { e_1 = { error: e_1_1 }; }
                finally {
                    try {
                        if (afElements_1_1 && !afElements_1_1.done && (_a = afElements_1.return)) _a.call(afElements_1);
                    }
                    finally { if (e_1) throw e_1.error; }
                }
            }
            try {
                for (var _h = __values(this.dialog.contentViewChild.nativeElement.getElementsByTagName('input')), _j = _h.next(); !_j.done; _j = _h.next()) {
                    var el = _j.value;
                    if (!el.disabled && !el.hidden) {
                        el.focus();
                        return;
                    }
                }
            }
            catch (e_3_1) { e_3 = { error: e_3_1 }; }
            finally {
                try {
                    if (_j && !_j.done && (_c = _h.return)) _c.call(_h);
                }
                finally { if (e_3) throw e_3.error; }
            }
            (_e = this.dialog.headerViewChild.nativeElement.getElementsByClassName('ui-dialog-titlebar-close')[0]) === null || _e === void 0 ? void 0 : _e.focus();
        };
        DialogExtDirective.prototype.disableDialog = function () {
            this.dialog.close = function (e) {
            };
        };
        DialogExtDirective.prototype.enableDialog = function () {
            this.dialog.close = this.dialogClose;
        };
        DialogExtDirective.prototype.updateLoadingElement = function () {
            if (this.loadingElem) {
                this.loadingElem.style.display = this._loading ? 'initial' : 'none';
            }
        };
        DialogExtDirective.prototype.createLoadingElement = function () {
            var el = document.createElement('app-dialog-loading');
            el.innerHTML = "\n    <div tabindex=\"-1\" style=\"background: rgba(200,200,200,0.5);\n        position: absolute; left:0; top:0; bottom: 0; right: 0; z-index: 9999;\n        display: flex; justify-content: center; align-items: center;\">\n      <div style=\"justify-content: center;font-size: 40px;\">\n        <i class=\"fa fa-circle-notch fa-spin\"></i>\n      </div>\n    </div>";
            return el;
        };
        DialogExtDirective.prototype.bindResizeEventListener = function () {
            var iframe = document.createElement('iframe');
            iframe.id = 'hacky-scrollbar-resize-listener';
            iframe.style.cssText = 'width: 0; background-color: transparent; margin: 0; padding: 0; overflow: hidden; border-width: 0; position: absolute; height: 100%;';
            var self = this;
            // Register our event when the iframe loads
            iframe.onload = function () {
                // The trick here is that because this iframe has 100% height
                // it should fire a window resize event when anything causes it to
                // resize (even scrollbars on the outer element)
                if (!self.dialog.resizable) {
                    self.center();
                }
                self.resizeListener = function () {
                    if (!self.dialog.resizable) {
                        self.center();
                    }
                };
                iframe.contentWindow.addEventListener('resize', self.resizeListener);
            };
            // Stick the iframe somewhere out of the way
            this.dialog.container.appendChild(iframe);
            this.iframe = iframe;
        };
        DialogExtDirective.prototype.unbindResizeEventListener = function () {
            if (this.iframe.contentWindow) {
                this.iframe.contentWindow.removeEventListener('resize', this.resizeListener);
                this.iframe.parentNode.removeChild(this.iframe);
            }
        };
        DialogExtDirective.prototype.center = function () {
            this.dialog.container.style.left = 'unset';
            this.dialog.container.style.top = 'unset';
        };
        DialogExtDirective.ɵfac = function DialogExtDirective_Factory(t) { return new (t || DialogExtDirective)(core["ɵɵdirectiveInject"](dialog.Dialog), core["ɵɵdirectiveInject"](DialogService)); };
        DialogExtDirective.ɵdir = core["ɵɵdefineDirective"]({ type: DialogExtDirective, selectors: [["p-dialog"]], hostBindings: function DialogExtDirective_HostBindings(rf, ctx) { if (rf & 1) {
                core["ɵɵlistener"]("keyup", function DialogExtDirective_keyup_HostBindingHandler($event) { return ctx.closeDialogs($event); }, false, core["ɵɵresolveDocument"])("onHide", function DialogExtDirective_onHide_HostBindingHandler() { return ctx.onHiding(); });
            } }, inputs: { loading: "loading" } });
        return DialogExtDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](DialogExtDirective, [{
            type: core.Directive,
            args: [{
                    selector: 'p-dialog'
                }]
        }], function () { return [{ type: dialog.Dialog }, { type: DialogService }]; }, { closeDialogs: [{
                type: core.HostListener,
                args: ['document:keyup', ['$event']]
            }], onHiding: [{
                type: core.HostListener,
                args: ['onHide']
            }], loading: [{
                type: core.Input
            }] }); })();

    var _c0$1 = ["content"];
    var _c1$1 = ["loading"];
    function RootComponent_ng_container_0_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainer"](0);
    } }
    function RootComponent_ng_template_1_ng_container_1_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainer"](0);
    } }
    function RootComponent_ng_template_1_ng_template_2_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementStart"](0, "div");
        core["ɵɵelement"](1, "img", 14);
        core["ɵɵelementStart"](2, "div");
        core["ɵɵtext"](3, "\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430...");
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } }
    function RootComponent_ng_template_1_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementStart"](0, "div", 12);
        core["ɵɵtemplate"](1, RootComponent_ng_template_1_ng_container_1_Template, 1, 0, "ng-container", 0);
        core["ɵɵtemplate"](2, RootComponent_ng_template_1_ng_template_2_Template, 4, 0, "ng-template", null, 13, core["ɵɵtemplateRefExtractor"]);
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var _r458 = core["ɵɵreference"](3);
        var ctx_r451 = core["ɵɵnextContext"]();
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", ctx_r451.loadingTemplate)("ngIfThen", ctx_r451.loadingTemplate)("ngIfElse", _r458);
    } }
    function RootComponent_ng_template_3_div_1_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementStart"](0, "div", 19);
        core["ɵɵelement"](1, "app-toolbar", 20);
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var ctx_r460 = core["ɵɵnextContext"](2);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("name", ctx_r460.name)("showVersion", ctx_r460.showVersion)("logoSrc", ctx_r460.logoSrc)("mainMenuItems", ctx_r460.mainMenu)("informationMenuEx", ctx_r460.informationMenuEx)("toolbarTemplate", ctx_r460.toolbarTemplate);
    } }
    function RootComponent_ng_template_3_ng_container_3_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainer"](0);
    } }
    function RootComponent_ng_template_3_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementStart"](0, "div", 15);
        core["ɵɵtemplate"](1, RootComponent_ng_template_3_div_1_Template, 2, 6, "div", 16);
        core["ɵɵelementStart"](2, "div", 17);
        core["ɵɵtemplate"](3, RootComponent_ng_template_3_ng_container_3_Template, 1, 0, "ng-container", 18);
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var ctx_r453 = core["ɵɵnextContext"]();
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", ctx_r453.showToolbar && ctx_r453.checkRouter());
        core["ɵɵadvance"](1);
        core["ɵɵclassProp"]("content-no-pad", ctx_r453.contentNoPadding);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngTemplateOutlet", ctx_r453.contentTemplate);
    } }
    function RootComponent_ng_template_7_ng_template_0_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementStart"](0, "div", 25);
        core["ɵɵelement"](1, "i", 26);
        core["ɵɵelementStart"](2, "h3");
        core["ɵɵtext"](3);
        core["ɵɵelementEnd"]();
        core["ɵɵelementStart"](4, "p");
        core["ɵɵtext"](5);
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var message_r462 = core["ɵɵnextContext"]().$implicit;
        var ctx_r464 = core["ɵɵnextContext"]();
        core["ɵɵadvance"](1);
        core["ɵɵclassMap"](ctx_r464.getDialogIconClassByMessage(message_r462));
        core["ɵɵadvance"](2);
        core["ɵɵtextInterpolate"](message_r462.summary);
        core["ɵɵadvance"](2);
        core["ɵɵtextInterpolate"](message_r462.detail);
    } }
    function RootComponent_ng_template_7_ng_container_2_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainer"](0);
    } }
    function RootComponent_ng_template_7_Template(rf, ctx) { if (rf & 1) {
        var _r468 = core["ɵɵgetCurrentView"]();
        core["ɵɵtemplate"](0, RootComponent_ng_template_7_ng_template_0_Template, 6, 4, "ng-template", null, 21, core["ɵɵtemplateRefExtractor"]);
        core["ɵɵtemplate"](2, RootComponent_ng_template_7_ng_container_2_Template, 1, 0, "ng-container", 18);
        core["ɵɵelementStart"](3, "div", 22);
        core["ɵɵelementStart"](4, "div", 23);
        core["ɵɵelementStart"](5, "button", 24);
        core["ɵɵlistener"]("click", function RootComponent_ng_template_7_Template_button_click_5_listener($event) { core["ɵɵrestoreView"](_r468); var ctx_r467 = core["ɵɵnextContext"](); return ctx_r467.onToastMessageOkButtonClick($event); });
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var message_r462 = ctx.$implicit;
        var _r463 = core["ɵɵreference"](1);
        var ctx_r454 = core["ɵɵnextContext"]();
        core["ɵɵadvance"](2);
        core["ɵɵproperty"]("ngTemplateOutlet", message_r462.data ? message_r462.data : _r463);
        core["ɵɵadvance"](3);
        core["ɵɵclassMap"](ctx_r454.getDialogButtonClassByMessage(message_r462));
    } }
    function RootComponent_div_12_Template(rf, ctx) { if (rf & 1) {
        var _r471 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "div", 27);
        core["ɵɵelementStart"](1, "button", 28);
        core["ɵɵlistener"]("click", function RootComponent_div_12_Template_button_click_1_listener() { core["ɵɵrestoreView"](_r471); var item_r469 = ctx.$implicit; var ctx_r470 = core["ɵɵnextContext"](); return ctx_r470.selectPersonal(item_r469); });
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var item_r469 = ctx.$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("label", "\u0414\u0435\u043F\u0430\u0440\u0442\u0430\u043C\u0435\u043D\u0442: " + (item_r469 == null ? null : item_r469.departmentCode) + ", \u0434\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C: " + (item_r469 == null ? null : item_r469.positionCode) + ", \u0442\u0430\u0431\u0435\u043B\u044C\u043D\u044B\u0439: " + (item_r469 == null ? null : item_r469.personalNumber));
    } }
    var _c2 = function () { return { width: "425px" }; };
    var RootComponent = /** @class */ (function () {
        function RootComponent(authService, router$1, confirmationService, configurationService, bus, messageService, user, entityConfigService) {
            var _this = this;
            this.authService = authService;
            this.router = router$1;
            this.confirmationService = confirmationService;
            this.configurationService = configurationService;
            this.bus = bus;
            this.messageService = messageService;
            this.user = user;
            this.entityConfigService = entityConfigService;
            this.MessageServiceKey = exports.MessageServiceKey;
            this.handlers = [];
            this.initialized = false;
            this.loading = false;
            this.employmentsDialogVisible = false;
            this.showToolbar = true;
            this.showVersion = true;
            this.logoSrc = 'assets/logo.svg';
            this.contentNoPadding = false;
            router$1.events.subscribe(function (event) {
                if (event instanceof router.NavigationStart) {
                    _this.loading = true;
                }
                else if (event instanceof router.NavigationEnd
                    || event instanceof router.NavigationCancel
                    || event instanceof router.NavigationError) {
                    _this.loading = false;
                }
            });
        }
        RootComponent.prototype.ngOnInit = function () {
            return __awaiter(this, void 0, void 0, function () {
                var _this = this;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            if (!!this.configurationService.config.restConfig && !this.configurationService.config.auth) {
                                console.log('Не известен URL авторизации');
                                this.reconnectPopup();
                                return [2 /*return*/];
                            }
                            this.handlers.push(this.bus.on(new HttpEventbusEvent(), function (event) {
                                switch (event.httpError) {
                                    case exports.HTTPErrors.TYPE_NETWROK_IO_ERROR:
                                    case exports.HTTPErrors.TYPE_BAD_GATEWAY:
                                        _this.reconnectPopup();
                                        break;
                                    case exports.HTTPErrors.TYPE_UNAUTHORIZED:
                                        _this.popup(event.message, function () { return _this.logoutUser(); });
                                        break;
                                    case exports.HTTPErrors.TYPE_UNPROCESSABLE_ENTITY:
                                        _this.logoutUser();
                                        break;
                                    case exports.HTTPErrors.TYPE_FORBIDDEN:
                                        _this.messageService.add({
                                            sticky: true, severity: 'error', summary: 'Ошибка',
                                            detail: 'У вас недостаточно прав для выполнения этого запроса.\nОбратитесь к администратору'
                                        });
                                        break;
                                    case exports.HTTPErrors.TYPE_PAYLOAD_TOO_LARGE:
                                        _this.messageService.add({ sticky: true, severity: 'error', summary: 'Ошибка', detail: 'Файл слишком большой для загрузки' });
                                        break;
                                    case exports.HTTPErrors.TYPE_INTERNAL_SERVER_ERROR:
                                        _this.messageService.add({ sticky: true, severity: 'error', summary: 'Ошибка', detail: 'Произошла ошибка на сервере' });
                                        break;
                                    case exports.HTTPErrors.TYPE_EXPECTATION_FAILED:
                                        _this.messageService.add({
                                            key: exports.MessageServiceKey.OK,
                                            sticky: true, severity: 'warn', summary: 'Информация', detail: event.message
                                        });
                                        break;
                                    default:
                                        _this.messageService.add({ key: exports.MessageServiceKey.OK, sticky: true, severity: 'error', summary: 'Ошибка', detail: event.message });
                                        break;
                                }
                            }));
                            this.user.personalNumberChange.subscribe(function (val) {
                                _this.userPersonalNumber = val;
                                _this.employmentsDialogVisible = false;
                            });
                            return [4 /*yield*/, this.user.init()];
                        case 1:
                            _a.sent();
                            if (!this.authService.getAccessToken()) return [3 /*break*/, 3];
                            return [4 /*yield*/, this.entityConfigService.init()];
                        case 2:
                            _a.sent();
                            _a.label = 3;
                        case 3:
                            this.employments = this.user.employments;
                            this.userPersonalNumber = this.user.personalNumber;
                            this.employmentsDialogVisible = this.user.personalNumberEmptyAndRequired;
                            this.initialized = !this.employmentsDialogVisible;
                            return [2 /*return*/];
                    }
                });
            });
        };
        RootComponent.prototype.ngOnDestroy = function () {
            this.unsuscribeHandlers();
        };
        RootComponent.prototype.unsuscribeHandlers = function () {
            this.handlers.forEach(function (handlerRegistration) { return handlerRegistration.unregister(); });
        };
        RootComponent.prototype.reconnectPopup = function () {
            var _this = this;
            this.popup('Сервис недоступен!<br></br> Нажмите "ОК" что-бы переподключиться или попробуйте позднее...', function () { return _this.logoutUser(); });
        };
        RootComponent.prototype.popup = function (message, callback) {
            this.confirmationService.confirm({
                header: 'ОШИБКА',
                icon: 'fa fa-exclamation-circle',
                message: message || 'undefined message',
                rejectVisible: false,
                acceptLabel: 'OK',
                accept: callback != null ? callback : function () {
                }
            });
        };
        RootComponent.prototype.logoutUser = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    // await this.authService.login(false);
                    window.location.reload();
                    return [2 /*return*/];
                });
            });
        };
        RootComponent.prototype.selectPersonal = function (personal) {
            this.initialized = true;
            this.user.select(personal);
        };
        RootComponent.prototype.checkRouter = function () {
            if (this.router.url === '/login') {
                return false;
            }
            else {
                return true;
            }
        };
        RootComponent.prototype.onToastMessageOkButtonClick = function (event) {
            var closeButton = event.target
                .closest('.ui-toast-message-content')
                .querySelector('.ui-toast-close-icon');
            closeButton.click();
        };
        RootComponent.prototype.getDialogIconClassByMessage = function (message) {
            if (!message || !message.hasOwnProperty('severity')) {
                return 'pi pi-check';
            }
            switch (message.severity) {
                case 'success':
                    return 'pi pi-check-circle';
                case 'warn':
                    return 'pi pi-exclamation-triangle';
                case 'error':
                    return 'pi pi-ban';
                case 'info':
                    return 'pi pi-info-circle';
                default:
                    return 'pi pi-check';
            }
        };
        RootComponent.prototype.getDialogButtonClassByMessage = function (message) {
            if (!message || !message.hasOwnProperty('severity')) {
                return 'ui-button-secondary';
            }
            switch (message.severity) {
                case 'success':
                    return 'ui-button-success';
                case 'warn':
                    return 'ui-button-warning';
                case 'error':
                    return 'ui-button-danger';
                case 'info':
                    return 'ui-button-info';
                default:
                    return 'ui-button-secondary';
            }
        };
        RootComponent.prototype.maxNumber = function () {
            return Number.MAX_SAFE_INTEGER - 10000;
        };
        RootComponent.ɵfac = function RootComponent_Factory(t) { return new (t || RootComponent)(core["ɵɵdirectiveInject"](AuthService), core["ɵɵdirectiveInject"](router.Router), core["ɵɵdirectiveInject"](api.ConfirmationService), core["ɵɵdirectiveInject"](ConfigurationService), core["ɵɵdirectiveInject"](EventBusService), core["ɵɵdirectiveInject"](api.MessageService), core["ɵɵdirectiveInject"](UserService), core["ɵɵdirectiveInject"](EntityConfigService)); };
        RootComponent.ɵcmp = core["ɵɵdefineComponent"]({ type: RootComponent, selectors: [["app-common-root"]], contentQueries: function RootComponent_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
                core["ɵɵcontentQuery"](dirIndex, _c0$1, true);
                core["ɵɵcontentQuery"](dirIndex, _c1$1, true);
            } if (rf & 2) {
                var _t;
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.contentTemplate = _t.first);
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.loadingTemplate = _t.first);
            } }, inputs: { showToolbar: "showToolbar", name: "name", showVersion: "showVersion", logoSrc: "logoSrc", mainMenu: "mainMenu", informationMenuEx: "informationMenuEx", contentNoPadding: "contentNoPadding", toolbarTemplate: "toolbarTemplate" }, decls: 16, vars: 18, consts: [[4, "ngIf", "ngIfThen", "ngIfElse"], ["loadingContainerTemplate", ""], ["pageTemplate", ""], [3, "baseZIndex"], ["position", "center", 3, "key", "modal", "baseZIndex"], ["pTemplate", "message"], [3, "visible", "modal", "closable", "header", "visibleChange"], ["userSelectDialog", ""], [2, "margin-top", "5px", "padding-left", "10px", "padding-right", "10px"], ["style", "min-height: 40px;", 4, "ngFor", "ngForOf"], [2, "text-align", "center", "margin-top", "5px"], ["pButton", "", "label", "\u0412\u044B\u0439\u0442\u0438", 1, "ui-button-secondary", 3, "click"], ["id", "loading-screen"], ["baseLoadingTemplate", ""], ["src", "assets/rosatom_loading.svg?v=1.1", 1, "rotate-animation"], [1, "v-flex"], ["id", "toolbar", 4, "ngIf"], ["id", "root-content", 1, "v-flex-grow"], [4, "ngTemplateOutlet"], ["id", "toolbar"], [3, "name", "showVersion", "logoSrc", "mainMenuItems", "informationMenuEx", "toolbarTemplate"], ["defaultMessage", ""], [1, "ui-g", "ui-fluid", 2, "text-align", "center"], [1, "ui-g-12"], ["type", "button", "pButton", "", "label", "OK", 2, "width", "50%", 3, "click"], [2, "text-align", "center"], [2, "font-size", "3em"], [2, "min-height", "40px"], ["pButton", "", "icon", "fa fa-user", 1, "toolbarBtn", 2, "width", "100%", 3, "label", "click"]], template: function RootComponent_Template(rf, ctx) { if (rf & 1) {
                core["ɵɵtemplate"](0, RootComponent_ng_container_0_Template, 1, 0, "ng-container", 0);
                core["ɵɵtemplate"](1, RootComponent_ng_template_1_Template, 4, 3, "ng-template", null, 1, core["ɵɵtemplateRefExtractor"]);
                core["ɵɵtemplate"](3, RootComponent_ng_template_3_Template, 4, 4, "ng-template", null, 2, core["ɵɵtemplateRefExtractor"]);
                core["ɵɵelement"](5, "p-toast", 3);
                core["ɵɵelementStart"](6, "p-toast", 4);
                core["ɵɵtemplate"](7, RootComponent_ng_template_7_Template, 6, 3, "ng-template", 5);
                core["ɵɵelementEnd"]();
                core["ɵɵelement"](8, "p-confirmDialog", 3);
                core["ɵɵelementStart"](9, "p-dialog", 6, 7);
                core["ɵɵlistener"]("visibleChange", function RootComponent_Template_p_dialog_visibleChange_9_listener($event) { return ctx.employmentsDialogVisible = $event; });
                core["ɵɵelementStart"](11, "div", 8);
                core["ɵɵtemplate"](12, RootComponent_div_12_Template, 2, 1, "div", 9);
                core["ɵɵelementEnd"]();
                core["ɵɵelementStart"](13, "p-footer");
                core["ɵɵelementStart"](14, "div", 10);
                core["ɵɵelementStart"](15, "button", 11);
                core["ɵɵlistener"]("click", function RootComponent_Template_button_click_15_listener() { return ctx.logoutUser(); });
                core["ɵɵelementEnd"]();
                core["ɵɵelementEnd"]();
                core["ɵɵelementEnd"]();
                core["ɵɵelementEnd"]();
            } if (rf & 2) {
                var _r450 = core["ɵɵreference"](2);
                var _r452 = core["ɵɵreference"](4);
                core["ɵɵproperty"]("ngIf", ctx.initialized && !ctx.loading)("ngIfThen", _r452)("ngIfElse", _r450);
                core["ɵɵadvance"](5);
                core["ɵɵproperty"]("baseZIndex", ctx.maxNumber());
                core["ɵɵadvance"](1);
                core["ɵɵpropertyInterpolate"]("key", ctx.MessageServiceKey.OK);
                core["ɵɵproperty"]("modal", true)("baseZIndex", ctx.maxNumber());
                core["ɵɵadvance"](2);
                core["ɵɵstyleMap"](core["ɵɵpureFunction0"](17, _c2));
                core["ɵɵproperty"]("baseZIndex", ctx.maxNumber());
                core["ɵɵadvance"](1);
                core["ɵɵproperty"]("visible", ctx.employmentsDialogVisible)("modal", true)("closable", false)("header", ctx.name + ". \u0412\u044B\u0431\u043E\u0440 \u0443\u0447\u0435\u0442\u043D\u043E\u0439 \u0437\u0430\u043F\u0438\u0441\u0438");
                core["ɵɵadvance"](3);
                core["ɵɵproperty"]("ngForOf", ctx.employments);
                core["ɵɵadvance"](3);
                core["ɵɵstyleProp"]("width", 50, "%");
            } }, directives: [common.NgIf, toast.Toast, api.PrimeTemplate, confirmdialog.ConfirmDialog, DialogExtDirective, dialog.Dialog, common.NgForOf, api.Footer, ButtonDirective, button.ButtonDirective, common.NgTemplateOutlet, ToolbarComponent], styles: ["#toolbar[_ngcontent-%COMP%]{min-width:800px}#root-content[_ngcontent-%COMP%]{padding:10px}#root-content.content-no-pad[_ngcontent-%COMP%]{padding:0}#loading-screen[_ngcontent-%COMP%]{width:100%;height:100%;color:#2d5a80;font-size:20px;display:-webkit-box;display:flex;-webkit-box-align:center;align-items:center;-webkit-box-pack:center;justify-content:center}#loading-screen[_ngcontent-%COMP%]   img[_ngcontent-%COMP%]{height:80px;width:80px}.rotate-animation[_ngcontent-%COMP%]{-webkit-animation:3s linear infinite rotation;animation:3s linear infinite rotation}@-webkit-keyframes rotation{from{-webkit-transform:rotate(0);transform:rotate(0)}to{-webkit-transform:rotate(359deg);transform:rotate(359deg)}}@keyframes rotation{from{-webkit-transform:rotate(0);transform:rotate(0)}to{-webkit-transform:rotate(359deg);transform:rotate(359deg)}}"] });
        return RootComponent;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](RootComponent, [{
            type: core.Component,
            args: [{
                    selector: 'app-common-root',
                    templateUrl: './root.component.html',
                    styleUrls: ['./root.component.css']
                }]
        }], function () { return [{ type: AuthService }, { type: router.Router }, { type: api.ConfirmationService }, { type: ConfigurationService }, { type: EventBusService }, { type: api.MessageService }, { type: UserService }, { type: EntityConfigService }]; }, { showToolbar: [{
                type: core.Input
            }], name: [{
                type: core.Input
            }], showVersion: [{
                type: core.Input
            }], logoSrc: [{
                type: core.Input
            }], mainMenu: [{
                type: core.Input
            }], informationMenuEx: [{
                type: core.Input
            }], contentNoPadding: [{
                type: core.Input
            }], toolbarTemplate: [{
                type: core.Input
            }], contentTemplate: [{
                type: core.ContentChild,
                args: ['content']
            }], loadingTemplate: [{
                type: core.ContentChild,
                args: ['loading']
            }] }); })();

    var _c0$2 = ["cell"];
    var Column = /** @class */ (function () {
        function Column() {
            this.index = -1;
            this.headerChange = new core.EventEmitter();
            this.onGetColumnStyle = new core.EventEmitter();
            this.cellValueChanged = new core.EventEmitter();
            this.pinned = false;
            this.lockPinned = false;
            this.filterAvailable = true;
            this.sortAvailable = true;
            this.isDisableSummaryRowCalculating = false;
            this._available = true;
            this._visible = true;
            this.layoutChange = new core.EventEmitter();
            this.widthChange = new core.EventEmitter();
        }
        Object.defineProperty(Column.prototype, "header", {
            get: function () {
                return this._header;
            },
            set: function (val) {
                if (this._header !== val) {
                    this._header = val;
                    this.headerChange.emit(val);
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Column.prototype, "type", {
            get: function () {
                return this._type;
            },
            set: function (val) {
                this._type = val;
                this.calcFilterOptions();
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Column.prototype, "enum", {
            get: function () {
                return this._enum;
            },
            set: function (val) {
                this._enum = val;
                this.calcFilterOptions();
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Column.prototype, "width", {
            get: function () {
                return this._width;
            },
            set: function (width) {
                if (this._width != width) {
                    this._width = width;
                    this.widthChange.emit(this);
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Column.prototype, "minWidth", {
            get: function () {
                return this._minWidth;
            },
            set: function (minWidth) {
                if (this._minWidth != minWidth) {
                    this._minWidth = minWidth;
                    if (this.width < this._minWidth) {
                        this.width = this._minWidth;
                    }
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Column.prototype, "maxWidth", {
            get: function () {
                return this._maxWidth;
            },
            set: function (maxWidth) {
                if (this._maxWidth != maxWidth) {
                    this._maxWidth = maxWidth;
                    if (this.width > this._maxWidth) {
                        this.width = this._maxWidth;
                    }
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Column.prototype, "flex", {
            get: function () {
                return this._flex;
            },
            set: function (flex) {
                this._flex = flex;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Column.prototype, "available", {
            get: function () {
                return this._available;
            },
            set: function (v) {
                if (this._available != v) {
                    this._available = v;
                    this.layoutChange.emit(this);
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Column.prototype, "visible", {
            get: function () {
                return this._visible;
            },
            set: function (v) {
                if (this._visible != v) {
                    this._visible = v;
                    this.layoutChange.emit(this);
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Column.prototype, "frozen", {
            get: function () {
                return this.pinned;
            },
            set: function (frozen) {
                this.pinned = frozen;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Column.prototype, "filterOptions", {
            get: function () {
                return this._filterOptions;
            },
            enumerable: true,
            configurable: true
        });
        Column.prototype.ngAfterContentInit = function () {
            var _this = this;
            this.children = this.cols.toArray().filter(function (c) { return c != _this; });
        };
        Column.prototype.calcFilterOptions = function () {
            if (this.type == 'bool') {
                this._filterOptions = [
                    { label: '', value: null },
                    { label: 'да', value: true },
                    { label: 'нет', value: false }
                ];
            }
            else {
                var options = [{ label: '', value: null }];
                for (var val in this._enum) {
                    options.push({ label: this._enum[val], value: val });
                }
                this._filterOptions = options;
            }
        };
        Column.create = function (field, header, type) {
            if (type === void 0) { type = null; }
            var col = new Column();
            col.field = field;
            col.header = header;
            col.type = type;
            return col;
        };
        Object.defineProperty(Column.prototype, "filterAvalible", {
            get: function () {
                return this.filterAvailable;
            },
            set: function (val) {
                console.warn('Use column propery "filterAvailable" instead of "filterAvalible"!');
                this.filterAvailable = val;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Column.prototype, "sortAvalible", {
            get: function () {
                return this.sortAvailable;
            },
            set: function (val) {
                console.warn('Use column propery "sortAvailable" instead of "sortAvalible"!');
                this.sortAvailable = val;
            },
            enumerable: true,
            configurable: true
        });
        Column.ɵfac = function Column_Factory(t) { return new (t || Column)(); };
        Column.ɵdir = core["ɵɵdefineDirective"]({ type: Column, selectors: [["column"]], contentQueries: function Column_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
                core["ɵɵcontentQuery"](dirIndex, _c0$2, true);
                core["ɵɵcontentQuery"](dirIndex, Column, false);
            } if (rf & 2) {
                var _t;
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.cellTemplate = _t.first);
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.cols = _t);
            } }, inputs: { field: "field", header: "header", filterMatchMode: "filterMatchMode", textAlign: "textAlign", pinned: "pinned", lockPinned: "lockPinned", calcCellStyle: "calcCellStyle", filterAvailable: "filterAvailable", sortAvailable: "sortAvailable", tooltipField: "tooltipField", headerTooltip: "headerTooltip", editable: "editable", cellEditor: "cellEditor", cellEditorParams: "cellEditorParams", valueGetter: "valueGetter", valueFormatter: "valueFormatter", valueSetter: "valueSetter", children: "children", cellEditorSelector: "cellEditorSelector", headerComponent: "headerComponent", headerComponentParams: "headerComponentParams", rowSpan: "rowSpan", cellClassRules: "cellClassRules", customCellRenderer: "customCellRenderer", customCellRendererStyle: "customCellRendererStyle", enableRowGroup: "enableRowGroup", rowGroup: "rowGroup", rowGroupIndex: "rowGroupIndex", enablePivot: "enablePivot", enableValue: "enableValue", pivot: "pivot", pivotIndex: "pivotIndex", aggFunc: "aggFunc", isDisableSummaryRowCalculating: "isDisableSummaryRowCalculating", type: "type", enum: "enum", width: "width", minWidth: "minWidth", maxWidth: "maxWidth", flex: "flex", available: "available", visible: "visible", filterAvalible: "filterAvalible", sortAvalible: "sortAvalible" }, outputs: { headerChange: "headerChange", onGetColumnStyle: "onGetColumnStyle", cellValueChanged: "cellValueChanged", layoutChange: "layoutChange", widthChange: "widthChange" } });
        return Column;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](Column, [{
            type: core.Directive,
            args: [{
                    selector: 'app-table column'
                }]
        }], null, { field: [{
                type: core.Input
            }], header: [{
                type: core.Input
            }], headerChange: [{
                type: core.Output
            }], onGetColumnStyle: [{
                type: core.Output
            }], cellValueChanged: [{
                type: core.Output
            }], filterMatchMode: [{
                type: core.Input
            }], textAlign: [{
                type: core.Input
            }], pinned: [{
                type: core.Input
            }], lockPinned: [{
                type: core.Input
            }], calcCellStyle: [{
                type: core.Input
            }], filterAvailable: [{
                type: core.Input
            }], sortAvailable: [{
                type: core.Input
            }], tooltipField: [{
                type: core.Input
            }], headerTooltip: [{
                type: core.Input
            }], editable: [{
                type: core.Input
            }], cellEditor: [{
                type: core.Input
            }], cellEditorParams: [{
                type: core.Input
            }], valueGetter: [{
                type: core.Input
            }], valueFormatter: [{
                type: core.Input
            }], valueSetter: [{
                type: core.Input
            }], children: [{
                type: core.Input
            }], cellEditorSelector: [{
                type: core.Input
            }], headerComponent: [{
                type: core.Input
            }], headerComponentParams: [{
                type: core.Input
            }], rowSpan: [{
                type: core.Input
            }], cellClassRules: [{
                type: core.Input
            }], customCellRenderer: [{
                type: core.Input
            }], customCellRendererStyle: [{
                type: core.Input
            }], enableRowGroup: [{
                type: core.Input
            }], rowGroup: [{
                type: core.Input
            }], rowGroupIndex: [{
                type: core.Input
            }], enablePivot: [{
                type: core.Input
            }], enableValue: [{
                type: core.Input
            }], pivot: [{
                type: core.Input
            }], pivotIndex: [{
                type: core.Input
            }], aggFunc: [{
                type: core.Input
            }], isDisableSummaryRowCalculating: [{
                type: core.Input
            }], type: [{
                type: core.Input
            }], enum: [{
                type: core.Input
            }], width: [{
                type: core.Input
            }], minWidth: [{
                type: core.Input
            }], maxWidth: [{
                type: core.Input
            }], flex: [{
                type: core.Input
            }], available: [{
                type: core.Input
            }], visible: [{
                type: core.Input
            }], layoutChange: [{
                type: core.Output
            }], widthChange: [{
                type: core.Output
            }], cellTemplate: [{
                type: core.ContentChild,
                args: ['cell']
            }], cols: [{
                type: core.ContentChildren,
                args: [Column]
            }], filterAvalible: [{
                type: core.Input
            }], sortAvalible: [{
                type: core.Input
            }] }); })();

    var SumPipe = /** @class */ (function () {
        function SumPipe(_local) {
            this._local = _local;
        }
        SumPipe.prototype.transform = function (value, args) {
            return value ? new common.DecimalPipe(this._local).transform(value, "1.2-2") : value;
        };
        SumPipe.ɵfac = function SumPipe_Factory(t) { return new (t || SumPipe)(core["ɵɵdirectiveInject"](core.LOCALE_ID)); };
        SumPipe.ɵpipe = core["ɵɵdefinePipe"]({ name: "sum", type: SumPipe, pure: true });
        return SumPipe;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](SumPipe, [{
            type: core.Pipe,
            args: [{
                    name: 'sum'
                }]
        }], function () { return [{ type: undefined, decorators: [{
                    type: core.Inject,
                    args: [core.LOCALE_ID]
                }] }]; }, null); })();

    var Cell = /** @class */ (function () {
        function Cell(table, local) {
            this.table = table;
            this.local = local;
        }
        Object.defineProperty(Cell.prototype, "col", {
            get: function () {
                return this.cellContext.col;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Cell.prototype, "rowData", {
            get: function () {
                return this.cellContext.rowData;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Cell.prototype, "rowIndex", {
            get: function () {
                return this.cellContext.rowIndex;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Cell.prototype, "value", {
            get: function () {
                var e_1, _a;
                var nestedProps = this.col.field.split('.');
                var value = this.rowData;
                try {
                    for (var nestedProps_1 = __values(nestedProps), nestedProps_1_1 = nestedProps_1.next(); !nestedProps_1_1.done; nestedProps_1_1 = nestedProps_1.next()) {
                        var prop = nestedProps_1_1.value;
                        value = value[prop];
                        if (value == null) {
                            value = '';
                        }
                    }
                }
                catch (e_1_1) { e_1 = { error: e_1_1 }; }
                finally {
                    try {
                        if (nestedProps_1_1 && !nestedProps_1_1.done && (_a = nestedProps_1.return)) _a.call(nestedProps_1);
                    }
                    finally { if (e_1) throw e_1.error; }
                }
                return value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Cell.prototype, "isSelected", {
            get: function () {
                return this.cellContext.isSelected;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Cell.prototype, "text", {
            get: function () {
                var value = this.value;
                switch (this.col.type) {
                    case 'bool': return null;
                    case 'sum': return new SumPipe(this.local).transform(value);
                    case 'date': return new common.DatePipe(this.local).transform(value, 'dd.MM.yyyy');
                    case 'dateTime': return new common.DatePipe(this.local).transform(value, 'dd.MM.yyyy HH:mm:ss');
                    case 'dateYear': return new common.DatePipe(this.local).transform(value, 'yyyy');
                    case 'enum': {
                        return value ? (this.col.enum && this.col.enum[value] ? this.col.enum[value] : ("[" + value + "]")) : "";
                    }
                    case 'enum_bool': {
                        return value != null ? (this.col.enum && this.col.enum[value] ? this.col.enum[value] : ("[" + value + "]")) : "";
                    }
                }
                return value == null ? null : value.toString();
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Cell.prototype, "icon", {
            get: function () {
                if (this.col.type == 'bool') {
                    var value = this.value;
                    return value == null ? "" : value ? "&#xF00C;" : "&#xF00D;";
                }
                return null;
            },
            enumerable: true,
            configurable: true
        });
        Cell.ɵfac = function Cell_Factory(t) { return new (t || Cell)(core["ɵɵdirectiveInject"](TableComponent), core["ɵɵdirectiveInject"](core.LOCALE_ID)); };
        Cell.ɵdir = core["ɵɵdefineDirective"]({ type: Cell, selectors: [["td", "cellContext", ""]], hostVars: 12, hostBindings: function Cell_HostBindings(rf, ctx) { if (rf & 2) {
                core["ɵɵstyleProp"]("text-align", ctx.col.textAlign ? ctx.col.textAlign : null)("height", "1.25em")("overflow", "hidden")("white-space", "nowrap")("text-overflow", "ellipsis");
                core["ɵɵclassProp"]("cell-no-color", ctx.isSelected);
            } }, inputs: { cellContext: "cellContext" }, exportAs: ["cell"] });
        return Cell;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](Cell, [{
            type: core.Directive,
            args: [{
                    selector: 'app-table td[cellContext]',
                    host: {
                        '[style.textAlign]': 'col.textAlign ? col.textAlign : null',
                        '[class.cell-no-color]': 'isSelected',
                        '[style.height]': '"1.25em"',
                        '[style.overflow]': '"hidden"',
                        '[style.white-space]': '"nowrap"',
                        '[style.text-overflow]': '"ellipsis"'
                    },
                    exportAs: 'cell'
                }]
        }], function () { return [{ type: TableComponent }, { type: undefined, decorators: [{
                    type: core.Inject,
                    args: [core.LOCALE_ID]
                }] }]; }, { cellContext: [{
                type: core.Input
            }] }); })();

    var TableFrozenFixDirective = /** @class */ (function () {
        function TableFrozenFixDirective(table) {
            this.table = table;
        }
        TableFrozenFixDirective.prototype.ngAfterViewInit = function () {
            var wrapper = this.table.el.nativeElement.querySelector(".ui-table-scrollable-wrapper");
            var fozen = this.table.el.nativeElement.querySelector(".ui-table-frozen-view");
            if (fozen) {
                wrapper.appendChild(fozen);
            }
        };
        TableFrozenFixDirective.ɵfac = function TableFrozenFixDirective_Factory(t) { return new (t || TableFrozenFixDirective)(core["ɵɵdirectiveInject"](table.Table)); };
        TableFrozenFixDirective.ɵdir = core["ɵɵdefineDirective"]({ type: TableFrozenFixDirective, selectors: [["p-table"]] });
        return TableFrozenFixDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](TableFrozenFixDirective, [{
            type: core.Directive,
            args: [{ selector: 'p-table' }]
        }], function () { return [{ type: table.Table }]; }, null); })();

    var MenuItemDirective = /** @class */ (function () {
        function MenuItemDirective() {
            var _this = this;
            this.item = { command: function (event) { return _this.onCommand(event); } };
            this.command = new core.EventEmitter();
        }
        Object.defineProperty(MenuItemDirective.prototype, "label", {
            get: function () { return this.item.label; },
            set: function (val) { this.item.label = val; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(MenuItemDirective.prototype, "icon", {
            get: function () { return this.item.icon; },
            set: function (val) { this.item.icon = val; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(MenuItemDirective.prototype, "url", {
            get: function () { return this.item.url; },
            set: function (val) { this.item.url = val; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(MenuItemDirective.prototype, "routerLink", {
            get: function () { return this.item.routerLink; },
            set: function (val) { this.item.routerLink = val; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(MenuItemDirective.prototype, "queryParams", {
            get: function () { return this.item.queryParams; },
            set: function (val) { this.item.queryParams = val; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(MenuItemDirective.prototype, "expanded", {
            get: function () { return this.item.expanded; },
            set: function (val) { this.item.expanded = val; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(MenuItemDirective.prototype, "disabled", {
            get: function () { return this.item.disabled; },
            set: function (val) { this.item.disabled = val; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(MenuItemDirective.prototype, "visible", {
            get: function () { return this.item.visible; },
            set: function (val) { this.item.visible = val; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(MenuItemDirective.prototype, "target", {
            get: function () { return this.item.target; },
            set: function (val) { this.item.target = val; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(MenuItemDirective.prototype, "routerLinkActiveOptions", {
            get: function () { return this.item.routerLinkActiveOptions; },
            set: function (val) { this.item.routerLinkActiveOptions = val; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(MenuItemDirective.prototype, "separator", {
            get: function () { return this.item.separator; },
            set: function (val) { this.item.separator = val; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(MenuItemDirective.prototype, "badge", {
            get: function () { return this.item.badge; },
            set: function (val) { this.item.badge = val; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(MenuItemDirective.prototype, "badgeStyleClass", {
            get: function () { return this.item.badgeStyleClass; },
            set: function (val) { this.item.badgeStyleClass = val; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(MenuItemDirective.prototype, "style", {
            get: function () { return this.item.style; },
            set: function (val) { this.item.style = val; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(MenuItemDirective.prototype, "styleClass", {
            get: function () { return this.item.styleClass; },
            set: function (val) { this.item.styleClass = val; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(MenuItemDirective.prototype, "title", {
            get: function () { return this.item.title; },
            set: function (val) { this.item.title = val; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(MenuItemDirective.prototype, "id", {
            get: function () { return this.item.id; },
            set: function (val) { this.item.id = val; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(MenuItemDirective.prototype, "automationId", {
            get: function () { return this.item.automationId; },
            set: function (val) { this.item.automationId = val; },
            enumerable: true,
            configurable: true
        });
        MenuItemDirective.prototype.onCommand = function (event) {
            this.command.emit(event);
        };
        ;
        MenuItemDirective.ɵfac = function MenuItemDirective_Factory(t) { return new (t || MenuItemDirective)(); };
        MenuItemDirective.ɵdir = core["ɵɵdefineDirective"]({ type: MenuItemDirective, selectors: [["p-menu-item"]], inputs: { label: "label", icon: "icon", url: "url", routerLink: "routerLink", queryParams: "queryParams", expanded: "expanded", disabled: "disabled", visible: "visible", target: "target", routerLinkActiveOptions: "routerLinkActiveOptions", separator: "separator", badge: "badge", badgeStyleClass: "badgeStyleClass", style: "style", styleClass: "styleClass", title: "title", id: "id", automationId: "automationId" }, outputs: { command: "command" } });
        return MenuItemDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](MenuItemDirective, [{
            type: core.Directive,
            args: [{
                    selector: 'p-menu-item'
                }]
        }], null, { label: [{
                type: core.Input
            }], icon: [{
                type: core.Input
            }], url: [{
                type: core.Input
            }], routerLink: [{
                type: core.Input
            }], queryParams: [{
                type: core.Input
            }], expanded: [{
                type: core.Input
            }], disabled: [{
                type: core.Input
            }], visible: [{
                type: core.Input
            }], target: [{
                type: core.Input
            }], routerLinkActiveOptions: [{
                type: core.Input
            }], separator: [{
                type: core.Input
            }], badge: [{
                type: core.Input
            }], badgeStyleClass: [{
                type: core.Input
            }], style: [{
                type: core.Input
            }], styleClass: [{
                type: core.Input
            }], title: [{
                type: core.Input
            }], id: [{
                type: core.Input
            }], automationId: [{
                type: core.Input
            }], command: [{
                type: core.Output
            }] }); })();

    var MenuDirective = /** @class */ (function () {
        function MenuDirective(menu) {
            this.menu = menu;
        }
        MenuDirective.prototype.ngAfterContentInit = function () {
            var _this = this;
            this.menu.model = this.menuItems.toArray().map(function (m) { return m.item; });
            this.menuItems.changes.subscribe(function (ch) {
                _this.menu.model = _this.menuItems.toArray().map(function (m) { return m.item; });
            });
        };
        MenuDirective.ɵfac = function MenuDirective_Factory(t) { return new (t || MenuDirective)(core["ɵɵdirectiveInject"](menu.Menu)); };
        MenuDirective.ɵdir = core["ɵɵdefineDirective"]({ type: MenuDirective, selectors: [["p-menu"]], contentQueries: function MenuDirective_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
                core["ɵɵcontentQuery"](dirIndex, MenuItemDirective, false);
            } if (rf & 2) {
                var _t;
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.menuItems = _t);
            } } });
        return MenuDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](MenuDirective, [{
            type: core.Directive,
            args: [{
                    selector: 'p-menu'
                }]
        }], function () { return [{ type: menu.Menu }]; }, { menuItems: [{
                type: core.ContentChildren,
                args: [MenuItemDirective]
            }] }); })();

    var InputDirective = /** @class */ (function () {
        function InputDirective(input) {
            this.input = input;
            this.autocomplete = false;
            this.emptyStringEqualsNull = true;
        }
        InputDirective.prototype.onChange = function (event) {
            if (this.emptyStringEqualsNull) {
                if (event.target.value === '') {
                    this.input.ngModel.valueAccessor.writeValue(null);
                    this.input.ngModel.viewToModelUpdate(null);
                }
            }
        };
        InputDirective.prototype.ngOnInit = function () {
            this.input.el.nativeElement.setAttribute('autocomplete', this.autocomplete ? '' : 'off');
        };
        InputDirective.ɵfac = function InputDirective_Factory(t) { return new (t || InputDirective)(core["ɵɵdirectiveInject"](primeng.InputText)); };
        InputDirective.ɵdir = core["ɵɵdefineDirective"]({ type: InputDirective, selectors: [["input", "pInputText", ""]], hostBindings: function InputDirective_HostBindings(rf, ctx) { if (rf & 1) {
                core["ɵɵlistener"]("change", function InputDirective_change_HostBindingHandler($event) { return ctx.onChange($event); });
            } }, inputs: { autocomplete: "autocomplete", emptyStringEqualsNull: "emptyStringEqualsNull" } });
        return InputDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](InputDirective, [{
            type: core.Directive,
            args: [{
                    selector: 'input [pInputText]'
                }]
        }], function () { return [{ type: primeng.InputText }]; }, { autocomplete: [{
                type: core.Input
            }], emptyStringEqualsNull: [{
                type: core.Input
            }], onChange: [{
                type: core.HostListener,
                args: ['change', ['$event']]
            }] }); })();

    var ValidationMessageDirective = /** @class */ (function () {
        function ValidationMessageDirective(el, control, ngZone) {
            var _this = this;
            this.sub = control.statusChanges.subscribe(function () {
                var formRow = el.nativeElement.closest('.form-row');
                if (formRow) {
                    if (control.pending) {
                        return;
                    }
                    if (_this.errorRowDiv) {
                        _this.errorRowDiv.classList.remove('form-error-row-show');
                        _this.errorDiv.innerHTML = '';
                    }
                    if (control.dirty && control.invalid) {
                        var error = '';
                        var ind = 0;
                        for (var errCode in control.errors) {
                            if (errCode == 'required') {
                                //
                            }
                            else {
                                error += (ind == 0 ? '' : '<br/>') + control.errors[errCode];
                            }
                            ind++;
                        }
                        if (error) {
                            if (!_this.errorRowDiv) {
                                _this.errorRowDiv = document.createElement('div');
                                _this.errorRowDiv.classList.add('form-row', 'form-error-row');
                                var labelDiv = document.createElement('div');
                                _this.errorRowDiv.appendChild(labelDiv);
                                _this.errorDiv = document.createElement('div');
                                _this.errorDiv.classList.add('validation-error');
                                _this.errorRowDiv.appendChild(_this.errorDiv);
                            }
                            formRow.after(_this.errorRowDiv);
                            window.getComputedStyle(_this.errorDiv).opacity; // force reset css animations
                            _this.errorDiv.innerHTML = '<i class="fa fa-exclamation-triangle"></i> ' + error;
                            _this.errorRowDiv.classList.add('form-error-row-show');
                        }
                    }
                }
            });
        }
        ValidationMessageDirective.prototype.ngAfterViewInit = function () {
        };
        ValidationMessageDirective.prototype.ngOnDestroy = function () {
            this.sub.unsubscribe();
        };
        ValidationMessageDirective.ɵfac = function ValidationMessageDirective_Factory(t) { return new (t || ValidationMessageDirective)(core["ɵɵdirectiveInject"](core.ElementRef), core["ɵɵdirectiveInject"](forms.NgControl), core["ɵɵdirectiveInject"](core.NgZone)); };
        ValidationMessageDirective.ɵdir = core["ɵɵdefineDirective"]({ type: ValidationMessageDirective, selectors: [["", "ngModel", ""], ["", "formControl", ""]] });
        return ValidationMessageDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](ValidationMessageDirective, [{
            type: core.Directive,
            args: [{
                    selector: '[ngModel], [formControl]'
                }]
        }], function () { return [{ type: core.ElementRef }, { type: forms.NgControl }, { type: core.NgZone }]; }, null); })();

    var _c0$3 = ["dt"];
    function TableComponent_ng_template_2_Template(rf, ctx) { }
    function TableComponent_ng_template_3_ng_container_1_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainerStart"](0);
        core["ɵɵelement"](1, "col");
        core["ɵɵelementContainerEnd"]();
    } if (rf & 2) {
        var col_r483 = ctx.$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵstyleProp"]("width", col_r483.width || 200, "px");
    } }
    function TableComponent_ng_template_3_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementStart"](0, "colgroup");
        core["ɵɵtemplate"](1, TableComponent_ng_template_3_ng_container_1_Template, 2, 2, "ng-container", 13);
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var columns_r481 = ctx.$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngForOf", columns_r481);
    } }
    function TableComponent_ng_template_4_tr_0_ng_container_1_th_1_p_sortIcon_1_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelement"](0, "p-sortIcon", 18);
    } if (rf & 2) {
        var col_r489 = core["ɵɵnextContext"](2).$implicit;
        core["ɵɵproperty"]("field", col_r489.field);
    } }
    function TableComponent_ng_template_4_tr_0_ng_container_1_th_1_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementStart"](0, "th", 16);
        core["ɵɵtemplate"](1, TableComponent_ng_template_4_tr_0_ng_container_1_th_1_p_sortIcon_1_Template, 1, 1, "p-sortIcon", 17);
        core["ɵɵtext"](2);
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var col_r489 = core["ɵɵnextContext"]().$implicit;
        var ctx_r490 = core["ɵɵnextContext"](3);
        core["ɵɵstyleProp"]("text-align", col_r489.textAlign);
        core["ɵɵproperty"]("pContextMenuRow", col_r489)("pResizableColumnDisabled", col_r489.frozen)("pReorderableColumnDisabled", col_r489.frozen)("pSortableColumn", col_r489.field)("pSortableColumnDisabled", !col_r489.field || ctx_r490.resizing);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", col_r489.field);
        core["ɵɵadvance"](1);
        core["ɵɵtextInterpolate1"](" ", col_r489.header, " ");
    } }
    function TableComponent_ng_template_4_tr_0_ng_container_1_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainerStart"](0);
        core["ɵɵtemplate"](1, TableComponent_ng_template_4_tr_0_ng_container_1_th_1_Template, 3, 9, "th", 15);
        core["ɵɵelementContainerEnd"]();
    } if (rf & 2) {
        var col_r489 = ctx.$implicit;
        var columns_r484 = core["ɵɵnextContext"](2).$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", columns_r484.length > 1 || col_r489.header);
    } }
    function TableComponent_ng_template_4_tr_0_th_2_span_1_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementStart"](0, "span");
        core["ɵɵtext"](1, "\u041D\u0435 \u0432\u044B\u0431\u0440\u0430\u043D\u044B \u043A\u043E\u043B\u043E\u043D\u043A\u0438 \u0434\u043B\u044F \u043E\u0442\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u044F");
        core["ɵɵelementEnd"]();
    } }
    function TableComponent_ng_template_4_tr_0_th_2_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementStart"](0, "th", 19);
        core["ɵɵtemplate"](1, TableComponent_ng_template_4_tr_0_th_2_span_1_Template, 2, 0, "span", 6);
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var columns_r484 = core["ɵɵnextContext"](2).$implicit;
        var ctx_r488 = core["ɵɵnextContext"]();
        core["ɵɵproperty"]("pContextMenuRow", ctx_r488.emptyColumn);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", columns_r484.length == 0);
    } }
    function TableComponent_ng_template_4_tr_0_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementStart"](0, "tr");
        core["ɵɵtemplate"](1, TableComponent_ng_template_4_tr_0_ng_container_1_Template, 2, 1, "ng-container", 13);
        core["ɵɵtemplate"](2, TableComponent_ng_template_4_tr_0_th_2_Template, 2, 2, "th", 14);
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var columns_r484 = core["ɵɵnextContext"]().$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngForOf", columns_r484);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", columns_r484.length == 0 || columns_r484.length > 1 || columns_r484[0].header);
    } }
    function TableComponent_ng_template_4_tr_1_ng_container_1_input_3_Template(rf, ctx) { if (rf & 1) {
        var _r510 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "input", 32, 33);
        core["ɵɵlistener"]("input", function TableComponent_ng_template_4_tr_1_ng_container_1_input_3_Template_input_input_0_listener($event) { core["ɵɵrestoreView"](_r510); var col_r500 = core["ɵɵnextContext"]().$implicit; var ctx_r509 = core["ɵɵnextContext"](3); return ctx_r509.applyFilter(true, $event.target.value, col_r500); })("keydown.enter", function TableComponent_ng_template_4_tr_1_ng_container_1_input_3_Template_input_keydown_enter_0_listener($event) { core["ɵɵrestoreView"](_r510); var col_r500 = core["ɵɵnextContext"]().$implicit; var ctx_r512 = core["ɵɵnextContext"](3); return ctx_r512.applyFilter(false, $event.target.value, col_r500); });
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var col_r500 = core["ɵɵnextContext"]().$implicit;
        var ctx_r501 = core["ɵɵnextContext"](3);
        var _r472 = core["ɵɵreference"](1);
        core["ɵɵstyleProp"]("text-align", col_r500.textAlign);
        core["ɵɵproperty"]("readonly", ctx_r501.loading)("value", _r472.filters[col_r500.field] == null ? null : _r472.filters[col_r500.field].value);
    } }
    var _c1$2 = function () { return { width: "100%", "margin-top": "-1px" }; };
    function TableComponent_ng_template_4_tr_1_ng_container_1_p_dropdown_4_Template(rf, ctx) { if (rf & 1) {
        var _r517 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "p-dropdown", 34, 35);
        core["ɵɵlistener"]("onChange", function TableComponent_ng_template_4_tr_1_ng_container_1_p_dropdown_4_Template_p_dropdown_onChange_0_listener($event) { core["ɵɵrestoreView"](_r517); var col_r500 = core["ɵɵnextContext"]().$implicit; var ctx_r516 = core["ɵɵnextContext"](3); return ctx_r516.applyFilter(false, $event.target.value, col_r500); });
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var col_r500 = core["ɵɵnextContext"]().$implicit;
        core["ɵɵnextContext"](3);
        var _r472 = core["ɵɵreference"](1);
        core["ɵɵstyleMap"](core["ɵɵpureFunction0"](4, _c1$2));
        core["ɵɵproperty"]("ngModel", _r472.filters[col_r500.field] == null ? null : _r472.filters[col_r500.field].value)("options", col_r500.filterOptions);
    } }
    function TableComponent_ng_template_4_tr_1_ng_container_1_button_5_Template(rf, ctx) { if (rf & 1) {
        var _r521 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "button", 36);
        core["ɵɵlistener"]("click", function TableComponent_ng_template_4_tr_1_ng_container_1_button_5_Template_button_click_0_listener($event) { core["ɵɵrestoreView"](_r521); core["ɵɵnextContext"](); var _r504 = core["ɵɵreference"](7); return _r504.toggle($event); });
        core["ɵɵtext"](1);
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var col_r500 = core["ɵɵnextContext"]().$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵtextInterpolate1"](" ", col_r500.filterMatchMode == "startsWith" ? "\u0430\u0431\u0432.." : col_r500.filterMatchMode == "equals" ? "=" : col_r500.filterMatchMode == "in" ? "\u0430\u0431,\u0432\u0433, \u0434\u0435" : col_r500.filterMatchMode == "isNotNull" ? "\u0437\u0430\u0434\u0430\u043D\u043E" : col_r500.filterMatchMode == "isNull" ? "\u043D\u0435 \u0437\u0430\u0434\u0430\u043D\u043E" : col_r500.type == "bool" || col_r500.type == "enum" ? "=" : "..\u0430\u0431\u0432..", " ");
    } }
    function TableComponent_ng_template_4_tr_1_ng_container_1_p_menu_item_8_Template(rf, ctx) { if (rf & 1) {
        var _r525 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "p-menu-item", 37);
        core["ɵɵlistener"]("command", function TableComponent_ng_template_4_tr_1_ng_container_1_p_menu_item_8_Template_p_menu_item_command_0_listener() { core["ɵɵrestoreView"](_r525); var col_r500 = core["ɵɵnextContext"]().$implicit; var ctx_r523 = core["ɵɵnextContext"](3); return ctx_r523.applyFilterMode("contains", col_r500); });
        core["ɵɵelementEnd"]();
    } }
    function TableComponent_ng_template_4_tr_1_ng_container_1_p_menu_item_9_Template(rf, ctx) { if (rf & 1) {
        var _r528 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "p-menu-item", 38);
        core["ɵɵlistener"]("command", function TableComponent_ng_template_4_tr_1_ng_container_1_p_menu_item_9_Template_p_menu_item_command_0_listener() { core["ɵɵrestoreView"](_r528); var col_r500 = core["ɵɵnextContext"]().$implicit; var ctx_r526 = core["ɵɵnextContext"](3); return ctx_r526.applyFilterMode("startsWith", col_r500); });
        core["ɵɵelementEnd"]();
    } }
    function TableComponent_ng_template_4_tr_1_ng_container_1_p_menu_item_11_Template(rf, ctx) { if (rf & 1) {
        var _r531 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "p-menu-item", 39);
        core["ɵɵlistener"]("command", function TableComponent_ng_template_4_tr_1_ng_container_1_p_menu_item_11_Template_p_menu_item_command_0_listener() { core["ɵɵrestoreView"](_r531); var col_r500 = core["ɵɵnextContext"]().$implicit; var ctx_r529 = core["ɵɵnextContext"](3); return ctx_r529.applyFilterMode("in", col_r500); });
        core["ɵɵelementEnd"]();
    } }
    function TableComponent_ng_template_4_tr_1_ng_container_1_Template(rf, ctx) { if (rf & 1) {
        var _r533 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementContainerStart"](0);
        core["ɵɵelementStart"](1, "th");
        core["ɵɵelementStart"](2, "div", 20);
        core["ɵɵtemplate"](3, TableComponent_ng_template_4_tr_1_ng_container_1_input_3_Template, 2, 4, "input", 21);
        core["ɵɵtemplate"](4, TableComponent_ng_template_4_tr_1_ng_container_1_p_dropdown_4_Template, 2, 5, "p-dropdown", 22);
        core["ɵɵtemplate"](5, TableComponent_ng_template_4_tr_1_ng_container_1_button_5_Template, 2, 1, "button", 23);
        core["ɵɵelementStart"](6, "p-menu", 24, 25);
        core["ɵɵtemplate"](8, TableComponent_ng_template_4_tr_1_ng_container_1_p_menu_item_8_Template, 1, 0, "p-menu-item", 26);
        core["ɵɵtemplate"](9, TableComponent_ng_template_4_tr_1_ng_container_1_p_menu_item_9_Template, 1, 0, "p-menu-item", 27);
        core["ɵɵelementStart"](10, "p-menu-item", 28);
        core["ɵɵlistener"]("command", function TableComponent_ng_template_4_tr_1_ng_container_1_Template_p_menu_item_command_10_listener() { core["ɵɵrestoreView"](_r533); var col_r500 = ctx.$implicit; var ctx_r532 = core["ɵɵnextContext"](3); return ctx_r532.applyFilterMode("equals", col_r500); });
        core["ɵɵelementEnd"]();
        core["ɵɵtemplate"](11, TableComponent_ng_template_4_tr_1_ng_container_1_p_menu_item_11_Template, 1, 0, "p-menu-item", 29);
        core["ɵɵelementStart"](12, "p-menu-item", 30);
        core["ɵɵlistener"]("command", function TableComponent_ng_template_4_tr_1_ng_container_1_Template_p_menu_item_command_12_listener() { core["ɵɵrestoreView"](_r533); var col_r500 = ctx.$implicit; var ctx_r534 = core["ɵɵnextContext"](3); return ctx_r534.applyFilterMode("isNotNull", col_r500); });
        core["ɵɵelementEnd"]();
        core["ɵɵelementStart"](13, "p-menu-item", 31);
        core["ɵɵlistener"]("command", function TableComponent_ng_template_4_tr_1_ng_container_1_Template_p_menu_item_command_13_listener() { core["ɵɵrestoreView"](_r533); var col_r500 = ctx.$implicit; var ctx_r535 = core["ɵɵnextContext"](3); return ctx_r535.applyFilterMode("isNull", col_r500); });
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
        core["ɵɵelementContainerEnd"]();
    } if (rf & 2) {
        var col_r500 = ctx.$implicit;
        core["ɵɵadvance"](3);
        core["ɵɵproperty"]("ngIf", col_r500.type != "bool" && col_r500.type != "enum" && col_r500.filterAvalible == true);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", (col_r500.type == "bool" || col_r500.type == "enum") && col_r500.filterAvalible == true);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", col_r500.filterAvalible == true);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("popup", true);
        core["ɵɵadvance"](2);
        core["ɵɵproperty"]("ngIf", col_r500.type != "bool" && col_r500.type != "enum");
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", col_r500.type != "bool" && col_r500.type != "enum");
        core["ɵɵadvance"](2);
        core["ɵɵproperty"]("ngIf", col_r500.type != "bool" && col_r500.type != "enum");
    } }
    function TableComponent_ng_template_4_tr_1_th_2_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelement"](0, "th");
    } }
    function TableComponent_ng_template_4_tr_1_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementStart"](0, "tr");
        core["ɵɵtemplate"](1, TableComponent_ng_template_4_tr_1_ng_container_1_Template, 14, 7, "ng-container", 13);
        core["ɵɵtemplate"](2, TableComponent_ng_template_4_tr_1_th_2_Template, 1, 0, "th", 6);
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var columns_r484 = core["ɵɵnextContext"]().$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngForOf", columns_r484);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", columns_r484.length == 0 || columns_r484.length > 1 || columns_r484[0].header);
    } }
    function TableComponent_ng_template_4_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵtemplate"](0, TableComponent_ng_template_4_tr_0_Template, 3, 2, "tr", 6);
        core["ɵɵtemplate"](1, TableComponent_ng_template_4_tr_1_Template, 3, 2, "tr", 6);
    } if (rf & 2) {
        var columns_r484 = ctx.$implicit;
        var ctx_r475 = core["ɵɵnextContext"]();
        core["ɵɵproperty"]("ngIf", columns_r484);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", columns_r484 && ctx_r475.filter);
    } }
    function TableComponent_ng_template_5_ng_template_1_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementStart"](0, "td", 42);
        core["ɵɵelement"](1, "span", 43);
        core["ɵɵelementStart"](2, "span");
        core["ɵɵtext"](3);
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var cellContext_r543 = ctx.$implicit;
        var ctx_r541 = core["ɵɵnextContext"](2);
        var _r472 = core["ɵɵreference"](1);
        core["ɵɵstyleProp"]("text-align", cellContext_r543.col.textAlign ? cellContext_r543.col.textAlign : null)("height", "1.25em")("overflow", "hidden")("white-space", "nowrap")("text-overflow", "ellipsis");
        core["ɵɵclassProp"]("cell-no-color", _r472.isSelected(cellContext_r543.rowData));
        core["ɵɵproperty"]("ngStyle", ctx_r541.getCellStyle(cellContext_r543.col, cellContext_r543.rowData));
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("innerHtml", ctx_r541.getIcon(cellContext_r543), core["ɵɵsanitizeHtml"]);
        core["ɵɵadvance"](2);
        core["ɵɵtextInterpolate"](ctx_r541.getText(cellContext_r543));
    } }
    function TableComponent_ng_template_5_ng_container_3_ng_container_1_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainer"](0);
    } }
    var _c2$1 = function (a0, a1, a2, a3) { return { "col": a0, "rowData": a1, "rowIndex": a2, "isSelected": a3 }; };
    var _c3 = function (a0) { return { $implicit: a0 }; };
    function TableComponent_ng_template_5_ng_container_3_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainerStart"](0);
        core["ɵɵtemplate"](1, TableComponent_ng_template_5_ng_container_3_ng_container_1_Template, 1, 0, "ng-container", 44);
        core["ɵɵelementContainerEnd"]();
    } if (rf & 2) {
        var col_r544 = ctx.$implicit;
        var ctx_r546 = core["ɵɵnextContext"]();
        var rowData_r537 = ctx_r546.$implicit;
        var rowIndex_r539 = ctx_r546.rowIndex;
        var _r540 = core["ɵɵreference"](2);
        core["ɵɵnextContext"]();
        var _r472 = core["ɵɵreference"](1);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngTemplateOutlet", col_r544.cellTemplate || _r540)("ngTemplateOutletContext", core["ɵɵpureFunction1"](7, _c3, core["ɵɵpureFunction4"](2, _c2$1, col_r544, rowData_r537, rowIndex_r539, _r472.isSelected(rowData_r537))));
    } }
    function TableComponent_ng_template_5_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementStart"](0, "tr", 40);
        core["ɵɵtemplate"](1, TableComponent_ng_template_5_ng_template_1_Template, 4, 15, "ng-template", null, 41, core["ɵɵtemplateRefExtractor"]);
        core["ɵɵtemplate"](3, TableComponent_ng_template_5_ng_container_3_Template, 2, 9, "ng-container", 13);
        core["ɵɵelement"](4, "td");
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var rowData_r537 = ctx.$implicit;
        var columns_r538 = ctx.columns;
        var rowIndex_r539 = ctx.rowIndex;
        core["ɵɵstyleProp"]("display", (columns_r538 == null ? null : columns_r538.length) ? null : "none");
        core["ɵɵproperty"]("pSelectableRow", rowData_r537)("pSelectableRowIndex", rowIndex_r539)("pSelectableRowDisabled", false);
        core["ɵɵadvance"](3);
        core["ɵɵproperty"]("ngForOf", columns_r538);
    } }
    function TableComponent_6_ng_template_0_tr_0_ng_container_1_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainerStart"](0);
        core["ɵɵelementStart"](1, "td");
        core["ɵɵtext"](2, " - ");
        core["ɵɵelementEnd"]();
        core["ɵɵelementContainerEnd"]();
    } }
    function TableComponent_6_ng_template_0_tr_0_td_2_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelement"](0, "td");
    } }
    function TableComponent_6_ng_template_0_tr_0_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementStart"](0, "tr");
        core["ɵɵtemplate"](1, TableComponent_6_ng_template_0_tr_0_ng_container_1_Template, 3, 0, "ng-container", 13);
        core["ɵɵtemplate"](2, TableComponent_6_ng_template_0_tr_0_td_2_Template, 1, 0, "td", 6);
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var columns_r548 = core["ɵɵnextContext"]().$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngForOf", columns_r548);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", columns_r548.length == 0 || columns_r548.length > 1 || columns_r548[0].header);
    } }
    function TableComponent_6_ng_template_0_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵtemplate"](0, TableComponent_6_ng_template_0_tr_0_Template, 3, 2, "tr", 6);
    } if (rf & 2) {
        var columns_r548 = ctx.$implicit;
        core["ɵɵproperty"]("ngIf", columns_r548 == null ? null : columns_r548.length);
    } }
    function TableComponent_6_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵtemplate"](0, TableComponent_6_ng_template_0_Template, 1, 1, "ng-template", 45);
    } }
    function TableComponent_ng_template_7_div_0_Template(rf, ctx) { if (rf & 1) {
        var _r556 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "div", 47);
        core["ɵɵelementStart"](1, "a", 48);
        core["ɵɵlistener"]("click", function TableComponent_ng_template_7_div_0_Template_a_click_1_listener($event) { core["ɵɵrestoreView"](_r556); var ctx_r555 = core["ɵɵnextContext"](2); $event.preventDefault(); return ctx_r555.clearFilterAll(); });
        core["ɵɵelement"](2, "span", 49);
        core["ɵɵelementEnd"]();
        core["ɵɵelementStart"](3, "span", 50);
        core["ɵɵtext"](4);
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var ctx_r554 = core["ɵɵnextContext"](2);
        core["ɵɵadvance"](4);
        core["ɵɵtextInterpolate1"]("\u0424\u0438\u043B\u044C\u0442\u0440: ", ctx_r554.filterString, "");
    } }
    function TableComponent_ng_template_7_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵtemplate"](0, TableComponent_ng_template_7_div_0_Template, 5, 1, "div", 46);
    } if (rf & 2) {
        var ctx_r478 = core["ɵɵnextContext"]();
        core["ɵɵproperty"]("ngIf", ctx_r478.filterString);
    } }
    function TableComponent_ng_template_12_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementStart"](0, "div");
        core["ɵɵtext"](1);
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var col_r557 = ctx.$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵtextInterpolate"](col_r557.header || col_r557.field);
    } }
    var _c4 = function () { return { "height": "300px" }; };
    function tableProviderFactory(table) {
        return table.dataTable;
    }
    var TableComponent = /** @class */ (function () {
        function TableComponent(cdr, domHandler, local) {
            this.cdr = cdr;
            this.domHandler = domHandler;
            this.local = local;
            this.layoutChanged = false;
            this.frozenLayoutChanged = false;
            this.reloadSettings = false;
            this._initValue = [];
            this._value = [];
            this.autoHeight = false;
            this.selectionMode = 'single';
            this.sortMode = 'multiple';
            this.onRowSelect = new core.EventEmitter();
            this.onLazyLoad = new core.EventEmitter(true);
            this.selectionChange = new core.EventEmitter();
            this.emptyColumn = new Column();
            this.resizing = false;
            this.showColumnsDialog = false;
            this.columnsDialogVisibleColumns = null;
            this.columnsDialogInvisibleColumns = null;
            this.selectFirstAfterLoad = false;
            this.selectLastAfterLoad = false;
        }
        Object.defineProperty(TableComponent.prototype, "value", {
            get: function () {
                return this._value;
            },
            set: function (val) {
                this._value = val;
                if (val) {
                    this._initValue = val.slice();
                }
                else {
                    this._initValue = [];
                }
                this.selectAfterLoad();
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(TableComponent.prototype, "selection", {
            get: function () {
                return this._selection;
            },
            set: function (val) {
                this._selection = val;
                this.selectionChange.emit(val);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(TableComponent.prototype, "settingsKey", {
            get: function () {
                return this._settingsKey;
            },
            set: function (value) {
                this._settingsKey = value;
                if (this.initialSettings) {
                    this.reloadSettings = true;
                }
            },
            enumerable: true,
            configurable: true
        });
        TableComponent.prototype.ngOnInit = function () {
            var self = this;
            var onColumnResizeBegin = this.dataTable.onColumnResizeBegin.bind(this.dataTable);
            var onColumnResizeEnd = this.dataTable.onColumnResizeEnd.bind(this.dataTable);
            this.dataTable.onColumnResizeBegin = function (event) {
                onColumnResizeBegin(event);
                self.resizing = true;
            };
            this.dataTable.onColumnResizeEnd = function (event, column) {
                onColumnResizeEnd(event, column);
                self.resizing = false;
            };
            this.dataTable.bindDocumentEditListener = function () { };
        };
        TableComponent.prototype.ngAfterContentInit = function () {
            var e_1, _a, e_2, _b, e_3, _c;
            var _this = this;
            var allColumns = this.cols.toArray();
            var columns = allColumns.filter(function (c) { return !c.frozen; });
            var ind = 0;
            try {
                for (var columns_1 = __values(columns), columns_1_1 = columns_1.next(); !columns_1_1.done; columns_1_1 = columns_1.next()) {
                    var col = columns_1_1.value;
                    col.index = ind;
                    ind++;
                    if (col.type === 'sum' || col.type === 'number') {
                        col.textAlign = 'right';
                    }
                    else if (col.type === 'bool') {
                        col.textAlign = 'center';
                    }
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (columns_1_1 && !columns_1_1.done && (_a = columns_1.return)) _a.call(columns_1);
                }
                finally { if (e_1) throw e_1.error; }
            }
            this.allColumns = columns;
            this.frozenColumns = allColumns.filter(function (c) { return !!c.frozen; });
            this.layout();
            this.loadSettings();
            try {
                for (var _d = __values(this.allColumns), _e = _d.next(); !_e.done; _e = _d.next()) {
                    var col = _e.value;
                    col.layoutChange.subscribe(function () {
                        _this.layoutChanged = true;
                    });
                }
            }
            catch (e_2_1) { e_2 = { error: e_2_1 }; }
            finally {
                try {
                    if (_e && !_e.done && (_b = _d.return)) _b.call(_d);
                }
                finally { if (e_2) throw e_2.error; }
            }
            if (this.frozenColumns) {
                try {
                    for (var _f = __values(this.frozenColumns), _g = _f.next(); !_g.done; _g = _f.next()) {
                        var col = _g.value;
                        col.layoutChange.subscribe(function () {
                            _this.frozenLayoutChanged = true;
                        });
                        col.widthChange.subscribe(function () {
                            _this.frozenLayoutChanged = true;
                        });
                    }
                }
                catch (e_3_1) { e_3 = { error: e_3_1 }; }
                finally {
                    try {
                        if (_g && !_g.done && (_c = _f.return)) _c.call(_f);
                    }
                    finally { if (e_3) throw e_3.error; }
                }
            }
        };
        TableComponent.prototype.loadSettings = function () {
            if (this.initialSettings) {
                this.applySettings(this.initialSettings);
            }
            this.initialSettings = this.getSettings(this.allColumns);
            var savedSettings = null;
            if (this.settingsKey && window.localStorage.getItem('Tabel_' + this.settingsKey)) {
                savedSettings = JSON.parse(window.localStorage.getItem('Tabel_' + this.settingsKey));
            }
            if (savedSettings) {
                this.applySettings(savedSettings);
            }
        };
        TableComponent.prototype.ngAfterViewInit = function () {
            var _this = this;
            this.frozenView = this.dataTable.el.nativeElement.querySelector('.ui-table-frozen-view');
            this.unfrozenView = this.dataTable.el.nativeElement.querySelector('.ui-table-unfrozen-view');
            this.frozenBody = this.frozenView.querySelector('.ui-table-scrollable-body');
            this.unfrozenBody = this.unfrozenView.querySelector('.ui-table-scrollable-body');
            this.dataTable.frozenColGroupTemplate = this.dataTable.colGroupTemplate;
            this.dataTable.frozenHeaderTemplate = this.dataTable.headerTemplate;
            this.dataTable.frozenBodyTemplate = this.dataTable.bodyTemplate;
            this.dataTable.frozenFooterTemplate = this.dataTable.footerTemplate;
            this.frozenLayout();
            this.dataTable.el.nativeElement.querySelector('.ui-table-scrollable-wrapper')
                .appendChild(this.frozenView);
            var iframe = document.createElement('iframe');
            iframe.id = 'hacky-scrollbar-resize-listener';
            iframe.style.cssText = 'height: 0; background-color: transparent; margin: 0; padding: 0; overflow: hidden; border-width: 0; position: absolute; width: 100%;';
            var self = this;
            // Register our event when the iframe loads
            iframe.onload = function () {
                // The trick here is that because this iframe has 100% width
                // it should fire a window resize event when anything causes it to
                // resize (even scrollbars on the outer element)
                iframe.contentWindow.addEventListener('resize', function () {
                    self.onColumnResize();
                });
            };
            // Stick the iframe somewhere out of the way
            this.unfrozenBody.appendChild(iframe);
            this.iframe = iframe;
            setTimeout(function () {
                _this.onColumnResize();
            });
        };
        TableComponent.prototype.ngAfterContentChecked = function () {
            if (this.reloadSettings) {
                this.loadSettings();
                this.reloadSettings = false;
            }
            if (this.layoutChanged) {
                //console.log('check')
                this.layout();
            }
            if (this.frozenLayoutChanged) {
                this.frozenLayout();
            }
        };
        TableComponent.prototype.layout = function () {
            this.visibleColumns = this.allColumns
                .filter(function (c) { return c.visible && c.available; })
                .sort(function (c1, c2) { return c1.index - c2.index; });
            this.layoutChanged = false;
        };
        TableComponent.prototype.frozenLayout = function () {
            var _this = this;
            var frozenColumns = this.frozenColumns.slice() || [];
            var frozenWidth = +frozenColumns.filter(function (c) { return c.visible && c.available; })
                .reduce(function (a, c) { return a + (c.width || 200); }, 0);
            this.dataTable.frozenColumns = this.frozenColumns;
            if (frozenWidth) {
                this.dataTable.frozenWidth = (frozenWidth + 1) + 'px';
            }
            else {
                this.dataTable.frozenWidth = '0px';
            }
            this.frozenView.style.width = this.dataTable.frozenWidth;
            this.unfrozenView.style.left = this.dataTable.frozenWidth;
            this.unfrozenView.style.width = 'calc(100% - ' + this.dataTable.frozenWidth + ')';
            if (this.dataTable.frozenColumns.length) {
                this.unfrozenView.style.position = 'absolute';
                this.frozenView.style.display = null;
            }
            else {
                this.unfrozenView.style.position = 'static';
                this.frozenView.style.display = 'none';
            }
            this.cdr.detectChanges();
            setTimeout(function () {
                _this.scrollSelectedIntoView();
                _this.frozenBody.scrollTop = _this.unfrozenBody.scrollTop;
            });
            this.frozenLayoutChanged = false;
        };
        TableComponent.prototype.showColumnsForm = function () {
            var _this = this;
            this.showColumnsDialog = true;
            this.columnsDialogVisibleColumns = this.visibleColumns;
            this.columnsDialogInvisibleColumns = this.allColumns
                .filter(function (c) { return c.available && _this.visibleColumns.indexOf(c) < 0; });
        };
        TableComponent.prototype.reload = function () {
            this.dataTable.onLazyLoad.emit(this.dataTable.createLazyLoadMetadata());
        };
        TableComponent.prototype.getCellStyle = function (col, rowData) {
            var rowStyle = Object.assign({}, this.calcRowStyle && this.calcRowStyle(rowData));
            var cellStyle = col.calcCellStyle && col.calcCellStyle(rowData);
            return Object.assign(rowStyle, cellStyle);
        };
        TableComponent.prototype.scrollSelectedIntoView = function () {
            var tr = this.unfrozenView.querySelector('tr.ui-state-highlight');
            if (tr) {
                if (scrollIntoView) {
                    scrollIntoView(tr, {
                        scrollMode: 'if-needed',
                        block: 'nearest',
                        inline: 'nearest',
                    });
                }
            }
        };
        TableComponent.prototype.onPageChange = function (event) {
            this.dataTable.onPageChange(event);
        };
        TableComponent.prototype.onColumnResize = function () {
            var tableHeadRow = this.dataTable.el.nativeElement.querySelector('colgroup');
            var tableHeads = tableHeadRow.querySelectorAll('col');
            var vColumns = this.visibleColumns;
            for (var i = 0; i < tableHeads.length; i++) {
                var colWidth = parseInt(tableHeads[i].style.width.replace('px', ''));
                vColumns[i].width = colWidth;
            }
            var tw = this.dataTable.el.nativeElement.querySelector('div.ui-table').offsetWidth;
            var tbls = this.dataTable.el.nativeElement.querySelectorAll('table');
            tbls[0].style.setProperty('width', tw + 'px');
            tbls[1].style.setProperty('width', (this.iframe.offsetWidth - 1) + 'px');
            if (tbls.length === 3) {
                tbls[2].style.setProperty('width', tw + 'px');
            }
            var ws = this.unfrozenBody.scrollWidth > this.unfrozenBody.clientWidth;
            if (ws) {
                this.frozenBody.style.marginBottom = (this.frozenBody.clientHeight - this.unfrozenBody.clientHeight) + 'px';
            }
            else {
                this.frozenBody.style.marginBottom = null;
            }
            this.saveSettings();
        };
        TableComponent.prototype.onKeydown = function (e) {
            if (this.loading || !this.selectionMode) {
                return;
            }
            if (e.which === 38) { //UP
                var arr = this.dataTable.filteredValue || this.dataTable.value;
                if (arr.length > 0) {
                    var i = this.focusedRowIndex;
                    if (i - 1 >= 0) {
                        this.selection = this.dataTable.isSingleSelectionMode()
                            ? arr[i - 1] : [arr[i - 1]];
                        this.emitRowSelect(arr[i - 1]);
                    }
                    else {
                        this.prevPage(e);
                    }
                }
            }
            else if (e.which === 40) { //DOWN
                var arr = this.dataTable.filteredValue || this.dataTable.value;
                if (arr.length > 0) {
                    var i = this.focusedRowIndex;
                    if (i + 1 < arr.length) {
                        this.selection = this.dataTable.isSingleSelectionMode()
                            ? arr[i + 1] : [arr[i + 1]];
                        this.emitRowSelect(arr[i + 1]);
                    }
                    else {
                        this.nextPage(e);
                    }
                }
            }
            else if (e.which === 34) { //PAGE UP
                this.nextPage(e);
            }
            else if (e.which === 33) { //PAGE DOWN
                this.prevPage(e);
            }
        };
        Object.defineProperty(TableComponent.prototype, "focusedRowIndex", {
            get: function () {
                var arr = this.dataTable.filteredValue || this.dataTable.value;
                if (this.dataTable.isSingleSelectionMode()) {
                    return this.selection ? arr.indexOf(this.selection) : -1;
                }
                else {
                    return this.selection && this.selection[0] ? arr.indexOf(this.selection[0]) : -1;
                }
            },
            enumerable: true,
            configurable: true
        });
        TableComponent.prototype.nextPage = function (e) {
            if (this.externalPaginator
                && this.externalPaginator.getPage() != this.externalPaginator.getPageCount() - 1) {
                this.selectFirstAfterLoad = true;
                this.externalPaginator.changePageToNext(e);
            }
        };
        TableComponent.prototype.prevPage = function (e) {
            if (this.externalPaginator
                && this.externalPaginator.getPage() != 0) {
                this.selectLastAfterLoad = true;
                this.externalPaginator.changePageToPrev(e);
            }
        };
        TableComponent.prototype.emitRowSelect = function (rowData) {
            var _this = this;
            var arr = this.dataTable.filteredValue || this.dataTable.value;
            this.dataTable.onRowSelect.emit({ data: rowData, type: 'row', index: arr.indexOf(rowData) });
            setTimeout(function () {
                _this.scrollSelectedIntoView();
            });
        };
        TableComponent.prototype.selectAfterLoad = function () {
            var _this = this;
            if (this._value && this._value.length > 0) {
                if (this.selectFirstAfterLoad) {
                    setTimeout(function () {
                        _this.selection = _this.dataTable.isSingleSelectionMode()
                            ? _this._value[0] : [_this._value[0]];
                        _this.emitRowSelect(_this._value[0]);
                    });
                }
                else if (this.selectLastAfterLoad) {
                    setTimeout(function () {
                        _this.selection = _this.dataTable.isSingleSelectionMode()
                            ? _this._value[_this._value.length - 1] : [_this._value[_this._value.length - 1]];
                        _this.emitRowSelect(_this._value[_this._value.length - 1]);
                    });
                }
            }
            this.selectFirstAfterLoad = false;
            this.selectLastAfterLoad = false;
        };
        TableComponent.prototype.contextMenu = function (data) {
            var e_4, _a;
            var _this = this;
            var isColumn = data instanceof Column;
            var order = 0;
            if (isColumn && this.dataTable._multiSortMeta) {
                try {
                    for (var _b = __values(this.dataTable._multiSortMeta), _c = _b.next(); !_c.done; _c = _b.next()) {
                        var sm = _c.value;
                        if (sm.field === data.field) {
                            order = sm.order;
                        }
                    }
                }
                catch (e_4_1) { e_4 = { error: e_4_1 }; }
                finally {
                    try {
                        if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                    }
                    finally { if (e_4) throw e_4.error; }
                }
            }
            if (isColumn) {
                this.items = [
                    {
                        label: 'По возрастанию',
                        icon: 'fa fa-caret-up',
                        disabled: !data.field || order === 1,
                        command: function (e) { return _this.sort(data.field, 1); }
                    },
                    {
                        label: 'По убыванию',
                        icon: 'fa fa-caret-down',
                        disabled: !data.field || order === -1,
                        command: function (e) { return _this.sort(data.field, -1); }
                    },
                    {
                        label: 'Очистить сортировку',
                        icon: 'fa fa-sort',
                        disabled: !data.field || order === 0,
                        command: function (e) { return _this.clearSort(data.field); }
                    },
                    {
                        separator: true
                    },
                    {
                        label: 'Очистить фильтр',
                        icon: 'fa fa-filter',
                        command: function (e) { return _this.clearFilter(data.field); }
                    },
                    {
                        separator: true
                    },
                    {
                        label: 'Колонки',
                        icon: 'fa fa-columns',
                        command: function (e) { return _this.showColumnsForm(); }
                    },
                    {
                        label: 'Сбросить настройки',
                        icon: 'na',
                        command: function (e) { return _this.clearSettings(); }
                    }
                ];
            }
            else {
                this.items = [];
            }
        };
        TableComponent.prototype.sort = function (field, order) {
            var sortMeta = this.dataTable.getSortMeta(field);
            if (sortMeta) {
                sortMeta.order = order;
            }
            else {
                if (!this.dataTable.multiSortMeta) {
                    this.dataTable._multiSortMeta = [];
                }
                this.dataTable.multiSortMeta.push({ field: field, order: order });
            }
            this.dataTable.sortMultiple();
        };
        TableComponent.prototype.clearSort = function (field) {
            var e_5, _a;
            if (this.dataTable._multiSortMeta) {
                var newMeta = [];
                try {
                    for (var _b = __values(this.dataTable._multiSortMeta), _c = _b.next(); !_c.done; _c = _b.next()) {
                        var sm = _c.value;
                        if (sm.field !== field) {
                            newMeta.push(sm);
                        }
                    }
                }
                catch (e_5_1) { e_5 = { error: e_5_1 }; }
                finally {
                    try {
                        if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                    }
                    finally { if (e_5) throw e_5.error; }
                }
                if (newMeta.length == 0) {
                    this.dataTable._multiSortMeta = null;
                }
                else {
                    this.dataTable._multiSortMeta = newMeta;
                }
            }
            if (this.dataTable.lazy) {
                this.dataTable.tableService.onSort(this.dataTable._multiSortMeta);
                this.dataTable.onLazyLoad.emit(this.dataTable.createLazyLoadMetadata());
            }
            else {
                if (this.dataTable._multiSortMeta) {
                    this.dataTable.sortMultiple();
                }
                else {
                    this.dataTable._multiSortMeta = null;
                    this.dataTable.tableService.onSort(null);
                }
                var sortingArr_1 = this._initValue;
                this.value.sort(function (a, b) {
                    return sortingArr_1.indexOf(a) - sortingArr_1.indexOf(b);
                });
            }
        };
        TableComponent.prototype.onFilter = function (event) {
            if (this.externalPaginator) {
                this.externalPaginator.first = 0;
            }
            var filterString = '';
            for (var prop in event.filters) {
                if (event.filters.hasOwnProperty(prop)) {
                    if (filterString) {
                        filterString += ' и ';
                    }
                    filterString +=
                        "'" + this.getColumnHeader(prop) + "' " + this.getMatchModeString(event.filters[prop].matchMode);
                    var mode = event.filters[prop].matchMode;
                    var withValue = mode != 'isNull' && mode != 'isNotNull';
                    if (withValue) {
                        filterString += " '" + event.filters[prop].value + "'";
                    }
                }
            }
            this.filterString = filterString;
        };
        TableComponent.prototype.getColumnHeader = function (field) {
            var e_6, _a;
            try {
                for (var _b = __values(this.allColumns), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var col = _c.value;
                    if (col.field == field) {
                        return col.header || col.field;
                    }
                }
            }
            catch (e_6_1) { e_6 = { error: e_6_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_6) throw e_6.error; }
            }
            return null;
        };
        TableComponent.prototype.getMatchModeString = function (matchMode) {
            switch (matchMode) {
                case 'contains':
                    return 'содержит';
                case 'startsWith':
                    return 'начинается с';
                case 'equals':
                    return '=';
                case 'in':
                    return 'одно из';
                case 'isNotNull':
                    return 'задано';
                case 'isNull':
                    return 'не задано';
            }
            return '';
        };
        TableComponent.prototype.clearFilterAll = function () {
            var e_7, _a;
            this.dataTable.filters = {};
            if (this.externalPaginator) {
                this.externalPaginator.first = 0;
            }
            try {
                for (var _b = __values(this.allColumns), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var col = _c.value;
                    this.resetFilterMode(col);
                }
            }
            catch (e_7_1) { e_7 = { error: e_7_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_7) throw e_7.error; }
            }
            this.dataTable._filter();
        };
        TableComponent.prototype.clearFilter = function (field) {
            if (this.dataTable.filters[field]) {
                delete this.dataTable.filters[field];
            }
            if (this.externalPaginator) {
                this.externalPaginator.first = 0;
            }
            this.resetFilterMode(this.allColumns.filter(function (c) { return c.field == field; })[0]);
            this.dataTable._filter();
        };
        TableComponent.prototype.resetFilterMode = function (col) {
            var withValue = col.filterMatchMode != 'isNull' && col.filterMatchMode != 'isNotNull';
            if (!withValue) {
                col.filterMatchMode = null;
                this.setDefualtFilterMode(col);
            }
        };
        TableComponent.prototype.updateColumns = function () {
            this.visibleColumns = __spread(this.visibleColumns);
            this.saveSettings();
        };
        TableComponent.prototype.updateColumnsFromDialog = function () {
            this.visibleColumns = __spread(this.columnsDialogVisibleColumns);
            this.saveSettings();
        };
        TableComponent.prototype.clearSettings = function () {
            this.applySettings(this.initialSettings);
            this.saveSettings();
        };
        TableComponent.prototype.getSettings = function (columns, initialSettings) {
            var e_8, _a;
            if (initialSettings === void 0) { initialSettings = null; }
            var settings = [];
            var ind = 0;
            var _loop_1 = function (col) {
                var width = col.width;
                if (initialSettings
                    && initialSettings.find(function (s) { return s.field == col.field && s.width == width; })) {
                    width = null;
                }
                settings.push({
                    field: col.field,
                    index: ind,
                    width: width,
                    visible: col.visible
                });
                ind++;
            };
            try {
                for (var columns_2 = __values(columns), columns_2_1 = columns_2.next(); !columns_2_1.done; columns_2_1 = columns_2.next()) {
                    var col = columns_2_1.value;
                    _loop_1(col);
                }
            }
            catch (e_8_1) { e_8 = { error: e_8_1 }; }
            finally {
                try {
                    if (columns_2_1 && !columns_2_1.done && (_a = columns_2.return)) _a.call(columns_2);
                }
                finally { if (e_8) throw e_8.error; }
            }
            return settings;
        };
        TableComponent.prototype.saveSettings = function () {
            var e_9, _a, e_10, _b;
            try {
                for (var _c = __values(this.allColumns), _d = _c.next(); !_d.done; _d = _c.next()) {
                    var col = _d.value;
                    if (col.available) {
                        col._visible = false;
                        col.index = null;
                    }
                }
            }
            catch (e_9_1) { e_9 = { error: e_9_1 }; }
            finally {
                try {
                    if (_d && !_d.done && (_a = _c.return)) _a.call(_c);
                }
                finally { if (e_9) throw e_9.error; }
            }
            var ind = 0;
            try {
                for (var _e = __values(this.visibleColumns), _f = _e.next(); !_f.done; _f = _e.next()) {
                    var col = _f.value;
                    col._visible = true;
                    col.index = ind;
                    ind++;
                }
            }
            catch (e_10_1) { e_10 = { error: e_10_1 }; }
            finally {
                try {
                    if (_f && !_f.done && (_b = _e.return)) _b.call(_e);
                }
                finally { if (e_10) throw e_10.error; }
            }
            if (this.settingsKey) {
                var settings = this.getSettings(this.allColumns.sort(function (a, b) {
                    if (a.index == null) {
                        return -1;
                    }
                    if (a.index < b.index) {
                        return -1;
                    }
                    if (b.index == null) {
                        return 1;
                    }
                    if (a.index > b.index) {
                        return 1;
                    }
                    return 0;
                }), this.initialSettings);
                window.localStorage.setItem('Tabel_' + this.settingsKey, JSON.stringify(settings));
            }
        };
        TableComponent.prototype.applySettings = function (settings) {
            var e_11, _a, e_12, _b;
            var ind = 0;
            try {
                for (var _c = __values(this.allColumns), _d = _c.next(); !_d.done; _d = _c.next()) {
                    var col = _d.value;
                    if (col.available) {
                        col.index = ind;
                        col._visible = true;
                        if (settings) {
                            try {
                                for (var settings_1 = (e_12 = void 0, __values(settings)), settings_1_1 = settings_1.next(); !settings_1_1.done; settings_1_1 = settings_1.next()) {
                                    var colSettings = settings_1_1.value;
                                    if (colSettings.field == col.field) {
                                        col._visible = colSettings.visible == null ? true : colSettings.visible;
                                        col.index = colSettings.index;
                                        if (colSettings.width) {
                                            col.width = colSettings.width;
                                        }
                                        break;
                                    }
                                }
                            }
                            catch (e_12_1) { e_12 = { error: e_12_1 }; }
                            finally {
                                try {
                                    if (settings_1_1 && !settings_1_1.done && (_b = settings_1.return)) _b.call(settings_1);
                                }
                                finally { if (e_12) throw e_12.error; }
                            }
                        }
                        ind++;
                    }
                }
            }
            catch (e_11_1) { e_11 = { error: e_11_1 }; }
            finally {
                try {
                    if (_d && !_d.done && (_a = _c.return)) _a.call(_c);
                }
                finally { if (e_11) throw e_11.error; }
            }
            this.layout();
        };
        TableComponent.prototype.applyFilter = function (delayed, value, col) {
            this.setDefualtFilterMode(col);
            var filterDelayTemp = this.dataTable.filterDelay;
            if (!delayed) {
                this.dataTable.filterDelay = 0;
            }
            var withValue = col.filterMatchMode != 'isNull' && col.filterMatchMode != 'isNotNull';
            this.dataTable.filter(withValue ? value : '-', col.field, col.filterMatchMode);
            this.dataTable.filterDelay = filterDelayTemp;
        };
        TableComponent.prototype.applyFilterMode = function (mode, col) {
            this.setDefualtFilterMode(col);
            if (col.filterMatchMode != mode) {
                var newWithValue = mode != 'isNull' && mode != 'isNotNull';
                var oldWithValue = col.filterMatchMode != 'isNull' && col.filterMatchMode != 'isNotNull';
                col.filterMatchMode = mode;
                if (!newWithValue) {
                    this.applyFilter(false, '-', col);
                }
                else if (!oldWithValue) {
                    this.applyFilter(false, '', col);
                }
                else if (this.dataTable.filters[col.field]) {
                    this.applyFilter(false, this.dataTable.filters[col.field].value, col);
                }
            }
        };
        TableComponent.prototype.setDefualtFilterMode = function (col) {
            if (col.filterMatchMode) {
                return;
            }
            var isSelect = col.type == 'bool' || col.type == 'enum';
            col.filterMatchMode = isSelect ? 'equals' : 'contains';
        };
        TableComponent.prototype.getText = function (cellContext) {
            var cell = new Cell(this, this.local);
            cell.cellContext = cellContext;
            return cell.text;
        };
        TableComponent.prototype.getIcon = function (cellContext) {
            var cell = new Cell(this, this.local);
            cell.cellContext = cellContext;
            return cell.icon;
        };
        TableComponent.ɵfac = function TableComponent_Factory(t) { return new (t || TableComponent)(core["ɵɵdirectiveInject"](core.ChangeDetectorRef), core["ɵɵdirectiveInject"](dom.DomHandler), core["ɵɵdirectiveInject"](core.LOCALE_ID)); };
        TableComponent.ɵcmp = core["ɵɵdefineComponent"]({ type: TableComponent, selectors: [["app-table"]], contentQueries: function TableComponent_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
                core["ɵɵcontentQuery"](dirIndex, Column, false);
            } if (rf & 2) {
                var _t;
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.cols = _t);
            } }, viewQuery: function TableComponent_Query(rf, ctx) { if (rf & 1) {
                core["ɵɵstaticViewQuery"](_c0$3, true);
                core["ɵɵviewQuery"](core.TemplateRef, true);
            } if (rf & 2) {
                var _t;
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.dataTable = _t.first);
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.tds = _t);
            } }, inputs: { value: "value", autoHeight: "autoHeight", totalRecords: "totalRecords", selectionMode: "selectionMode", paginator: "paginator", paginatorPosition: "paginatorPosition", externalPaginator: "externalPaginator", rows: "rows", filter: "filter", footer: "footer", lazy: "lazy", loading: "loading", metaKeySelection: "metaKeySelection", sortMode: "sortMode", calcRowStyle: "calcRowStyle", selection: "selection", settingsKey: "settingsKey" }, outputs: { onRowSelect: "onRowSelect", onLazyLoad: "onLazyLoad", selectionChange: "selectionChange" }, features: [core["ɵɵProvidersFeature"]([
                    dom.DomHandler,
                    { provide: table.Table, useFactory: tableProviderFactory, deps: [TableComponent] }
                ])], decls: 13, vars: 35, consts: [["columnResizeMode", "expand", 3, "value", "selectionMode", "selection", "paginator", "paginatorPosition", "rows", "totalRecords", "scrollable", "resizableColumns", "autoLayout", "columns", "loading", "metaKeySelection", "filterDelay", "sortMode", "reorderableColumns", "lazy", "contextMenu", "styleClass", "selectionChange", "onRowSelect", "onColResize", "onLazyLoad", "keydown", "contextMenuSelectionChange", "onColReorder", "onFilter"], ["dt", ""], ["pTemplate", "frozenbody"], ["pTemplate", "colgroup"], ["pTemplate", "header"], ["pTemplate", "body"], [4, "ngIf"], ["pTemplate", "summary"], ["appendTo", "body", 3, "model"], ["cm", ""], ["header", "\u041A\u043E\u043B\u043E\u043D\u043A\u0438", "appendTo", "body", 3, "visible", "resizable", "modal", "dismissableMask", "visibleChange"], ["filterBy", "header", "sourceHeader", "\u041D\u0435\u0432\u0438\u0434\u0438\u043C\u044B\u0435", "targetHeader", "\u0412\u0438\u0434\u0438\u043C\u044B\u0435", 3, "source", "target", "dragdrop", "showSourceControls", "responsive", "sourceStyle", "targetStyle", "onTargetReorder", "onMoveToTarget", "onMoveToSource", "onMoveAllToTarget", "onMoveAllToSource"], ["pTemplate", "item"], [4, "ngFor", "ngForOf"], ["style", "padding: 0", 3, "pContextMenuRow", 4, "ngIf"], ["pResizableColumn", "", "pReorderableColumn", "", 3, "pContextMenuRow", "pResizableColumnDisabled", "pReorderableColumnDisabled", "pSortableColumn", "pSortableColumnDisabled", "textAlign", 4, "ngIf"], ["pResizableColumn", "", "pReorderableColumn", "", 3, "pContextMenuRow", "pResizableColumnDisabled", "pReorderableColumnDisabled", "pSortableColumn", "pSortableColumnDisabled"], [3, "field", 4, "ngIf"], [3, "field"], [2, "padding", "0", 3, "pContextMenuRow"], [1, "h-flex"], ["pInputText", "", "type", "text", "class", "ui-inputfilter h-flex-grow", "placeholder", "\uF002", 3, "readonly", "value", "textAlign", "input", "keydown.enter", 4, "ngIf"], ["class", "h-flex-grow", "appendTo", "body", 3, "ngModel", "options", "style", "onChange", 4, "ngIf"], ["class", "filter-button", 3, "click", 4, "ngIf"], ["appendTo", "body", 3, "popup"], ["filterMenu", ""], ["label", "\u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442", 3, "command", 4, "ngIf"], ["label", "\u043D\u0430\u0447\u0438\u043D\u0430\u0435\u0442\u0441\u044F \u0441", 3, "command", 4, "ngIf"], ["label", "\u0440\u0430\u0432\u043D\u043E", 3, "command"], ["label", "\u043E\u0434\u043D\u043E \u0438\u0437", 3, "command", 4, "ngIf"], ["label", "\u0437\u0430\u0434\u0430\u043D\u043E", 3, "command"], ["label", "\u043D\u0435 \u0437\u0430\u0434\u0430\u043D\u043E", 3, "command"], ["pInputText", "", "type", "text", "placeholder", "\uF002", 1, "ui-inputfilter", "h-flex-grow", 3, "readonly", "value", "input", "keydown.enter"], ["inp", ""], ["appendTo", "body", 1, "h-flex-grow", 3, "ngModel", "options", "onChange"], ["d", ""], [1, "filter-button", 3, "click"], ["label", "\u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442", 3, "command"], ["label", "\u043D\u0430\u0447\u0438\u043D\u0430\u0435\u0442\u0441\u044F \u0441", 3, "command"], ["label", "\u043E\u0434\u043D\u043E \u0438\u0437", 3, "command"], [3, "pSelectableRow", "pSelectableRowIndex", "pSelectableRowDisabled"], ["defaultCell", ""], [3, "ngStyle"], [1, "fa", 3, "innerHtml"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], ["pTemplate", "footer"], ["class", "ui-table-filter-summary", 4, "ngIf"], [1, "ui-table-filter-summary"], ["href", "#", "role", "button", "title", "\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0444\u0438\u043B\u044C\u0442\u0440", 1, "ui-filter-clear", 3, "click"], [1, "fa", "fa-fw", "fa-times"], [1, "ui-table-filter-text"]], template: function TableComponent_Template(rf, ctx) { if (rf & 1) {
                core["ɵɵelementStart"](0, "p-table", 0, 1);
                core["ɵɵlistener"]("selectionChange", function TableComponent_Template_p_table_selectionChange_0_listener($event) { return ctx.selection = $event; })("onRowSelect", function TableComponent_Template_p_table_onRowSelect_0_listener($event) { return ctx.onRowSelect.emit($event); })("onColResize", function TableComponent_Template_p_table_onColResize_0_listener() { return ctx.onColumnResize(); })("onLazyLoad", function TableComponent_Template_p_table_onLazyLoad_0_listener($event) { ctx.onLazyLoad.emit($event); return ctx.selection = ctx.selection ? null : ctx.selection; })("keydown", function TableComponent_Template_p_table_keydown_0_listener($event) { return ctx.onKeydown($event); })("contextMenuSelectionChange", function TableComponent_Template_p_table_contextMenuSelectionChange_0_listener($event) { return ctx.contextMenu($event); })("onColReorder", function TableComponent_Template_p_table_onColReorder_0_listener() { return ctx.updateColumns(); })("onFilter", function TableComponent_Template_p_table_onFilter_0_listener($event) { return ctx.onFilter($event); });
                core["ɵɵtemplate"](2, TableComponent_ng_template_2_Template, 0, 0, "ng-template", 2);
                core["ɵɵtemplate"](3, TableComponent_ng_template_3_Template, 2, 1, "ng-template", 3);
                core["ɵɵtemplate"](4, TableComponent_ng_template_4_Template, 2, 2, "ng-template", 4);
                core["ɵɵtemplate"](5, TableComponent_ng_template_5_Template, 5, 6, "ng-template", 5);
                core["ɵɵtemplate"](6, TableComponent_6_Template, 1, 0, undefined, 6);
                core["ɵɵtemplate"](7, TableComponent_ng_template_7_Template, 1, 1, "ng-template", 7);
                core["ɵɵelementEnd"]();
                core["ɵɵelement"](8, "p-contextMenu", 8, 9);
                core["ɵɵelementStart"](10, "p-dialog", 10);
                core["ɵɵlistener"]("visibleChange", function TableComponent_Template_p_dialog_visibleChange_10_listener($event) { return ctx.showColumnsDialog = $event; });
                core["ɵɵelementStart"](11, "p-pickList", 11);
                core["ɵɵlistener"]("onTargetReorder", function TableComponent_Template_p_pickList_onTargetReorder_11_listener() { return ctx.updateColumnsFromDialog(); })("onMoveToTarget", function TableComponent_Template_p_pickList_onMoveToTarget_11_listener() { return ctx.updateColumnsFromDialog(); })("onMoveToSource", function TableComponent_Template_p_pickList_onMoveToSource_11_listener() { return ctx.updateColumnsFromDialog(); })("onMoveAllToTarget", function TableComponent_Template_p_pickList_onMoveAllToTarget_11_listener() { return ctx.updateColumnsFromDialog(); })("onMoveAllToSource", function TableComponent_Template_p_pickList_onMoveAllToSource_11_listener() { return ctx.updateColumnsFromDialog(); });
                core["ɵɵtemplate"](12, TableComponent_ng_template_12_Template, 2, 1, "ng-template", 12);
                core["ɵɵelementEnd"]();
                core["ɵɵelementEnd"]();
            } if (rf & 2) {
                var _r479 = core["ɵɵreference"](9);
                core["ɵɵproperty"]("value", ctx.value)("selectionMode", ctx.selectionMode)("selection", ctx.selection)("paginator", ctx.paginator)("paginatorPosition", ctx.paginatorPosition)("rows", ctx.externalPaginator ? ctx.externalPaginator.rows : ctx.rows)("totalRecords", ctx.externalPaginator ? ctx.externalPaginator.totalRecords : ctx.totalRecords)("scrollable", true)("resizableColumns", true)("autoLayout", false)("columns", ctx.visibleColumns)("loading", ctx.loading)("metaKeySelection", ctx.metaKeySelection)("filterDelay", ctx.lazy ? 2500 : 300)("sortMode", ctx.sortMode)("reorderableColumns", true)("lazy", ctx.lazy)("contextMenu", _r479)("styleClass", ctx.autoHeight ? "" : "ui-table-flex");
                core["ɵɵattribute"]("tabindex", 1);
                core["ɵɵadvance"](6);
                core["ɵɵproperty"]("ngIf", ctx.footer);
                core["ɵɵadvance"](2);
                core["ɵɵproperty"]("model", ctx.items);
                core["ɵɵadvance"](2);
                core["ɵɵproperty"]("visible", ctx.showColumnsDialog)("resizable", false)("modal", true)("dismissableMask", true);
                core["ɵɵadvance"](1);
                core["ɵɵproperty"]("source", ctx.columnsDialogInvisibleColumns)("target", ctx.columnsDialogVisibleColumns)("dragdrop", true)("showSourceControls", false)("responsive", true)("sourceStyle", core["ɵɵpureFunction0"](33, _c4))("targetStyle", core["ɵɵpureFunction0"](34, _c4));
            } }, directives: [TableFrozenFixDirective, table.Table, api.PrimeTemplate, common.NgIf, contextmenu.ContextMenu, DialogExtDirective, dialog.Dialog, picklist.PickList, common.NgForOf, table.ResizableColumn, table.ReorderableColumn, table.ContextMenuRow, table.SortableColumn, table.SortIcon, MenuDirective, menu.Menu, MenuItemDirective, InputDirective, inputtext.InputText, dropdown.Dropdown, ValidationMessageDirective, forms.NgControlStatus, forms.NgModel, ButtonDirective, table.SelectableRow, common.NgStyle, common.NgTemplateOutlet], styles: ["p-table:focus{outline:0}  .ui-table-tbody>tr>td{overflow:hidden;white-space:nowrap;text-overflow:ellipsis}  .ui-table-thead>tr>th{text-align:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}  .ui-table-thead>tr>th>span{white-space:nowrap;text-overflow:ellipsis}  .ui-table-tbody>tr>td.cell-no-color{background:inherit!important;color:inherit!important}  .ui-table tr.ui-state-highlight a{color:#fff}  .ui-table-summary{border:none;padding:0}.ui-table-filter-summary[_ngcontent-%COMP%]{text-align:left;width:100%;border-top:1px solid #d9d9d9;padding:.5em;font-weight:400}.ui-inputfilter[_ngcontent-%COMP%]{border:none!important}.ui-inputfilter[_ngcontent-%COMP%]::-webkit-input-placeholder{font-family:\"Font Awesome 5 Free\";font-weight:900;color:#2d5a80}.ui-inputfilter[_ngcontent-%COMP%]::-moz-placeholder{font-family:\"Font Awesome 5 Free\";font-weight:900;color:#2d5a80}.ui-inputfilter[_ngcontent-%COMP%]:-ms-input-placeholder{font-family:\"Font Awesome 5 Free\";font-weight:900;color:#2d5a80}.ui-inputfilter[_ngcontent-%COMP%]::-ms-input-placeholder{font-family:\"Font Awesome 5 Free\";font-weight:900;color:#2d5a80}.ui-inputfilter[_ngcontent-%COMP%]::placeholder{font-family:\"Font Awesome 5 Free\";font-weight:900;color:#2d5a80}.ui-inputfilter[_ngcontent-%COMP%]:focus::-webkit-input-placeholder{color:transparent}.ui-inputfilter[_ngcontent-%COMP%]:focus::-moz-placeholder{color:transparent}.ui-inputfilter[_ngcontent-%COMP%]:focus:-ms-input-placeholder{color:transparent}.ui-inputfilter[_ngcontent-%COMP%]:focus::-ms-input-placeholder{color:transparent}.ui-inputfilter[_ngcontent-%COMP%]:focus::placeholder{color:transparent}.filter-button[_ngcontent-%COMP%]{padding:1px;font-size:10.5px;width:38px;white-space:normal;word-wrap:break-word;line-height:11px;border:0;border-left:1px solid #c8c8c8;background-color:transparent;color:#3d60a1}.filter-button[_ngcontent-%COMP%]:hover{background-color:#83b9ff;cursor:pointer}"] });
        return TableComponent;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](TableComponent, [{
            type: core.Component,
            args: [{
                    selector: 'app-table',
                    templateUrl: 'table.component.html',
                    styleUrls: ['table.component.css'],
                    providers: [
                        dom.DomHandler,
                        { provide: table.Table, useFactory: tableProviderFactory, deps: [TableComponent] }
                    ]
                }]
        }], function () { return [{ type: core.ChangeDetectorRef }, { type: dom.DomHandler }, { type: undefined, decorators: [{
                    type: core.Inject,
                    args: [core.LOCALE_ID]
                }] }]; }, { value: [{
                type: core.Input
            }], autoHeight: [{
                type: core.Input
            }], totalRecords: [{
                type: core.Input
            }], selectionMode: [{
                type: core.Input
            }], paginator: [{
                type: core.Input
            }], paginatorPosition: [{
                type: core.Input
            }], externalPaginator: [{
                type: core.Input
            }], rows: [{
                type: core.Input
            }], filter: [{
                type: core.Input
            }], footer: [{
                type: core.Input
            }], lazy: [{
                type: core.Input
            }], loading: [{
                type: core.Input
            }], metaKeySelection: [{
                type: core.Input
            }], sortMode: [{
                type: core.Input
            }], calcRowStyle: [{
                type: core.Input
            }], onRowSelect: [{
                type: core.Output
            }], onLazyLoad: [{
                type: core.Output
            }], selectionChange: [{
                type: core.Output
            }], selection: [{
                type: core.Input
            }], settingsKey: [{
                type: core.Input
            }], dataTable: [{
                type: core.ViewChild,
                args: ['dt', { static: true }]
            }], tds: [{
                type: core.ViewChildren,
                args: [core.TemplateRef]
            }], cols: [{
                type: core.ContentChildren,
                args: [Column]
            }] }); })();

    var PKeyFilterNumDirective = /** @class */ (function () {
        function PKeyFilterNumDirective() {
            this.numberMatchRegExp = /(^-?\d{0,9}$)|(^-?\d{1,9}\.\d{1,10}$)/;
            this.positiveNumberMatchRegExp = /(^\d{0,9}$)|(^\d{1,9}\.\d{1,10}$)/;
        }
        Object.defineProperty(PKeyFilterNumDirective.prototype, "pKeyFilter", {
            get: function () {
                return this._filter;
            },
            set: function (value) {
                var _this = this;
                this._filter = value;
                setTimeout(function () {
                    if (_this.onValidatorChange) {
                        _this.onValidatorChange();
                    }
                });
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(PKeyFilterNumDirective.prototype, "pMayBeEmpty", {
            get: function () {
                return this._mayBeEmpty;
            },
            set: function (value) {
                var _this = this;
                this._mayBeEmpty = value;
                setTimeout(function () {
                    if (_this.onValidatorChange) {
                        _this.onValidatorChange();
                    }
                });
            },
            enumerable: true,
            configurable: true
        });
        PKeyFilterNumDirective.prototype.validate = function (control) {
            if (this._mayBeEmpty === true && (control.value === null || control.value === undefined)) {
                return null;
            }
            if ((this._filter === 'num' && !this.numberMatchRegExp.test(control.value))
                || (this._filter === 'pnum' && !this.positiveNumberMatchRegExp.test(control.value))) {
                return { 'pKeyFilter': 'Неверное число' };
            }
            return null;
        };
        PKeyFilterNumDirective.prototype.registerOnValidatorChange = function (fn) {
            this.onValidatorChange = fn;
        };
        PKeyFilterNumDirective.ɵfac = function PKeyFilterNumDirective_Factory(t) { return new (t || PKeyFilterNumDirective)(); };
        PKeyFilterNumDirective.ɵdir = core["ɵɵdefineDirective"]({ type: PKeyFilterNumDirective, selectors: [["", "pKeyFilter", ""]], inputs: { pKeyFilter: "pKeyFilter", pMayBeEmpty: "pMayBeEmpty" }, features: [core["ɵɵProvidersFeature"]([
                    { provide: forms.NG_VALIDATORS, useExisting: core.forwardRef(function () { return PKeyFilterNumDirective; }), multi: true }
                ])] });
        return PKeyFilterNumDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](PKeyFilterNumDirective, [{
            type: core.Directive,
            args: [{
                    selector: '[pKeyFilter]',
                    providers: [
                        { provide: forms.NG_VALIDATORS, useExisting: core.forwardRef(function () { return PKeyFilterNumDirective; }), multi: true }
                    ]
                }]
        }], function () { return []; }, { pKeyFilter: [{
                type: core.Input
            }], pMayBeEmpty: [{
                type: core.Input
            }] }); })();

    var InvalidIfDirective = /** @class */ (function () {
        function InvalidIfDirective() {
        }
        Object.defineProperty(InvalidIfDirective.prototype, "appInvalidIf", {
            get: function () {
                return this._appInvalidIf;
            },
            set: function (value) {
                var _this = this;
                this._appInvalidIf = value;
                setTimeout(function () {
                    if (_this.onValidatorChange) {
                        _this.onValidatorChange();
                    }
                });
            },
            enumerable: true,
            configurable: true
        });
        InvalidIfDirective.prototype.validate = function (control) {
            return this._appInvalidIf ? { 'appInvalidIf': this.appInvalidIfMessage || 'Неверное значение' } : null;
        };
        InvalidIfDirective.prototype.registerOnValidatorChange = function (fn) {
            this.onValidatorChange = fn;
        };
        InvalidIfDirective.ɵfac = function InvalidIfDirective_Factory(t) { return new (t || InvalidIfDirective)(); };
        InvalidIfDirective.ɵdir = core["ɵɵdefineDirective"]({ type: InvalidIfDirective, selectors: [["", "appInvalidIf", ""]], inputs: { appInvalidIf: "appInvalidIf", appInvalidIfMessage: "appInvalidIfMessage" }, features: [core["ɵɵProvidersFeature"]([
                    { provide: forms.NG_VALIDATORS, useExisting: core.forwardRef(function () { return InvalidIfDirective; }), multi: true }
                ])] });
        return InvalidIfDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](InvalidIfDirective, [{
            type: core.Directive,
            args: [{
                    selector: '[appInvalidIf]',
                    providers: [
                        { provide: forms.NG_VALIDATORS, useExisting: core.forwardRef(function () { return InvalidIfDirective; }), multi: true }
                    ]
                }]
        }], function () { return []; }, { appInvalidIf: [{
                type: core.Input
            }], appInvalidIfMessage: [{
                type: core.Input
            }] }); })();

    function TextFloatingFilterComponent_p_menu_item_7_Template(rf, ctx) { if (rf & 1) {
        var _r563 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "p-menu-item", 7);
        core["ɵɵlistener"]("command", function TextFloatingFilterComponent_p_menu_item_7_Template_p_menu_item_command_0_listener() { core["ɵɵrestoreView"](_r563); var type_r561 = ctx.$implicit; var ctx_r562 = core["ɵɵnextContext"](); return ctx_r562.applyFilterMode(type_r561.key); });
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var type_r561 = ctx.$implicit;
        var ctx_r560 = core["ɵɵnextContext"]();
        core["ɵɵproperty"]("label", ctx_r560.getFilterModesTitle(type_r561));
    } }
    var TextFloatingFilterComponent = /** @class */ (function () {
        function TextFloatingFilterComponent() {
            this.debounceVal = new rxjs.Subject();
            this.val = new rxjs.Subject();
            this.keyFilter = /.*/;
            this.numberValidPattern = /^(-?\d+(?:\.\d+)?)((?:(:-?\d+(?:\.\d+)?))?|(?:(,\d+(?:\.\d+)?)+))$/;
            this.isInvalid = false;
            this.types = [];
            this.getFilterModesTitle = getFilterModesTitle;
        }
        Object.defineProperty(TextFloatingFilterComponent.prototype, "isNumberColumn", {
            get: function () {
                var _a;
                return ((_a = this.params) === null || _a === void 0 ? void 0 : _a.column.getColDef().type) == 'number';
            },
            enumerable: true,
            configurable: true
        });
        TextFloatingFilterComponent.prototype.agInit = function (params) {
            var _this = this;
            var _a;
            this.params = params;
            this.currentValue = '';
            this.value = '';
            this.types = this.getTypes();
            this.type = this.getDefaultType();
            var colType = params.column.getColDef().type;
            if (colType) {
                this.types = this.getTypes(colType);
                this.type = this.getDefaultType(colType);
            }
            this.debounceVal
                .pipe(operators.debounceTime((_a = this.params.debounceMs, (_a !== null && _a !== void 0 ? _a : 500))))
                .pipe(operators.takeUntil(this.val))
                .pipe(operators.repeat())
                .subscribe(function (val) {
                if (_this.currentValue != val) {
                    _this.apply();
                }
            });
            this.val
                .subscribe(function (val) {
                if (_this.currentValue != val) {
                    _this.apply();
                }
            });
            this.setKeyFilter();
        };
        TextFloatingFilterComponent.prototype.valueChanged = function () {
            this.debounceVal.next(this.value);
        };
        TextFloatingFilterComponent.prototype.applyFilterMode = function (type) {
            var oldType = __assign({}, this.type);
            var newType = this.types.find(function (findType) { return findType.key === type; });
            this.type = newType;
            this.setKeyFilter();
            if (newType.key == 'isNull' || newType.key == 'isNotNull') {
                this.value = '-';
                this.apply();
            }
            else if (oldType.key == 'isNull' ||
                oldType.key == 'isNotNull' ||
                oldType.key == 'in' ||
                oldType.key == 'between') {
                this.value = '';
                this.apply();
            }
            else if (this.value != '' || this.value != this.currentValue) {
                this.apply();
            }
        };
        TextFloatingFilterComponent.prototype.onKeyDown = function (event) {
            if (event.keyCode === 13) {
                this.val.next(this.value);
            }
        };
        TextFloatingFilterComponent.prototype.onBlur = function () {
            this.val.next(this.value);
        };
        TextFloatingFilterComponent.prototype.apply = function () {
            var _this = this;
            if (this.isInvalid) {
                return;
            }
            this.currentValue = this.value;
            this.params.parentFilterInstance(function (filterInstance) {
                if (filterInstance) {
                    var textFilter = filterInstance;
                    textFilter.onFloatingFilterChanged(_this.type.key || (_this.isNumberColumn ? 'equals' : 'contains'), _this.currentValue);
                }
            });
        };
        TextFloatingFilterComponent.prototype.onParentModelChanged = function (parentModel, filterChangedEvent) {
            if (!parentModel) {
                this.value = '';
                this.currentValue = '';
            }
            else {
                this.value = parentModel.filter;
                this.currentValue = parentModel.filter;
                this.type = this.types.find(function (findType) { return findType.key === parentModel.type; });
            }
        };
        TextFloatingFilterComponent.prototype.getPlaceholder = function () {
            var _a;
            switch ((_a = this.type) === null || _a === void 0 ? void 0 : _a.key) {
                case 'in':
                    return this.isNumberColumn ? 'например: 1,2,3' : 'например: аб,вг,гд';
                case 'between':
                    return this.isNumberColumn ? 'например: 1:5' : 'например: 1-5';
                default:
                    return '';
            }
        };
        TextFloatingFilterComponent.prototype.setKeyFilter = function () {
            var _a;
            if (this.isNumberColumn) {
                switch ((_a = this.type) === null || _a === void 0 ? void 0 : _a.key) {
                    case 'in':
                        this.keyFilter = /^[0-9]*[-.,]?$/;
                        break;
                    case 'between':
                        this.keyFilter = /^[0-9]*[-.:]?$/;
                        break;
                    default:
                        this.keyFilter = /^[0-9]*[-.]?$/;
                        break;
                }
            }
        };
        TextFloatingFilterComponent.prototype.isNumberValueInvalid = function (value, inputElement) {
            var _a, _b;
            if (((_a = this.type) === null || _a === void 0 ? void 0 : _a.key) !== 'isNull' && ((_b = this.type) === null || _b === void 0 ? void 0 : _b.key) !== 'isNotNull') {
                if (!this.isNumberColumn || !value || this.numberValidPattern.test(value)) {
                    inputElement.style.border = '0';
                    return this.isInvalid = false;
                }
                else {
                    inputElement.style.border = '1px solid red';
                    return this.isInvalid = true;
                }
            }
        };
        TextFloatingFilterComponent.prototype.getDefaultType = function (colType) {
            if (colType) {
                switch (colType) {
                    case 'number':
                        return __assign({ key: 'equals' }, localeColumnFilterModes.equals);
                    default:
                        return __assign({ key: 'contains' }, localeColumnFilterModes.contains);
                }
            }
            return __assign({ key: 'contains' }, localeColumnFilterModes.contains);
        };
        TextFloatingFilterComponent.prototype.getTypes = function (colType) {
            var matchTypes = columnTypeFilterMatchModes['string'];
            if (colType && columnTypeFilterMatchModes[colType]) {
                matchTypes = columnTypeFilterMatchModes[colType];
            }
            return matchTypes.map(function (type) {
                return { key: type, title: localeColumnFilterModes[type].title, sign: localeColumnFilterModes[type].sign };
            });
        };
        TextFloatingFilterComponent.ɵfac = function TextFloatingFilterComponent_Factory(t) { return new (t || TextFloatingFilterComponent)(); };
        TextFloatingFilterComponent.ɵcmp = core["ɵɵdefineComponent"]({ type: TextFloatingFilterComponent, selectors: [["ng-component"]], decls: 8, vars: 8, consts: [[2, "display", "flex", "height", "100%"], ["type", "text", 2, "flex", "1", "height", "100%", "border", "0", "padding", "7px", 3, "ngModel", "pKeyFilter", "placeholder", "appInvalidIf", "disabled", "ngModelChange", "keydown", "blur"], ["inputElement", ""], [1, "filter-button", 3, "click"], ["appendTo", "body", 3, "popup"], ["filterMenu", ""], [3, "label", "command", 4, "ngFor", "ngForOf"], [3, "label", "command"]], template: function TextFloatingFilterComponent_Template(rf, ctx) { if (rf & 1) {
                var _r564 = core["ɵɵgetCurrentView"]();
                core["ɵɵelementStart"](0, "div", 0);
                core["ɵɵelementStart"](1, "input", 1, 2);
                core["ɵɵlistener"]("ngModelChange", function TextFloatingFilterComponent_Template_input_ngModelChange_1_listener($event) { return ctx.value = $event; })("ngModelChange", function TextFloatingFilterComponent_Template_input_ngModelChange_1_listener() { return ctx.valueChanged(); })("keydown", function TextFloatingFilterComponent_Template_input_keydown_1_listener($event) { return ctx.onKeyDown($event); })("blur", function TextFloatingFilterComponent_Template_input_blur_1_listener() { return ctx.onBlur(); });
                core["ɵɵelementEnd"]();
                core["ɵɵelementStart"](3, "button", 3);
                core["ɵɵlistener"]("click", function TextFloatingFilterComponent_Template_button_click_3_listener($event) { core["ɵɵrestoreView"](_r564); var _r559 = core["ɵɵreference"](6); return _r559.toggle($event); });
                core["ɵɵtext"](4);
                core["ɵɵelementEnd"]();
                core["ɵɵelementStart"](5, "p-menu", 4, 5);
                core["ɵɵtemplate"](7, TextFloatingFilterComponent_p_menu_item_7_Template, 1, 1, "p-menu-item", 6);
                core["ɵɵelementEnd"]();
                core["ɵɵelementEnd"]();
            } if (rf & 2) {
                var _r558 = core["ɵɵreference"](2);
                core["ɵɵadvance"](1);
                core["ɵɵproperty"]("ngModel", ctx.value)("pKeyFilter", ctx.keyFilter)("placeholder", ctx.getPlaceholder())("appInvalidIf", ctx.isNumberValueInvalid(ctx.value, _r558))("disabled", (ctx.type == null ? null : ctx.type.key) == "isNull" || (ctx.type == null ? null : ctx.type.key) == "isNotNull");
                core["ɵɵadvance"](3);
                core["ɵɵtextInterpolate1"](" ", ctx.type.sign || ctx.getDefaultType().sign, " ");
                core["ɵɵadvance"](1);
                core["ɵɵproperty"]("popup", true);
                core["ɵɵadvance"](2);
                core["ɵɵproperty"]("ngForOf", ctx.types);
            } }, directives: [forms.DefaultValueAccessor, ValidationMessageDirective, forms.NgControlStatus, forms.NgModel, PKeyFilterNumDirective, keyfilter.KeyFilter, InvalidIfDirective, ButtonDirective, MenuDirective, menu.Menu, common.NgForOf, MenuItemDirective], styles: ["input[_ngcontent-%COMP%]:focus {\n      outline: none;\n    }\n\n    .filter-button[_ngcontent-%COMP%] {\n      padding: 1px;\n      font-size: 10.5px;\n      width: 38px;\n      white-space: normal;\n      word-wrap: break-word;\n      line-height: 11px;\n      border: 0;\n      border-left: 1px solid #c8c8c8;\n      background-color: transparent;\n      color: #3d60a1;\n    }\n\n    .filter-button[_ngcontent-%COMP%]:hover {\n      background-color: #83b9ff;\n      cursor: pointer;\n    }"] });
        return TextFloatingFilterComponent;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](TextFloatingFilterComponent, [{
            type: core.Component,
            args: [{
                    template: "\n    <div style=\"display: flex; height: 100%\">\n      <input #inputElement\n             style=\"flex: 1; height: 100%; border: 0; padding: 7px\"\n             type=\"text\"\n             [(ngModel)]=\"value\"\n             (ngModelChange)=\"valueChanged()\"\n             [pKeyFilter]=\"keyFilter\"\n             [placeholder]=\"getPlaceholder()\"\n             (keydown)=\"onKeyDown($event)\"\n             (blur)=\"onBlur()\"\n             [appInvalidIf]=\"isNumberValueInvalid(value, inputElement)\"\n             [disabled]=\"type?.key == 'isNull' || type?.key == 'isNotNull'\"/>\n      <button\n        class=\"filter-button\"\n        (click)=\"filterMenu.toggle($event)\"\n      >\n        {{ type.sign || getDefaultType().sign }}\n      </button>\n      <p-menu #filterMenu\n              [popup]=\"true\"\n              appendTo=\"body\"\n      >\n        <p-menu-item *ngFor=\"let type of this.types\"\n                     [label]=\"getFilterModesTitle(type)\"\n                     (command)=\"applyFilterMode(type.key)\"\n        ></p-menu-item>\n      </p-menu>\n    </div>",
                    styles: ["\n    input:focus {\n      outline: none;\n    }\n\n    .filter-button {\n      padding: 1px;\n      font-size: 10.5px;\n      width: 38px;\n      white-space: normal;\n      word-wrap: break-word;\n      line-height: 11px;\n      border: 0;\n      border-left: 1px solid #c8c8c8;\n      background-color: transparent;\n      color: #3d60a1;\n    }\n\n    .filter-button:hover {\n      background-color: #83b9ff;\n      cursor: pointer;\n    }\n  "]
                }]
        }], null, null); })();

    function DropdownFloatingFilterComponent_p_menu_item_7_Template(rf, ctx) { if (rf & 1) {
        var _r569 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "p-menu-item", 7);
        core["ɵɵlistener"]("command", function DropdownFloatingFilterComponent_p_menu_item_7_Template_p_menu_item_command_0_listener() { core["ɵɵrestoreView"](_r569); var type_r567 = ctx.$implicit; var ctx_r568 = core["ɵɵnextContext"](); return ctx_r568.applyFilterMode(type_r567.key); });
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var type_r567 = ctx.$implicit;
        var ctx_r566 = core["ɵɵnextContext"]();
        core["ɵɵproperty"]("label", ctx_r566.getFilterModesTitle(type_r567));
    } }
    var _c0$4 = function () { return { height: "100%", "width": "100%", border: 0 }; };
    var DropdownFloatingFilterComponent = /** @class */ (function () {
        function DropdownFloatingFilterComponent() {
            this.isEnum = false;
            this.getFilterModesTitle = getFilterModesTitle;
        }
        DropdownFloatingFilterComponent.prototype.agInit = function (params) {
            this.params = params;
            this.currentValue = null;
            this.value = null;
            this.type = __assign({ key: 'equals' }, localeColumnFilterModes.equals);
            var colType = params.column.getColDef().type;
            this.types = [];
            if (colType) {
                var matchTypes = columnTypeFilterMatchModes[colType];
                this.types = matchTypes.map(function (type) {
                    return { key: type, title: localeColumnFilterModes[type].title, sign: localeColumnFilterModes[type].sign };
                });
            }
        };
        DropdownFloatingFilterComponent.prototype.isFilterActive = function () {
            return this.value != null;
        };
        DropdownFloatingFilterComponent.prototype.valueChanged = function () {
            if (this.value != this.currentValue) {
                this.apply();
            }
        };
        DropdownFloatingFilterComponent.prototype.applyFilterMode = function (type) {
            var oldType = __assign({}, this.type);
            var newType = this.types.find(function (findType) { return findType.key === type; });
            this.type = newType;
            var newWithValue = newType.key != 'isNull' && newType.key != 'isNotNull';
            var oldWithValue = oldType.key != 'isNull' && oldType.key != 'isNotNull';
            if (!newWithValue) {
                this.value = '-';
                this.apply();
            }
            else if (!oldWithValue) {
                this.value = '';
                this.apply();
            }
            else if (this.value != '' || this.value != this.currentValue) {
                this.apply();
            }
        };
        DropdownFloatingFilterComponent.prototype.apply = function () {
            var _this = this;
            this.currentValue = this.value;
            this.params.parentFilterInstance(function (filterInstance) {
                var _a;
                if (filterInstance) {
                    var simpleFilter = filterInstance;
                    simpleFilter.onFloatingFilterChanged(_this.type.key || 'equals', (_a = _this.currentValue) === null || _a === void 0 ? void 0 : _a.value);
                }
            });
        };
        DropdownFloatingFilterComponent.prototype.onParentModelChanged = function (parentModel) {
            if (!parentModel) {
                this.value = null;
                this.currentValue = null;
            }
            else {
                this.value = this.params.enum.find(function (e) { return e.value === parentModel.filter; });
                this.currentValue = parentModel.filter;
                this.type = this.types.find(function (findType) { return findType.key === parentModel.type; });
            }
        };
        DropdownFloatingFilterComponent.ɵfac = function DropdownFloatingFilterComponent_Factory(t) { return new (t || DropdownFloatingFilterComponent)(); };
        DropdownFloatingFilterComponent.ɵcmp = core["ɵɵdefineComponent"]({ type: DropdownFloatingFilterComponent, selectors: [["ng-component"]], decls: 8, vars: 9, consts: [[2, "display", "flex", "height", "100%"], [2, "flex", "1", "min-width", "0", "overflow", "hidden"], ["appendTo", "body", "optionLabel", "label", 3, "options", "ngModel", "disabled", "ngModelChange"], [1, "filter-button", 3, "click"], ["appendTo", "body", 3, "popup"], ["filterMenu", ""], [3, "label", "command", 4, "ngFor", "ngForOf"], [3, "label", "command"]], template: function DropdownFloatingFilterComponent_Template(rf, ctx) { if (rf & 1) {
                var _r570 = core["ɵɵgetCurrentView"]();
                core["ɵɵelementStart"](0, "div", 0);
                core["ɵɵelementStart"](1, "div", 1);
                core["ɵɵelementStart"](2, "p-dropdown", 2);
                core["ɵɵlistener"]("ngModelChange", function DropdownFloatingFilterComponent_Template_p_dropdown_ngModelChange_2_listener($event) { return ctx.value = $event; })("ngModelChange", function DropdownFloatingFilterComponent_Template_p_dropdown_ngModelChange_2_listener() { return ctx.valueChanged(); });
                core["ɵɵelementEnd"]();
                core["ɵɵelementEnd"]();
                core["ɵɵelementStart"](3, "button", 3);
                core["ɵɵlistener"]("click", function DropdownFloatingFilterComponent_Template_button_click_3_listener($event) { core["ɵɵrestoreView"](_r570); var _r565 = core["ɵɵreference"](6); return _r565.toggle($event); });
                core["ɵɵtext"](4);
                core["ɵɵelementEnd"]();
                core["ɵɵelementStart"](5, "p-menu", 4, 5);
                core["ɵɵtemplate"](7, DropdownFloatingFilterComponent_p_menu_item_7_Template, 1, 1, "p-menu-item", 6);
                core["ɵɵelementEnd"]();
                core["ɵɵelementEnd"]();
            } if (rf & 2) {
                core["ɵɵadvance"](2);
                core["ɵɵstyleMap"](core["ɵɵpureFunction0"](8, _c0$4));
                core["ɵɵproperty"]("options", ctx.params.enum)("ngModel", ctx.value)("disabled", ctx.type.key == "isNull" || ctx.type.key == "isNotNull");
                core["ɵɵadvance"](2);
                core["ɵɵtextInterpolate1"](" ", ctx.type.sign || ctx.types["equails"].sign, " ");
                core["ɵɵadvance"](1);
                core["ɵɵproperty"]("popup", true);
                core["ɵɵadvance"](2);
                core["ɵɵproperty"]("ngForOf", ctx.types);
            } }, directives: [dropdown.Dropdown, ValidationMessageDirective, forms.NgControlStatus, forms.NgModel, ButtonDirective, MenuDirective, menu.Menu, common.NgForOf, MenuItemDirective], styles: [".filter-button[_ngcontent-%COMP%] {\n      padding: 1px;\n      font-size: 10.5px;\n      width: 38px;\n      white-space: normal;\n      word-wrap: break-word;\n      line-height: 11px;\n      border: 0;\n      border-left: 1px solid #c8c8c8;\n      background-color: transparent;\n      color: #3d60a1;\n    }\n\n    .filter-button[_ngcontent-%COMP%]:hover {\n      background-color: #83b9ff;\n      cursor: pointer;\n    }"] });
        return DropdownFloatingFilterComponent;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](DropdownFloatingFilterComponent, [{
            type: core.Component,
            args: [{
                    template: "\n    <div style=\"display: flex; height: 100%\">\n      <div style=\"flex: 1; min-width: 0; overflow: hidden\">\n        <p-dropdown\n          [style]=\"{height: '100%', 'width': '100%', border: 0}\"\n          appendTo=\"body\"\n          [options]=\"params.enum\"\n          optionLabel=\"label\"\n          [(ngModel)]=\"value\"\n          (ngModelChange)=\"valueChanged()\"\n          [disabled]=\"type.key == 'isNull' || type.key == 'isNotNull'\">\n        </p-dropdown>\n      </div>\n      <button\n        class=\"filter-button\"\n        (click)=\"filterMenu.toggle($event)\"\n      >\n        {{ type.sign || types['equails'].sign }}\n      </button>\n      <p-menu #filterMenu\n              [popup]=\"true\"\n              appendTo=\"body\"\n      >\n        <p-menu-item *ngFor=\"let type of this.types\"\n                     [label]=\"getFilterModesTitle(type)\"\n                     (command)=\"applyFilterMode(type.key)\"\n        ></p-menu-item>\n      </p-menu>\n    </div>",
                    styles: ["\n    .filter-button {\n      padding: 1px;\n      font-size: 10.5px;\n      width: 38px;\n      white-space: normal;\n      word-wrap: break-word;\n      line-height: 11px;\n      border: 0;\n      border-left: 1px solid #c8c8c8;\n      background-color: transparent;\n      color: #3d60a1;\n    }\n\n    .filter-button:hover {\n      background-color: #83b9ff;\n      cursor: pointer;\n    }\n  "]
                }]
        }], null, null); })();

    var _c0$5 = function () { return { height: "100%", "width": "100%", border: 0 }; };
    var DropdownFilterComponent = /** @class */ (function () {
        function DropdownFilterComponent() {
        }
        DropdownFilterComponent.prototype.agInit = function (params) {
            this.params = params;
            this.value = null;
        };
        DropdownFilterComponent.prototype.isFilterActive = function () {
            return this.value != null;
        };
        DropdownFilterComponent.prototype.doesFilterPass = function (params) {
            return this.params.valueGetter(params.node) === this.value.value;
        };
        DropdownFilterComponent.prototype.getModel = function () {
            return this.value ? { filter: this.value.value, type: this.params.type } : null;
        };
        DropdownFilterComponent.prototype.setModel = function (model) {
            this.value = model ? this.params.enum.find(function (e) { return e.value === model.filter; }) : null;
            if (model) {
                this.params.type = model.type;
            }
        };
        DropdownFilterComponent.prototype.onFloatingFilterChanged = function (type, filter) {
            this.value = filter != null ? this.params.enum.find(function (e) { return e.value == filter; }) : null;
            this.params.type = (type !== null && type !== void 0 ? type : 'equals');
            this.params.filterChangedCallback();
        };
        DropdownFilterComponent.prototype.valueChanged = function () {
            this.params.filterChangedCallback();
        };
        DropdownFilterComponent.ɵfac = function DropdownFilterComponent_Factory(t) { return new (t || DropdownFilterComponent)(); };
        DropdownFilterComponent.ɵcmp = core["ɵɵdefineComponent"]({ type: DropdownFilterComponent, selectors: [["ng-component"]], decls: 3, vars: 5, consts: [[2, "display", "flex", "height", "100%"], [2, "flex", "1"], ["appendTo", "body", "optionLabel", "text", 3, "options", "ngModel", "ngModelChange"]], template: function DropdownFilterComponent_Template(rf, ctx) { if (rf & 1) {
                core["ɵɵelementStart"](0, "div", 0);
                core["ɵɵelementStart"](1, "div", 1);
                core["ɵɵelementStart"](2, "p-dropdown", 2);
                core["ɵɵlistener"]("ngModelChange", function DropdownFilterComponent_Template_p_dropdown_ngModelChange_2_listener($event) { return ctx.value = $event; })("ngModelChange", function DropdownFilterComponent_Template_p_dropdown_ngModelChange_2_listener() { return ctx.valueChanged(); });
                core["ɵɵelementEnd"]();
                core["ɵɵelementEnd"]();
                core["ɵɵelementEnd"]();
            } if (rf & 2) {
                core["ɵɵadvance"](2);
                core["ɵɵstyleMap"](core["ɵɵpureFunction0"](4, _c0$5));
                core["ɵɵproperty"]("options", ctx.params.enum)("ngModel", ctx.value);
            } }, directives: [dropdown.Dropdown, ValidationMessageDirective, forms.NgControlStatus, forms.NgModel], encapsulation: 2 });
        return DropdownFilterComponent;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](DropdownFilterComponent, [{
            type: core.Component,
            args: [{
                    template: "\n      <div style=\"display: flex; height: 100%\">\n        <div style=\"flex: 1\">\n          <p-dropdown\n            [style]=\"{height: '100%', 'width': '100%', border: 0}\"\n            appendTo=\"body\"\n            [options]=\"params.enum\"\n            optionLabel=\"text\"\n            [(ngModel)]=\"value\"\n            (ngModelChange)=\"valueChanged()\">\n          </p-dropdown>\n        </div>\n      </div>"
                }]
        }], null, null); })();

    var PageQuery = /** @class */ (function () {
        function PageQuery(options) {
            this.first = options.first;
            this.rows = options.rows;
            this.sorts = options.sorts;
            this.filters = options.filters;
            this.query = options.query;
            this.exportColumns = options.exportColumns;
            this.distinctColumn = options.distinctColumn;
            this.findRowQuery = options.findRowQuery;
        }
        PageQuery.prototype.clone = function (overrides) {
            return new PageQuery(Object.assign({}, this, overrides));
        };
        return PageQuery;
    }());

    var LoadingCellRenderer = /** @class */ (function (_super) {
        __extends(LoadingCellRenderer, _super);
        function LoadingCellRenderer() {
            return _super.call(this, "<div style=\"width: 100%; height: 100%; display: flex; align-items: center; justify-content: center\">\n            <div>\n                <i class=\"fa fa-spinner fa-spin\"></i>\n            </div>\n        </div>") || this;
        }
        return LoadingCellRenderer;
    }(agGridCommunity.Component));

    var CheckboxHeaderComponent = /** @class */ (function () {
        function CheckboxHeaderComponent() {
            this.isChecked = false;
            this.checkboxClick = new core.EventEmitter();
        }
        CheckboxHeaderComponent.prototype.agInit = function (params) {
            this.params = params;
            this.colId = params.column.getColId();
            this.type = params.column.getColDef().type;
        };
        CheckboxHeaderComponent.prototype.onChange = function (value) {
            var _this = this;
            if (this.type !== 'bool') {
                console.warn("Column " + this.colId + " must be bool");
            }
            else {
                this.params.api.forEachNodeAfterFilterAndSort(function (node) {
                    node.data[_this.colId] = value;
                    node.setData(node.data);
                });
            }
        };
        CheckboxHeaderComponent.ɵfac = function CheckboxHeaderComponent_Factory(t) { return new (t || CheckboxHeaderComponent)(); };
        CheckboxHeaderComponent.ɵcmp = core["ɵɵdefineComponent"]({ type: CheckboxHeaderComponent, selectors: [["ng-component"]], outputs: { checkboxClick: "checkboxClick" }, decls: 2, vars: 2, consts: [[2, "width", "100%", "height", "100%", "text-align", "center"], ["binary", "true", 3, "ngModel", "pTooltip", "ngModelChange", "onChange"]], template: function CheckboxHeaderComponent_Template(rf, ctx) { if (rf & 1) {
                core["ɵɵelementStart"](0, "div", 0);
                core["ɵɵelementStart"](1, "p-checkbox", 1);
                core["ɵɵlistener"]("ngModelChange", function CheckboxHeaderComponent_Template_p_checkbox_ngModelChange_1_listener($event) { return ctx.isChecked = $event; })("onChange", function CheckboxHeaderComponent_Template_p_checkbox_onChange_1_listener($event) { return ctx.onChange($event); });
                core["ɵɵelementEnd"]();
                core["ɵɵelementEnd"]();
            } if (rf & 2) {
                core["ɵɵadvance"](1);
                core["ɵɵproperty"]("ngModel", ctx.isChecked)("pTooltip", ctx.isChecked ? "\u0421\u043D\u044F\u0442\u044C \u0432\u0441\u0435 \u043E\u0442\u043C\u0435\u0442\u043A\u0438" : "\u041E\u0442\u043C\u0435\u0442\u0438\u0442\u044C \u0432\u0441\u0435 \u0437\u0430\u043F\u0438\u0441\u0438");
            } }, directives: [checkbox.Checkbox, ValidationMessageDirective, forms.NgControlStatus, forms.NgModel, TooltipExtDirective, tooltip.Tooltip], encapsulation: 2 });
        return CheckboxHeaderComponent;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](CheckboxHeaderComponent, [{
            type: core.Component,
            args: [{
                    template: "\n    <div style=\"width: 100%; height: 100%; text-align: center\">\n      <p-checkbox [(ngModel)]=\"isChecked\" binary=\"true\" (onChange)=\"onChange($event)\"\n                  [pTooltip]=\"isChecked ? '\u0421\u043D\u044F\u0442\u044C \u0432\u0441\u0435 \u043E\u0442\u043C\u0435\u0442\u043A\u0438' : '\u041E\u0442\u043C\u0435\u0442\u0438\u0442\u044C \u0432\u0441\u0435 \u0437\u0430\u043F\u0438\u0441\u0438'\">\n      </p-checkbox>\n    </div>"
                }]
        }], null, { checkboxClick: [{
                type: core.Output
            }] }); })();

    var _c0$6 = ["checkbox"];
    var TriStateCheckboxHeaderComponent = /** @class */ (function () {
        function TriStateCheckboxHeaderComponent() {
            this.isChecked = false;
        }
        TriStateCheckboxHeaderComponent.prototype.agInit = function (params) {
            var _this = this;
            this.checkbox.toggle = function (event) {
                if (_this.checkbox.value == null) {
                    _this.checkbox.value = false;
                }
                else {
                    _this.checkbox.value = !_this.checkbox.value;
                }
                _this.checkbox.onModelChange(_this.checkbox.value);
                _this.checkbox.onChange.emit({
                    originalEvent: event,
                    value: _this.checkbox.value
                });
            };
            this.updateCheckedStateListener = this.updateCheckedStateWithDebounce.bind(this);
            this.params = params;
            this.nodesFilter = params.nodesFilter;
            this.bindEvents();
            this.updateCheckedStateWithDebounce();
        };
        TriStateCheckboxHeaderComponent.prototype.bindEvents = function () {
            this.params.api.addEventListener('modelUpdated', this.updateCheckedStateListener);
            this.params.api.addEventListener('cellValueChanged', this.updateCheckedStateListener);
        };
        TriStateCheckboxHeaderComponent.prototype.unbindEvents = function () {
            this.params.api.removeEventListener('modelUpdated', this.updateCheckedStateListener);
            this.params.api.removeEventListener('cellValueChanged', this.updateCheckedStateListener);
        };
        TriStateCheckboxHeaderComponent.prototype.ngOnDestroy = function () {
            if (this.updateTimerId) {
                clearTimeout(this.updateTimerId);
            }
            this.unbindEvents();
        };
        TriStateCheckboxHeaderComponent.prototype.updateCheckedStateWithDebounce = function () {
            var _this = this;
            if (this.updateTimerId) {
                clearTimeout(this.updateTimerId);
            }
            this.updateTimerId = setTimeout(function () {
                _this.updateCheckedState();
            }, 20);
        };
        TriStateCheckboxHeaderComponent.prototype.updateCheckedState = function () {
            var _this = this;
            var checkedCount = 0;
            var allCount = 0;
            this.params.api.forEachNodeAfterFilterAndSort(function (node) {
                if (!_this.nodesFilter || _this.nodesFilter(node)) {
                    var checked = _this.params.api.getValue(_this.params.column, node);
                    if (checked) {
                        checkedCount++;
                    }
                    allCount++;
                }
            });
            var allChecked = null;
            if (allCount > 0) {
                if (checkedCount == allCount) {
                    allChecked = true;
                }
                else if (checkedCount == 0) {
                    allChecked = false;
                }
            }
            else {
                allChecked = false;
            }
            this.isChecked = allChecked;
        };
        TriStateCheckboxHeaderComponent.prototype.onChange = function (event) {
            var _this = this;
            if (this.params.column.getColDef().type !== 'bool') {
                console.warn("Column " + this.params.column.getColId() + " must be bool");
            }
            else {
                this.unbindEvents();
                this.params.api.forEachNodeAfterFilterAndSort(function (node) {
                    if (!_this.nodesFilter || _this.nodesFilter(node)) {
                        node.setDataValue(_this.params.column, _this.isChecked);
                    }
                });
                this.bindEvents();
                this.updateCheckedState();
            }
        };
        TriStateCheckboxHeaderComponent.ɵfac = function TriStateCheckboxHeaderComponent_Factory(t) { return new (t || TriStateCheckboxHeaderComponent)(); };
        TriStateCheckboxHeaderComponent.ɵcmp = core["ɵɵdefineComponent"]({ type: TriStateCheckboxHeaderComponent, selectors: [["ng-component"]], viewQuery: function TriStateCheckboxHeaderComponent_Query(rf, ctx) { if (rf & 1) {
                core["ɵɵstaticViewQuery"](_c0$6, true);
            } if (rf & 2) {
                var _t;
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.checkbox = _t.first);
            } }, decls: 3, vars: 2, consts: [[2, "width", "100%", "height", "100%", "text-align", "center"], [3, "ngModel", "pTooltip", "ngModelChange", "onChange"], ["checkbox", ""]], template: function TriStateCheckboxHeaderComponent_Template(rf, ctx) { if (rf & 1) {
                core["ɵɵelementStart"](0, "div", 0);
                core["ɵɵelementStart"](1, "p-triStateCheckbox", 1, 2);
                core["ɵɵlistener"]("ngModelChange", function TriStateCheckboxHeaderComponent_Template_p_triStateCheckbox_ngModelChange_1_listener($event) { return ctx.isChecked = $event; })("onChange", function TriStateCheckboxHeaderComponent_Template_p_triStateCheckbox_onChange_1_listener($event) { return ctx.onChange($event); });
                core["ɵɵelementEnd"]();
                core["ɵɵelementEnd"]();
            } if (rf & 2) {
                core["ɵɵadvance"](1);
                core["ɵɵproperty"]("ngModel", ctx.isChecked)("pTooltip", ctx.isChecked == null || !ctx.isChecked ? "\u041E\u0442\u043C\u0435\u0442\u0438\u0442\u044C \u0432\u0441\u0435 \u0437\u0430\u043F\u0438\u0441\u0438" : "\u0421\u043D\u044F\u0442\u044C \u0432\u0441\u0435 \u043E\u0442\u043C\u0435\u0442\u043A\u0438");
            } }, directives: [tristatecheckbox.TriStateCheckbox, ValidationMessageDirective, forms.NgControlStatus, forms.NgModel, TooltipExtDirective, tooltip.Tooltip], encapsulation: 2 });
        return TriStateCheckboxHeaderComponent;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](TriStateCheckboxHeaderComponent, [{
            type: core.Component,
            args: [{
                    template: "\n    <div style=\"width: 100%; height: 100%; text-align: center\">\n      <p-triStateCheckbox #checkbox [(ngModel)]=\"isChecked\" (onChange)=\"onChange($event)\"\n                  [pTooltip]=\"(isChecked == null || !isChecked) ? '\u041E\u0442\u043C\u0435\u0442\u0438\u0442\u044C \u0432\u0441\u0435 \u0437\u0430\u043F\u0438\u0441\u0438' : '\u0421\u043D\u044F\u0442\u044C \u0432\u0441\u0435 \u043E\u0442\u043C\u0435\u0442\u043A\u0438'\">\n      </p-triStateCheckbox>\n    </div>"
                }]
        }], null, { checkbox: [{
                type: core.ViewChild,
                args: ['checkbox', { static: true }]
            }] }); })();

    function CustomDetailComponent_ng_container_0_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainer"](0);
    } }
    var _c0$7 = function (a0) { return { $implicit: a0 }; };
    var CustomDetailComponent = /** @class */ (function () {
        function CustomDetailComponent() {
        }
        CustomDetailComponent.prototype.agInit = function (params) {
            if (params.template) {
                this.template = params.template;
            }
            else {
                console.warn('You need to use detailCellRendererParams.template for detail view');
            }
            this.params = params;
        };
        CustomDetailComponent.prototype.refresh = function (params) {
            return false;
        };
        CustomDetailComponent.ɵfac = function CustomDetailComponent_Factory(t) { return new (t || CustomDetailComponent)(); };
        CustomDetailComponent.ɵcmp = core["ɵɵdefineComponent"]({ type: CustomDetailComponent, selectors: [["app-detail-cell-renderer"]], decls: 1, vars: 4, consts: [[4, "ngTemplateOutlet", "ngTemplateOutletContext"]], template: function CustomDetailComponent_Template(rf, ctx) { if (rf & 1) {
                core["ɵɵtemplate"](0, CustomDetailComponent_ng_container_0_Template, 1, 0, "ng-container", 0);
            } if (rf & 2) {
                core["ɵɵproperty"]("ngTemplateOutlet", ctx.template)("ngTemplateOutletContext", core["ɵɵpureFunction1"](2, _c0$7, ctx.params));
            } }, directives: [common.NgTemplateOutlet], encapsulation: 2 });
        return CustomDetailComponent;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](CustomDetailComponent, [{
            type: core.Component,
            args: [{
                    selector: 'app-detail-cell-renderer',
                    template: "\n    <ng-container *ngTemplateOutlet=\"template; context: {$implicit: params}\"></ng-container>"
                }]
        }], null, null); })();

    var CalendarDirective = /** @class */ (function () {
        function CalendarDirective(calendar) {
            this.calendar = calendar;
            calendar.locale = {
                firstDayOfWeek: 1,
                dayNames: ['Воскресенье', 'Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота'],
                dayNamesShort: ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'],
                dayNamesMin: ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'],
                monthNames: ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'],
                monthNamesShort: ['Янв', 'Фев', 'Мар', 'Апр', 'Май', 'Июн', 'Июл', 'Авг', 'Сен', 'Окт', 'Ноя', 'Дек'],
                today: 'Сегодня',
                clear: 'Очистить'
            };
        }
        CalendarDirective.prototype.onClose = function () {
            if (!this.calendar.showOnFocus) {
                this.calendar.inputfieldViewChild.nativeElement.focus();
            }
        };
        CalendarDirective.ɵfac = function CalendarDirective_Factory(t) { return new (t || CalendarDirective)(core["ɵɵdirectiveInject"](calendar.Calendar)); };
        CalendarDirective.ɵdir = core["ɵɵdefineDirective"]({ type: CalendarDirective, selectors: [["p-calendar"]], hostBindings: function CalendarDirective_HostBindings(rf, ctx) { if (rf & 1) {
                core["ɵɵlistener"]("onClose", function CalendarDirective_onClose_HostBindingHandler() { return ctx.onClose(); });
            } } });
        return CalendarDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](CalendarDirective, [{
            type: core.Directive,
            args: [{
                    selector: 'p-calendar',
                    host: {
                        '(onClose)': 'onClose()'
                    }
                }]
        }], function () { return [{ type: calendar.Calendar }]; }, null); })();

    var CalenderMaskDirective = /** @class */ (function () {
        function CalenderMaskDirective(calendar) {
            this.calendar = calendar;
            this.mask = 'мм/дд/гггг';
            this.enableMask = true;
        }
        CalenderMaskDirective.prototype.ngAfterViewInit = function () {
            var _this = this;
            if (!this.enableMask || this.calendar.timeOnly || this.calendar.inline || this.calendar.selectionMode != 'single') {
                return;
            }
            if (this.calendar.dateFormat) {
                this.mask = this.calendar.dateFormat
                    .replace('yy', 'гггг')
                    .replace('mm', 'мм')
                    .replace('dd', 'дд');
            }
            var input = this.calendar.el.nativeElement.querySelector('input.ui-inputtext');
            input.addEventListener('focus', function (e) {
                if (!input.value) {
                    input.value = _this.mask;
                    setTimeout(function () {
                        input.setSelectionRange(0, 0);
                    });
                }
            });
            input.addEventListener('keydown', function (e) {
                var oldValue = input.value;
                if (e.ctrlKey) {
                    // copy/paste
                }
                else if (e.code == 'Enter' || e.code == 'NumpadEnter' || e.code == 'Tab') {
                    //
                }
                else if (e.code == 'Backspace' && input.selectionStart == input.selectionEnd) {
                    var start = input.selectionStart;
                    if (start - 1 >= 0) {
                        input.value = oldValue.substr(0, start - 1) + _this.mask[start - 1] + oldValue.substr(start);
                        input.setSelectionRange(start - 1, start - 1);
                    }
                    e.preventDefault();
                }
                else if (e.code == 'Delete' && input.selectionStart == input.selectionEnd) {
                    e.preventDefault();
                }
                else if (e.code == 'Backspace' || e.code == 'Delete') {
                    var start = input.selectionStart;
                    var value = oldValue;
                    for (var i = input.selectionStart; i < input.selectionEnd; i++) {
                        value = value.substr(0, i) + _this.mask[i] + value.substr(i + 1);
                    }
                    input.value = value;
                    input.setSelectionRange(start, start);
                    e.preventDefault();
                }
                else if (e.code == 'ArrowLeft') {
                    var start = input.selectionStart - 1;
                    if (start >= 0) {
                        input.setSelectionRange(start, start);
                    }
                    e.preventDefault();
                }
                else if (e.code == 'ArrowRight') {
                    var start = input.selectionStart + 1;
                    if (start <= _this.mask.length) {
                        input.setSelectionRange(start, start);
                    }
                    e.preventDefault();
                }
                else if (/\d/.test(e.key)) {
                    var start = input.selectionStart;
                    if (/[^дгм]/.test(_this.mask[start])) {
                        start++;
                    }
                    if (start < _this.mask.length) {
                        input.value = oldValue.substr(0, start) + e.key + oldValue.substr(start + 1);
                        start++;
                        if (/[^дгм]/.test(_this.mask[start])) {
                            start++;
                        }
                        input.setSelectionRange(start, start);
                    }
                    e.preventDefault();
                }
                else {
                    _this.calendar.onInputKeydown(e);
                    e.preventDefault();
                }
                if (oldValue != input.value) {
                    _this.calendar.onUserInput(e);
                }
            });
            input.addEventListener('paste', function (e) {
                var text = e.clipboardData.getData('text');
                if (text) {
                    var value = input.value;
                    var start = input.selectionStart;
                    for (var i = 0; i < _this.mask.length - start && i < text.length; i++) {
                        if (/[^дгм]/.test(_this.mask[start + i])) {
                            //
                        }
                        else if (/\d/.test(text[i])) {
                            value = value.substr(0, start + i) + text[i] + value.substr(start + i + 1);
                        }
                    }
                    input.value = value;
                    input.setSelectionRange(start + text.length, start + text.length);
                    _this.calendar.isKeydown = true;
                    _this.calendar.onUserInput(e);
                }
                e.preventDefault();
            });
        };
        CalenderMaskDirective.ɵfac = function CalenderMaskDirective_Factory(t) { return new (t || CalenderMaskDirective)(core["ɵɵdirectiveInject"](calendar.Calendar)); };
        CalenderMaskDirective.ɵdir = core["ɵɵdefineDirective"]({ type: CalenderMaskDirective, selectors: [["p-calendar", 3, "rPCalendarMask", ""]], inputs: { enableMask: "enableMask" } });
        return CalenderMaskDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](CalenderMaskDirective, [{
            type: core.Directive,
            args: [{
                    selector: 'p-calendar:not([rPCalendarMask])'
                }]
        }], function () { return [{ type: calendar.Calendar }]; }, { enableMask: [{
                type: core.Input,
                args: ["enableMask"]
            }] }); })();

    var CalendarUtcDateDirective = /** @class */ (function () {
        function CalendarUtcDateDirective(calendar) {
            var updateDate = function (value, inc) {
                if (value === null) {
                    return null;
                }
                var date = new Date(value);
                date.setTime(date.getTime() + (!!inc ? 1 : -1) * date.getTimezoneOffset() * 60000);
                return date;
            };
            var oldWriteValue = calendar.writeValue.bind(calendar);
            calendar.writeValue = function (value) {
                if (!!value) {
                    if (value instanceof Array) {
                        var res_1 = [];
                        value.forEach(function (date) {
                            res_1.push(updateDate(date, true));
                        });
                        oldWriteValue(res_1);
                    }
                    else {
                        oldWriteValue(updateDate(value, true));
                    }
                }
                else {
                    oldWriteValue(value);
                }
            };
            var oldRegisterOnChange = calendar.registerOnChange.bind(calendar);
            calendar.registerOnChange = function (fn) {
                oldRegisterOnChange(function (value) {
                    if (!!value) {
                        if (value instanceof Array) {
                            var res_2 = [];
                            value.forEach(function (date) {
                                res_2.push(updateDate(date, false));
                            });
                            fn(res_2);
                        }
                        else {
                            fn(updateDate(value, false));
                        }
                    }
                    else {
                        fn(value);
                    }
                });
            };
        }
        CalendarUtcDateDirective.ɵfac = function CalendarUtcDateDirective_Factory(t) { return new (t || CalendarUtcDateDirective)(core["ɵɵdirectiveInject"](calendar.Calendar)); };
        CalendarUtcDateDirective.ɵdir = core["ɵɵdefineDirective"]({ type: CalendarUtcDateDirective, selectors: [["p-calendar", "utcDate", ""]] });
        return CalendarUtcDateDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](CalendarUtcDateDirective, [{
            type: core.Directive,
            args: [{
                    selector: 'p-calendar[utcDate]'
                }]
        }], function () { return [{ type: calendar.Calendar }]; }, null); })();

    var _c0$8 = ["calendar"];
    var _c1$3 = function () { return { width: "100%" }; };
    var _c2$2 = function () { return { border: "none", color: "#3d60a1ff" }; };
    function DateFloatingFilterComponent_p_calendar_2_Template(rf, ctx) { if (rf & 1) {
        var _r579 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "p-calendar", 8, 9);
        core["ɵɵlistener"]("ngModelChange", function DateFloatingFilterComponent_p_calendar_2_Template_p_calendar_ngModelChange_0_listener($event) { core["ɵɵrestoreView"](_r579); var ctx_r578 = core["ɵɵnextContext"](); return ctx_r578.calendarValue = $event; })("onClose", function DateFloatingFilterComponent_p_calendar_2_Template_p_calendar_onClose_0_listener() { core["ɵɵrestoreView"](_r579); var ctx_r580 = core["ɵɵnextContext"](); return ctx_r580.onCloseCalendar(); })("onSelect", function DateFloatingFilterComponent_p_calendar_2_Template_p_calendar_onSelect_0_listener($event) { core["ɵɵrestoreView"](_r579); var ctx_r581 = core["ɵɵnextContext"](); return ctx_r581.onSelectCalendar($event); })("onClearClick", function DateFloatingFilterComponent_p_calendar_2_Template_p_calendar_onClearClick_0_listener() { core["ɵɵrestoreView"](_r579); var ctx_r582 = core["ɵɵnextContext"](); return ctx_r582.onClearCalendar(); })("keypress", function DateFloatingFilterComponent_p_calendar_2_Template_p_calendar_keypress_0_listener($event) { core["ɵɵrestoreView"](_r579); var ctx_r583 = core["ɵɵnextContext"](); return ctx_r583.onKeyPress($event); });
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var ctx_r573 = core["ɵɵnextContext"]();
        core["ɵɵstyleMap"](core["ɵɵpureFunction0"](10, _c1$3));
        core["ɵɵproperty"]("ngModel", ctx_r573.calendarValue)("showIcon", true)("monthNavigator", true)("yearNavigator", true)("showOnFocus", false)("showButtonBar", true)("ngStyle", core["ɵɵpureFunction0"](11, _c1$3))("inputStyle", core["ɵɵpureFunction0"](12, _c2$2));
    } }
    function DateFloatingFilterComponent_p_calendar_3_Template(rf, ctx) { if (rf & 1) {
        var _r586 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "p-calendar", 10, 9);
        core["ɵɵlistener"]("ngModelChange", function DateFloatingFilterComponent_p_calendar_3_Template_p_calendar_ngModelChange_0_listener($event) { core["ɵɵrestoreView"](_r586); var ctx_r585 = core["ɵɵnextContext"](); return ctx_r585.calendarValue = $event; })("onClose", function DateFloatingFilterComponent_p_calendar_3_Template_p_calendar_onClose_0_listener() { core["ɵɵrestoreView"](_r586); var ctx_r587 = core["ɵɵnextContext"](); return ctx_r587.onCloseCalendar(); })("onSelect", function DateFloatingFilterComponent_p_calendar_3_Template_p_calendar_onSelect_0_listener($event) { core["ɵɵrestoreView"](_r586); var ctx_r588 = core["ɵɵnextContext"](); return ctx_r588.onSelectCalendar($event); })("onClearClick", function DateFloatingFilterComponent_p_calendar_3_Template_p_calendar_onClearClick_0_listener() { core["ɵɵrestoreView"](_r586); var ctx_r589 = core["ɵɵnextContext"](); return ctx_r589.onClearCalendar(); })("keypress", function DateFloatingFilterComponent_p_calendar_3_Template_p_calendar_keypress_0_listener($event) { core["ɵɵrestoreView"](_r586); var ctx_r590 = core["ɵɵnextContext"](); return ctx_r590.onKeyPress($event); })("onFocus", function DateFloatingFilterComponent_p_calendar_3_Template_p_calendar_onFocus_0_listener() { core["ɵɵrestoreView"](_r586); var ctx_r591 = core["ɵɵnextContext"](); return ctx_r591.onRangeFocus(); })("onBlur", function DateFloatingFilterComponent_p_calendar_3_Template_p_calendar_onBlur_0_listener() { core["ɵɵrestoreView"](_r586); var ctx_r592 = core["ɵɵnextContext"](); return ctx_r592.onRangeBlur(); });
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var ctx_r574 = core["ɵɵnextContext"]();
        core["ɵɵstyleMap"](core["ɵɵpureFunction0"](10, _c1$3));
        core["ɵɵproperty"]("ngModel", ctx_r574.calendarValue)("showIcon", true)("monthNavigator", true)("yearNavigator", true)("showOnFocus", false)("showButtonBar", true)("ngStyle", core["ɵɵpureFunction0"](11, _c1$3))("inputStyle", core["ɵɵpureFunction0"](12, _c2$2));
    } }
    function DateFloatingFilterComponent_p_menu_item_8_Template(rf, ctx) { if (rf & 1) {
        var _r595 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "p-menu-item", 11);
        core["ɵɵlistener"]("command", function DateFloatingFilterComponent_p_menu_item_8_Template_p_menu_item_command_0_listener() { core["ɵɵrestoreView"](_r595); var type_r593 = ctx.$implicit; var ctx_r594 = core["ɵɵnextContext"](); return ctx_r594.applyFilterMode(type_r593.key); });
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var type_r593 = ctx.$implicit;
        var ctx_r576 = core["ɵɵnextContext"]();
        core["ɵɵproperty"]("label", ctx_r576.getFilterModesTitle(type_r593));
    } }
    var DateFloatingFilterComponent = /** @class */ (function () {
        function DateFloatingFilterComponent() {
            this.getFilterModesTitle = getFilterModesTitle;
        }
        DateFloatingFilterComponent.prototype.agInit = function (params) {
            this.params = params;
            this.params.type = __assign({ key: 'between' }, localeColumnFilterModes.between);
            var colType = params.column.getColDef().type;
            this.types = [];
            if (colType) {
                var matchTypes = columnTypeFilterMatchModes[colType];
                this.types = matchTypes.map(function (type) {
                    return { key: type, title: localeColumnFilterModes[type].title, sign: localeColumnFilterModes[type].sign };
                });
            }
        };
        DateFloatingFilterComponent.prototype.onParentModelChanged = function (parentModel, filterChangedEvent) {
            if (!parentModel) {
                this.calendarValue = null;
            }
            else {
                if (parentModel.type === 'between') {
                    this.calendarValue = parentModel.filter.split(',').map(function (dateStr) {
                        if (!!dateStr) {
                            return new Date(dateStr);
                        }
                        return null;
                    });
                }
                else {
                    this.calendarValue = new Date(parentModel.filter);
                }
            }
        };
        DateFloatingFilterComponent.prototype.applyFilterMode = function (typeKey) {
            if (this.params.type.key !== typeKey && (typeKey === 'between' || this.params.type.key === 'between')) {
                if (typeKey === 'between') {
                    if (this.calendarValue && !(this.calendarValue instanceof Array)) {
                        this.calendarValue = [this.calendarValue, null];
                    }
                    else {
                        this.calendarValue = null;
                    }
                }
                else {
                    if (this.calendarValue instanceof Array) {
                        if (this.calendarValue[0]) {
                            this.calendarValue = this.calendarValue[0];
                        }
                    }
                    else {
                        this.calendarValue = null;
                    }
                }
            }
            this.params.type = this.types.find(function (type) { return type.key === typeKey; });
            if (this.calendarValue) {
                this.apply();
            }
        };
        DateFloatingFilterComponent.prototype.onKeyPress = function (event) {
            if (event.key === 'Enter') {
                this.apply();
            }
        };
        DateFloatingFilterComponent.prototype.onCloseCalendar = function () {
            if (this.calendarValue) {
                this.apply();
            }
        };
        DateFloatingFilterComponent.prototype.onClearCalendar = function () {
            this.calendarValue = null;
            this.apply();
        };
        DateFloatingFilterComponent.prototype.onRangeFocus = function () {
            this.calendar.placeholder = 'дд.мм.гггг - дд.мм.гггг';
        };
        DateFloatingFilterComponent.prototype.onRangeBlur = function () {
            this.calendar.placeholder = '';
        };
        DateFloatingFilterComponent.prototype.onSelectCalendar = function (changeDate) {
            if (this.params.type.key === 'between') {
                if (!!this.calendarValue[0] && !!this.calendarValue[1]) {
                    this.calendar.hideOverlay();
                    return;
                }
                return;
            }
            this.calendar.hideOverlay();
        };
        DateFloatingFilterComponent.prototype.apply = function () {
            var _this = this;
            this.params.parentFilterInstance(function (filterInstance) {
                if (filterInstance) {
                    var simpleFilter = filterInstance;
                    simpleFilter.onFloatingFilterChanged(_this.params.type.key, _this.calendarValue);
                }
            });
        };
        DateFloatingFilterComponent.ɵfac = function DateFloatingFilterComponent_Factory(t) { return new (t || DateFloatingFilterComponent)(); };
        DateFloatingFilterComponent.ɵcmp = core["ɵɵdefineComponent"]({ type: DateFloatingFilterComponent, selectors: [["ng-component"]], viewQuery: function DateFloatingFilterComponent_Query(rf, ctx) { if (rf & 1) {
                core["ɵɵviewQuery"](_c0$8, true);
            } if (rf & 2) {
                var _t;
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.calendar = _t.first);
            } }, decls: 9, vars: 5, consts: [[2, "display", "flex", "width", "100%", "height", "100%", "flex-direction", "row"], [2, "flex", "auto", "width", "100%", "overflow", "hidden", "display", "flex", "align-items", "center", "justify-content", "left"], ["class", "filter-calendar", "appendTo", "body", "dateFormat", "dd.mm.yy", "yearRange", "2000:2030", "utcDate", "", 3, "ngModel", "showIcon", "monthNavigator", "yearNavigator", "showOnFocus", "showButtonBar", "ngStyle", "style", "inputStyle", "ngModelChange", "onClose", "onSelect", "onClearClick", "keypress", 4, "ngIf"], ["class", "filter-calendar", "appendTo", "body", "dateFormat", "dd.mm.yy", "yearRange", "2000:2030", "utcDate", "", "selectionMode", "range", 3, "ngModel", "showIcon", "monthNavigator", "yearNavigator", "showOnFocus", "showButtonBar", "ngStyle", "style", "inputStyle", "ngModelChange", "onClose", "onSelect", "onClearClick", "keypress", "onFocus", "onBlur", 4, "ngIf"], [1, "filter-button", 3, "click"], ["appendTo", "body", 3, "popup"], ["filterMenu", ""], [3, "label", "command", 4, "ngFor", "ngForOf"], ["appendTo", "body", "dateFormat", "dd.mm.yy", "yearRange", "2000:2030", "utcDate", "", 1, "filter-calendar", 3, "ngModel", "showIcon", "monthNavigator", "yearNavigator", "showOnFocus", "showButtonBar", "ngStyle", "inputStyle", "ngModelChange", "onClose", "onSelect", "onClearClick", "keypress"], ["calendar", ""], ["appendTo", "body", "dateFormat", "dd.mm.yy", "yearRange", "2000:2030", "utcDate", "", "selectionMode", "range", 1, "filter-calendar", 3, "ngModel", "showIcon", "monthNavigator", "yearNavigator", "showOnFocus", "showButtonBar", "ngStyle", "inputStyle", "ngModelChange", "onClose", "onSelect", "onClearClick", "keypress", "onFocus", "onBlur"], [3, "label", "command"]], template: function DateFloatingFilterComponent_Template(rf, ctx) { if (rf & 1) {
                var _r596 = core["ɵɵgetCurrentView"]();
                core["ɵɵelementStart"](0, "div", 0);
                core["ɵɵelementStart"](1, "div", 1);
                core["ɵɵtemplate"](2, DateFloatingFilterComponent_p_calendar_2_Template, 2, 13, "p-calendar", 2);
                core["ɵɵtemplate"](3, DateFloatingFilterComponent_p_calendar_3_Template, 2, 13, "p-calendar", 3);
                core["ɵɵelementEnd"]();
                core["ɵɵelementStart"](4, "button", 4);
                core["ɵɵlistener"]("click", function DateFloatingFilterComponent_Template_button_click_4_listener($event) { core["ɵɵrestoreView"](_r596); var _r575 = core["ɵɵreference"](7); return _r575.toggle($event); });
                core["ɵɵtext"](5);
                core["ɵɵelementEnd"]();
                core["ɵɵelementStart"](6, "p-menu", 5, 6);
                core["ɵɵtemplate"](8, DateFloatingFilterComponent_p_menu_item_8_Template, 1, 1, "p-menu-item", 7);
                core["ɵɵelementEnd"]();
                core["ɵɵelementEnd"]();
            } if (rf & 2) {
                core["ɵɵadvance"](2);
                core["ɵɵproperty"]("ngIf", ctx.params.type.key !== "between");
                core["ɵɵadvance"](1);
                core["ɵɵproperty"]("ngIf", ctx.params.type.key === "between");
                core["ɵɵadvance"](2);
                core["ɵɵtextInterpolate1"](" ", ctx.params.type.sign || ctx.types["between"].sign, " ");
                core["ɵɵadvance"](1);
                core["ɵɵproperty"]("popup", true);
                core["ɵɵadvance"](2);
                core["ɵɵproperty"]("ngForOf", ctx.types);
            } }, directives: [common.NgIf, ButtonDirective, MenuDirective, menu.Menu, common.NgForOf, CalendarDirective, CalenderMaskDirective, calendar.Calendar, CalendarUtcDateDirective, ValidationMessageDirective, forms.NgControlStatus, forms.NgModel, common.NgStyle, MenuItemDirective], styles: [".filter-button[_ngcontent-%COMP%] {\n      padding: 1px;\n      font-size: 10.5px;\n      width: 38px;\n      white-space: normal;\n      word-wrap: break-word;\n      line-height: 11px;\n      border: 0;\n      border-left: 1px solid #c8c8c8;\n      background-color: transparent;\n      color: #3d60a1;\n      flex: none;\n    }\n\n    .filter-button[_ngcontent-%COMP%]:hover {\n      background-color: #83b9ff;\n      cursor: pointer;\n    }\n\n    .filter-calendar[_ngcontent-%COMP%]     ::-webkit-input-placeholder {\n      color: #3d60a1ff;\n    }\n\n    .filter-calendar[_ngcontent-%COMP%]     ::-moz-placeholder {\n      color: #3d60a1ff;\n    }\n\n    .filter-calendar[_ngcontent-%COMP%]     :-moz-placeholder {\n      color: #3d60a1ff;\n    }\n\n    .filter-calendar[_ngcontent-%COMP%]     :-ms-input-placeholder {\n      color: #3d60a1ff;\n    }\n\n    .filter-calendar[_ngcontent-%COMP%]     .ui-datepicker-trigger {\n      border: none !important;\n      background: transparent !important;\n      color: #3d60a199;\n    }\n\n    .filter-calendar[_ngcontent-%COMP%]     .ui-datepicker-trigger:hover {\n      color: #3d60a1ff;\n    }\n\n    .filter-calendar[_ngcontent-%COMP%]     .ui-datepicker-trigger:active {\n      color: #3d60a1ff;\n    }"] });
        return DateFloatingFilterComponent;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](DateFloatingFilterComponent, [{
            type: core.Component,
            args: [{
                    template: "\n    <div style=\"display:flex; width: 100%; height: 100%; flex-direction: row\">\n      <div style=\"flex: auto; width: 100%; overflow: hidden; display: flex; align-items: center; justify-content: left\">\n        <p-calendar *ngIf=\"this.params.type.key !== 'between'\"\n                    #calendar\n                    class=\"filter-calendar\"\n                    appendTo=\"body\"\n                    dateFormat=\"dd.mm.yy\"\n                    yearRange=\"2000:2030\"\n                    utcDate\n                    [(ngModel)]=\"calendarValue\"\n                    [showIcon]=\"true\"\n                    [monthNavigator]=\"true\"\n                    [yearNavigator]=\"true\"\n                    [showOnFocus]=\"false\"\n                    [showButtonBar]=\"true\"\n                    [ngStyle]=\"{width: '100%'}\"\n                    [style]=\"{width: '100%'}\"\n                    [inputStyle]=\"{border: 'none',color: '#3d60a1ff'}\"\n                    (onClose)=\"onCloseCalendar()\"\n                    (onSelect)=\"onSelectCalendar($event)\"\n                    (onClearClick)=\"onClearCalendar()\"\n                    (keypress)=\"onKeyPress($event)\"\n        ></p-calendar>\n        <p-calendar *ngIf=\"this.params.type.key === 'between'\"\n                    #calendar\n                    class=\"filter-calendar\"\n                    appendTo=\"body\"\n                    dateFormat=\"dd.mm.yy\"\n                    yearRange=\"2000:2030\"\n                    utcDate\n                    selectionMode=\"range\"\n                    [(ngModel)]=\"calendarValue\"\n                    [showIcon]=\"true\"\n                    [monthNavigator]=\"true\"\n                    [yearNavigator]=\"true\"\n                    [showOnFocus]=\"false\"\n                    [showButtonBar]=\"true\"\n                    [ngStyle]=\"{width: '100%'}\"\n                    [style]=\"{width: '100%'}\"\n                    [inputStyle]=\"{border: 'none',color: '#3d60a1ff'}\"\n                    (onClose)=\"onCloseCalendar()\"\n                    (onSelect)=\"onSelectCalendar($event)\"\n                    (onClearClick)=\"onClearCalendar()\"\n                    (keypress)=\"onKeyPress($event)\"\n                    (onFocus)=\"onRangeFocus()\"\n                    (onBlur)=\"onRangeBlur()\"\n        >\n        </p-calendar>\n      </div>\n      <button\n        class=\"filter-button\"\n        (click)=\"filterMenu.toggle($event)\"\n      >\n        {{ params.type.sign || this.types['between'].sign }}\n      </button>\n      <p-menu #filterMenu [popup]=\"true\" appendTo=\"body\">\n        <p-menu-item *ngFor=\"let type of this.types\"\n                     [label]=\"getFilterModesTitle(type)\"\n                     (command)=\"applyFilterMode(type.key)\"></p-menu-item>\n      </p-menu>\n    </div>\n  ",
                    styles: ["\n    .filter-button {\n      padding: 1px;\n      font-size: 10.5px;\n      width: 38px;\n      white-space: normal;\n      word-wrap: break-word;\n      line-height: 11px;\n      border: 0;\n      border-left: 1px solid #c8c8c8;\n      background-color: transparent;\n      color: #3d60a1;\n      flex: none;\n    }\n\n    .filter-button:hover {\n      background-color: #83b9ff;\n      cursor: pointer;\n    }\n\n    .filter-calendar ::ng-deep ::-webkit-input-placeholder {\n      color: #3d60a1ff;\n    }\n\n    .filter-calendar ::ng-deep ::-moz-placeholder {\n      color: #3d60a1ff;\n    }\n\n    .filter-calendar ::ng-deep :-moz-placeholder {\n      color: #3d60a1ff;\n    }\n\n    .filter-calendar ::ng-deep :-ms-input-placeholder {\n      color: #3d60a1ff;\n    }\n\n    .filter-calendar ::ng-deep .ui-datepicker-trigger {\n      border: none !important;\n      background: transparent !important;\n      color: #3d60a199;\n    }\n\n    .filter-calendar ::ng-deep .ui-datepicker-trigger:hover {\n      color: #3d60a1ff;\n    }\n\n    .filter-calendar ::ng-deep .ui-datepicker-trigger:active {\n      color: #3d60a1ff;\n    }\n  "]
                }]
        }], null, { calendar: [{
                type: core.ViewChild,
                args: ['calendar']
            }] }); })();

    var DateFilterComponent = /** @class */ (function () {
        function DateFilterComponent(local) {
            this.local = local;
        }
        DateFilterComponent.prototype.agInit = function (params) {
            this.params = params;
        };
        DateFilterComponent.prototype.doesFilterPass = function (params) {
            var _a, _b;
            var nodeDateUtc = (_a = this.params.valueGetter(params.node)) === null || _a === void 0 ? void 0 : _a.valueOf();
            if (!nodeDateUtc) {
                return false;
            }
            switch (this.params.type) {
                case 'gt': {
                    return nodeDateUtc > this.calendarValue.valueOf();
                }
                case 'goe': {
                    return nodeDateUtc >= this.calendarValue.valueOf();
                }
                case 'lt': {
                    return nodeDateUtc < this.calendarValue.valueOf();
                }
                case 'loe': {
                    return nodeDateUtc <= this.calendarValue.valueOf();
                }
                case 'between': {
                    return nodeDateUtc >= this.calendarValue[0].valueOf() && (nodeDateUtc <= (((_b = this.calendarValue[1]) === null || _b === void 0 ? void 0 : _b.valueOf()) || nodeDateUtc));
                }
                default: {
                    return nodeDateUtc === this.calendarValue.valueOf();
                }
            }
        };
        DateFilterComponent.prototype.getModel = function () {
            if (!this.calendarValue) {
                return null;
            }
            if (this.calendarValue instanceof Array) {
                if (this.params.type === 'between') {
                    return {
                        filter: this.calendarValue.map(function (date) {
                            if (date === null) {
                                return null;
                            }
                            return date.toJSON();
                        }).join(','),
                        type: this.params.type
                    };
                }
            }
            else {
                return { filter: this.calendarValue.toJSON(), type: this.params.type };
            }
        };
        DateFilterComponent.prototype.isFilterActive = function () {
            return !!this.calendarValue;
        };
        DateFilterComponent.prototype.setModel = function (model) {
            if (!model) {
                this.calendarValue = null;
            }
            else {
                this.params.type = model.type;
                this.calendarValue = model.filter;
            }
        };
        DateFilterComponent.prototype.onFloatingFilterChanged = function (type, calendarValue) {
            this.calendarValue = calendarValue;
            this.params.type = type;
            this.params.filterChangedCallback();
        };
        DateFilterComponent.ɵfac = function DateFilterComponent_Factory(t) { return new (t || DateFilterComponent)(core["ɵɵdirectiveInject"](core.LOCALE_ID)); };
        DateFilterComponent.ɵcmp = core["ɵɵdefineComponent"]({ type: DateFilterComponent, selectors: [["ng-component"]], decls: 0, vars: 0, template: function DateFilterComponent_Template(rf, ctx) { }, encapsulation: 2 });
        return DateFilterComponent;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](DateFilterComponent, [{
            type: core.Component,
            args: [{ template: "" }]
        }], function () { return [{ type: undefined, decorators: [{
                    type: core.Inject,
                    args: [core.LOCALE_ID]
                }] }]; }, null); })();

    var DistinctFilterService = /** @class */ (function () {
        function DistinctFilterService() {
        }
        Object.defineProperty(DistinctFilterService.prototype, "isEnabled", {
            get: function () { return true; },
            enumerable: true,
            configurable: true
        });
        return DistinctFilterService;
    }());

    var AgGridAutoGroupColumn = /** @class */ (function (_super) {
        __extends(AgGridAutoGroupColumn, _super);
        function AgGridAutoGroupColumn() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        AgGridAutoGroupColumn.ɵfac = function AgGridAutoGroupColumn_Factory(t) { return ɵAgGridAutoGroupColumn_BaseFactory(t || AgGridAutoGroupColumn); };
        AgGridAutoGroupColumn.ɵcmp = core["ɵɵdefineComponent"]({ type: AgGridAutoGroupColumn, selectors: [["ag-grid-auto-group-column"]], features: [core["ɵɵInheritDefinitionFeature"]], decls: 0, vars: 0, template: function AgGridAutoGroupColumn_Template(rf, ctx) { }, encapsulation: 2 });
        return AgGridAutoGroupColumn;
    }(agGridAngular.AgGridColumn));
    var ɵAgGridAutoGroupColumn_BaseFactory = core["ɵɵgetInheritedFactory"](AgGridAutoGroupColumn);
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](AgGridAutoGroupColumn, [{
            type: core.Component,
            args: [{
                    selector: 'ag-grid-auto-group-column',
                    template: ''
                }]
        }], null, null); })();
    var AgGridDirective = /** @class */ (function () {
        function AgGridDirective(grid) {
            this.grid = grid;
            this._loading = false;
        }
        AgGridDirective.prototype.ngAfterContentInit = function () {
            // commented  because autoGroupColumnDef -> go to table.html
            // this.grid.autoGroupColumnDef = this.column;
            this.loading = this._loading;
        };
        AgGridDirective.prototype.ngAfterViewInit = function () {
            this.loading = this._loading;
        };
        Object.defineProperty(AgGridDirective.prototype, "loading", {
            get: function () {
                return this._loading;
            },
            set: function (val) {
                this._loading = val;
                if (this.grid && this.grid.api) {
                    if (this._loading) {
                        this.grid.api.showLoadingOverlay();
                    }
                    else {
                        this.grid.api.hideOverlay();
                    }
                }
            },
            enumerable: true,
            configurable: true
        });
        AgGridDirective.ɵfac = function AgGridDirective_Factory(t) { return new (t || AgGridDirective)(core["ɵɵdirectiveInject"](agGridAngular.AgGridAngular)); };
        AgGridDirective.ɵdir = core["ɵɵdefineDirective"]({ type: AgGridDirective, selectors: [["ag-grid-angular"]], contentQueries: function AgGridDirective_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
                core["ɵɵcontentQuery"](dirIndex, AgGridAutoGroupColumn, true);
            } if (rf & 2) {
                var _t;
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.column = _t.first);
            } }, inputs: { loading: "loading" } });
        return AgGridDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](AgGridDirective, [{
            type: core.Directive,
            args: [{
                    selector: 'ag-grid-angular'
                }]
        }], function () { return [{ type: agGridAngular.AgGridAngular }]; }, { column: [{
                type: core.ContentChild,
                args: [AgGridAutoGroupColumn]
            }], loading: [{
                type: core.Input
            }] }); })();

    var AgGridColumnDirective = /** @class */ (function () {
        function AgGridColumnDirective(column) {
            var _this = this;
            var toColDef = column.toColDef.bind(column);
            column.toColDef = function () {
                var colDef = toColDef();
                colDef.col = _this.col;
                return colDef;
            };
        }
        AgGridColumnDirective.ɵfac = function AgGridColumnDirective_Factory(t) { return new (t || AgGridColumnDirective)(core["ɵɵdirectiveInject"](agGridAngular.AgGridColumn)); };
        AgGridColumnDirective.ɵdir = core["ɵɵdefineDirective"]({ type: AgGridColumnDirective, selectors: [["ag-grid-column"]], inputs: { col: "col" } });
        return AgGridColumnDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](AgGridColumnDirective, [{
            type: core.Directive,
            args: [{
                    selector: 'ag-grid-column'
                }]
        }], function () { return [{ type: agGridAngular.AgGridColumn }]; }, { col: [{
                type: core.Input
            }] }); })();

    var _c0$9 = function () { return ["asc", "desc"]; };
    var _c1$4 = function () { return ["generalMenuTab"]; };
    function Table2Component_ag_grid_column_4_ag_grid_column_1_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelement"](0, "ag-grid-column", 8);
    } if (rf & 2) {
        var col_r602 = ctx.$implicit;
        var ctx_r601 = core["ɵɵnextContext"](2);
        core["ɵɵproperty"]("col", col_r602)("field", col_r602.field)("type", col_r602.type)("headerName", col_r602.header)("headerComponent", col_r602.headerComponent)("headerComponentParams", col_r602.headerComponentParams)("hide", !col_r602.visible || !col_r602.available)("lockVisible", !col_r602.available)("resizable", true)("sortable", ctx_r601.defaultSortEnabled ? col_r602.sortAvailable : false)("width", col_r602.width)("minWidth", col_r602.minWidth)("maxWidth", col_r602.maxWidth)("flex", col_r602.flex)("pinned", col_r602.pinned)("suppressMenu", false)("sortingOrder", core["ɵɵpureFunction0"](46, _c0$9))("cellRenderer", ctx_r601.getCellRenderer(col_r602))("cellStyle", ctx_r601.cellStyle)("tooltipField", ctx_r601.getTooltipField(col_r602))("tooltipValueGetter", ctx_r601.getCellTooltip)("headerTooltip", col_r602.headerTooltip)("filter", ctx_r601.getFilter(col_r602))("filterParams", ctx_r601.getFilterParams(col_r602))("floatingFilterComponent", ctx_r601.getFloatingFilter(col_r602))("floatingFilterComponentParams", ctx_r601.getFloatingFilterParams(col_r602))("menuTabs", core["ɵɵpureFunction0"](47, _c1$4))("refData", col_r602.enum)("editable", col_r602.editable == undefined && (!!col_r602.cellEditor || !!col_r602.cellEditorSelector) || col_r602.editable != undefined && col_r602.editable)("valueGetter", col_r602.valueGetter)("valueFormatter", ctx_r601.getValueFormatter(col_r602))("comparator", ctx_r601.getComparator(col_r602))("valueSetter", col_r602.valueSetter)("cellEditor", col_r602.cellEditor)("cellEditorParams", col_r602.cellEditorParams)("cellEditorSelector", col_r602.cellEditorSelector)("rowSpan", col_r602.rowSpan)("cellClassRules", col_r602.cellClassRules)("enableRowGroup", col_r602.enableRowGroup)("rowGroup", col_r602.rowGroup)("rowGroupIndex", col_r602.rowGroupIndex)("enablePivot", col_r602.enablePivot)("enableValue", col_r602.enableValue)("pivot", col_r602.pivot)("pivotIndex", col_r602.pivotIndex)("aggFunc", col_r602.aggFunc);
    } }
    function Table2Component_ag_grid_column_4_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementStart"](0, "ag-grid-column", 6);
        core["ɵɵtemplate"](1, Table2Component_ag_grid_column_4_ag_grid_column_1_Template, 1, 48, "ag-grid-column", 7);
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var col_r600 = ctx.$implicit;
        var ctx_r598 = core["ɵɵnextContext"]();
        core["ɵɵproperty"]("col", col_r600)("field", col_r600.field)("type", col_r600.type)("headerName", col_r600.header)("headerComponent", col_r600.headerComponent)("headerComponentParams", col_r600.headerComponentParams)("hide", !col_r600.visible || !col_r600.available)("lockVisible", !col_r600.available || col_r600.lockPinned)("resizable", true)("sortable", ctx_r598.defaultSortEnabled ? col_r600.sortAvailable : false)("width", col_r600.width)("minWidth", col_r600.minWidth)("maxWidth", col_r600.maxWidth)("flex", col_r600.flex)("pinned", col_r600.pinned)("lockPinned", col_r600.lockPinned)("suppressMenu", false)("sortingOrder", core["ɵɵpureFunction0"](48, _c0$9))("cellRenderer", ctx_r598.getCellRenderer(col_r600))("cellStyle", ctx_r598.cellStyle)("tooltipField", ctx_r598.getTooltipField(col_r600))("tooltipValueGetter", ctx_r598.getCellTooltip)("headerTooltip", col_r600.headerTooltip)("filter", ctx_r598.getFilter(col_r600))("filterParams", ctx_r598.getFilterParams(col_r600))("floatingFilterComponent", ctx_r598.getFloatingFilter(col_r600))("floatingFilterComponentParams", ctx_r598.getFloatingFilterParams(col_r600))("menuTabs", core["ɵɵpureFunction0"](49, _c1$4))("refData", col_r600.enum)("editable", col_r600.editable == undefined && (!!col_r600.cellEditor || !!col_r600.cellEditorSelector) || col_r600.editable != undefined && col_r600.editable)("valueGetter", col_r600.valueGetter)("valueFormatter", ctx_r598.getValueFormatter(col_r600))("comparator", ctx_r598.getComparator(col_r600))("valueSetter", col_r600.valueSetter)("cellEditor", col_r600.cellEditor)("cellEditorParams", col_r600.cellEditorParams)("cellEditorSelector", col_r600.cellEditorSelector)("rowSpan", col_r600.rowSpan)("cellClassRules", col_r600.cellClassRules)("enableRowGroup", col_r600.enableRowGroup)("rowGroup", col_r600.rowGroup)("rowGroupIndex", col_r600.rowGroupIndex)("enablePivot", col_r600.enablePivot)("enableValue", col_r600.enableValue)("pivot", col_r600.pivot)("pivotIndex", col_r600.pivotIndex)("aggFunc", col_r600.aggFunc);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngForOf", col_r600.children);
    } }
    function Table2Component_div_5_Template(rf, ctx) { if (rf & 1) {
        var _r604 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "div", 9);
        core["ɵɵelementStart"](1, "a", 10);
        core["ɵɵlistener"]("click", function Table2Component_div_5_Template_a_click_1_listener($event) { core["ɵɵrestoreView"](_r604); var ctx_r603 = core["ɵɵnextContext"](); $event.preventDefault(); return ctx_r603.clearFilterAll(); });
        core["ɵɵelement"](2, "span", 11);
        core["ɵɵelementEnd"]();
        core["ɵɵelementStart"](3, "span", 12);
        core["ɵɵtext"](4);
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var ctx_r599 = core["ɵɵnextContext"]();
        core["ɵɵadvance"](3);
        core["ɵɵattribute"]("title", ctx_r599.filterString);
        core["ɵɵadvance"](1);
        core["ɵɵtextInterpolate1"]("\u0424\u0438\u043B\u044C\u0442\u0440: ", ctx_r599.filterString, "");
    } }
    var _c2$3 = function () { return ["columnsMenuTab", "generalMenuTab"]; };
    var columnTypeFilterMatchModes = {
        bool: ['equals', 'isNotNull', 'isNull'],
        date: ['equals', 'gt', 'goe', 'lt', 'loe', 'between'],
        dateTime: ['equals', 'gt', 'goe', 'lt', 'loe', 'between'],
        dateYear: ['equals', 'gt', 'goe', 'lt', 'loe', 'between'],
        sum: ['equals', 'gt', 'goe', 'lt', 'loe', 'between'],
        enum: ['equals', 'isNotNull', 'isNull'],
        group: ['equals', 'contains', 'startsWith', 'in', 'isNotNull', 'isNull'],
        custom: ['equals', 'contains', 'startsWith', 'in', 'isNotNull', 'isNull'],
        string: ['equals', 'contains', 'startsWith', 'in', 'isNotNull', 'isNull'],
        number: ['equals', 'gt', 'goe', 'lt', 'loe', 'in', 'between', 'isNotNull', 'isNull']
    };
    var localeColumnFilterModes = {
        equals: { title: 'равно', sign: '=' },
        contains: { title: 'содержит', sign: '..абв..' },
        startsWith: { title: 'начинается с', sign: 'абв..' },
        isNull: { title: 'не задано', sign: 'не задано' },
        isNotNull: { title: 'задано', sign: 'задано' },
        in: { title: 'одно из', sign: 'a,2,в' },
        gt: { title: 'больше', sign: '>' },
        goe: { title: 'больше или равно', sign: '>=' },
        lt: { title: 'меньше', sign: '<' },
        loe: { title: 'меньше или равно', sign: '<=' },
        between: { title: 'между', sign: '[n..m]' },
    };
    var getFilterModesTitle = function (localFilterMode) {
        return localFilterMode.sign + " (" + localFilterMode.title + ")";
    };
    var LazyLoadEvent = /** @class */ (function () {
        function LazyLoadEvent(options) {
            this.first = options.first;
            this.rows = options.rows;
            this.multiSortMeta = options.multiSortMeta;
            this.filters = options.filters;
            this.exportColumns = options.exportColumns;
            this.distinctColumn = options.distinctColumn;
            this.successCallback = options.successCallback;
            this.failCallback = options.failCallback;
            this.parentNode = options.parentNode;
            this.findRowQuery = options.findRowQuery;
        }
        Object.defineProperty(LazyLoadEvent.prototype, "pageQuery", {
            get: function () {
                return new PageQuery({
                    first: this.first,
                    rows: this.rows,
                    sorts: this.multiSortMeta,
                    filters: this.filters,
                    exportColumns: this.exportColumns,
                    distinctColumn: this.distinctColumn,
                    findRowQuery: this.findRowQuery
                });
            },
            enumerable: true,
            configurable: true
        });
        return LazyLoadEvent;
    }());
    var DataSource = /** @class */ (function () {
        function DataSource(table) {
            this.table = table;
        }
        DataSource.prototype.getRows = function (params) {
            var _this = this;
            var filters = {};
            for (var key in params.request.filterModel) {
                if (params.request.filterModel.hasOwnProperty(key)) {
                    filters[key] = { value: params.request.filterModel[key].filter, matchMode: params.request.filterModel[key].type };
                }
            }
            var event = new LazyLoadEvent({
                first: params.request.startRow,
                rows: params.request.endRow - params.request.startRow,
                multiSortMeta: params.request.sortModel.map(function (f) { return ({
                    field: f.colId,
                    order: f.sort === 'desc' ? -1 : f.sort === 'asc' ? 1 : 0
                }); }),
                filters: filters,
                parentNode: params.parentNode,
                successCallback: function (data, lastRow) {
                    var _a;
                    if (!!lastRow && ((_a = data) === null || _a === void 0 ? void 0 : _a.length) === 0) {
                        lastRow = 0;
                    }
                    params.successCallback(data, lastRow);
                    _this.table.restoreFocusIfNeeded();
                    if (_this.table.keepSelectionAfterFilter) {
                        _this.table.updateSelection();
                    }
                    _this.table.isLazyLoading = false;
                },
                failCallback: function () {
                    if (params.hasOwnProperty('failCallback')) {
                        params.failCallback();
                    }
                    _this.table.isLazyLoading = false;
                },
                exportColumns: params.context ? params.context.exportColumns : null,
                distinctColumn: params.context ? params.context.distinctColumn : null,
                findRowQuery: params.context ? params.context.findRowQuery : null
            });
            this.table.onLazyLoad.emit(event);
            this.table.isLazyLoading = true;
        };
        return DataSource;
    }());
    var Table2Component = /** @class */ (function () {
        function Table2Component(local, configService, renderer2, distinctFilterService, el) {
            var _this = this;
            this.local = local;
            this.configService = configService;
            this.renderer2 = renderer2;
            this.distinctFilterService = distinctFilterService;
            this.el = el;
            this.loadingSettings = false;
            this.saveFocus = false;
            this.calculateFontSize = FontSize__default;
            this.tooltipsIntervalIdsHash = new Map();
            this.prevFocusRowIndex = -1;
            this.subscriptions = [];
            this.isSummaryRowPicked = false;
            this.summaryColAggregateMap = new Map();
            this.allSummaryResultsMap = new Map();
            this.colIdsWithCalculatedSummary = [];
            this.disableSummaryRow = false;
            this.loading = false;
            this.lazy = false;
            this.deltaRowDataMode = false;
            this.selectionMode = 'single';
            this.suppressCellSelection = false;
            this.suppressRowTransform = false;
            this.checkboxSelection = false;
            this.defaultSortEnabled = true;
            this.defaultFilterEnabled = true;
            this.rowHeight = 32;
            this.headerHeight = 36;
            this.enableTooltips = true;
            this.contextMenuExtension = [];
            this.keepSelectionAfterFilter = false;
            this.cacheBlockSize = 100;
            this.maxBlocksInCache = 20;
            this.suppressRowClickSelection = null;
            this.embedFullWidthRows = true;
            this.masterDetail = false;
            this.wrapHeaderText = false;
            this.headerVerticalPadding = 15;
            this.pivotMode = false;
            this.suppressAggFuncInHeader = false;
            this.stopEditingWhenGridLosesFocus = true;
            this.selectionChange = new core.EventEmitter();
            this.rowDoubleClicked = new core.EventEmitter();
            this.cellClicked = new core.EventEmitter();
            this.cellDoubleClicked = new core.EventEmitter();
            this.onLazyLoad = new core.EventEmitter();
            this.onGetIndicatorStyle = new core.EventEmitter();
            this.onGetRowStyle = new core.EventEmitter();
            this.cellKeyDown = new core.EventEmitter();
            this.onDataSourceReady = new core.EventEmitter();
            this.modelUpdated = new core.EventEmitter();
            this.rowSelected = new core.EventEmitter();
            this.filterChanged = new core.EventEmitter();
            this.cellEditingStarted = new core.EventEmitter();
            this.filterString = '';
            this.focused = false;
            this.exporting = false;
            this.isLazyLoading = false;
            this.components = {
                agLoadingCellRenderer: LoadingCellRenderer
            };
            this.tableFrameworkComponents = {
                textFloatingFilter: TextFloatingFilterComponent,
                dropdownFilter: DropdownFilterComponent,
                dropdownFloatingFilter: DropdownFloatingFilterComponent,
                checkboxHeaderComponent: CheckboxHeaderComponent,
                triStateCheckboxHeaderComponent: TriStateCheckboxHeaderComponent,
                customDetailComponent: CustomDetailComponent,
                dateFilter: DateFilterComponent,
                dateFloatingFilter: DateFloatingFilterComponent
            };
            this.columnTypes = {
                'bool': {},
                'date': {},
                'dateTime': {},
                'dateYear': {},
                'sum': {},
                'enum': {},
                'group': {},
                'custom': {},
                'string': {},
                'number': {}
            };
            this.localeText = {
                filterOoo: 'Фильтр...',
                // enterprise menu
                pinColumn: 'Закрепить колонку',
                autosizeThiscolumn: 'Автоподбор ширины',
                autosizeAllColumns: 'Автоподбор ширины (все колонки)',
                resetColumns: 'Сбросить настройки',
                expandAll: 'Развернуть все',
                collapseAll: 'Свернуть все',
                // enterprise menu pinning
                pinLeft: 'Закрепить слева',
                pinRight: 'Закрепить справа',
                noPin: 'Открепить',
                valueAggregation: 'Агрегирующие функции',
                group: 'Группа',
                // standard menu
                copy: 'Копировать',
                copyWithHeaders: 'Копировать с заголовками',
                paste: 'Вставить',
                // other
                loadingOoo: 'Загрузка...'
            };
            this.autoGroupColumnDef = {
                cellRendererParams: {
                    suppressCount: false
                }
            };
            this.processRowPostCreate = function (params) {
                // отключение выделения свернутых нод с шифтом
                var node = params.node;
                var selectThisNode = node.selectThisNode.bind(node);
                node.selectThisNode = function (value) {
                    var oldSelectable = node.selectable;
                    if (value) {
                        var parent_1 = node.parent;
                        while (parent_1 != null && parent_1.level >= 0) {
                            if (!parent_1.expanded) {
                                node.selectable = false;
                                break;
                            }
                            parent_1 = parent_1.parent;
                        }
                    }
                    var res = selectThisNode(value);
                    node.selectable = oldSelectable;
                    return res;
                };
            };
            this.boolRenderer = function (e) {
                if (e.value == null) {
                    return '';
                }
                if (e.value) {
                    return '<i class="far fa-check-square"></i>';
                }
                return '<i class="far fa-square"></i>';
            };
            this.dateFormatter = function (e) {
                if (e.value == null) {
                    return '';
                }
                return new common.DatePipe(_this.local).transform(e.value, 'dd.MM.yyyy');
            };
            this.dateTimeFormatter = function (e) {
                if (e.value == null) {
                    return '';
                }
                return new common.DatePipe(_this.local).transform(e.value, 'dd.MM.yyyy HH:mm:ss');
            };
            this.dateYearFormatter = function (e) {
                if (e.value == null) {
                    return '';
                }
                return new common.DatePipe(_this.local).transform(e.value, 'yyyy');
            };
            this.sumFormatter = function (e) {
                if (e.value == null) {
                    return '';
                }
                return new SumPipe(_this.local).transform(e.value);
            };
            this.loadingCellRenderer = function (e) {
                return e.data ? '' : '<span class="fa fa-spinner fa-spin"></span>';
            };
            this.fullWidthCellRenderer = function (e) {
                if (!e.pinned && e.data.__deleted) {
                    return '<div style="margin: 5px">' + e.data.__deleted + '</div>';
                }
                return '';
            };
            this.indicatorStyle = function (params) {
                _this.onGetIndicatorStyle.emit(params);
                return Object.assign({ backgroundColor: '#fbfbfb', overflow: 'visible' }, params.style);
            };
            this.rowStyle = function (params) {
                _this.onGetRowStyle.emit(params);
                var style = Object.assign({}, params.style);
                if (params.node.rowIndex % 2 === 0) {
                    var bg = style.backgroundColor || style['background-color'];
                    if (bg) {
                        delete (style['background-color']);
                        style.backgroundColor = new Color(bg).clearer(0.2).rgbaString();
                    }
                }
                return style;
            };
            this.cellStyle = function (params) {
                params.colDef.col.onGetColumnStyle.emit(params);
                var style = {};
                if (params.colDef.type == 'bool') {
                    style = Object.assign(style, { 'text-align': 'center' });
                }
                else if (params.colDef.type == 'custom') {
                    style = Object.assign(style, params.colDef.col.customCellRendererStyle(params));
                }
                else if (params.colDef.type == 'sum' || params.colDef.type == 'number') {
                    style = Object.assign(style, { 'text-align': 'right' });
                }
                if (!!params.colDef.rowSpan) {
                    if (params.colDef.rowSpan({
                        node: params.node,
                        data: params.data,
                        colDef: params.colDef,
                        column: params['column'],
                        api: _this.gridApi,
                        columnApi: _this.columnApi,
                        context: params.context
                    }) > 1) {
                        style = Object.assign(style, {
                            'background-color': '#FFF',
                            'color': '#000',
                            'display': 'flex',
                            'flex-direction': 'column',
                            'justify-content': 'center',
                            'border-right': '1px solid #c8c8c8 !important',
                            'border-bottom': '1px solid #c8c8c8 !important'
                        });
                    }
                }
                style = Object.assign(style, params.style);
                return style;
            };
            this.isFullWidthCell = function (node) {
                return node.data && node.data.__deleted;
            };
            this.getCellTooltip = function (params) {
                if (_this.enableTooltips) {
                    return params.valueFormatted == null ? params.value : params.valueFormatted;
                }
            };
            this.getContextMenuItems = function (params) {
                var e_1, _a;
                var contextMenuExtensionWithSummaryRow = _this.contextMenuExtensionWithSummaryRow();
                var defaultItems = ['copy', 'copyWithHeaders', 'paste'];
                if (contextMenuExtensionWithSummaryRow && contextMenuExtensionWithSummaryRow.length > 0) {
                    defaultItems.push('separator');
                    var _loop_1 = function (menu) {
                        defaultItems.push({
                            name: menu.label,
                            icon: menu.icon ? "<span class=\"" + menu.icon + "\" style=\"height: auto\"></span>" : '',
                            disabled: menu.disabled,
                            subMenu: menu.items ? _this.getSubMenu(params, menu.items) : null,
                            action: function () { return menu.command(params.node); }
                        });
                    };
                    try {
                        for (var contextMenuExtensionWithSummaryRow_1 = __values(contextMenuExtensionWithSummaryRow), contextMenuExtensionWithSummaryRow_1_1 = contextMenuExtensionWithSummaryRow_1.next(); !contextMenuExtensionWithSummaryRow_1_1.done; contextMenuExtensionWithSummaryRow_1_1 = contextMenuExtensionWithSummaryRow_1.next()) {
                            var menu = contextMenuExtensionWithSummaryRow_1_1.value;
                            _loop_1(menu);
                        }
                    }
                    catch (e_1_1) { e_1 = { error: e_1_1 }; }
                    finally {
                        try {
                            if (contextMenuExtensionWithSummaryRow_1_1 && !contextMenuExtensionWithSummaryRow_1_1.done && (_a = contextMenuExtensionWithSummaryRow_1.return)) _a.call(contextMenuExtensionWithSummaryRow_1);
                        }
                        finally { if (e_1) throw e_1.error; }
                    }
                }
                return defaultItems;
            };
            this.getSubMenu = function (params, menuItems) {
                var e_2, _a;
                var subItems = [];
                var _loop_2 = function (menu) {
                    subItems.push({
                        name: menu.label,
                        icon: menu.icon ? "<span class=\"" + menu.icon + "\" style=\"height: auto\"></span>" : '',
                        disabled: menu.disabled,
                        subMenu: menu.items ? _this.getSubMenu(params, menu.items) : null,
                        action: function () {
                            menu.command ? menu.command(params.node) : null;
                        }
                    });
                };
                try {
                    for (var menuItems_1 = __values(menuItems), menuItems_1_1 = menuItems_1.next(); !menuItems_1_1.done; menuItems_1_1 = menuItems_1.next()) {
                        var menu = menuItems_1_1.value;
                        _loop_2(menu);
                    }
                }
                catch (e_2_1) { e_2 = { error: e_2_1 }; }
                finally {
                    try {
                        if (menuItems_1_1 && !menuItems_1_1.done && (_a = menuItems_1.return)) _a.call(menuItems_1);
                    }
                    finally { if (e_2) throw e_2.error; }
                }
                return subItems;
            };
            this.getMainMenuItems = function (params) {
                var _a, _b;
                var defaultItems = params.defaultItems;
                var a = defaultItems[0];
                defaultItems[params.defaultItems.indexOf('resetColumns')] = {
                    name: 'Сбросить настройки',
                    action: function () {
                        params.columnApi.setColumnState(_this.initialSate);
                        localStorage.removeItem(_this.getSettingsStorageKey());
                    }
                };
                if (params.column.getColId() === '0') {
                    return params.defaultItems.filter(function (i) { return i !== 'autoSizeThis'; });
                }
                else {
                    defaultItems.unshift('separator');
                    defaultItems.unshift({
                        name: 'Очистить фильтр',
                        disabled: !_this.defaultFilterEnabled || params.column.getColDef().filter === false,
                        icon: '<span class="ag-icon ag-icon-cross"></span>',
                        action: function () {
                            var filterComponent = params.api.getFilterInstance(params.column.getColId());
                            filterComponent.setModel(null);
                            params.api.onFilterChanged();
                        }
                    });
                    if (_this.distinctFilterService.isEnabled) {
                        defaultItems.unshift({
                            name: 'Фильтр (подбор значений из колонки)',
                            disabled: _this.defaultFilterEnabled ?
                                params.column.getColDef().filter === false
                                    || params.column.getColDef().type == 'date'
                                    || params.column.getColDef().type == 'dateTime'
                                    || params.column.getColDef().type == 'dateYear'
                                    || params.column.getColDef().type == 'bool'
                                    || params.column.getColDef().type == 'custom'
                                    || _this.lazy === false
                                : true,
                            icon: '<span class="ag-icon ag-icon-filter"></span>',
                            action: function () {
                                _this.distinctFilterService.showFilterDialog(params.api, params.column);
                            }
                        });
                    }
                    defaultItems.push('separator');
                    defaultItems.push({
                        name: 'По возрастанию',
                        icon: '<span class="ag-icon ag-icon-asc"></span>',
                        disabled: !params.column.getColDef().sortable,
                        action: function () {
                            var model = params.api.getSortModel();
                            params.api.setSortModel(model.concat([{ colId: params.column.getColId(), sort: 'asc' }]));
                        }
                    });
                    defaultItems.push({
                        name: 'По убыванию',
                        icon: '<span class="ag-icon ag-icon-desc"></span>',
                        disabled: !params.column.getColDef().sortable,
                        action: function () {
                            var model = params.api.getSortModel();
                            params.api.setSortModel(model.concat([{ colId: params.column.getColId(), sort: 'desc' }]));
                        }
                    });
                    defaultItems.push({
                        name: 'Очистить сортировку',
                        icon: '<span class="ag-icon ag-icon-cross"></span>',
                        disabled: !_this.defaultSortEnabled || ((_b = (_a = _this.defaultSortModel) === null || _a === void 0 ? void 0 : _a.find(function (s) { return s.field == params.column.getColId(); })) === null || _b === void 0 ? void 0 : _b.fixed),
                        action: function () {
                            var model = params.api.getSortModel();
                            var newModel = model.filter(function (s) { return s.colId !== params.column.getColId(); });
                            if (newModel.length === 0 && _this.defaultSortModel) {
                                _this.setDefaultSortModel();
                            }
                            else {
                                params.api.setSortModel(newModel);
                            }
                        }
                    });
                    return params.defaultItems;
                }
            };
            this.navigateToNextCell = function (params) {
                var previousCell = params.previousCellPosition;
                var suggestedNextCell = params.nextCellPosition;
                var KEY_UP = 38;
                var KEY_DOWN = 40;
                var KEY_LEFT = 37;
                var KEY_RIGHT = 39;
                switch (params.key) {
                    case KEY_DOWN:
                        if (previousCell.rowIndex + 1 < _this.gridApi.getModel().getRowCount()) {
                            if (!_this.checkboxSelection) {
                                if (!params.event.shiftKey) {
                                    _this.gridApi.deselectAll();
                                }
                                previousCell = params.previousCellPosition;
                                // set selected cell on current cell + 1
                                _this.gridApi.forEachNode(function (node) {
                                    if (previousCell.rowIndex + 1 === node.rowIndex) {
                                        node.setSelected(true);
                                    }
                                });
                            }
                        }
                        return suggestedNextCell;
                    case KEY_UP:
                        if (previousCell.rowIndex - 1 >= 0) {
                            if (!_this.checkboxSelection) {
                                if (!params.event.shiftKey) {
                                    _this.gridApi.deselectAll();
                                }
                                previousCell = params.previousCellPosition;
                                // set selected cell on current cell - 1
                                _this.gridApi.forEachNode(function (node) {
                                    if (previousCell.rowIndex - 1 === node.rowIndex) {
                                        node.setSelected(true);
                                    }
                                });
                            }
                        }
                        return suggestedNextCell;
                    case KEY_LEFT:
                    case KEY_RIGHT:
                        return suggestedNextCell;
                    default:
                        throw new Error('this will never happen, navigation is always on of the 4 keys above');
                }
            };
        }
        Object.defineProperty(Table2Component.prototype, "showGroupsCount", {
            get: function () {
                return !this.autoGroupColumnDef.cellRendererParams.suppressCount;
            },
            set: function (value) {
                this.autoGroupColumnDef.cellRendererParams.suppressCount = !value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Table2Component.prototype, "availableColumns", {
            get: function () {
                return this.settingsKey ? this.columns.filter(function (c) { return c.available; }) : this.columns;
            },
            enumerable: true,
            configurable: true
        });
        Table2Component.prototype.ngOnInit = function () {
            var _this = this;
            if (this.el.nativeElement.addEventListener) {
                this.el.nativeElement.addEventListener('focus', function (e) {
                    _this.focused = e.target.className.indexOf('ag-cell') >= 0;
                }, true);
                this.el.nativeElement.addEventListener('blur', function (e) {
                    _this.focused = false;
                }, true);
            }
            if (this.frameworkComponents) {
                this.tableFrameworkComponents = __assign(__assign({}, this.tableFrameworkComponents), this.frameworkComponents);
            }
        };
        Table2Component.prototype.ngOnDestroy = function () {
            var e_3, _a;
            this.gridApi = null;
            try {
                for (var _b = __values(this.subscriptions), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var sub = _c.value;
                    sub.unsubscribe();
                }
            }
            catch (e_3_1) { e_3 = { error: e_3_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_3) throw e_3.error; }
            }
        };
        Table2Component.prototype.ngAfterContentInit = function () {
            var e_4, _a;
            var _this = this;
            this.columns = this.cols.toArray();
            var _loop_3 = function (col) {
                var sub = col.layoutChange.subscribe(function () {
                    if (_this.gridApi && !_this.settingsKey) {
                        _this.columnApi.getAllColumns()
                            .filter(function (c) { return c.getColDef().col === col; })
                            .forEach(function (c) {
                            c.getColDef().lockVisible = !col.available;
                            _this.columnApi.setColumnVisible(c, col.visible && col.available);
                        });
                    }
                });
                this_1.subscriptions.push(sub);
                sub = col.headerChange.subscribe(function () {
                    if (_this.gridApi) {
                        _this.columnApi.getAllColumns()
                            .filter(function (c) { return c.getColDef().col === col; })
                            .forEach(function (c) {
                            c.getColDef().headerName = col.header;
                        });
                        _this.gridApi.refreshHeader();
                    }
                });
                this_1.subscriptions.push(sub);
            };
            var this_1 = this;
            try {
                for (var _b = __values(this.columns), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var col = _c.value;
                    _loop_3(col);
                }
            }
            catch (e_4_1) { e_4 = { error: e_4_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_4) throw e_4.error; }
            }
        };
        Table2Component.prototype.ngOnChanges = function (changes) {
            var _this = this;
            if (changes['selection']) {
                setTimeout(function () { return _this.updateSelection(); });
            }
            else if (changes['filter']) {
                setTimeout(function () { return _this.gridApi && _this.gridApi.refreshHeader(); });
            }
            else if (changes['settingsKey']) {
                setTimeout(function () { return _this.reloadColumns(); });
            }
        };
        Table2Component.prototype.onRowSelected = function (event) {
            this.rowSelected.emit(event);
        };
        Table2Component.prototype.onGridReady = function (params) {
            this.gridApi = params.api;
            this.columnApi = params.columnApi;
            this.initialSate = this.columnApi.getColumnState();
            this.loadSettings();
            this.updateSelection();
            this.setDefaultSortModel();
            if (this.lazy) {
                this.gridApi.setServerSideDatasource(new DataSource(this));
            }
            this.gridApi.setPopupParent(document.body);
            this.updateAllTooltips();
            if (this.wrapHeaderText) {
                this.makeHeaderTextMultiline();
                this.resizeHeader(this.headerVerticalPadding);
            }
            this.onDataSourceReady.emit(this.gridApi);
            (!this.lazy && !this.disableSummaryRow) ? this.generateContextMenuForSummary() : null;
        };
        Table2Component.prototype.reload = function (restoreFocus) {
            if (restoreFocus === void 0) { restoreFocus = false; }
            if (this.gridApi) {
                this.gridApi.purgeServerSideCache([]);
                this.saveFocus = restoreFocus;
                if (!restoreFocus) {
                    this.gridApi.deselectAll();
                }
            }
        };
        Table2Component.prototype.reloadGroup = function (route) {
            this.gridApi.purgeServerSideCache(route);
        };
        Table2Component.prototype.reloadColumns = function () {
            if (this.gridApi && this.grid && this.grid.columns) {
                var filterModel = this.gridApi.getFilterModel();
                var sortModel = this.gridApi.getSortModel();
                this.gridApi.setColumnDefs([]);
                this.gridApi.setColumnDefs(this.grid.columns.map(function (c) { return c.toColDef(); }));
                this.initialSate = this.columnApi.getColumnState();
                this.loadSettings();
                this.gridApi.setFilterModel(filterModel);
                this.gridApi.setSortModel(sortModel);
                this.updateAllTooltips();
            }
        };
        Table2Component.prototype.exportToExcel = function (exportedColumns, customFilter, customSort) {
            var _this = this;
            if (this.lazy) {
                if (!this.exporting) {
                    this.exporting = true;
                    var cols = this.columnApi.getAllGridColumns()
                        .filter(function (c) { return c.getColDef().field && (exportedColumns ? exportedColumns.includes(c.getColDef().field) : c.isVisible()); })
                        .map(function (c) { return ({
                        header: c.getColDef().headerName,
                        field: c.getColDef().field,
                        type: c.getColDef().type,
                        enum: c.getColDef().refData,
                        width: c.getActualWidth()
                    }); });
                    var ds = this.gridApi.getModel().datasource;
                    var params = {
                        request: {
                            startRow: 0,
                            endRow: 10000,
                            sortModel: (customSort ? customSort : this.gridApi.getSortModel()),
                            filterModel: (customFilter ? customFilter : this.gridApi.getFilterModel()),
                            rowGroupCols: [],
                            valueCols: [],
                            pivotCols: [],
                            pivotMode: false,
                            groupKeys: []
                        },
                        successCallback: function () {
                            console.log('exported');
                            _this.exporting = false;
                        },
                        failCallback: function () {
                            console.log('export fail');
                            _this.exporting = false;
                        },
                        parentNode: null,
                        context: { exportColumns: cols }
                    };
                    ds.getRows(params);
                }
            }
            else {
                this.gridApi.exportDataAsExcel({
                    fileName: 'export.xlsx',
                    exportMode: 'xlsx',
                    processCellCallback: function (e) {
                        if (e.column.getColDef().type == 'bool') {
                            return e.value == null ? '' : e.value ? '1' : '0';
                        }
                        else if (e.column.getColDef().type == 'enum') {
                            return e.value
                                ? (e.column.getColDef().refData && e.column.getColDef().refData[e.value]
                                    ? e.column.getColDef().refData[e.value]
                                    : ('[' + e.value + ']'))
                                : '';
                        }
                        else if (e.column.getColDef().valueFormatter) {
                            var valueFormatterService = e.api.rowRenderer.beans.valueFormatterService;
                            return valueFormatterService.formatValue(e.column, e.node, null, e.value);
                        }
                        return e.value;
                    }
                });
            }
        };
        Table2Component.prototype.addRow = function (rowData) {
            this.addRowInternal(rowData);
        };
        Table2Component.prototype.addRowInternal = function (rowData, attempt) {
            var _this = this;
            if (attempt === void 0) { attempt = 0; }
            var _a;
            var rowCount = this.gridApi.serverSideRowModel.rootNode
                .childrenCache.getVirtualRowCount();
            if (rowCount > 0) {
                this.gridApi.ensureIndexVisible(rowCount - 1);
            }
            var lastPageLoaded = false;
            if (rowCount == 0 || ((_a = this.gridApi.getDisplayedRowAtIndex(rowCount - 1)) === null || _a === void 0 ? void 0 : _a.data)) {
                lastPageLoaded = true;
            }
            if (!lastPageLoaded) {
                if (attempt < 50) {
                    setTimeout(function () {
                        _this.addRowInternal(rowData, attempt + 1);
                    }, 100);
                }
                return;
            }
            this.gridApi.serverSideRowModel.rootNode.childrenCache
                .setVirtualRowCount(rowCount + 1);
            this.gridApi.getDisplayedRowAtIndex(rowCount)
                .setDataAndId(rowData, (rowCount).toString());
            var node = this.gridApi.getDisplayedRowAtIndex(rowCount);
            node.setSelected(true, true);
            this.gridApi.ensureIndexVisible(rowCount);
        };
        Table2Component.prototype.updateRow = function (oldData, newData) {
            var _this = this;
            this.gridApi.forEachNode(function (node) {
                if (node.data == oldData) {
                    node.setData(newData);
                    _this.gridApi.ensureNodeVisible(node);
                }
            });
        };
        Table2Component.prototype.updateRows = function (rows) {
            var e_5, _a;
            var nodes = [];
            try {
                for (var rows_1 = __values(rows), rows_1_1 = rows_1.next(); !rows_1_1.done; rows_1_1 = rows_1.next()) {
                    var row = rows_1_1.value;
                    var id = this.getRowId(row);
                    var node = this.gridApi.getRowNode(id);
                    if (node) {
                        node.setData(row);
                        nodes.push(node);
                    }
                }
            }
            catch (e_5_1) { e_5 = { error: e_5_1 }; }
            finally {
                try {
                    if (rows_1_1 && !rows_1_1.done && (_a = rows_1.return)) _a.call(rows_1);
                }
                finally { if (e_5) throw e_5.error; }
            }
            if (nodes.length > 0) {
                this.gridApi.ensureIndexVisible(nodes[0].rowIndex);
                this.gridApi.refreshCells({ rowNodes: nodes, force: true });
            }
        };
        Table2Component.prototype.removeRows = function (rows, message) {
            var e_6, _a;
            var nodes = [];
            var _loop_4 = function (row) {
                this_2.gridApi.forEachNode(function (node) {
                    if (node.data == row) {
                        node.data.__deleted = message;
                        node.setRowSelectable(false);
                        nodes.push(node);
                    }
                });
            };
            var this_2 = this;
            try {
                for (var rows_2 = __values(rows), rows_2_1 = rows_2.next(); !rows_2_1.done; rows_2_1 = rows_2.next()) {
                    var row = rows_2_1.value;
                    _loop_4(row);
                }
            }
            catch (e_6_1) { e_6 = { error: e_6_1 }; }
            finally {
                try {
                    if (rows_2_1 && !rows_2_1.done && (_a = rows_2.return)) _a.call(rows_2);
                }
                finally { if (e_6) throw e_6.error; }
            }
            this.gridApi.redrawRows({
                rowNodes: nodes
            });
            // this.gridApi.purgeServerSideCache([]);
        };
        Table2Component.prototype.removeRowsById = function (ids, message) {
            var e_7, _a;
            var nodes = [];
            try {
                for (var ids_1 = __values(ids), ids_1_1 = ids_1.next(); !ids_1_1.done; ids_1_1 = ids_1.next()) {
                    var id = ids_1_1.value;
                    var node = this.gridApi.getRowNode(id);
                    if (node) {
                        node.data.__deleted = message;
                        node.setRowSelectable(false);
                        nodes.push(node);
                    }
                }
            }
            catch (e_7_1) { e_7 = { error: e_7_1 }; }
            finally {
                try {
                    if (ids_1_1 && !ids_1_1.done && (_a = ids_1.return)) _a.call(ids_1);
                }
                finally { if (e_7) throw e_7.error; }
            }
            this.gridApi.redrawRows({
                rowNodes: nodes
            });
            // this.gridApi.purgeServerSideCache([]);
        };
        Table2Component.prototype.scrollToTop = function () {
            this.gridApi.ensureIndexVisible(0, 'top');
        };
        Table2Component.prototype.setFilterModel = function (model) {
            this.gridApi.setFilterModel(model);
        };
        Table2Component.prototype.addNewRowFilter = function (field, value, rowData) {
            if (rowData === void 0) { rowData = null; }
            var model = this.gridApi.getFilterModel();
            var filter = value;
            if (model && model[field] && model[field].type == 'in') {
                filter = model[field].filter + ',' + filter;
            }
            model = {};
            model[field] = { filter: filter, type: 'in' };
            this.keepSelection = true;
            this.gridApi.setFilterModel(model);
            if (rowData) {
                this.gridApi.updateRowData({
                    add: [rowData],
                    addIndex: 0
                });
                this.gridApi.forEachNode(function (node) {
                    if (node.rowIndex == 0) {
                        node.setSelected(true, true);
                    }
                });
            }
        };
        Table2Component.prototype.findAndSelectRow = function (field, value) {
            return __awaiter(this, void 0, void 0, function () {
                var _this = this;
                return __generator(this, function (_a) {
                    return [2 /*return*/, new Promise(function (resolve, reject) { return __awaiter(_this, void 0, void 0, function () {
                            var ds, params;
                            var _this = this;
                            return __generator(this, function (_a) {
                                ds = this.gridApi.getModel().datasource;
                                params = {
                                    request: {
                                        startRow: 0,
                                        endRow: 1,
                                        sortModel: this.gridApi.getSortModel(),
                                        filterModel: this.gridApi.getFilterModel(),
                                        rowGroupCols: [],
                                        valueCols: [],
                                        pivotCols: [],
                                        pivotMode: false,
                                        groupKeys: []
                                    },
                                    successCallback: function (res, rowIndex) {
                                        if (rowIndex >= 0) {
                                            var rowCount = _this.gridApi.serverSideRowModel.rootNode.childrenCache
                                                .getVirtualRowCount();
                                            if (rowIndex + 1 > rowCount) {
                                                rowCount = rowIndex + 1;
                                            }
                                            var initialRowCount = _this.gridApi.serverSideRowModel.rootNode.childrenCache
                                                .cacheParams.initialRowCount;
                                            _this.gridApi.serverSideRowModel.rootNode.childrenCache
                                                .cacheParams.initialRowCount = rowCount;
                                            _this.gridApi.purgeServerSideCache();
                                            _this.gridApi.serverSideRowModel.rootNode.childrenCache
                                                .cacheParams.initialRowCount = initialRowCount;
                                            _this.gridApi.ensureIndexVisible(rowIndex, 'middle');
                                            var sub_1 = _this.modelUpdated.subscribe(function (e) {
                                                _this.gridApi.ensureIndexVisible(rowIndex, 'middle');
                                                var node = _this.gridApi.getDisplayedRowAtIndex(rowIndex);
                                                if (node) {
                                                    if (node.data) {
                                                        if (node.data[field] === value) {
                                                            sub_1.unsubscribe();
                                                            node.setSelected(true, true);
                                                            resolve(true);
                                                        }
                                                        else {
                                                            var checkedRows = 0;
                                                            for (var i = -50; i <= 50; i++) {
                                                                var node2 = _this.gridApi.getDisplayedRowAtIndex(rowIndex + i);
                                                                if (!node2 || node2.data) {
                                                                    checkedRows++;
                                                                }
                                                                if (node2 && node2.data && node2.data[field] === value) {
                                                                    sub_1.unsubscribe();
                                                                    node2.setSelected(true, true);
                                                                    _this.gridApi.ensureIndexVisible(rowIndex + i, 'middle');
                                                                    resolve(true);
                                                                    break;
                                                                }
                                                            }
                                                            if (checkedRows === 21) {
                                                                sub_1.unsubscribe();
                                                                resolve(false);
                                                            }
                                                        }
                                                    }
                                                }
                                                else {
                                                    sub_1.unsubscribe();
                                                    resolve(false);
                                                }
                                            });
                                        }
                                        else {
                                            _this.gridApi.purgeServerSideCache();
                                            resolve(false);
                                        }
                                    },
                                    failCallback: function () {
                                        reject();
                                    },
                                    parentNode: null,
                                    context: { findRowQuery: field + ' = ' + value }
                                };
                                ds.getRows(params);
                                return [2 /*return*/];
                            });
                        }); })];
                });
            });
        };
        Table2Component.prototype.onSelectionChanged = function (e) {
            var selectedRows = this.gridApi.getSelectedRows()
                .filter(function (r) { return !r.__deleted; });
            var changed = false;
            if (this.selectionMode === 'single') {
                var selection = selectedRows.length > 0 ? selectedRows[0] : null;
                if (this.selection != selection) {
                    changed = true;
                    this.selection = selection;
                }
            }
            else {
                var selection = this.selection == null ? [] : this.selection;
                if (selection.length != selectedRows.length) {
                    changed = true;
                }
                else {
                    for (var i = 0; i < selection.length; i++) {
                        if (selection[i] != selectedRows[i]) {
                            changed = true;
                            break;
                        }
                    }
                }
                if (changed) {
                    this.selection = selectedRows;
                }
            }
            if (changed) {
                this.selectionChange.emit(this.selection);
            }
        };
        Table2Component.prototype.onCellClicked = function (event) {
            if (this.lazy
                && this.getServerSideGroupKey
                && event.node
                && (event.node.level == 0
                    || (this.selectionMode == 'multiple' && event.event.shiftKey))) {
                if (this.selectionMode == 'single') {
                    event.node.setSelected(true, true);
                }
                else if (this.selectionMode == 'multiple') {
                    if (event.event.shiftKey && this.prevFocusRowIndex >= 0) {
                        var startIndex_1 = this.prevFocusRowIndex;
                        var endIndex_1 = event.node.rowIndex;
                        if (startIndex_1 > endIndex_1) {
                            endIndex_1 = startIndex_1;
                            startIndex_1 = event.node.rowIndex;
                        }
                        this.gridApi.forEachNode(function (n) {
                            if (n.rowIndex >= startIndex_1 && n.rowIndex <= endIndex_1) {
                                n.setSelected(true, false);
                            }
                        });
                    }
                    else if (event.event.ctrlKey) {
                        event.node.setSelected(!event.node.isSelected(), false);
                    }
                    else {
                        event.node.setSelected(true, true);
                    }
                }
            }
            this.cellClicked.emit(event);
        };
        Table2Component.prototype.onCellDoubleClicked = function (event) {
            this.cellDoubleClicked.emit(event);
        };
        Table2Component.prototype.onCellEditingStarted = function (event) {
            this.cellEditingStarted.emit(event);
        };
        Table2Component.prototype.updateSelection = function () {
            var _this = this;
            var _a;
            if (this.gridApi) {
                this.prevFocusRowIndex = (_a = this.gridApi.getFocusedCell()) === null || _a === void 0 ? void 0 : _a.rowIndex;
                var hasSelection_1 = this.selection && (this.selectionMode === 'single' || this.selection.length > 0);
                this.gridApi.forEachNode(function (node) {
                    if (node.data) {
                        if (_this.selectionMode === 'single') {
                            if (_this.getRowId) {
                                node.setSelected(hasSelection_1 && _this.getRowId(_this.selection) == _this.getRowId(node.data));
                            }
                            else {
                                node.setSelected(hasSelection_1 && _this.selection === node.data);
                            }
                        }
                        else {
                            if (_this.getRowId) {
                                node.setSelected(hasSelection_1
                                    && _this.selection.map(function (v) { return v && _this.getRowId(v).toString(); })
                                        .indexOf(_this.getRowId(node.data).toString()) >= 0);
                            }
                            else {
                                node.setSelected(hasSelection_1 && _this.selection.indexOf(node.data) >= 0);
                            }
                        }
                    }
                });
            }
        };
        Table2Component.prototype.onColumnMoved = function () {
            if (!this.loadingSettings) {
                this.saveSettings();
            }
        };
        Table2Component.prototype.onColumnResized = function (event) {
            this.updateColumnTooltip(event.column);
            if (!this.loadingSettings) {
                this.saveSettings();
            }
            if (this.wrapHeaderText) {
                this.resizeHeaderWithDebounce(this.headerVerticalPadding);
            }
        };
        Table2Component.prototype.displayedColumnsWidthChanged = function (event) {
            console.log('displayedColumnsWidthChanged', event, Math.random());
        };
        Table2Component.prototype.onColumnVisible = function () {
            if (!this.loadingSettings) {
                this.saveSettings();
            }
        };
        Table2Component.prototype.onColumnPinned = function () {
            if (!this.loadingSettings) {
                this.saveSettings();
            }
            if (this.wrapHeaderText) {
                this.makeHeaderTextMultiline();
                this.resizeHeader(this.headerVerticalPadding);
            }
        };
        Table2Component.prototype.onBodyScroll = function (event) {
            if (event.direction === 'horizontal' && this.wrapHeaderText) {
                this.makeHeaderTextMultiline();
                this.resizeHeaderWithDebounce(this.headerVerticalPadding);
            }
        };
        Table2Component.prototype.onFilterChanged = function () {
            if (this.keepSelectionAfterFilter) {
            }
            else if (this.keepSelection) {
                this.keepSelection = false;
            }
            else {
                this.gridApi.deselectAll();
            }
            var filters = {};
            var filterModel = this.gridApi.getFilterModel();
            if (filterModel) {
                for (var key in filterModel) {
                    if (filterModel.hasOwnProperty(key)) {
                        filters[key] = { value: filterModel[key].filter, matchMode: filterModel[key].type };
                    }
                }
            }
            var filterString = '';
            var _loop_5 = function (prop) {
                if (filters.hasOwnProperty(prop)) {
                    if (filterString) {
                        filterString += ' и ';
                    }
                    filterString +=
                        "'" + this_3.getColumnHeader(prop) + "' " + getFilterModesTitle(localeColumnFilterModes[filters[prop].matchMode]);
                    var mode = filters[prop].matchMode;
                    var withValue = mode != 'isNull' && mode != 'isNotNull';
                    if (withValue) {
                        var enumFilter = this_3.columnApi.getColumn(prop).getColDef().filterParams.enum;
                        var filtersPropValue_1 = filters[prop].value;
                        var colType = this_3.columnApi.getColumn(prop).getColDef().type;
                        if (colType === 'date' || colType === 'dateTime' || colType === 'dateYear') {
                            var arr = filtersPropValue_1.split(',');
                            filtersPropValue_1 = arr.map(function (item) { return new Date(item).toLocaleDateString().replace('Invalid Date', '...'); }).join(' - ');
                        }
                        filterString += enumFilter ? " '" + (enumFilter.find(function (f) { return f.value == filtersPropValue_1; }) ?
                            enumFilter.find(function (f) { return f.value == filtersPropValue_1; }).label : "" + filtersPropValue_1) + "'" : " '" + filtersPropValue_1 + "'";
                    }
                }
            };
            var this_3 = this;
            for (var prop in filters) {
                _loop_5(prop);
            }
            this.filterString = filterString;
            this.filterChanged.emit();
        };
        Table2Component.prototype.onCellValueChanged = function (e) {
            var col = e.colDef.col;
            col.cellValueChanged.emit(e);
        };
        Table2Component.prototype.onKeyDown = function (event) {
            if (this.focused) {
                this.cellKeyDown.emit(event);
            }
        };
        Table2Component.prototype.onModelUpdated = function (event) {
            this.modelUpdated.emit(event);
            this.isSummaryRowPicked ? !this.lazy ? this.getSummaryRow() : null : null;
        };
        Table2Component.prototype.onSortChanged = function (event) {
            var e_8, _a;
            var currentModel = event.api.getSortModel();
            var fixedSorts = this.defaultSortModel ? this.defaultSortModel.filter(function (s) { return s.fixed; }) : [];
            var unusedFixedSorts = [];
            var _loop_6 = function (sort) {
                if (!event.api.getSortModel().find(function (s) { return s.colId == sort.field; })) {
                    unusedFixedSorts.push(this_4.mapSortMetaToGridSortModel(sort));
                }
            };
            var this_4 = this;
            try {
                for (var fixedSorts_1 = __values(fixedSorts), fixedSorts_1_1 = fixedSorts_1.next(); !fixedSorts_1_1.done; fixedSorts_1_1 = fixedSorts_1.next()) {
                    var sort = fixedSorts_1_1.value;
                    _loop_6(sort);
                }
            }
            catch (e_8_1) { e_8 = { error: e_8_1 }; }
            finally {
                try {
                    if (fixedSorts_1_1 && !fixedSorts_1_1.done && (_a = fixedSorts_1.return)) _a.call(fixedSorts_1);
                }
                finally { if (e_8) throw e_8.error; }
            }
            if (unusedFixedSorts.length > 0) {
                event.api.setSortModel(unusedFixedSorts.concat(currentModel));
            }
        };
        Table2Component.prototype.getColumnHeader = function (colId) {
            return this.columnApi.getColumn(colId).getColDef().headerName;
        };
        Table2Component.prototype.getColumnTooltip = function (col) {
            var cellCpacings = 50;
            if (!this.enableTooltips) {
                return null;
            }
            if (col.getUserProvidedColDef().headerTooltip) {
                return col.getUserProvidedColDef().headerTooltip;
            }
            var width = this.calculateFontSize(col.getColDef().headerName, { font: 'Tahoma', fontSize: '12pt' }).width + cellCpacings;
            var result = col.getActualWidth() <= width ? col.getColDef().headerName : null;
            // console.log(col.getActualWidth(), width, col.getColDef().headerName, result);
            return result;
        };
        Table2Component.prototype.updateColumnTooltip = function (column) {
            var _this = this;
            if (this.tooltipsIntervalIdsHash.has(column)) {
                clearTimeout(this.tooltipsIntervalIdsHash.get(column));
            }
            this.tooltipsIntervalIdsHash.set(column, setTimeout(function () {
                if (!_this.gridApi || !column || !column.getColDef() || !column.getColDef().field) {
                    return;
                }
                var oldTooltip = column.getColDef().headerTooltip;
                column.getColDef().headerTooltip = _this.getColumnTooltip(column);
                if (oldTooltip != column.getColDef().headerTooltip) {
                    _this.gridApi.refreshHeader();
                }
                _this.tooltipsIntervalIdsHash.delete(column);
                if (_this.wrapHeaderText) {
                    _this.makeHeaderTextMultiline();
                }
            }, 500));
        };
        Table2Component.prototype.updateAllTooltips = function () {
            var _this = this;
            this.columnApi.getAllColumns().forEach(function (c) {
                _this.updateColumnTooltip(c);
            });
        };
        Table2Component.prototype.getValueFormatter = function (col) {
            return !!col.valueFormatter ? col.valueFormatter
                : col.type == 'date' ? this.dateFormatter
                    : col.type == 'dateTime' ? this.dateTimeFormatter
                        : col.type == 'dateYear' ? this.dateYearFormatter
                            : col.type == 'sum' ? this.sumFormatter
                                : null;
        };
        Table2Component.prototype.getCellRenderer = function (col) {
            return !!col.customCellRenderer ? col.customCellRenderer
                : col.type == 'group' ? 'agGroupCellRenderer'
                    : col.type == 'bool' ? this.boolRenderer
                        : null;
        };
        Table2Component.prototype.getComparator = function (col) {
            if (col.type == 'date' || col.type == 'dateTime' || col.type == 'dateYear') {
                return function (a, b) { return a.valueOf() - b.valueOf(); };
            }
            if (col.type == 'number') {
                return function (a, b) { return a - b; };
            }
            return false;
        };
        Table2Component.prototype.getFilter = function (col) {
            if (this.defaultFilterEnabled) {
                if (col.filterAvailable) {
                    switch (col.type) {
                        case 'enum':
                            return 'dropdownFilter';
                        case 'bool':
                            return 'dropdownFilter';
                        case 'date':
                            return 'dateFilter';
                        case 'dateTime':
                            return 'dateFilter';
                        case 'dateYear':
                            return 'dateFilter';
                        default:
                            return 'agTextColumnFilter';
                    }
                }
                return false;
            }
            return false;
        };
        Table2Component.prototype.getFilterParams = function (col) {
            return {
                newRowsAction: 'keep',
                filterOptions: columnTypeFilterMatchModes[col.type] || columnTypeFilterMatchModes['string'],
                textFormatter: agGridCommunity.TextFilter.DEFAULT_FORMATTER,
                textCustomComparator: function (filter, value, filterText) {
                    if (col.type == 'number') {
                        var num = Number(value);
                        switch (filter) {
                            case 'gt':
                                return num > Number(filterText);
                            case 'goe':
                                return num >= Number(filterText);
                            case 'lt':
                                return num < Number(filterText);
                            case 'loe':
                                return num <= Number(filterText);
                            case 'between': {
                                var values = filterText.split(':');
                                var valLo = Number(values[0]);
                                var valHi = Number(values[1]);
                                if (valLo && valHi) {
                                    return num >= valLo && num <= valHi;
                                }
                                if (valLo) {
                                    return num >= valLo;
                                }
                                return false;
                            }
                        }
                    }
                    value = agGridCommunity.TextFilter.DEFAULT_LOWERCASE_FORMATTER(value);
                    filterText = agGridCommunity.TextFilter.DEFAULT_LOWERCASE_FORMATTER(filterText);
                    if (filter == 'in') {
                        return filterText.split(',').map(function (v) { return v.trim(); }).includes(value);
                    }
                    if (filter == 'isNull') {
                        return value == null || value == '';
                    }
                    if (filter == 'isNotNull') {
                        return value != null && value != '';
                    }
                    return agGridCommunity.TextFilter.DEFAULT_COMPARATOR(filter, value, filterText);
                },
                enum: col.filterOptions,
                values: [],
                suppressRemoveEntries: true,
                suppressSorting: true
            };
        };
        Table2Component.prototype.getFloatingFilter = function (col) {
            switch (col.type) {
                case 'enum':
                    return 'dropdownFloatingFilter';
                case 'bool':
                    return 'dropdownFloatingFilter';
                case 'date':
                    return 'dateFloatingFilter';
                case 'dateTime':
                    return 'dateFloatingFilter';
                case 'dateYear':
                    return 'dateFloatingFilter';
                default:
                    return 'textFloatingFilter';
            }
        };
        Table2Component.prototype.getFloatingFilterParams = function (col) {
            return col.type == 'enum' ? { suppressFilterButton: true, enum: col.filterOptions }
                : col.type == 'bool' ? { suppressFilterButton: true, enum: col.filterOptions }
                    : { suppressFilterButton: true, debounceMs: 3000 };
        };
        Table2Component.prototype.getTooltipField = function (col) {
            return this.enableTooltips ? (!!col.tooltipField ? col.tooltipField : null) : null;
        };
        Table2Component.prototype.clearFilterAll = function () {
            this.gridApi.setFilterModel(null);
        };
        Table2Component.prototype.getSettingsStorageKey = function () {
            return this.configService.config.clientId + '-table-' + this.settingsKey;
        };
        Table2Component.prototype.saveSettings = function () {
            if (this.settingsKey) {
                var columnState = JSON.stringify(this.columnApi.getColumnState());
                localStorage.setItem(this.getSettingsStorageKey(), columnState);
            }
        };
        Table2Component.prototype.loadSettings = function () {
            if (this.settingsKey) {
                this.loadingSettings = true;
                var loadedState = JSON.parse(localStorage.getItem(this.getSettingsStorageKey()));
                if (loadedState) {
                    var curState = this.columnApi.getColumnState();
                    var loadedStateIds_1 = loadedState.map(function (c) { return c.colId; });
                    var newStates = curState.filter(function (c) { return loadedStateIds_1.indexOf(c.colId) < 0; });
                    this.columnApi.setColumnState(loadedState.concat(newStates));
                }
                this.loadingSettings = false;
            }
        };
        Table2Component.prototype.restoreFocusIfNeeded = function () {
            if (this.saveFocus) {
                var cell = this.gridApi.getFocusedCell();
                if (cell) {
                    this.gridApi.setFocusedCell(cell.rowIndex, cell.column.getColId());
                }
                this.saveFocus = false;
            }
        };
        Table2Component.prototype.setDefaultSortModel = function () {
            var _this = this;
            var _a;
            if (((_a = this.defaultSortModel) === null || _a === void 0 ? void 0 : _a.length) > 0) {
                this.gridApi.setSortModel(this.defaultSortModel.map(function (m) { return _this.mapSortMetaToGridSortModel(m); }));
            }
        };
        Table2Component.prototype.mapSortMetaToGridSortModel = function (sort) {
            return { colId: sort.field, sort: sort.order < 0 ? 'desc' : 'asc' };
        };
        Table2Component.prototype.resizeHeaderWithDebounce = function (padding) {
            var _this = this;
            if (this.resizeHeaderTimerId) {
                clearTimeout(this.resizeHeaderTimerId);
            }
            this.resizeHeaderTimerId = setTimeout(function () {
                _this.resizeHeader(padding);
            }, 30);
        };
        Table2Component.prototype.resizeHeader = function (padding) {
            var maxHeaderHeight = Math.max.apply(Math, __spread(Array.from(document.querySelectorAll('.ag-header-cell-text'))
                .map(function (text) { return text.clientHeight; })));
            this.gridApi.setHeaderHeight(maxHeaderHeight + padding);
        };
        Table2Component.prototype.makeHeaderTextMultiline = function () {
            var _this = this;
            document.querySelectorAll('.ag-header-cell-text').forEach(function (el) {
                _this.renderer2.setStyle(el, 'overflow', 'visible');
                _this.renderer2.setStyle(el, 'white-space', 'normal');
                _this.renderer2.setStyle(el, 'overflow-wrap', 'break-word');
            });
        };
        Table2Component.prototype.generateContextMenuForSummary = function () {
            var _this = this;
            this.contextMenuExtension.push({
                label: 'Открыть итоговую строку',
                title: 'OpenAggMenu',
                command: function () {
                    _this.isSummaryRowPicked = true;
                    _this.getSummaryRow();
                }
            }, {
                label: 'Закрыть итоговую строку',
                title: 'CloseAggMenu',
                command: function () {
                    _this.isSummaryRowPicked = false;
                    _this.gridApi.setPinnedBottomRowData(null);
                }
            }, {
                label: 'Агрегирующие функции',
                title: 'AggMenu',
                items: [
                    {
                        label: 'Сумма',
                        title: 'Sum',
                        command: function () {
                            _this.summaryColAggregateMap.set(_this.gridApi.getFocusedCell().column.getColId(), 'Sum');
                            _this.showPickedFuncInSummaryRow(_this.gridApi.getFocusedCell().column.getColId(), 'Sum');
                        }
                    },
                    {
                        label: 'Среднее значение',
                        title: 'Avg',
                        command: function () {
                            _this.summaryColAggregateMap.set(_this.gridApi.getFocusedCell().column.getColId(), 'Avg');
                            _this.showPickedFuncInSummaryRow(_this.gridApi.getFocusedCell().column.getColId(), 'Avg');
                        }
                    },
                    {
                        label: 'Максимальное значение',
                        title: 'Max',
                        command: function () {
                            _this.summaryColAggregateMap.set(_this.gridApi.getFocusedCell().column.getColId(), 'Max');
                            _this.showPickedFuncInSummaryRow(_this.gridApi.getFocusedCell().column.getColId(), 'Max');
                        }
                    },
                    {
                        label: 'Минимальное значение',
                        title: 'Min',
                        command: function () {
                            _this.summaryColAggregateMap.set(_this.gridApi.getFocusedCell().column.getColId(), 'Min');
                            _this.showPickedFuncInSummaryRow(_this.gridApi.getFocusedCell().column.getColId(), 'Min');
                        }
                    },
                    {
                        label: 'Убрать столбец из итоговой строки',
                        title: 'Del',
                        command: function () {
                            _this.summaryColAggregateMap.delete(_this.gridApi.getFocusedCell().column.getColId());
                            _this.summaryRow[_this.gridApi.getFocusedCell().column.getColId()] = null;
                            _this.gridApi.setPinnedBottomRowData(Array.of(_this.summaryRow));
                        }
                    }
                ]
            });
        };
        Table2Component.prototype.contextMenuExtensionWithSummaryRow = function () {
            var _this = this;
            var contextMenuExtensionWithSummaryRow = this.contextMenuExtension;
            if (this.isSummaryRowPicked) {
                contextMenuExtensionWithSummaryRow = contextMenuExtensionWithSummaryRow.filter(function (e) { return e.title != 'OpenAggMenu'; });
                if (!this.colIdsWithCalculatedSummary.includes(this.gridApi.getFocusedCell().column.getColId())) {
                    contextMenuExtensionWithSummaryRow = contextMenuExtensionWithSummaryRow.filter(function (menu) { return menu.title != 'AggMenu'; });
                }
                else {
                    contextMenuExtensionWithSummaryRow.forEach(function (extension) {
                        if (extension.title == 'AggMenu') {
                            extension.items.forEach(function (item) {
                                if (item['title'] == _this.summaryColAggregateMap.get(_this.gridApi.getFocusedCell().column.getColId())) {
                                    item['icon'] = 'pi pi-check';
                                }
                                else {
                                    item['icon'] = null;
                                }
                            });
                        }
                    });
                }
            }
            else {
                contextMenuExtensionWithSummaryRow = contextMenuExtensionWithSummaryRow.filter(function (e) { return e.title != 'CloseAggMenu' && e.title != 'AggMenu'; });
            }
            return contextMenuExtensionWithSummaryRow;
        };
        Table2Component.prototype.getSummaryRow = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: //инициируем итоговую строку, по дефолту все результаты в виде суммы//если пользователь открыл-закрыл-открыл строку, то ничего грузить не нужно
                        return [4 /*yield*/, this.calculateSummaryRow(true)];
                        case 1:
                            _a.sent();
                            this.setSummaryDefaultResults();
                            this.highlightPinnedRow();
                            this.gridApi.setPinnedBottomRowData(Array.of(this.summaryRow));
                            return [2 /*return*/];
                    }
                });
            });
        };
        Table2Component.prototype.calculateSummaryRow = function (isInit) {
            return __awaiter(this, void 0, void 0, function () {
                var filteredRows;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            filteredRows = [];
                            return [4 /*yield*/, this.getAllTableRowsForSummary()];
                        case 1:
                            filteredRows = _a.sent();
                            this.generateAllSummaryResultsMap(filteredRows);
                            this.generateAvailableColumnsToSummaryRow();
                            this.redrawSummaryRow();
                            return [2 /*return*/];
                    }
                });
            });
        };
        Table2Component.prototype.getAllTableRowsForSummary = function () {
            return __awaiter(this, void 0, void 0, function () {
                var filteredRows;
                return __generator(this, function (_a) {
                    filteredRows = [];
                    if (!this.lazy) {
                        this.gridApi.forEachNodeAfterFilter(function (node) { return filteredRows.push(node.data); });
                    }
                    if (filteredRows.length > 0) {
                        this.summaryRow = new filteredRows[0].constructor; //присваиваем итоговой строке соответствующий класс
                    }
                    return [2 /*return*/, filteredRows];
                });
            });
        };
        Table2Component.prototype.generateAllSummaryResultsMap = function (nodes) {
            var _this = this;
            var allColumns = this.recursiveColumnsSearch(this.columns);
            allColumns.forEach(function (currentColumn) {
                _this.allSummaryResultsMap.set(currentColumn.field, _this.aggFuncCalculating(nodes, currentColumn));
            });
        };
        Table2Component.prototype.recursiveColumnsSearch = function (columnList) {
            var _this = this;
            var result = [];
            columnList.forEach(function (column) {
                if (column.children.length > 0) {
                    _this.recursiveColumnsSearch(column.children).forEach(function (e) { return result.push(e); });
                }
                else {
                    result.push(column);
                }
            });
            return result;
        };
        Table2Component.prototype.generateAvailableColumnsToSummaryRow = function () {
            var _this = this;
            this.colIdsWithCalculatedSummary = [];
            this.allSummaryResultsMap.forEach(function (v, k) {
                v != null ? _this.colIdsWithCalculatedSummary.push(k) : null;
            });
        };
        Table2Component.prototype.redrawSummaryRow = function () {
            var _this = this;
            this.summaryColAggregateMap.forEach(function (v, k) {
                var _a, _b;
                _this.summaryRow[k] = (_b = (_a = _this.allSummaryResultsMap) === null || _a === void 0 ? void 0 : _a.get(k)) === null || _b === void 0 ? void 0 : _b.get(v);
            });
            this.gridApi.setPinnedBottomRowData(Array.of(this.summaryRow));
        };
        Table2Component.prototype.setSummaryDefaultResults = function () {
            var _this = this;
            this.allSummaryResultsMap.forEach(function (value, columnName) {
                if (value != null) {
                    _this.summaryRow[columnName] = 0;
                    _this.summaryRow[columnName] = value.get('Sum');
                    _this.summaryColAggregateMap.set(columnName, 'Sum');
                }
            });
        };
        Table2Component.prototype.showPickedFuncInSummaryRow = function (columnName, aggregateFunc) {
            this.summaryRow[columnName] = 0;
            switch (aggregateFunc) {
                case 'Sum':
                    this.summaryRow[columnName] = this.allSummaryResultsMap.get(columnName).get('Sum');
                    break;
                case 'Avg':
                    this.summaryRow[columnName] = this.allSummaryResultsMap.get(columnName).get('Avg');
                    break;
                case 'Max':
                    this.summaryRow[columnName] = this.allSummaryResultsMap.get(columnName).get('Max');
                    break;
                case 'Min':
                    this.summaryRow[columnName] = this.allSummaryResultsMap.get(columnName).get('Min');
                    break;
            }
            this.gridApi.setPinnedBottomRowData(Array.of(this.summaryRow));
        };
        Table2Component.prototype.aggFuncCalculating = function (nodes, column) {
            var columnName = column.field;
            var isDisableSummaryRowCalculating = column.isDisableSummaryRowCalculating;
            var isAvailableNodeType = true;
            var countOfNumberTypes = 0;
            nodes.forEach(function (node) {
                typeof node[columnName] == 'string' ? isAvailableNodeType = false : null;
                typeof node[columnName] == 'number' ? countOfNumberTypes++ : null;
            });
            (countOfNumberTypes == 0) ? isAvailableNodeType = false : null;
            if (isAvailableNodeType && !isDisableSummaryRowCalculating) {
                var sum_1 = 0;
                var avg = 0;
                var max_1 = -1;
                var min_1 = Number.MAX_VALUE;
                var countNotNullItems_1 = 0;
                nodes.forEach(function (node) {
                    if (node[columnName] != null) {
                        countNotNullItems_1++;
                        sum_1 += node[columnName];
                        node[columnName] > max_1 ? max_1 = node[columnName] : max_1 = max_1;
                        node[columnName] < min_1 ? min_1 = node[columnName] : min_1 = min_1;
                    }
                });
                avg = sum_1 / countNotNullItems_1;
                sum_1 = parseFloat(sum_1.toFixed(2));
                avg = parseFloat(avg.toFixed(2));
                return new Map([['Sum', sum_1], ['Avg', avg], ['Max', max_1], ['Min', min_1]]);
            }
            return null;
        };
        Table2Component.prototype.highlightPinnedRow = function () {
            this.grid.gridOptions.getRowStyle = function (params) {
                if (params.node.rowPinned === 'bottom') {
                    return { 'background-color': '#c6ddf5' };
                }
            };
        };
        Table2Component.ɵfac = function Table2Component_Factory(t) { return new (t || Table2Component)(core["ɵɵdirectiveInject"](core.LOCALE_ID), core["ɵɵdirectiveInject"](ConfigurationService), core["ɵɵdirectiveInject"](core.Renderer2), core["ɵɵdirectiveInject"](DistinctFilterService), core["ɵɵdirectiveInject"](core.ElementRef)); };
        Table2Component.ɵcmp = core["ɵɵdefineComponent"]({ type: Table2Component, selectors: [["app-table2"]], contentQueries: function Table2Component_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
                core["ɵɵcontentQuery"](dirIndex, Column, false);
            } if (rf & 2) {
                var _t;
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.cols = _t);
            } }, viewQuery: function Table2Component_Query(rf, ctx) { if (rf & 1) {
                core["ɵɵviewQuery"](agGridAngular.AgGridAngular, true);
            } if (rf & 2) {
                var _t;
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.grid = _t.first);
            } }, inputs: { disableSummaryRow: "disableSummaryRow", value: "value", loading: "loading", totalRecords: "totalRecords", lazy: "lazy", deltaRowDataMode: "deltaRowDataMode", selectionMode: "selectionMode", suppressCellSelection: "suppressCellSelection", suppressRowTransform: "suppressRowTransform", checkboxSelection: "checkboxSelection", defaultSortEnabled: "defaultSortEnabled", defaultSortModel: "defaultSortModel", defaultFilterEnabled: "defaultFilterEnabled", getRowId: "getRowId", filter: "filter", settingsKey: "settingsKey", rowHeight: "rowHeight", headerHeight: "headerHeight", selection: "selection", enableTooltips: "enableTooltips", contextMenuExtension: "contextMenuExtension", keepSelectionAfterFilter: "keepSelectionAfterFilter", frameworkComponents: "frameworkComponents", getDataPath: "getDataPath", isServerSideGroup: "isServerSideGroup", getServerSideGroupKey: "getServerSideGroupKey", groupDefaultExpanded: "groupDefaultExpanded", cacheBlockSize: "cacheBlockSize", maxBlocksInCache: "maxBlocksInCache", suppressRowClickSelection: "suppressRowClickSelection", embedFullWidthRows: "embedFullWidthRows", masterDetail: "masterDetail", isRowMaster: "isRowMaster", detailCellRenderer: "detailCellRenderer", detailCellRendererParams: "detailCellRendererParams", detailRowHeight: "detailRowHeight", wrapHeaderText: "wrapHeaderText", headerVerticalPadding: "headerVerticalPadding", pivotMode: "pivotMode", suppressAggFuncInHeader: "suppressAggFuncInHeader", showGroupsCount: "showGroupsCount", stopEditingWhenGridLosesFocus: "stopEditingWhenGridLosesFocus", processSecondaryColDef: "processSecondaryColDef", processSecondaryColGroupDef: "processSecondaryColGroupDef", pivotColumnGroupTotals: "pivotColumnGroupTotals" }, outputs: { selectionChange: "selectionChange", rowDoubleClicked: "rowDoubleClicked", cellClicked: "cellClicked", cellDoubleClicked: "cellDoubleClicked", onLazyLoad: "onLazyLoad", onGetIndicatorStyle: "onGetIndicatorStyle", onGetRowStyle: "onGetRowStyle", cellKeyDown: "cellKeyDown", onDataSourceReady: "onDataSourceReady", modelUpdated: "modelUpdated", rowSelected: "rowSelected", filterChanged: "filterChanged", cellEditingStarted: "cellEditingStarted" }, features: [core["ɵɵNgOnChangesFeature"]()], decls: 6, vars: 68, consts: [[2, "display", "flex", "flex-flow", "column", "height", "100%"], ["id", "myGrid", "floatingFiltersHeight", "35", "overlayLoadingTemplate", "<span class='fa fa-spinner fa-spin'></span>", "overlayNoRowsTemplate", " ", 1, "ag-theme-balham", 2, "width", "100%", "flex", "1", "min-height", "0", 3, "localeText", "deltaRowDataMode", "rowData", "rowModelType", "animateRows", "rowSelection", "suppressCellSelection", "suppressRowTransform", "processRowPostCreate", "suppressRowClickSelection", "rowDeselection", "groupSelectsChildren", "getRowNodeId", "isFullWidthCell", "fullWidthCellRenderer", "embedFullWidthRows", "floatingFilter", "components", "frameworkComponents", "columnTypes", "rowHeight", "headerHeight", "getMainMenuItems", "getContextMenuItems", "suppressCopyRowsToClipboard", "navigateToNextCell", "getRowStyle", "cacheBlockSize", "infiniteInitialRowCount", "maxBlocksInCache", "blockLoadDebounceMillis", "loading", "stopEditingWhenGridLosesFocus", "suppressPropertyNamesCheck", "treeData", "getDataPath", "isServerSideGroup", "getServerSideGroupKey", "groupSuppressAutoColumn", "groupDefaultExpanded", "masterDetail", "isRowMaster", "detailCellRenderer", "detailCellRendererParams", "detailRowHeight", "pivotMode", "autoGroupColumnDef", "suppressAggFuncInHeader", "processSecondaryColDef", "processSecondaryColGroupDef", "pivotColumnGroupTotals", "gridReady", "rowSelected", "selectionChanged", "cellClicked", "cellDoubleClicked", "cellEditingStarted", "columnMoved", "columnResized", "columnVisible", "columnPinned", "filterChanged", "rowDoubleClicked", "cellValueChanged", "keydown", "sortChanged", "bodyScroll", "modelUpdated"], ["agGrid", ""], [3, "pinned", "lockPinned", "lockVisible", "lockPosition", "suppressMovable", "width", "minWidth", "maxWidth", "cellStyle", "menuTabs", "cellRenderer", "checkboxSelection"], [3, "col", "field", "type", "headerName", "headerComponent", "headerComponentParams", "hide", "lockVisible", "resizable", "sortable", "width", "minWidth", "maxWidth", "flex", "pinned", "lockPinned", "suppressMenu", "sortingOrder", "cellRenderer", "cellStyle", "tooltipField", "tooltipValueGetter", "headerTooltip", "filter", "filterParams", "floatingFilterComponent", "floatingFilterComponentParams", "menuTabs", "refData", "editable", "valueGetter", "valueFormatter", "comparator", "valueSetter", "cellEditor", "cellEditorParams", "cellEditorSelector", "rowSpan", "cellClassRules", "enableRowGroup", "rowGroup", "rowGroupIndex", "enablePivot", "enableValue", "pivot", "pivotIndex", "aggFunc", 4, "ngFor", "ngForOf"], ["class", "filter-string-panel", 4, "ngIf"], [3, "col", "field", "type", "headerName", "headerComponent", "headerComponentParams", "hide", "lockVisible", "resizable", "sortable", "width", "minWidth", "maxWidth", "flex", "pinned", "lockPinned", "suppressMenu", "sortingOrder", "cellRenderer", "cellStyle", "tooltipField", "tooltipValueGetter", "headerTooltip", "filter", "filterParams", "floatingFilterComponent", "floatingFilterComponentParams", "menuTabs", "refData", "editable", "valueGetter", "valueFormatter", "comparator", "valueSetter", "cellEditor", "cellEditorParams", "cellEditorSelector", "rowSpan", "cellClassRules", "enableRowGroup", "rowGroup", "rowGroupIndex", "enablePivot", "enableValue", "pivot", "pivotIndex", "aggFunc"], [3, "col", "field", "type", "headerName", "headerComponent", "headerComponentParams", "hide", "lockVisible", "resizable", "sortable", "width", "minWidth", "maxWidth", "flex", "pinned", "suppressMenu", "sortingOrder", "cellRenderer", "cellStyle", "tooltipField", "tooltipValueGetter", "headerTooltip", "filter", "filterParams", "floatingFilterComponent", "floatingFilterComponentParams", "menuTabs", "refData", "editable", "valueGetter", "valueFormatter", "comparator", "valueSetter", "cellEditor", "cellEditorParams", "cellEditorSelector", "rowSpan", "cellClassRules", "enableRowGroup", "rowGroup", "rowGroupIndex", "enablePivot", "enableValue", "pivot", "pivotIndex", "aggFunc", 4, "ngFor", "ngForOf"], [3, "col", "field", "type", "headerName", "headerComponent", "headerComponentParams", "hide", "lockVisible", "resizable", "sortable", "width", "minWidth", "maxWidth", "flex", "pinned", "suppressMenu", "sortingOrder", "cellRenderer", "cellStyle", "tooltipField", "tooltipValueGetter", "headerTooltip", "filter", "filterParams", "floatingFilterComponent", "floatingFilterComponentParams", "menuTabs", "refData", "editable", "valueGetter", "valueFormatter", "comparator", "valueSetter", "cellEditor", "cellEditorParams", "cellEditorSelector", "rowSpan", "cellClassRules", "enableRowGroup", "rowGroup", "rowGroupIndex", "enablePivot", "enableValue", "pivot", "pivotIndex", "aggFunc"], [1, "filter-string-panel"], ["href", "#", "role", "button", "title", "\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0444\u0438\u043B\u044C\u0442\u0440", 1, "ui-filter-clear", 3, "click"], [1, "fa", "fa-fw", "fa-times"], [1, "ui-table-filter-text"]], template: function Table2Component_Template(rf, ctx) { if (rf & 1) {
                core["ɵɵelementStart"](0, "div", 0);
                core["ɵɵelementStart"](1, "ag-grid-angular", 1, 2);
                core["ɵɵlistener"]("gridReady", function Table2Component_Template_ag_grid_angular_gridReady_1_listener($event) { return ctx.onGridReady($event); })("rowSelected", function Table2Component_Template_ag_grid_angular_rowSelected_1_listener($event) { return ctx.onRowSelected($event); })("selectionChanged", function Table2Component_Template_ag_grid_angular_selectionChanged_1_listener($event) { return ctx.onSelectionChanged($event); })("cellClicked", function Table2Component_Template_ag_grid_angular_cellClicked_1_listener($event) { return ctx.onCellClicked($event); })("cellDoubleClicked", function Table2Component_Template_ag_grid_angular_cellDoubleClicked_1_listener($event) { return ctx.onCellDoubleClicked($event); })("cellEditingStarted", function Table2Component_Template_ag_grid_angular_cellEditingStarted_1_listener($event) { return ctx.onCellEditingStarted($event); })("columnMoved", function Table2Component_Template_ag_grid_angular_columnMoved_1_listener() { return ctx.onColumnMoved(); })("columnResized", function Table2Component_Template_ag_grid_angular_columnResized_1_listener($event) { return ctx.onColumnResized($event); })("columnVisible", function Table2Component_Template_ag_grid_angular_columnVisible_1_listener() { return ctx.onColumnVisible(); })("columnPinned", function Table2Component_Template_ag_grid_angular_columnPinned_1_listener() { return ctx.onColumnPinned(); })("filterChanged", function Table2Component_Template_ag_grid_angular_filterChanged_1_listener() { return ctx.onFilterChanged(); })("rowDoubleClicked", function Table2Component_Template_ag_grid_angular_rowDoubleClicked_1_listener() { return ctx.rowDoubleClicked.emit(); })("cellValueChanged", function Table2Component_Template_ag_grid_angular_cellValueChanged_1_listener($event) { return ctx.onCellValueChanged($event); })("keydown", function Table2Component_Template_ag_grid_angular_keydown_1_listener($event) { return ctx.onKeyDown($event); })("sortChanged", function Table2Component_Template_ag_grid_angular_sortChanged_1_listener($event) { return ctx.onSortChanged($event); })("bodyScroll", function Table2Component_Template_ag_grid_angular_bodyScroll_1_listener($event) { return ctx.onBodyScroll($event); })("modelUpdated", function Table2Component_Template_ag_grid_angular_modelUpdated_1_listener($event) { return ctx.onModelUpdated($event); });
                core["ɵɵelement"](3, "ag-grid-column", 3);
                core["ɵɵtemplate"](4, Table2Component_ag_grid_column_4_Template, 2, 50, "ag-grid-column", 4);
                core["ɵɵelementEnd"]();
                core["ɵɵtemplate"](5, Table2Component_div_5_Template, 5, 2, "div", 5);
                core["ɵɵelementEnd"]();
            } if (rf & 2) {
                core["ɵɵadvance"](1);
                core["ɵɵclassProp"]("focused-grid", ctx.focused);
                core["ɵɵproperty"]("localeText", ctx.localeText)("deltaRowDataMode", ctx.deltaRowDataMode)("rowData", ctx.value)("rowModelType", ctx.lazy ? "serverSide" : "")("animateRows", true)("rowSelection", ctx.selectionMode)("suppressCellSelection", ctx.suppressCellSelection)("suppressRowTransform", ctx.suppressRowTransform)("processRowPostCreate", ctx.processRowPostCreate)("suppressRowClickSelection", ctx.suppressRowClickSelection != null ? ctx.suppressRowClickSelection : ctx.checkboxSelection)("rowDeselection", true)("groupSelectsChildren", false)("getRowNodeId", ctx.getRowId)("isFullWidthCell", ctx.isFullWidthCell)("fullWidthCellRenderer", ctx.fullWidthCellRenderer)("embedFullWidthRows", ctx.embedFullWidthRows)("floatingFilter", ctx.filter)("components", ctx.components)("frameworkComponents", ctx.tableFrameworkComponents)("columnTypes", ctx.columnTypes)("rowHeight", ctx.rowHeight)("headerHeight", ctx.headerHeight)("getMainMenuItems", ctx.getMainMenuItems)("getContextMenuItems", ctx.getContextMenuItems)("suppressCopyRowsToClipboard", true)("navigateToNextCell", ctx.navigateToNextCell)("getRowStyle", ctx.rowStyle)("cacheBlockSize", ctx.cacheBlockSize)("infiniteInitialRowCount", 1)("maxBlocksInCache", ctx.maxBlocksInCache)("blockLoadDebounceMillis", 100)("loading", ctx.loading)("stopEditingWhenGridLosesFocus", ctx.stopEditingWhenGridLosesFocus)("suppressPropertyNamesCheck", true)("treeData", !!ctx.getServerSideGroupKey || !!ctx.getDataPath)("getDataPath", ctx.getDataPath)("isServerSideGroup", ctx.isServerSideGroup)("getServerSideGroupKey", ctx.getServerSideGroupKey)("groupSuppressAutoColumn", true)("groupDefaultExpanded", ctx.groupDefaultExpanded)("masterDetail", ctx.masterDetail)("isRowMaster", ctx.isRowMaster)("detailCellRenderer", ctx.detailCellRenderer)("detailCellRendererParams", ctx.detailCellRendererParams)("detailRowHeight", ctx.detailRowHeight)("pivotMode", ctx.pivotMode)("autoGroupColumnDef", ctx.autoGroupColumnDef)("suppressAggFuncInHeader", ctx.suppressAggFuncInHeader)("processSecondaryColDef", ctx.processSecondaryColDef)("processSecondaryColGroupDef", ctx.processSecondaryColGroupDef)("pivotColumnGroupTotals", ctx.pivotColumnGroupTotals);
                core["ɵɵadvance"](2);
                core["ɵɵproperty"]("pinned", true)("lockPinned", true)("lockVisible", true)("lockPosition", true)("suppressMovable", true)("width", ctx.checkboxSelection ? 50 : 30)("minWidth", ctx.checkboxSelection ? 50 : 30)("maxWidth", ctx.checkboxSelection ? 50 : 30)("cellStyle", ctx.indicatorStyle)("menuTabs", core["ɵɵpureFunction0"](67, _c2$3))("cellRenderer", ctx.loadingCellRenderer)("checkboxSelection", ctx.checkboxSelection);
                core["ɵɵadvance"](1);
                core["ɵɵproperty"]("ngForOf", ctx.availableColumns);
                core["ɵɵadvance"](1);
                core["ɵɵproperty"]("ngIf", ctx.filterString);
            } }, directives: [AgGridDirective, agGridAngular.AgGridAngular, AgGridColumnDirective, agGridAngular.AgGridColumn, common.NgForOf, common.NgIf], styles: [".filter-string-panel[_ngcontent-%COMP%]{border:1px solid #dedede;border-top:0;padding:7px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}  .ag-selection-checkbox{cursor:pointer}.header-cell-text-wrap[_ngcontent-%COMP%]{overflow:visible;white-space:normal;overflow-wrap:break-word}  .ag-tooltip{white-space:pre-wrap;max-width:90%}  .ui-datepicker .ui-datepicker-header .ui-datepicker-title select{border:none}"] });
        return Table2Component;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](Table2Component, [{
            type: core.Component,
            args: [{
                    selector: 'app-table2',
                    templateUrl: './table2.component.html',
                    styleUrls: ['./table2.component.css']
                }]
        }], function () { return [{ type: undefined, decorators: [{
                    type: core.Inject,
                    args: [core.LOCALE_ID]
                }] }, { type: ConfigurationService }, { type: core.Renderer2 }, { type: DistinctFilterService }, { type: core.ElementRef }]; }, { disableSummaryRow: [{
                type: core.Input
            }], value: [{
                type: core.Input
            }], loading: [{
                type: core.Input
            }], totalRecords: [{
                type: core.Input
            }], lazy: [{
                type: core.Input
            }], deltaRowDataMode: [{
                type: core.Input
            }], selectionMode: [{
                type: core.Input
            }], suppressCellSelection: [{
                type: core.Input
            }], suppressRowTransform: [{
                type: core.Input
            }], checkboxSelection: [{
                type: core.Input
            }], defaultSortEnabled: [{
                type: core.Input
            }], defaultSortModel: [{
                type: core.Input
            }], defaultFilterEnabled: [{
                type: core.Input
            }], getRowId: [{
                type: core.Input
            }], filter: [{
                type: core.Input
            }], settingsKey: [{
                type: core.Input
            }], rowHeight: [{
                type: core.Input
            }], headerHeight: [{
                type: core.Input
            }], selection: [{
                type: core.Input
            }], enableTooltips: [{
                type: core.Input
            }], contextMenuExtension: [{
                type: core.Input
            }], keepSelectionAfterFilter: [{
                type: core.Input
            }], frameworkComponents: [{
                type: core.Input
            }], getDataPath: [{
                type: core.Input
            }], isServerSideGroup: [{
                type: core.Input
            }], getServerSideGroupKey: [{
                type: core.Input
            }], groupDefaultExpanded: [{
                type: core.Input
            }], cacheBlockSize: [{
                type: core.Input
            }], maxBlocksInCache: [{
                type: core.Input
            }], suppressRowClickSelection: [{
                type: core.Input
            }], embedFullWidthRows: [{
                type: core.Input
            }], masterDetail: [{
                type: core.Input
            }], isRowMaster: [{
                type: core.Input
            }], detailCellRenderer: [{
                type: core.Input
            }], detailCellRendererParams: [{
                type: core.Input
            }], detailRowHeight: [{
                type: core.Input
            }], wrapHeaderText: [{
                type: core.Input
            }], headerVerticalPadding: [{
                type: core.Input
            }], pivotMode: [{
                type: core.Input
            }], suppressAggFuncInHeader: [{
                type: core.Input
            }], showGroupsCount: [{
                type: core.Input
            }], stopEditingWhenGridLosesFocus: [{
                type: core.Input
            }], processSecondaryColDef: [{
                type: core.Input
            }], processSecondaryColGroupDef: [{
                type: core.Input
            }], pivotColumnGroupTotals: [{
                type: core.Input
            }], selectionChange: [{
                type: core.Output
            }], rowDoubleClicked: [{
                type: core.Output
            }], cellClicked: [{
                type: core.Output
            }], cellDoubleClicked: [{
                type: core.Output
            }], onLazyLoad: [{
                type: core.Output
            }], onGetIndicatorStyle: [{
                type: core.Output
            }], onGetRowStyle: [{
                type: core.Output
            }], cellKeyDown: [{
                type: core.Output
            }], onDataSourceReady: [{
                type: core.Output
            }], modelUpdated: [{
                type: core.Output
            }], rowSelected: [{
                type: core.Output
            }], filterChanged: [{
                type: core.Output
            }], cellEditingStarted: [{
                type: core.Output
            }], grid: [{
                type: core.ViewChild,
                args: [agGridAngular.AgGridAngular]
            }], cols: [{
                type: core.ContentChildren,
                args: [Column]
            }] }); })();

    var BoolPipe = /** @class */ (function () {
        function BoolPipe(_local) {
            this._local = _local;
        }
        BoolPipe.prototype.transform = function (value, args) {
            return value == null || value == undefined ? "" : value ? "&#xF00C;" : "&#xF00D;";
        };
        BoolPipe.ɵfac = function BoolPipe_Factory(t) { return new (t || BoolPipe)(core["ɵɵdirectiveInject"](core.LOCALE_ID)); };
        BoolPipe.ɵpipe = core["ɵɵdefinePipe"]({ name: "bool", type: BoolPipe, pure: true });
        return BoolPipe;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](BoolPipe, [{
            type: core.Pipe,
            args: [{
                    name: 'bool'
                }]
        }], function () { return [{ type: undefined, decorators: [{
                    type: core.Inject,
                    args: [core.LOCALE_ID]
                }] }]; }, null); })();

    var EnumPipe = /** @class */ (function () {
        function EnumPipe() {
        }
        EnumPipe.prototype.transform = function (value, args) {
            return value == null ? "" : (args && args[value] ? args[value] : ("[" + value + "]"));
        };
        EnumPipe.ɵfac = function EnumPipe_Factory(t) { return new (t || EnumPipe)(); };
        EnumPipe.ɵpipe = core["ɵɵdefinePipe"]({ name: "enum", type: EnumPipe, pure: true });
        return EnumPipe;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](EnumPipe, [{
            type: core.Pipe,
            args: [{
                    name: 'enum'
                }]
        }], null, null); })();

    var LookupBaseComponent = /** @class */ (function () {
        function LookupBaseComponent() {
        }
        return LookupBaseComponent;
    }());

    var _c0$a = ["lookupTable"];
    var _c1$5 = ["lookupAutoComplete"];
    var _c2$4 = ["input"];
    var _c3$1 = ["autoCompleteWrapper"];
    var _c4$1 = ["dialog"];
    function LookupComponent_input_1_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelement"](0, "input", 9, 10);
    } if (rf & 2) {
        var ctx_r605 = core["ɵɵnextContext"]();
        core["ɵɵproperty"]("required", ctx_r605.required)("value", ctx_r605.text);
    } }
    function LookupComponent_div_2_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementStart"](0, "div", 11, 12);
        core["ɵɵelementContainer"](2, 13);
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var ctx_r606 = core["ɵɵnextContext"]();
        core["ɵɵadvance"](2);
        core["ɵɵproperty"]("ngTemplateOutlet", ctx_r606.lookupAutoComplete);
    } }
    function LookupComponent_button_3_Template(rf, ctx) { if (rf & 1) {
        var _r613 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "button", 14);
        core["ɵɵlistener"]("click", function LookupComponent_button_3_Template_button_click_0_listener() { core["ɵɵrestoreView"](_r613); var ctx_r612 = core["ɵɵnextContext"](); return ctx_r612.showForm(); });
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var ctx_r607 = core["ɵɵnextContext"]();
        core["ɵɵproperty"]("disabled", ctx_r607.disabled);
        core["ɵɵattribute"]("tabindex", ctx_r607.lookupAutoComplete ? null : 0 - 1);
    } }
    function LookupComponent_div_6_ng_container_1_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainer"](0, 13);
    } if (rf & 2) {
        var ctx_r614 = core["ɵɵnextContext"](2);
        core["ɵɵproperty"]("ngTemplateOutlet", ctx_r614.dialogContent);
    } }
    function LookupComponent_div_6_ng_container_2_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainer"](0, 13);
    } if (rf & 2) {
        var ctx_r615 = core["ɵɵnextContext"](2);
        core["ɵɵproperty"]("ngTemplateOutlet", ctx_r615.lookupTable);
    } }
    function LookupComponent_div_6_Template(rf, ctx) { if (rf & 1) {
        var _r617 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "div", 15);
        core["ɵɵlistener"]("keydown", function LookupComponent_div_6_Template_div_keydown_0_listener($event) { core["ɵɵrestoreView"](_r617); var ctx_r616 = core["ɵɵnextContext"](); return ctx_r616.onDialogKeyDown($event); });
        core["ɵɵtemplate"](1, LookupComponent_div_6_ng_container_1_Template, 1, 1, "ng-container", 16);
        core["ɵɵtemplate"](2, LookupComponent_div_6_ng_container_2_Template, 1, 1, "ng-container", 16);
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var ctx_r609 = core["ɵɵnextContext"]();
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", !ctx_r609.lookupTable);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", ctx_r609.lookupTable);
    } }
    var _c5 = function () { return { width: "70vw", height: "80vh" }; };
    var _c6 = function () { return { "display": "flex", "min-height": "calc(100% - 7em)", "max-height": "calc(100% - 7em)" }; };
    var LookupComponent = /** @class */ (function () {
        function LookupComponent() {
            this.invalid = true;
            this.required = false;
        }
        LookupComponent.prototype.onresize = function (e) {
            var _this = this;
            if (this.dialog.maximized) {
                return;
            }
            setTimeout(function () {
                if (_this.dialog.container) {
                    _this.dialog.container.style.left = 'unset';
                    _this.dialog.container.style.top = 'unset';
                }
            });
        };
        LookupComponent.prototype.ngOnInit = function () {
        };
        LookupComponent.prototype.writeValue = function (obj) {
            this.value = obj;
            this.text = this.getText();
        };
        LookupComponent.prototype.registerOnChange = function (fn) {
            this.onChange = fn;
        };
        LookupComponent.prototype.registerOnTouched = function (fn) {
            this.onTouched = fn;
        };
        LookupComponent.prototype.setDisabledState = function (isDisabled) {
            this.disabled = isDisabled;
        };
        LookupComponent.prototype.showForm = function () {
            this.display = true;
        };
        Object.defineProperty(LookupComponent.prototype, "selection", {
            get: function () {
                return this.lookupComponent ? this.lookupComponent.selectedValue : null;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(LookupComponent.prototype, "formHeader", {
            get: function () {
                return this.lookupComponent ? this.lookupComponent.header : null;
            },
            enumerable: true,
            configurable: true
        });
        LookupComponent.prototype.select = function () {
            this.value = this.lookupComponent.selectedValue;
            this.text = this.getText();
            this.onChange(this.value);
            this.onTouched();
            this.display = false;
        };
        LookupComponent.prototype.onHide = function () {
            var _this = this;
            if (this.input) {
                setTimeout(function () { return _this.input.focus(); });
            }
            else {
                this.autoCompleteWrapper.nativeElement.querySelector('input').focus();
            }
        };
        LookupComponent.prototype.onDialogKeyDown = function (e) {
            if (e.key === 'Enter' && this.selection) {
                this.select();
                e.preventDefault();
                e.stopPropagation();
            }
        };
        LookupComponent.prototype.getText = function () {
            var textValue = this.value;
            if (this.field) {
                textValue = this.value ? this.field.split('.').reduce(function (object, index) { return !!object && object[index]; }, this.value) : null;
            }
            return textValue ? textValue.toString() : '';
        };
        LookupComponent.ɵfac = function LookupComponent_Factory(t) { return new (t || LookupComponent)(); };
        LookupComponent.ɵcmp = core["ɵɵdefineComponent"]({ type: LookupComponent, selectors: [["app-lookup"]], contentQueries: function LookupComponent_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
                core["ɵɵcontentQuery"](dirIndex, core.TemplateRef, true);
                core["ɵɵcontentQuery"](dirIndex, _c0$a, true);
                core["ɵɵcontentQuery"](dirIndex, _c1$5, true);
                core["ɵɵcontentQuery"](dirIndex, LookupBaseComponent, true);
            } if (rf & 2) {
                var _t;
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.dialogContent = _t.first);
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.lookupTable = _t.first);
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.lookupAutoComplete = _t.first);
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.lookupComponent = _t.first);
            } }, viewQuery: function LookupComponent_Query(rf, ctx) { if (rf & 1) {
                core["ɵɵviewQuery"](_c2$4, true);
                core["ɵɵviewQuery"](_c3$1, true);
                core["ɵɵviewQuery"](_c4$1, true);
            } if (rf & 2) {
                var _t;
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.input = _t.first);
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.autoCompleteWrapper = _t.first);
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.dialog = _t.first);
            } }, inputs: { field: "field", header: "header", readonly: "readonly", display: "display", style: "style", required: "required" }, features: [core["ɵɵProvidersFeature"]([
                    {
                        provide: forms.NG_VALUE_ACCESSOR,
                        useExisting: core.forwardRef(function () { return LookupComponent; }),
                        multi: true
                    }
                ])], decls: 10, vars: 16, consts: [[1, "ui-inputgroup", 3, "ngStyle"], ["pInputText", "", "placeholder", "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435", "readonly", "", 3, "required", "value", 4, "ngIf"], ["style", "flex: 1", 4, "ngIf"], ["type", "button", "pButton", "", "icon", "fa fa-ellipsis-h", "pTooltip", "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435", 3, "disabled", "click", 4, "ngIf"], [3, "header", "modal", "maximizable", "visible", "resizable", "contentStyle", "visibleChange", "onHide", "resize"], ["dialog", ""], ["style", "width: 100%", 3, "keydown", 4, "ngIf"], ["type", "submit", "pButton", "", "icon", "fa fa-check", "label", "\u0412\u044B\u0431\u0440\u0430\u0442\u044C", 3, "disabled", "click"], ["type", "reset", "pButton", "", "icon", "fa fa-times", "label", "\u041E\u0442\u043C\u0435\u043D\u0430", 1, "ui-button-secondary", 3, "click"], ["pInputText", "", "placeholder", "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435", "readonly", "", 3, "required", "value"], ["input", ""], [2, "flex", "1"], ["autoCompleteWrapper", ""], [3, "ngTemplateOutlet"], ["type", "button", "pButton", "", "icon", "fa fa-ellipsis-h", "pTooltip", "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435", 3, "disabled", "click"], [2, "width", "100%", 3, "keydown"], [3, "ngTemplateOutlet", 4, "ngIf"]], template: function LookupComponent_Template(rf, ctx) { if (rf & 1) {
                core["ɵɵelementStart"](0, "div", 0);
                core["ɵɵtemplate"](1, LookupComponent_input_1_Template, 2, 2, "input", 1);
                core["ɵɵtemplate"](2, LookupComponent_div_2_Template, 3, 1, "div", 2);
                core["ɵɵtemplate"](3, LookupComponent_button_3_Template, 1, 2, "button", 3);
                core["ɵɵelementEnd"]();
                core["ɵɵelementStart"](4, "p-dialog", 4, 5);
                core["ɵɵlistener"]("visibleChange", function LookupComponent_Template_p_dialog_visibleChange_4_listener($event) { return ctx.display = $event; })("onHide", function LookupComponent_Template_p_dialog_onHide_4_listener() { return ctx.onHide(); })("resize", function LookupComponent_Template_p_dialog_resize_4_listener($event) { return ctx.onresize($event); }, false, core["ɵɵresolveWindow"]);
                core["ɵɵtemplate"](6, LookupComponent_div_6_Template, 3, 2, "div", 6);
                core["ɵɵelementStart"](7, "p-footer");
                core["ɵɵelementStart"](8, "button", 7);
                core["ɵɵlistener"]("click", function LookupComponent_Template_button_click_8_listener() { return ctx.select(); });
                core["ɵɵelementEnd"]();
                core["ɵɵelementStart"](9, "button", 8);
                core["ɵɵlistener"]("click", function LookupComponent_Template_button_click_9_listener() { return ctx.display = false; });
                core["ɵɵelementEnd"]();
                core["ɵɵelementEnd"]();
                core["ɵɵelementEnd"]();
            } if (rf & 2) {
                core["ɵɵproperty"]("ngStyle", ctx.style);
                core["ɵɵadvance"](1);
                core["ɵɵproperty"]("ngIf", !ctx.lookupAutoComplete);
                core["ɵɵadvance"](1);
                core["ɵɵproperty"]("ngIf", ctx.lookupAutoComplete);
                core["ɵɵadvance"](1);
                core["ɵɵproperty"]("ngIf", !ctx.readonly);
                core["ɵɵadvance"](1);
                core["ɵɵstyleMap"](core["ɵɵpureFunction0"](14, _c5));
                core["ɵɵproperty"]("header", ctx.header || ctx.formHeader)("modal", true)("maximizable", true)("visible", ctx.display)("resizable", false)("contentStyle", core["ɵɵpureFunction0"](15, _c6));
                core["ɵɵadvance"](2);
                core["ɵɵproperty"]("ngIf", ctx.display);
                core["ɵɵadvance"](2);
                core["ɵɵproperty"]("disabled", ctx.display && !ctx.selection);
            } }, directives: [common.NgStyle, common.NgIf, DialogExtDirective, dialog.Dialog, api.Footer, button.ButtonDirective, InputDirective, inputtext.InputText, common.NgTemplateOutlet, TooltipExtDirective, tooltip.Tooltip], styles: [".ui-inputgroup[_ngcontent-%COMP%]{display:-webkit-box;display:flex}.ui-inputgroup[_ngcontent-%COMP%]   input[_ngcontent-%COMP%]{-webkit-box-flex:1;flex:1;min-width:0}"] });
        return LookupComponent;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](LookupComponent, [{
            type: core.Component,
            args: [{
                    selector: 'app-lookup',
                    templateUrl: 'lookup.component.html',
                    styleUrls: ['lookup.component.css'],
                    providers: [
                        {
                            provide: forms.NG_VALUE_ACCESSOR,
                            useExisting: core.forwardRef(function () { return LookupComponent; }),
                            multi: true
                        }
                    ]
                }]
        }], function () { return []; }, { field: [{
                type: core.Input
            }], header: [{
                type: core.Input
            }], readonly: [{
                type: core.Input
            }], display: [{
                type: core.Input
            }], style: [{
                type: core.Input
            }], required: [{
                type: core.Input
            }], input: [{
                type: core.ViewChild,
                args: ['input']
            }], autoCompleteWrapper: [{
                type: core.ViewChild,
                args: ['autoCompleteWrapper']
            }], dialogContent: [{
                type: core.ContentChild,
                args: [core.TemplateRef]
            }], lookupTable: [{
                type: core.ContentChild,
                args: ['lookupTable']
            }], lookupAutoComplete: [{
                type: core.ContentChild,
                args: ['lookupAutoComplete']
            }], lookupComponent: [{
                type: core.ContentChild,
                args: [LookupBaseComponent]
            }], dialog: [{
                type: core.ViewChild,
                args: ['dialog']
            }] }); })();

    var _c0$b = ["*"];
    var ProgressPanelComponent = /** @class */ (function () {
        function ProgressPanelComponent() {
            this.blocked = false;
        }
        ProgressPanelComponent.ɵfac = function ProgressPanelComponent_Factory(t) { return new (t || ProgressPanelComponent)(); };
        ProgressPanelComponent.ɵcmp = core["ɵɵdefineComponent"]({ type: ProgressPanelComponent, selectors: [["app-progressPanel"]], inputs: { blocked: "blocked", style: "style", styleClass: "styleClass" }, ngContentSelectors: _c0$b, decls: 6, vars: 6, consts: [[3, "target", "blocked"], [2, "position", "absolute", "top", "50%", "left", "50%", "margin-top", "-2em", "margin-left", "-2em", "text-align", "center"], [1, "pi-spin", "pi", "pi-spinner", 2, "font-size", "4em"], [3, "showHeader", "styleClass"], ["content", ""]], template: function ProgressPanelComponent_Template(rf, ctx) { if (rf & 1) {
                core["ɵɵprojectionDef"]();
                core["ɵɵelementStart"](0, "p-blockUI", 0);
                core["ɵɵelementStart"](1, "div", 1);
                core["ɵɵelement"](2, "i", 2);
                core["ɵɵelementEnd"]();
                core["ɵɵelementEnd"]();
                core["ɵɵelementStart"](3, "p-panel", 3, 4);
                core["ɵɵprojection"](5);
                core["ɵɵelementEnd"]();
            } if (rf & 2) {
                var _r618 = core["ɵɵreference"](4);
                core["ɵɵproperty"]("target", _r618)("blocked", ctx.blocked);
                core["ɵɵadvance"](3);
                core["ɵɵstyleMap"](ctx.style);
                core["ɵɵproperty"]("showHeader", false)("styleClass", ctx.styleClass);
            } }, directives: [blockui.BlockUI, panel.Panel], styles: ["app-progressPanel > p-panel > .ui-panel > .ui-panel-content-wrapper > .ui-panel-content { border: none !important; }"] });
        return ProgressPanelComponent;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](ProgressPanelComponent, [{
            type: core.Component,
            args: [{
                    selector: 'app-progressPanel',
                    template: "<p-blockUI [target]=\"content\" [blocked]=\"blocked\">\n            <div style=\"position: absolute; top: 50%; left: 50%; margin-top: -2em; margin-left: -2em; text-align: center;\">\n                <i class=\"pi-spin pi pi-spinner\" style=\"font-size: 4em\"></i>\n            </div>           \n        </p-blockUI>\n        <p-panel #content [showHeader]=\"false\" [style]=\"style\" [styleClass]=\"styleClass\">\n            <ng-content select></ng-content>\n        </p-panel>",
                    styles: [
                        '::ng-deep app-progressPanel > p-panel > .ui-panel > .ui-panel-content-wrapper > .ui-panel-content { border: none !important; }'
                    ]
                }]
        }], null, { blocked: [{
                type: core.Input
            }], style: [{
                type: core.Input
            }], styleClass: [{
                type: core.Input
            }] }); })();

    var DialogComponent = /** @class */ (function () {
        function DialogComponent() {
            this._shown = false;
            this.visibleChange = new core.EventEmitter();
            this.onShow = new core.EventEmitter();
            this.onHide = new core.EventEmitter();
        }
        Object.defineProperty(DialogComponent.prototype, "visible", {
            get: function () {
                return this.dialog.visible;
            },
            set: function (visible) {
                this.dialog.visible = visible;
                this.visibleChange.emit(this.visible);
                if (visible) {
                    this.showInternal();
                }
                else {
                    this.hideInternal();
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DialogComponent.prototype, "loading", {
            get: function () {
                return this.dialogExt.loading;
            },
            set: function (loading) {
                this.dialogExt.loading = loading;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DialogComponent.prototype, "shown", {
            get: function () {
                return this._shown;
            },
            enumerable: true,
            configurable: true
        });
        DialogComponent.prototype.ngAfterContentInit = function () {
            var _this = this;
            this._shown = !!this.dialog.visible;
            this.dialog.visibleChange.subscribe(function (visible) {
                _this.visible = visible;
            });
            this.dialog.modal = true;
            this.dialog.resizable = false;
        };
        DialogComponent.prototype.showInternal = function () {
            this._shown = true;
            this.onShow.emit(null);
        };
        DialogComponent.prototype.hideInternal = function () {
            var _this = this;
            var timeout = parseInt(this.dialog.transitionOptions, 10);
            if (isNaN(timeout) || !isFinite(timeout)) {
                timeout = 0;
            }
            setTimeout(function () {
                _this._shown = false;
                _this.onHide.emit(null);
            }, timeout);
        };
        DialogComponent.ɵfac = function DialogComponent_Factory(t) { return new (t || DialogComponent)(); };
        DialogComponent.ɵdir = core["ɵɵdefineDirective"]({ type: DialogComponent, viewQuery: function DialogComponent_Query(rf, ctx) { if (rf & 1) {
                core["ɵɵstaticViewQuery"](dialog.Dialog, true);
                core["ɵɵstaticViewQuery"](DialogExtDirective, true);
            } if (rf & 2) {
                var _t;
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.dialog = _t.first);
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.dialogExt = _t.first);
            } }, inputs: { visible: "visible", loading: "loading" }, outputs: { visibleChange: "visibleChange", onShow: "onShow", onHide: "onHide" } });
        return DialogComponent;
    }());

    var FileLoadService = /** @class */ (function () {
        function FileLoadService() {
        }
        FileLoadService.prototype.readFileAsync = function (file) {
            return new Promise(function (resolve, reject) {
                var reader = new FileReader();
                reader.onload = function () {
                    resolve(reader.result);
                };
                reader.onerror = reject;
                reader.readAsArrayBuffer(file);
            });
        };
        FileLoadService.ɵfac = function FileLoadService_Factory(t) { return new (t || FileLoadService)(); };
        FileLoadService.ɵprov = core["ɵɵdefineInjectable"]({ token: FileLoadService, factory: FileLoadService.ɵfac, providedIn: 'root' });
        return FileLoadService;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](FileLoadService, [{
            type: core.Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], null, null); })();

    var _c0$c = ["tiffContainer"];
    function FileViewerComponent_button_3_Template(rf, ctx) { if (rf & 1) {
        var _r629 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "button", 13);
        core["ɵɵlistener"]("click", function FileViewerComponent_button_3_Template_button_click_0_listener() { core["ɵɵrestoreView"](_r629); var ctx_r628 = core["ɵɵnextContext"](); return ctx_r628.scale(0.1); });
        core["ɵɵelementEnd"]();
    } }
    function FileViewerComponent_button_4_Template(rf, ctx) { if (rf & 1) {
        var _r631 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "button", 14);
        core["ɵɵlistener"]("click", function FileViewerComponent_button_4_Template_button_click_0_listener() { core["ɵɵrestoreView"](_r631); var ctx_r630 = core["ɵɵnextContext"](); return ctx_r630.scale(0 - 0.1); });
        core["ɵɵelementEnd"]();
    } }
    function FileViewerComponent_div_5_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelement"](0, "div", 15);
    } }
    function FileViewerComponent_button_6_Template(rf, ctx) { if (rf & 1) {
        var _r633 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "button", 16);
        core["ɵɵlistener"]("click", function FileViewerComponent_button_6_Template_button_click_0_listener() { core["ɵɵrestoreView"](_r633); var ctx_r632 = core["ɵɵnextContext"](); return ctx_r632.saveFile(); });
        core["ɵɵelementEnd"]();
    } }
    function FileViewerComponent_div_7_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelement"](0, "div", 15);
    } }
    function FileViewerComponent_object_9_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelement"](0, "object", 17);
    } if (rf & 2) {
        var ctx_r624 = core["ɵɵnextContext"]();
        core["ɵɵproperty"]("type", ctx_r624.mediaType);
        core["ɵɵattribute"]("data", ctx_r624.url, core["ɵɵsanitizeResourceUrl"]);
    } }
    function FileViewerComponent_object_12_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelement"](0, "object", 18);
    } if (rf & 2) {
        var ctx_r625 = core["ɵɵnextContext"]();
        core["ɵɵproperty"]("type", ctx_r625.mediaType);
        core["ɵɵattribute"]("data", ctx_r625.url, core["ɵɵsanitizeResourceUrl"]);
    } }
    function FileViewerComponent_div_13_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelement"](0, "div", 19, 20);
    } }
    function FileViewerComponent_div_14_Template(rf, ctx) { if (rf & 1) {
        var _r636 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "div", 21);
        core["ɵɵelementStart"](1, "p-paginator", 22);
        core["ɵɵlistener"]("onPageChange", function FileViewerComponent_div_14_Template_p_paginator_onPageChange_1_listener($event) { core["ɵɵrestoreView"](_r636); var ctx_r635 = core["ɵɵnextContext"](); return ctx_r635.onPageChange($event); });
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var ctx_r627 = core["ɵɵnextContext"]();
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("rows", 1)("totalRecords", ctx_r627.maxTiffPages);
    } }
    var _c1$6 = function () { return { width: "1100px", height: "98%" }; };
    var _c2$5 = function () { return { width: "100%", height: "100%" }; };

    (function (ServeFileType) {
        ServeFileType["SAVE"] = "SAVE";
        ServeFileType["VIEW"] = "VIEW";
    })(exports.ServeFileType || (exports.ServeFileType = {}));
    var FileViewerComponent = /** @class */ (function (_super) {
        __extends(FileViewerComponent, _super);
        function FileViewerComponent(messageService, fileLoadService, sanitizer) {
            var _this = _super.call(this) || this;
            _this.messageService = messageService;
            _this.fileLoadService = fileLoadService;
            _this.sanitizer = sanitizer;
            _this.currentTiffPage = 0;
            _this.maxTiffPages = 1;
            _this.scaleRatio = 1;
            _this.isTiff = false;
            _this.isPDF = false;
            _this.isAvailableToDownload = true;
            return _this;
        }
        FileViewerComponent.prototype.init = function (data, mediaType, fileName, isAvailableToDownload) {
            if (isAvailableToDownload === void 0) { isAvailableToDownload = true; }
            return __awaiter(this, void 0, void 0, function () {
                var unsafeURL, url, _a, buffer;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            this.data = data;
                            this.fileName = fileName;
                            this.mediaType = mediaType;
                            this.isAvailableToDownload = isAvailableToDownload;
                            unsafeURL = window.URL.createObjectURL(data);
                            url = this.sanitizer.bypassSecurityTrustResourceUrl(unsafeURL);
                            _a = mediaType.toLowerCase();
                            switch (_a) {
                                case 'application/pdf': return [3 /*break*/, 1];
                                case 'image/tif': return [3 /*break*/, 2];
                                case 'image/tiff': return [3 /*break*/, 2];
                            }
                            return [3 /*break*/, 4];
                        case 1:
                            this.isPDF = true;
                            this.url = url;
                            return [3 /*break*/, 5];
                        case 2:
                            this.scaleRatio = 0.5;
                            this.isTiff = true;
                            return [4 /*yield*/, this.fileLoadService.readFileAsync(data)];
                        case 3:
                            buffer = _b.sent();
                            this.tiffImage = new Tiff({ buffer: buffer });
                            this.maxTiffPages = this.tiffImage.countDirectory();
                            this.updateTiffCanvas();
                            console.log('TiffPages ' + this.maxTiffPages);
                            return [3 /*break*/, 5];
                        case 4:
                            this.isPDF = false;
                            this.url = url;
                            return [3 /*break*/, 5];
                        case 5: return [2 /*return*/];
                    }
                });
            });
        };
        FileViewerComponent.prototype.updateTiffCanvas = function () {
            var e_1, _a;
            this.tiffImage.setDirectory(this.currentTiffPage);
            var childElements = this.tiffContainer.nativeElement.childNodes;
            try {
                for (var childElements_1 = __values(childElements), childElements_1_1 = childElements_1.next(); !childElements_1_1.done; childElements_1_1 = childElements_1.next()) {
                    var child = childElements_1_1.value;
                    child.parentNode.removeChild(child);
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (childElements_1_1 && !childElements_1_1.done && (_a = childElements_1.return)) _a.call(childElements_1);
                }
                finally { if (e_1) throw e_1.error; }
            }
            this.tiffContainer.nativeElement.appendChild(this.tiffImage.toCanvas());
        };
        FileViewerComponent.prototype.saveFile = function () {
            fileSaver.saveAs(this.data, decodeURIComponent(this.fileName));
        };
        FileViewerComponent.prototype.close = function () {
            this.visible = false;
        };
        FileViewerComponent.prototype.scale = function (ratio) {
            this.scaleRatio = Math.max(0.1, Math.min(2, this.scaleRatio + ratio));
        };
        FileViewerComponent.prototype.onWheelScroll = function (event) {
            if (event.shiftKey) {
                this.scale(event.deltaY * -0.001);
            }
        };
        FileViewerComponent.prototype.onPageChange = function (event) {
            this.currentTiffPage = event.page;
            this.updateTiffCanvas();
        };
        FileViewerComponent.prototype.getSanitizedTransform = function () {
            return this.sanitizer.bypassSecurityTrustStyle('translate(0px, 0px) scale(' + this.scaleRatio + ')');
        };
        FileViewerComponent.ɵfac = function FileViewerComponent_Factory(t) { return new (t || FileViewerComponent)(core["ɵɵdirectiveInject"](api.MessageService), core["ɵɵdirectiveInject"](FileLoadService), core["ɵɵdirectiveInject"](platformBrowser.DomSanitizer)); };
        FileViewerComponent.ɵcmp = core["ɵɵdefineComponent"]({ type: FileViewerComponent, selectors: [["app-file-viewer"]], viewQuery: function FileViewerComponent_Query(rf, ctx) { if (rf & 1) {
                core["ɵɵviewQuery"](_c0$c, true);
            } if (rf & 2) {
                var _t;
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.tiffContainer = _t.first);
            } }, features: [core["ɵɵProvidersFeature"]([]), core["ɵɵInheritDefinitionFeature"]], decls: 15, vars: 17, consts: [["maximizable", "true", "resizable", "true", "breakpoint", "1100"], [2, "display", "inline-flex"], ["pButton", "", "icon", "fa fa-plus", "pTooltip", "\u0423\u0432\u0435\u043B\u0438\u0447\u0438\u0442\u044C (Shift + \u043A\u043E\u043B\u0435\u0441\u043E \u043C\u044B\u0448\u0438)", 3, "click", 4, "ngIf"], ["pButton", "", "icon", "fa fa-minus", "pTooltip", "\u0423\u043C\u0435\u043D\u044C\u0448\u0438\u0442\u044C (Shift + \u043A\u043E\u043B\u0435\u0441\u043E \u043C\u044B\u0448\u0438)", 3, "click", 4, "ngIf"], ["class", "splitter", 4, "ngIf"], ["pButton", "", "icon", "fa fa-file-import", "pTooltip", "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0444\u0430\u0439\u043B", 3, "click", 4, "ngIf"], [2, "width", "100%", "height", "100%", "overflow", "hidden"], ["width", "100%", "height", "100%", 3, "type", 4, "ngIf"], [3, "wheel"], ["id", "scaleContainer"], ["id", "objectContainer", "style", "max-height: 100%; max-width: 100%", 3, "type", 4, "ngIf"], ["id", "tiffContainer", 4, "ngIf"], ["style", "z-index: 99999; position:absolute; bottom:0; left:50%; margin-left: -200px;", 4, "ngIf"], ["pButton", "", "icon", "fa fa-plus", "pTooltip", "\u0423\u0432\u0435\u043B\u0438\u0447\u0438\u0442\u044C (Shift + \u043A\u043E\u043B\u0435\u0441\u043E \u043C\u044B\u0448\u0438)", 3, "click"], ["pButton", "", "icon", "fa fa-minus", "pTooltip", "\u0423\u043C\u0435\u043D\u044C\u0448\u0438\u0442\u044C (Shift + \u043A\u043E\u043B\u0435\u0441\u043E \u043C\u044B\u0448\u0438)", 3, "click"], [1, "splitter"], ["pButton", "", "icon", "fa fa-file-import", "pTooltip", "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0444\u0430\u0439\u043B", 3, "click"], ["width", "100%", "height", "100%", 3, "type"], ["id", "objectContainer", 2, "max-height", "100%", "max-width", "100%", 3, "type"], ["id", "tiffContainer"], ["tiffContainer", ""], [2, "z-index", "99999", "position", "absolute", "bottom", "0", "left", "50%", "margin-left", "-200px"], [3, "rows", "totalRecords", "onPageChange"]], template: function FileViewerComponent_Template(rf, ctx) { if (rf & 1) {
                core["ɵɵelementStart"](0, "p-dialog", 0);
                core["ɵɵelementStart"](1, "p-header");
                core["ɵɵelementStart"](2, "div", 1);
                core["ɵɵtemplate"](3, FileViewerComponent_button_3_Template, 1, 0, "button", 2);
                core["ɵɵtemplate"](4, FileViewerComponent_button_4_Template, 1, 0, "button", 3);
                core["ɵɵtemplate"](5, FileViewerComponent_div_5_Template, 1, 0, "div", 4);
                core["ɵɵtemplate"](6, FileViewerComponent_button_6_Template, 1, 0, "button", 5);
                core["ɵɵtemplate"](7, FileViewerComponent_div_7_Template, 1, 0, "div", 4);
                core["ɵɵelementEnd"]();
                core["ɵɵelementEnd"]();
                core["ɵɵelementStart"](8, "div", 6);
                core["ɵɵtemplate"](9, FileViewerComponent_object_9_Template, 1, 2, "object", 7);
                core["ɵɵelementStart"](10, "p-scrollPanel", 8);
                core["ɵɵlistener"]("wheel", function FileViewerComponent_Template_p_scrollPanel_wheel_10_listener($event) { return ctx.onWheelScroll($event); });
                core["ɵɵelementStart"](11, "div", 9);
                core["ɵɵtemplate"](12, FileViewerComponent_object_12_Template, 1, 2, "object", 10);
                core["ɵɵtemplate"](13, FileViewerComponent_div_13_Template, 2, 0, "div", 11);
                core["ɵɵelementEnd"]();
                core["ɵɵelementEnd"]();
                core["ɵɵtemplate"](14, FileViewerComponent_div_14_Template, 2, 2, "div", 12);
                core["ɵɵelementEnd"]();
                core["ɵɵelementEnd"]();
            } if (rf & 2) {
                core["ɵɵstyleMap"](core["ɵɵpureFunction0"](15, _c1$6));
                core["ɵɵadvance"](3);
                core["ɵɵproperty"]("ngIf", !ctx.isPDF);
                core["ɵɵadvance"](1);
                core["ɵɵproperty"]("ngIf", !ctx.isPDF);
                core["ɵɵadvance"](1);
                core["ɵɵproperty"]("ngIf", !ctx.isPDF && ctx.isAvailableToDownload);
                core["ɵɵadvance"](1);
                core["ɵɵproperty"]("ngIf", ctx.isAvailableToDownload);
                core["ɵɵadvance"](1);
                core["ɵɵproperty"]("ngIf", ctx.isTiff && ctx.maxTiffPages > 1);
                core["ɵɵadvance"](2);
                core["ɵɵproperty"]("ngIf", ctx.isPDF);
                core["ɵɵadvance"](1);
                core["ɵɵstyleMap"](core["ɵɵpureFunction0"](16, _c2$5));
                core["ɵɵadvance"](1);
                core["ɵɵstyleProp"]("transform", ctx.getSanitizedTransform());
                core["ɵɵadvance"](1);
                core["ɵɵproperty"]("ngIf", !ctx.isPDF && !ctx.isTiff);
                core["ɵɵadvance"](1);
                core["ɵɵproperty"]("ngIf", ctx.isTiff);
                core["ɵɵadvance"](1);
                core["ɵɵproperty"]("ngIf", ctx.isTiff && ctx.maxTiffPages > 1);
            } }, directives: [DialogExtDirective, dialog.Dialog, api.Header, common.NgIf, scrollpanel.ScrollPanel, ButtonDirective, button.ButtonDirective, TooltipExtDirective, tooltip.Tooltip, paginator.Paginator], styles: ["[_nghost-%COMP%] .ui-dialog .ui-dialog-content{padding:0!important}button[_ngcontent-%COMP%]{margin-left:5px}.splitter[_ngcontent-%COMP%]{height:1.5em;display:inline-block;width:1px;background-color:#aaa;margin:.35em}[_nghost-%COMP%] .ui-scrollpanel-content{display:-webkit-box;display:flex;-webkit-box-pack:center;justify-content:center;-webkit-box-align:center;align-items:center}#scaleContainer[_ngcontent-%COMP%]{text-align:center;-webkit-transform-origin:center top;transform-origin:center top;width:100%;height:100%}#objectContainer[_ngcontent-%COMP%]{pointer-events:none}"] });
        return FileViewerComponent;
    }(DialogComponent));
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](FileViewerComponent, [{
            type: core.Component,
            args: [{
                    selector: 'app-file-viewer',
                    templateUrl: './file-viewer.component.html',
                    styleUrls: ['./file-viewer.component.css'],
                    providers: []
                }]
        }], function () { return [{ type: api.MessageService }, { type: FileLoadService }, { type: platformBrowser.DomSanitizer }]; }, { tiffContainer: [{
                type: core.ViewChild,
                args: ['tiffContainer']
            }] }); })();

    var SizeableTreeDirective = /** @class */ (function () {
        function SizeableTreeDirective(treeTable) {
            this.treeTable = treeTable;
        }
        SizeableTreeDirective.prototype.ngAfterViewInit = function () {
            var _this = this;
            if (this.treeTable.resizableColumns && this.treeTable.scrollable) {
                this.treeTable.onColResize.subscribe(function () {
                    _this.onColumnResize();
                });
                this.unfrozenView = this.treeTable.el.nativeElement.querySelector('.ui-treetable-scrollable-view');
                this.unfrozenBody = this.unfrozenView.querySelector('.ui-treetable-scrollable-body');
                var iframe_1 = document.createElement('iframe');
                iframe_1.id = 'hacky-scrollbar-resize-listener';
                iframe_1.style.cssText = 'height: 0; background-color: transparent; margin: 0; padding: 0; overflow: hidden; border-width: 0; position: absolute; width: 100%;';
                var self_1 = this;
                // Register our event when the iframe loads
                iframe_1.onload = function () {
                    // The trick here is that because this iframe has 100% width
                    // it should fire a window resize event when anything causes it to
                    // resize (even scrollbars on the outer element)
                    iframe_1.contentWindow.addEventListener('resize', function () {
                        self_1.onColumnResize();
                    });
                };
                // Stick the iframe somewhere out of the way
                this.unfrozenBody.appendChild(iframe_1);
                this.iframe = iframe_1;
                setTimeout(function () {
                    _this.onColumnResize();
                });
            }
        };
        SizeableTreeDirective.prototype.onColumnResize = function () {
            var tw = this.treeTable.el.nativeElement.querySelector('div.ui-treetable').offsetWidth;
            var tbls = this.treeTable.el.nativeElement.querySelectorAll('table');
            tbls[0].style.setProperty('width', tw + 'px');
            tbls[1].style.setProperty('width', (this.iframe.offsetWidth - 1) + 'px');
            if (tbls.length === 3) {
                tbls[2].style.setProperty('width', tw + 'px');
            }
        };
        SizeableTreeDirective.ɵfac = function SizeableTreeDirective_Factory(t) { return new (t || SizeableTreeDirective)(core["ɵɵdirectiveInject"](treetable.TreeTable)); };
        SizeableTreeDirective.ɵdir = core["ɵɵdefineDirective"]({ type: SizeableTreeDirective, selectors: [["p-treeTable"]] });
        return SizeableTreeDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](SizeableTreeDirective, [{
            type: core.Directive,
            args: [{
                    selector: "p-treeTable"
                }]
        }], function () { return [{ type: treetable.TreeTable }]; }, null); })();

    var AutocompleteFixDirective = /** @class */ (function () {
        function AutocompleteFixDirective(autocomplete) {
            var onOverlayAnimationDone = autocomplete.onOverlayAnimationDone.bind(autocomplete);
            autocomplete.onOverlayAnimationDone = function (e) {
                if (!autocomplete.forceSelection) {
                    onOverlayAnimationDone(e);
                }
            };
            var onOverlayHide = function () {
                this.unbindDocumentClickListener();
                this.unbindDocumentResizeListener();
                this.overlay = null;
                this.onHide.emit({}); // patching for this line, original: this.onHide.emit(event)
            };
            autocomplete.onOverlayHide = onOverlayHide.bind(autocomplete);
        }
        AutocompleteFixDirective.ɵfac = function AutocompleteFixDirective_Factory(t) { return new (t || AutocompleteFixDirective)(core["ɵɵdirectiveInject"](autocomplete.AutoComplete)); };
        AutocompleteFixDirective.ɵdir = core["ɵɵdefineDirective"]({ type: AutocompleteFixDirective, selectors: [["p-autoComplete"]] });
        return AutocompleteFixDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](AutocompleteFixDirective, [{
            type: core.Directive,
            args: [{
                    selector: 'p-autoComplete'
                }]
        }], function () { return [{ type: autocomplete.AutoComplete }]; }, null); })();

    var DialogBreakpointsDirective = /** @class */ (function () {
        function DialogBreakpointsDirective(dialog) {
            this.dialog = dialog;
        }
        Object.defineProperty(DialogBreakpointsDirective.prototype, "breakpoints", {
            set: function (breakpoints) {
                this._breakpoints = breakpoints;
                this.updateSize();
            },
            enumerable: true,
            configurable: true
        });
        DialogBreakpointsDirective.prototype.ngOnInit = function () {
            this.updateSize();
        };
        DialogBreakpointsDirective.prototype.onWindowResize = function () {
            this.updateSize();
        };
        DialogBreakpointsDirective.prototype.updateSize = function () {
            var e_1, _a;
            if (!this._breakpoints || !this._breakpoints.length) {
                return;
            }
            if (!this.dialog.style) {
                this.dialog.style = {};
            }
            var baseWidth = this._breakpoints[0];
            this.dialog.style.width = baseWidth;
            this.dialog.breakpoint = this.getPixelWidth(baseWidth);
            if (window.innerWidth < this.dialog.breakpoint) {
                this.dialog.style.width = '100%';
                this.dialog.style.left = '0px';
            }
            else {
                try {
                    for (var _b = __values(this._breakpoints.slice(1)), _c = _b.next(); !_c.done; _c = _b.next()) {
                        var width = _c.value;
                        if (window.innerWidth > this.getPixelWidth(width)) {
                            this.dialog.style.width = width;
                            break;
                        }
                    }
                }
                catch (e_1_1) { e_1 = { error: e_1_1 }; }
                finally {
                    try {
                        if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                    }
                    finally { if (e_1) throw e_1.error; }
                }
            }
            if (this.dialog.container) {
                this.dialog.container.style.left = 'unset';
                this.dialog.container.style.top = 'unset';
            }
        };
        DialogBreakpointsDirective.prototype.getPixelWidth = function (width) {
            var widthNum = Number.parseFloat(width);
            var pixelWidth = widthNum;
            if (width.indexOf('em')) {
                var fontSize = getComputedStyle(this.dialog.el.nativeElement).getPropertyValue('font-size');
                var fontSizeNum = Number.parseFloat(fontSize);
                if (fontSize.indexOf('pt') > 0) {
                    fontSizeNum = fontSizeNum * 4 / 3;
                }
                pixelWidth = fontSizeNum * widthNum;
            }
            return pixelWidth;
        };
        DialogBreakpointsDirective.ɵfac = function DialogBreakpointsDirective_Factory(t) { return new (t || DialogBreakpointsDirective)(core["ɵɵdirectiveInject"](dialog.Dialog)); };
        DialogBreakpointsDirective.ɵdir = core["ɵɵdefineDirective"]({ type: DialogBreakpointsDirective, selectors: [["p-dialog", "breakpoints", ""]], hostBindings: function DialogBreakpointsDirective_HostBindings(rf, ctx) { if (rf & 1) {
                core["ɵɵlistener"]("resize", function DialogBreakpointsDirective_resize_HostBindingHandler() { return ctx.onWindowResize(); }, false, core["ɵɵresolveWindow"]);
            } }, inputs: { breakpoints: "breakpoints" } });
        return DialogBreakpointsDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](DialogBreakpointsDirective, [{
            type: core.Directive,
            args: [{
                    selector: 'p-dialog[breakpoints]'
                }]
        }], function () { return [{ type: dialog.Dialog }]; }, { breakpoints: [{
                type: core.Input
            }], onWindowResize: [{
                type: core.HostListener,
                args: ['window:resize']
            }] }); })();

    var _c0$d = ["primaryComponent"];
    var _c1$7 = ["secondaryComponent"];
    var SplitPaneComponent = /** @class */ (function () {
        function SplitPaneComponent() {
            this.initialRatio = 0.5;
            this.primaryMinSize = 0;
            this.secondaryMinSize = 0;
            this.separatorThickness = 7;
            this.primaryToggledOff = false;
            this.secondaryToggledOff = false;
            this.localStorageKey = null;
            this.notifySizeDidChange = new core.EventEmitter();
            this.notifyBeginResizing = new core.EventEmitter();
            this.notifyEndedResizing = new core.EventEmitter();
            this.dividerSize = 8.0;
            this.isResizing = false;
        }
        SplitPaneComponent.prototype.ngAfterViewInit = function () {
            this.checkBothToggledOff();
            if (!this.primaryToggledOff && !this.secondaryToggledOff) {
                var ratio = this.initialRatio;
                if (this.localStorageKey != null) {
                    var ratioStr = localStorage.getItem(this.localStorageKey);
                    if (ratioStr != null) {
                        ratio = JSON.parse(ratioStr);
                    }
                }
                var size = ratio * this.getTotalSize();
                this.applySizeChange(size);
            }
        };
        SplitPaneComponent.prototype.ngOnChanges = function (changes) {
            this.checkBothToggledOff();
            if (changes['primaryToggledOff']) {
                if (changes['primaryToggledOff'].currentValue === true) {
                    this.primarySizeBeforeTogglingOff = this.getPrimarySize();
                    this.applySizeChange(0);
                }
                else {
                    this.applySizeChange(this.primarySizeBeforeTogglingOff);
                }
            }
            else if (changes['secondaryToggledOff']) {
                if (changes['secondaryToggledOff'].currentValue === true) {
                    this.primarySizeBeforeTogglingOff = this.getPrimarySize();
                    this.applySizeChange(this.getTotalSize());
                }
                else {
                    this.applySizeChange(this.primarySizeBeforeTogglingOff);
                }
            }
        };
        SplitPaneComponent.prototype.getTotalSize = function () {
            throw ("SplitPaneComponent shouldn't be instantiated. Override this method.");
        };
        SplitPaneComponent.prototype.getPrimarySize = function () {
            throw ("SplitPaneComponent shouldn't be instantiated. Override this method.");
        };
        SplitPaneComponent.prototype.getSecondarySize = function () {
            throw ("SplitPaneComponent shouldn't be instantiated. Override this method.");
        };
        SplitPaneComponent.prototype.dividerPosition = function (size) {
            throw ("SplitPaneComponent shouldn't be instantiated. Override this method.");
        };
        SplitPaneComponent.prototype.getAvailableSize = function () {
            return this.getTotalSize() - this.dividerSize;
        };
        SplitPaneComponent.prototype.applySizeChange = function (size) {
            var primarySize = this.checkValidBounds(size, this.primaryMinSize, this.getAvailableSize() - this.secondaryMinSize);
            if (this.primaryToggledOff) {
                primarySize = 0;
            }
            else if (this.secondaryToggledOff) {
                primarySize = this.getTotalSize();
            }
            this.dividerPosition(primarySize);
            this.notifySizeDidChange.emit({ 'primary': this.getPrimarySize(), 'secondary': this.getSecondarySize() });
        };
        SplitPaneComponent.prototype.notifyWillChangeSize = function (resizing) {
            this.isResizing = resizing;
            this.notifyBeginResizing.emit();
        };
        SplitPaneComponent.prototype.checkValidBounds = function (newSize, minSize, maxSize) {
            return newSize >= minSize
                ? (newSize <= maxSize)
                    ? newSize
                    : maxSize
                : minSize;
        };
        SplitPaneComponent.prototype.checkBothToggledOff = function () {
            // We do not allow both the primary and secondary content to be toggled off
            // at the same time, because then it would be very confusing.
            if (this.primaryToggledOff && this.secondaryToggledOff) {
                throw ('You cannot toggle off both the primary and secondary component');
            }
        };
        SplitPaneComponent.prototype.stopResizing = function () {
            this.isResizing = false;
            this.primaryComponent.nativeElement.style.cursor = "auto";
            this.secondaryComponent.nativeElement.style.cursor = "auto";
            if (this.localStorageKey != null) {
                var ratio = this.getPrimarySize() / (this.getTotalSize());
                localStorage.setItem(this.localStorageKey, JSON.stringify(ratio));
            }
            this.notifyEndedResizing.emit();
        };
        SplitPaneComponent.prototype.onMouseup = function (event) {
            if (this.isResizing) {
                this.stopResizing();
                return false;
            }
        };
        SplitPaneComponent.ɵfac = function SplitPaneComponent_Factory(t) { return new (t || SplitPaneComponent)(); };
        SplitPaneComponent.ɵcmp = core["ɵɵdefineComponent"]({ type: SplitPaneComponent, selectors: [["split-pane"]], viewQuery: function SplitPaneComponent_Query(rf, ctx) { if (rf & 1) {
                core["ɵɵstaticViewQuery"](_c0$d, true);
                core["ɵɵstaticViewQuery"](_c1$7, true);
            } if (rf & 2) {
                var _t;
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.primaryComponent = _t.first);
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.secondaryComponent = _t.first);
            } }, hostAttrs: [2, "height", "100%"], hostBindings: function SplitPaneComponent_HostBindings(rf, ctx) { if (rf & 1) {
                core["ɵɵlistener"]("mouseup", function SplitPaneComponent_mouseup_HostBindingHandler($event) { return ctx.onMouseup($event); })("touchend", function SplitPaneComponent_touchend_HostBindingHandler($event) { return ctx.onMouseup($event); });
            } }, inputs: { initialRatio: ["primary-component-initialratio", "initialRatio"], primaryMinSize: ["primary-component-minsize", "primaryMinSize"], secondaryMinSize: ["secondary-component-minsize", "secondaryMinSize"], separatorThickness: ["separator-thickness", "separatorThickness"], primaryToggledOff: ["primary-component-toggled-off", "primaryToggledOff"], secondaryToggledOff: ["secondary-component-toggled-off", "secondaryToggledOff"], localStorageKey: ["local-storage-key", "localStorageKey"] }, outputs: { notifySizeDidChange: "on-change", notifyBeginResizing: "on-begin-resizing", notifyEndedResizing: "on-ended-resizing" }, features: [core["ɵɵNgOnChangesFeature"]()], decls: 0, vars: 0, template: function SplitPaneComponent_Template(rf, ctx) { }, encapsulation: 2 });
        return SplitPaneComponent;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](SplitPaneComponent, [{
            type: core.Component,
            args: [{
                    selector: 'split-pane',
                    template: '',
                    host: { 'style': 'height: 100%' }
                }]
        }], null, { primaryComponent: [{
                type: core.ViewChild,
                args: ['primaryComponent', { static: true }]
            }], secondaryComponent: [{
                type: core.ViewChild,
                args: ['secondaryComponent', { static: true }]
            }], initialRatio: [{
                type: core.Input,
                args: ['primary-component-initialratio']
            }], primaryMinSize: [{
                type: core.Input,
                args: ['primary-component-minsize']
            }], secondaryMinSize: [{
                type: core.Input,
                args: ['secondary-component-minsize']
            }], separatorThickness: [{
                type: core.Input,
                args: ['separator-thickness']
            }], primaryToggledOff: [{
                type: core.Input,
                args: ['primary-component-toggled-off']
            }], secondaryToggledOff: [{
                type: core.Input,
                args: ['secondary-component-toggled-off']
            }], localStorageKey: [{
                type: core.Input,
                args: ['local-storage-key']
            }], notifySizeDidChange: [{
                type: core.Output,
                args: ['on-change']
            }], notifyBeginResizing: [{
                type: core.Output,
                args: ['on-begin-resizing']
            }], notifyEndedResizing: [{
                type: core.Output,
                args: ['on-ended-resizing']
            }], onMouseup: [{
                type: core.HostListener,
                args: ['mouseup', ['$event']]
            }, {
                type: core.HostListener,
                args: ['touchend', ['$event']]
            }] }); })();

    var PositionService = /** @class */ (function () {
        function PositionService() {
        }
        /**
         * Provides read-only equivalent of jQuery's position function:
         * http://api.jquery.com/position/
         */
        PositionService.position = function (element) {
            var nativeEl = element.nativeElement;
            var elBCR = this.offset(nativeEl);
            var offsetParentBCR = { top: 0, left: 0 };
            var offsetParentEl = this.parentOffsetEl(nativeEl);
            if (offsetParentEl !== document) {
                offsetParentBCR = this.offset(offsetParentEl);
                offsetParentBCR.top += offsetParentEl.clientTop - offsetParentEl.scrollTop;
                offsetParentBCR.left += offsetParentEl.clientLeft - offsetParentEl.scrollLeft;
            }
            var boundingClientRect = nativeEl.getBoundingClientRect();
            return {
                width: boundingClientRect.width || nativeEl.offsetWidth,
                height: boundingClientRect.height || nativeEl.offsetHeight,
                top: elBCR.top - offsetParentBCR.top,
                left: elBCR.left - offsetParentBCR.left
            };
        };
        /**
         * Provides read-only equivalent of jQuery's offset function:
         * http://api.jquery.com/offset/
         */
        PositionService.offset = function (element) {
            var nativeEl = element.nativeElement;
            var boundingClientRect = nativeEl.getBoundingClientRect();
            return {
                width: boundingClientRect.width || nativeEl.offsetWidth,
                height: boundingClientRect.height || nativeEl.offsetHeight,
                top: boundingClientRect.top + (window.pageYOffset || document.documentElement.scrollTop),
                left: boundingClientRect.left + (window.pageXOffset || document.documentElement.scrollLeft)
            };
        };
        /**
         * Provides coordinates for the targetEl in relation to hostEl
         */
        PositionService.positionElements = function (host, target, positionStr, appendToBody) {
            var hostEl = host.nativeElement;
            var targetEl = target.nativeElement;
            var positionStrParts = positionStr.split('-');
            var pos0 = positionStrParts[0];
            var pos1 = positionStrParts[1] || 'center';
            var hostElPos = appendToBody ?
                this.offset(hostEl) :
                this.position(hostEl);
            var targetElWidth = targetEl.offsetWidth;
            var targetElHeight = targetEl.offsetHeight;
            var shiftWidth = {
                center: function () {
                    return hostElPos.left + hostElPos.width / 2 - targetElWidth / 2;
                },
                left: function () {
                    return hostElPos.left;
                },
                right: function () {
                    return hostElPos.left + hostElPos.width;
                }
            };
            var shiftHeight = {
                center: function () {
                    return hostElPos.top + hostElPos.height / 2 - targetElHeight / 2;
                },
                top: function () {
                    return hostElPos.top;
                },
                bottom: function () {
                    return hostElPos.top + hostElPos.height;
                }
            };
            var targetElPos;
            switch (pos0) {
                case 'right':
                    targetElPos = {
                        top: shiftHeight[pos1](),
                        left: shiftWidth[pos0]()
                    };
                    break;
                case 'left':
                    targetElPos = {
                        top: shiftHeight[pos1](),
                        left: hostElPos.left - targetElWidth
                    };
                    break;
                case 'bottom':
                    targetElPos = {
                        top: shiftHeight[pos0](),
                        left: shiftWidth[pos1]()
                    };
                    break;
                default:
                    targetElPos = {
                        top: hostElPos.top - targetElHeight,
                        left: shiftWidth[pos1]()
                    };
                    break;
            }
            return targetElPos;
        };
        PositionService.getStyle = function (nativeEl, cssProp) {
            // IE
            if (nativeEl.currentStyle) {
                return nativeEl.currentStyle[cssProp];
            }
            if (window.getComputedStyle) {
                return window.getComputedStyle(nativeEl)[cssProp];
            }
            // finally try and get inline style
            return nativeEl.style[cssProp];
        };
        /**
         * Checks if a given element is statically positioned
         * @param nativeEl - raw DOM element
         */
        PositionService.isStaticPositioned = function (nativeEl) {
            return (this.getStyle(nativeEl, 'position') || 'static') === 'static';
        };
        /**
         * returns the closest, non-statically positioned parentOffset of a given element
         * @param nativeEl
         */
        PositionService.parentOffsetEl = function (nativeEl) {
            var offsetParent = nativeEl.offsetParent || document;
            while (offsetParent && offsetParent !== document &&
                this.isStaticPositioned(offsetParent)) {
                offsetParent = offsetParent.offsetParent;
            }
            return offsetParent || document;
        };
        ;
        return PositionService;
    }());

    var _c0$e = ["invisibleExtension"];
    var SplitSeparatorComponent = /** @class */ (function () {
        function SplitSeparatorComponent() {
            this.notifyWillChangeSize = new core.EventEmitter();
        }
        SplitSeparatorComponent.prototype.ngOnInit = function () {
        };
        SplitSeparatorComponent.prototype.onMousedown = function (event) {
            this.notifyWillChangeSize.emit(true);
            return false;
        };
        SplitSeparatorComponent.ɵfac = function SplitSeparatorComponent_Factory(t) { return new (t || SplitSeparatorComponent)(); };
        SplitSeparatorComponent.ɵcmp = core["ɵɵdefineComponent"]({ type: SplitSeparatorComponent, selectors: [["ng-component"]], viewQuery: function SplitSeparatorComponent_Query(rf, ctx) { if (rf & 1) {
                core["ɵɵviewQuery"](_c0$e, true);
            } if (rf & 2) {
                var _t;
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.invisibleExtension = _t.first);
            } }, hostBindings: function SplitSeparatorComponent_HostBindings(rf, ctx) { if (rf & 1) {
                core["ɵɵlistener"]("mousedown", function SplitSeparatorComponent_mousedown_HostBindingHandler($event) { return ctx.onMousedown($event); });
            } }, inputs: { thickness: "thickness" }, outputs: { notifyWillChangeSize: "notifyWillChangeSize" }, decls: 0, vars: 0, template: function SplitSeparatorComponent_Template(rf, ctx) { }, encapsulation: 2 });
        return SplitSeparatorComponent;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](SplitSeparatorComponent, [{
            type: core.Component,
            args: [{
                    template: ''
                }]
        }], function () { return []; }, { thickness: [{
                type: core.Input
            }], notifyWillChangeSize: [{
                type: core.Output
            }], invisibleExtension: [{
                type: core.ViewChild,
                args: ['invisibleExtension']
            }], onMousedown: [{
                type: core.HostListener,
                args: ['mousedown', ['$event']]
            }] }); })();

    var HorizontalSplitSeparatorComponent = /** @class */ (function (_super) {
        __extends(HorizontalSplitSeparatorComponent, _super);
        function HorizontalSplitSeparatorComponent() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        HorizontalSplitSeparatorComponent.prototype.ngAfterViewInit = function () {
            this.invisibleExtension.nativeElement.style.top =
                -(7 - this.thickness) / 2 + "px";
        };
        HorizontalSplitSeparatorComponent.ɵfac = function HorizontalSplitSeparatorComponent_Factory(t) { return ɵHorizontalSplitSeparatorComponent_BaseFactory(t || HorizontalSplitSeparatorComponent); };
        HorizontalSplitSeparatorComponent.ɵcmp = core["ɵɵdefineComponent"]({ type: HorizontalSplitSeparatorComponent, selectors: [["horizontal-split-separator"]], hostVars: 2, hostBindings: function HorizontalSplitSeparatorComponent_HostBindings(rf, ctx) { if (rf & 2) {
                core["ɵɵstyleProp"]("height", ctx.thickness, "px");
            } }, features: [core["ɵɵInheritDefinitionFeature"]], decls: 3, vars: 1, consts: [[1, "invisible-extension", 3, "hidden"], ["invisibleExtension", ""], [1, "handle"]], template: function HorizontalSplitSeparatorComponent_Template(rf, ctx) { if (rf & 1) {
                core["ɵɵelement"](0, "div", 0, 1);
                core["ɵɵelement"](2, "div", 2);
            } if (rf & 2) {
                core["ɵɵproperty"]("hidden", ctx.thickness >= 7);
            } }, styles: ["[_nghost-%COMP%] {\n      background-color: #fff;\n      border-top: 1px solid #ddd;\n      cursor: ns-resize;\n      position: relative;\n    }\n    [_nghost-%COMP%]:hover {\n      background-color: #fafafa;\n    }\n\n    .invisible-extension[_ngcontent-%COMP%] {\n      position: absolute;\n      height: 100%;\n      width: 100%;\n      min-height: 7px;\n    }\n\n    .handle[_ngcontent-%COMP%] {\n      width: 35px;\n      height: 100%;\n      background-color: #eee;\n      margin: auto;\n    }"] });
        return HorizontalSplitSeparatorComponent;
    }(SplitSeparatorComponent));
    var ɵHorizontalSplitSeparatorComponent_BaseFactory = core["ɵɵgetInheritedFactory"](HorizontalSplitSeparatorComponent);
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](HorizontalSplitSeparatorComponent, [{
            type: core.Component,
            args: [{
                    selector: 'horizontal-split-separator',
                    styles: ["\n    :host {\n      background-color: #fff;\n      border-top: 1px solid #ddd;\n      cursor: ns-resize;\n      position: relative;\n    }\n    :host:hover {\n      background-color: #fafafa;\n    }\n\n    .invisible-extension {\n      position: absolute;\n      height: 100%;\n      width: 100%;\n      min-height: 7px;\n    }\n\n    .handle {\n      width: 35px;\n      height: 100%;\n      background-color: #eee;\n      margin: auto;\n    }\n  "],
                    template: "\n    <!-- Used to extend the 'draggable' area in case the separator is too thin,\n    so it's not too hard to drag. -->\n    <div\n      #invisibleExtension\n      [hidden]=\"thickness >= 7\"\n      class=\"invisible-extension\"></div>\n\n    <div class=\"handle\"></div>\n  ",
                    host: {
                        '[style.height.px]': 'thickness'
                    }
                }]
        }], null, null); })();

    var _c0$f = ["outer"];
    var _c1$8 = [[["", 8, "split-pane-content-primary"]], [["", 8, "split-pane-content-secondary"]]];
    var _c2$6 = [".split-pane-content-primary", ".split-pane-content-secondary"];
    var HorizontalSplitPaneComponent = /** @class */ (function (_super) {
        __extends(HorizontalSplitPaneComponent, _super);
        function HorizontalSplitPaneComponent() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        HorizontalSplitPaneComponent.prototype.getTotalSize = function () {
            return this.outerContainer.nativeElement.offsetHeight;
        };
        HorizontalSplitPaneComponent.prototype.getPrimarySize = function () {
            return this.primaryComponent.nativeElement.offsetHeight;
        };
        HorizontalSplitPaneComponent.prototype.getSecondarySize = function () {
            return this.secondaryComponent.nativeElement.offsetHeight;
        };
        HorizontalSplitPaneComponent.prototype.dividerPosition = function (size) {
            var sizePct = (size / this.getTotalSize()) * 100.0;
            this.primaryComponent.nativeElement.style.height = sizePct + "%";
            this.secondaryComponent.nativeElement.style.height =
                "calc(" + (100 - sizePct) + "% - " +
                    (this.primaryToggledOff || this.secondaryToggledOff ? 0 : this.separatorThickness) + "px)";
        };
        HorizontalSplitPaneComponent.prototype.onMousemove = function (event) {
            if (this.isResizing) {
                var coords = PositionService.offset(this.primaryComponent);
                this.applySizeChange(event.pageY - coords.top);
                return false;
            }
        };
        HorizontalSplitPaneComponent.ɵfac = function HorizontalSplitPaneComponent_Factory(t) { return ɵHorizontalSplitPaneComponent_BaseFactory(t || HorizontalSplitPaneComponent); };
        HorizontalSplitPaneComponent.ɵcmp = core["ɵɵdefineComponent"]({ type: HorizontalSplitPaneComponent, selectors: [["horizontal-split-pane"]], viewQuery: function HorizontalSplitPaneComponent_Query(rf, ctx) { if (rf & 1) {
                core["ɵɵstaticViewQuery"](_c0$f, true);
            } if (rf & 2) {
                var _t;
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.outerContainer = _t.first);
            } }, hostBindings: function HorizontalSplitPaneComponent_HostBindings(rf, ctx) { if (rf & 1) {
                core["ɵɵlistener"]("mousemove", function HorizontalSplitPaneComponent_mousemove_HostBindingHandler($event) { return ctx.onMousemove($event); });
            } }, inputs: { test: "test" }, features: [core["ɵɵInheritDefinitionFeature"]], ngContentSelectors: _c2$6, decls: 10, vars: 4, consts: [[1, "h-outer"], ["outer", ""], [1, "upper-component", 3, "hidden"], ["primaryComponent", ""], [3, "hidden", "thickness", "notifyWillChangeSize"], ["separator", ""], [1, "lower-component", 3, "hidden"], ["secondaryComponent", ""]], template: function HorizontalSplitPaneComponent_Template(rf, ctx) { if (rf & 1) {
                core["ɵɵprojectionDef"](_c1$8);
                core["ɵɵelementStart"](0, "div", 0, 1);
                core["ɵɵelementStart"](2, "div", 2, 3);
                core["ɵɵprojection"](4);
                core["ɵɵelementEnd"]();
                core["ɵɵelementStart"](5, "horizontal-split-separator", 4, 5);
                core["ɵɵlistener"]("notifyWillChangeSize", function HorizontalSplitPaneComponent_Template_horizontal_split_separator_notifyWillChangeSize_5_listener($event) { return ctx.notifyWillChangeSize($event); });
                core["ɵɵelementEnd"]();
                core["ɵɵelementStart"](7, "div", 6, 7);
                core["ɵɵprojection"](9, 1);
                core["ɵɵelementEnd"]();
                core["ɵɵelementEnd"]();
            } if (rf & 2) {
                core["ɵɵadvance"](2);
                core["ɵɵproperty"]("hidden", ctx.primaryToggledOff);
                core["ɵɵadvance"](3);
                core["ɵɵproperty"]("hidden", ctx.primaryToggledOff || ctx.secondaryToggledOff)("thickness", ctx.separatorThickness);
                core["ɵɵadvance"](2);
                core["ɵɵproperty"]("hidden", ctx.secondaryToggledOff);
            } }, directives: [HorizontalSplitSeparatorComponent], styles: [".h-outer[_ngcontent-%COMP%] {\n      height: 100%;\n      width: 100%;\n      display: flex;\n      flex-flow: column;\n    }\n\n    .upper-component[_ngcontent-%COMP%] {\n      height: calc(50% - 4px);\n    }\n\n    .lower-component[_ngcontent-%COMP%] {\n      height: calc(50% - 4px);\n    }"] });
        return HorizontalSplitPaneComponent;
    }(SplitPaneComponent));
    var ɵHorizontalSplitPaneComponent_BaseFactory = core["ɵɵgetInheritedFactory"](HorizontalSplitPaneComponent);
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](HorizontalSplitPaneComponent, [{
            type: core.Component,
            args: [{
                    selector: 'horizontal-split-pane',
                    styles: ["\n    .h-outer {\n      height: 100%;\n      width: 100%;\n      display: flex;\n      flex-flow: column;\n    }\n\n    .upper-component {\n      height: calc(50% - 4px);\n    }\n\n    .lower-component {\n      height: calc(50% - 4px);\n    }\n  "],
                    template: "\n  <div #outer class=\"h-outer\">\n    <div\n      #primaryComponent\n      [hidden]=\"primaryToggledOff\"\n      class=\"upper-component\">\n      <ng-content select=\".split-pane-content-primary\"></ng-content>\n    </div>\n    <horizontal-split-separator\n      #separator\n      [hidden]=\"primaryToggledOff ||\u00A0secondaryToggledOff\"\n      [thickness]=\"separatorThickness\"\n      (notifyWillChangeSize)=\"notifyWillChangeSize($event)\">\n    </horizontal-split-separator>\n    <div\n      #secondaryComponent\n      [hidden]=\"secondaryToggledOff\"\n      class=\"lower-component\">\n      <ng-content select=\".split-pane-content-secondary\"></ng-content>\n    </div>\n  </div>\n  ",
                }]
        }], null, { outerContainer: [{
                type: core.ViewChild,
                args: ['outer', { static: true }]
            }], test: [{
                type: core.Input
            }], onMousemove: [{
                type: core.HostListener,
                args: ['mousemove', ['$event']]
            }] }); })();

    var HorizontalSplitPaneFix = /** @class */ (function () {
        function HorizontalSplitPaneFix(pane) {
            this.pane = pane;
        }
        HorizontalSplitPaneFix.prototype.ngAfterViewInit = function () {
            if (this.pane.secondaryToggledOff) {
                this.pane.primaryComponent.nativeElement.style.height = "100%";
            }
        };
        HorizontalSplitPaneFix.ɵfac = function HorizontalSplitPaneFix_Factory(t) { return new (t || HorizontalSplitPaneFix)(core["ɵɵdirectiveInject"](HorizontalSplitPaneComponent)); };
        HorizontalSplitPaneFix.ɵdir = core["ɵɵdefineDirective"]({ type: HorizontalSplitPaneFix, selectors: [["horizontal-split-pane"]] });
        return HorizontalSplitPaneFix;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](HorizontalSplitPaneFix, [{
            type: core.Directive,
            args: [{
                    selector: 'horizontal-split-pane'
                }]
        }], function () { return [{ type: HorizontalSplitPaneComponent }]; }, null); })();

    var PDataViewDirective = /** @class */ (function () {
        function PDataViewDirective(view) {
            this.view = view;
            this.view.emptyMessage = 'Записи не найдены';
        }
        PDataViewDirective.prototype.ngAfterViewInit = function () {
        };
        PDataViewDirective.ɵfac = function PDataViewDirective_Factory(t) { return new (t || PDataViewDirective)(core["ɵɵdirectiveInject"](dataview.DataView)); };
        PDataViewDirective.ɵdir = core["ɵɵdefineDirective"]({ type: PDataViewDirective, selectors: [["p-dataView"]] });
        return PDataViewDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](PDataViewDirective, [{
            type: core.Directive,
            args: [{
                    selector: 'p-dataView'
                }]
        }], function () { return [{ type: dataview.DataView }]; }, null); })();

    var PFileUploadDirective = /** @class */ (function () {
        function PFileUploadDirective(fileUpload, authService, bus) {
            this.fileUpload = fileUpload;
            this.authService = authService;
            this.bus = bus;
            this.accept = '.jpg,.txt,.pdf,.tiff,.tif,.jpeg,.png,.bmp,.gif,.doc,.docx,.xls,.xlsx';
            this.customUpload = false;
            this.fileUpload.chooseLabel = 'Выберите файл(ы)';
            this.fileUpload.uploadLabel = 'Загрузить';
            this.fileUpload.cancelLabel = 'Отмена';
            this.fileUpload.invalidFileSizeMessageSummary = '{0}: Неправильный размер файла, ';
            this.fileUpload.invalidFileSizeMessageDetail = 'максимальный размер {0}.';
            this.fileUpload.invalidFileTypeMessageSummary = '{0}: Неправильный тип файла, ';
            this.fileUpload.invalidFileTypeMessageDetail = 'разрешенные типы: {0}.';
            this.fileUpload.withCredentials = true;
            this.fileUpload.name = 'uploadingFiles[]';
            this.fileUpload.maxFileSize = PFileUploadDirective.MAX_UPLOAD_FILESIZE;
            this.fileUpload.accept = this.accept;
            this.fileUpload.customUpload = this.customUpload;
            this.fileUpload.showUploadButton = false;
            this.fileUpload.showCancelButton = false;
        }
        PFileUploadDirective.prototype.ngOnInit = function () {
            var _this = this;
            this.fileUpload.files = [];
            this.fileUpload.onError.subscribe(function (event) { return __awaiter(_this, void 0, void 0, function () {
                var response, message, message;
                var _a;
                return __generator(this, function (_b) {
                    if (!!event.xhr) {
                        switch (event.xhr.status) {
                            case exports.HTTPErrors.TYPE_INSUFFICIENT_STORAGE: {
                                response = JSON.parse(event.xhr.responseText);
                                message = response != null ? (response['message']) : 'unknown';
                                this.bus.emit(new HttpEventbusEvent(event.xhr.status, message));
                                break;
                            }
                        }
                    }
                    else {
                        message = 'Не удалось загрузить файл: ' + ((_a = event.error) === null || _a === void 0 ? void 0 : _a.message) || event.error;
                        this.bus.emit(new HttpEventbusEvent(exports.HTTPErrors.TYPE_PRECONDITION_FAILED, message));
                    }
                    return [2 /*return*/];
                });
            }); });
        };
        PFileUploadDirective.MAX_UPLOAD_FILESIZE = 20 * 1024 * 1024;
        PFileUploadDirective.ɵfac = function PFileUploadDirective_Factory(t) { return new (t || PFileUploadDirective)(core["ɵɵdirectiveInject"](fileupload.FileUpload), core["ɵɵdirectiveInject"](AuthService), core["ɵɵdirectiveInject"](EventBusService)); };
        PFileUploadDirective.ɵdir = core["ɵɵdefineDirective"]({ type: PFileUploadDirective, selectors: [["p-fileUpload"]], inputs: { accept: "accept", customUpload: "customUpload" } });
        return PFileUploadDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](PFileUploadDirective, [{
            type: core.Directive,
            args: [{
                    selector: 'p-fileUpload'
                }]
        }], function () { return [{ type: fileupload.FileUpload }, { type: AuthService }, { type: EventBusService }]; }, { accept: [{
                type: core.Input
            }], customUpload: [{
                type: core.Input
            }] }); })();

    var RequiredIfDirective = /** @class */ (function () {
        function RequiredIfDirective() {
        }
        Object.defineProperty(RequiredIfDirective.prototype, "requiredIf", {
            get: function () { return this._requiredIf; },
            set: function (value) {
                this._requiredIf = value;
                if (this._onChange) {
                    this._onChange();
                }
            },
            enumerable: true,
            configurable: true
        });
        RequiredIfDirective.prototype.validate = function (c) {
            if (c.status === 'VALID' && this.requiredIf) {
                return { requiredIf: { condition: this.requiredIf } };
            }
            return null;
        };
        RequiredIfDirective.prototype.registerOnChange = function (fn) { this._onChange = fn; };
        RequiredIfDirective.prototype.registerOnValidatorChange = function (fn) { this._onChange = fn; };
        RequiredIfDirective.prototype.ngOnChanges = function (changes) {
            if ('requiredIf' in changes) {
                if (this._onChange) {
                    this._onChange();
                }
            }
        };
        RequiredIfDirective.ɵfac = function RequiredIfDirective_Factory(t) { return new (t || RequiredIfDirective)(); };
        RequiredIfDirective.ɵdir = core["ɵɵdefineDirective"]({ type: RequiredIfDirective, selectors: [["", "requiredIf", ""]], inputs: { requiredIf: "requiredIf" }, features: [core["ɵɵProvidersFeature"]([
                    { provide: forms.NG_VALIDATORS, useExisting: core.forwardRef(function () { return RequiredIfDirective; }), multi: true }
                ]), core["ɵɵNgOnChangesFeature"]()] });
        return RequiredIfDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](RequiredIfDirective, [{
            type: core.Directive,
            args: [{
                    selector: '[requiredIf]',
                    providers: [
                        { provide: forms.NG_VALIDATORS, useExisting: core.forwardRef(function () { return RequiredIfDirective; }), multi: true }
                    ]
                }]
        }], function () { return []; }, { requiredIf: [{
                type: core.Input
            }] }); })();

    var DictionaryService = /** @class */ (function (_super) {
        __extends(DictionaryService, _super);
        function DictionaryService(httpClient, authService, bus) {
            var _this = _super.call(this, httpClient, authService, bus) || this;
            _this.httpClient = httpClient;
            _this.authService = authService;
            _this.bus = bus;
            return _this;
        }
        // Поиск справочника по конкретному коду
        DictionaryService.prototype.searchLocalDictionary = function (pageQuery, key, url) {
            return __awaiter(this, void 0, void 0, function () {
                var dictionary;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.httpClient.post(url || "/local-dictionaries/" + key + "/items/search", pageQuery, {}).toPromise()];
                        case 1:
                            dictionary = _a.sent();
                            console.log('fetched dictionary');
                            return [2 /*return*/, dictionary];
                    }
                });
            });
        };
        DictionaryService.prototype.searchDictionary = function (pageQuery, key, filter, filterParams, url) {
            return __awaiter(this, void 0, void 0, function () {
                var httpParams, _a, _b, key_1, dictionary;
                var e_1, _c;
                return __generator(this, function (_d) {
                    switch (_d.label) {
                        case 0:
                            httpParams = new http.HttpParams();
                            if (filter) {
                                httpParams = httpParams.append('filter', filter);
                                if (filterParams) {
                                    try {
                                        for (_a = __values(Object.keys(filterParams)), _b = _a.next(); !_b.done; _b = _a.next()) {
                                            key_1 = _b.value;
                                            if (filterParams[key_1]) {
                                                httpParams = httpParams.append(key_1, filterParams[key_1]);
                                            }
                                        }
                                    }
                                    catch (e_1_1) { e_1 = { error: e_1_1 }; }
                                    finally {
                                        try {
                                            if (_b && !_b.done && (_c = _a.return)) _c.call(_a);
                                        }
                                        finally { if (e_1) throw e_1.error; }
                                    }
                                }
                            }
                            return [4 /*yield*/, this.httpClient.post(url || "/dictionaries/" + key + "/items/search", pageQuery, {
                                    params: httpParams
                                }).toPromise()];
                        case 1:
                            dictionary = _d.sent();
                            console.log('fetched dictionary');
                            return [2 /*return*/, dictionary];
                    }
                });
            });
        };
        DictionaryService.prototype.getMetaInf = function (key) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.httpClient.get("/dictionaries/" + key + "/metainf").toPromise()];
                        case 1: return [2 /*return*/, _a.sent()];
                    }
                });
            });
        };
        DictionaryService.prototype.getViewValue = function (id, key) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.httpClient.get("/dictionaries/views/" + key + "/" + id).toPromise()];
                        case 1: return [2 /*return*/, _a.sent()];
                    }
                });
            });
        };
        DictionaryService.ɵfac = function DictionaryService_Factory(t) { return new (t || DictionaryService)(core["ɵɵinject"](http.HttpClient), core["ɵɵinject"](AuthService), core["ɵɵinject"](EventBusService)); };
        DictionaryService.ɵprov = core["ɵɵdefineInjectable"]({ token: DictionaryService, factory: DictionaryService.ɵfac, providedIn: 'root' });
        return DictionaryService;
    }(BaseService));
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](DictionaryService, [{
            type: core.Injectable,
            args: [{ providedIn: 'root' }]
        }], function () { return [{ type: http.HttpClient }, { type: AuthService }, { type: EventBusService }]; }, null); })();

    var EntityConfigDirective = /** @class */ (function () {
        function EntityConfigDirective(entityConfigService, keyValueDiffers) {
            this.entityConfigService = entityConfigService;
            this.keyValueDiffers = keyValueDiffers;
            this._fieldConfigs = {};
            this.entityChanged = new core.EventEmitter();
        }
        Object.defineProperty(EntityConfigDirective.prototype, "fieldConfigs", {
            get: function () {
                return this._fieldConfigs;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(EntityConfigDirective.prototype, "appEntityConfigName", {
            set: function (configName) {
                this.configName = configName;
                this.loadConfig();
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(EntityConfigDirective.prototype, "appEntityConfig", {
            set: function (config) {
                this._fieldConfigs = config;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(EntityConfigDirective.prototype, "appEntity", {
            get: function () {
                return this.entity;
            },
            set: function (entity) {
                var _this = this;
                this.entity = entity;
                this.differ = this.keyValueDiffers.find(this.entity).create();
                this.differ2 = this.keyValueDiffers.find(this.entity.extension).create();
                if (this.configName) {
                    this.loadConfig();
                }
                setTimeout(function () {
                    _this.entityChanged.emit(_this.entity);
                });
            },
            enumerable: true,
            configurable: true
        });
        EntityConfigDirective.prototype.ngDoCheck = function () {
            if (this.differ) {
                if (this.differ.diff(this.entity) || this.differ2.diff(this.entity.extension)) {
                    this.entityChanged.emit(this.entity);
                }
            }
        };
        EntityConfigDirective.prototype.loadConfig = function () {
            this._fieldConfigs = this.entityConfigService.getEntityConfig(this.configName, this.entity);
        };
        EntityConfigDirective.ɵfac = function EntityConfigDirective_Factory(t) { return new (t || EntityConfigDirective)(core["ɵɵdirectiveInject"](EntityConfigService), core["ɵɵdirectiveInject"](core.KeyValueDiffers)); };
        EntityConfigDirective.ɵdir = core["ɵɵdefineDirective"]({ type: EntityConfigDirective, selectors: [["form", "appEntityConfigName", ""], ["form", "appEntityConfig", ""]], inputs: { appEntityConfigName: "appEntityConfigName", appEntityConfig: "appEntityConfig", appEntity: "appEntity" } });
        return EntityConfigDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](EntityConfigDirective, [{
            type: core.Directive,
            args: [{
                    selector: 'form[appEntityConfigName], form[appEntityConfig]'
                }]
        }], function () { return [{ type: EntityConfigService }, { type: core.KeyValueDiffers }]; }, { appEntityConfigName: [{
                type: core.Input
            }], appEntityConfig: [{
                type: core.Input
            }], appEntity: [{
                type: core.Input
            }] }); })();

    var FieldConfigDirective = /** @class */ (function () {
        function FieldConfigDirective(templateRef, viewContainer, ngForm, entityConfigDirective) {
            this.templateRef = templateRef;
            this.viewContainer = viewContainer;
            this.ngForm = ngForm;
            this.entityConfigDirective = entityConfigDirective;
            this.visible = false;
            this.required = false;
            this.readOnly = false;
            this.changed = false;
        }
        Object.defineProperty(FieldConfigDirective.prototype, "appFieldConfig", {
            set: function (fieldName) {
                this.fieldName = fieldName;
            },
            enumerable: true,
            configurable: true
        });
        FieldConfigDirective.prototype.ngOnInit = function () {
            var _this = this;
            if (this.entityConfigDirective) {
                this.valuesChangeSubscription = this.entityConfigDirective.entityChanged.subscribe(function () {
                    _this.update();
                });
            }
            this.update();
        };
        FieldConfigDirective.prototype.ngOnDestroy = function () {
            if (this.valuesChangeSubscription) {
                this.valuesChangeSubscription.unsubscribe();
            }
        };
        FieldConfigDirective.prototype.ngDoCheck = function () {
            if (this.changed) {
                this.update();
            }
        };
        FieldConfigDirective.prototype.update = function () {
            var _this = this;
            var fieldConfig = this.entityConfigDirective
                ? this.entityConfigDirective.fieldConfigs[this.fieldName]
                : null;
            var visible;
            try {
                visible = !fieldConfig || this.bindEntity(fieldConfig.visible)();
            }
            catch (e) {
                visible = false;
                console.log('Entity-config visible expression error = ' + e);
            }
            if (this.visible !== visible) {
                if (this.visible) {
                    this.visible = false;
                    this.required = false;
                    this.validator = null;
                    this.label = null;
                    this.viewContainer.clear();
                }
                else {
                    this.visible = true;
                    var ref = this.viewContainer.createEmbeddedView(this.templateRef);
                    var node = ref.rootNodes[0];
                    var labels = node.getElementsByTagName('label');
                    if (labels && labels.length > 0) {
                        this.label = labels[0];
                    }
                }
            }
            setTimeout(function () {
                var control = _this.visible && fieldConfig && _this.ngForm.controls[fieldConfig.name];
                if (control) {
                    if (!_this.validator) {
                        _this.validator = _this.bindEntity(control.validator || (function (_) { return null; }));
                    }
                    var required = void 0;
                    try {
                        required = _this.bindEntity(fieldConfig.required)();
                    }
                    catch (e) {
                        required = false;
                        console.log('Entity-config required expression error = ' + e);
                    }
                    var changed = false;
                    if (_this.required !== required) {
                        if (_this.required) {
                            _this.required = false;
                            control.clearValidators();
                            if (_this.label) {
                                _this.label.classList.remove('required');
                            }
                        }
                        else {
                            _this.required = true;
                            control.setValidators([_this.validator, forms.Validators.required]);
                            if (_this.label) {
                                _this.label.classList.add('required');
                            }
                        }
                        changed = true;
                    }
                    var readOnly = void 0;
                    try {
                        readOnly = fieldConfig.readonly();
                    }
                    catch (e) {
                        readOnly = false;
                        console.log('Entity-config readonly expression error = ' + e);
                    }
                    if (_this.readOnly != readOnly) {
                        if (readOnly) {
                            control.disable({ emitEvent: false });
                        }
                        else {
                            control.enable({ emitEvent: false });
                        }
                        _this.readOnly = readOnly;
                        changed = true;
                    }
                    if (changed) {
                        control.updateValueAndValidity();
                    }
                }
            });
        };
        FieldConfigDirective.prototype.bindEntity = function (func) {
            if (this.entityConfigDirective && this.entityConfigDirective.appEntity) {
                return func.bind(__assign(__assign({}, this.entityConfigDirective.appEntity.extension), this.entityConfigDirective.appEntity));
            }
            return func;
        };
        FieldConfigDirective.ɵfac = function FieldConfigDirective_Factory(t) { return new (t || FieldConfigDirective)(core["ɵɵdirectiveInject"](core.TemplateRef), core["ɵɵdirectiveInject"](core.ViewContainerRef), core["ɵɵdirectiveInject"](forms.NgForm), core["ɵɵdirectiveInject"](EntityConfigDirective)); };
        FieldConfigDirective.ɵdir = core["ɵɵdefineDirective"]({ type: FieldConfigDirective, selectors: [["", "appFieldConfig", ""]], inputs: { appFieldConfig: "appFieldConfig" } });
        return FieldConfigDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](FieldConfigDirective, [{
            type: core.Directive,
            args: [{
                    selector: '[appFieldConfig]'
                }]
        }], function () { return [{ type: core.TemplateRef }, { type: core.ViewContainerRef }, { type: forms.NgForm }, { type: EntityConfigDirective }]; }, { appFieldConfig: [{
                type: core.Input
            }] }); })();

    function DictionaryLookupGridComponent_div_0_column_7_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelement"](0, "column", 8);
    } if (rf & 2) {
        var col_r644 = ctx.$implicit;
        core["ɵɵproperty"]("field", col_r644.field)("header", col_r644.header)("type", col_r644.type);
    } }
    function DictionaryLookupGridComponent_div_0_Template(rf, ctx) { if (rf & 1) {
        var _r646 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "div", 1);
        core["ɵɵelementStart"](1, "p-toolbar");
        core["ɵɵelementStart"](2, "div", 2);
        core["ɵɵelementStart"](3, "button", 3);
        core["ɵɵlistener"]("click", function DictionaryLookupGridComponent_div_0_Template_button_click_3_listener() { core["ɵɵrestoreView"](_r646); var _r642 = core["ɵɵreference"](6); return _r642.reload(); });
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
        core["ɵɵelementStart"](4, "div", 4);
        core["ɵɵelementStart"](5, "app-table2", 5, 6);
        core["ɵɵlistener"]("selectionChange", function DictionaryLookupGridComponent_div_0_Template_app_table2_selectionChange_5_listener($event) { core["ɵɵrestoreView"](_r646); var ctx_r647 = core["ɵɵnextContext"](); return ctx_r647.selectedDictionaryRow = $event; })("onLazyLoad", function DictionaryLookupGridComponent_div_0_Template_app_table2_onLazyLoad_5_listener($event) { core["ɵɵrestoreView"](_r646); var ctx_r648 = core["ɵɵnextContext"](); return ctx_r648.onLoad($event); })("rowDoubleClicked", function DictionaryLookupGridComponent_div_0_Template_app_table2_rowDoubleClicked_5_listener() { core["ɵɵrestoreView"](_r646); var ctx_r649 = core["ɵɵnextContext"](); return ctx_r649.rowDoubleClick.emit(); })("cellKeyDown", function DictionaryLookupGridComponent_div_0_Template_app_table2_cellKeyDown_5_listener($event) { core["ɵɵrestoreView"](_r646); var ctx_r650 = core["ɵɵnextContext"](); return ctx_r650.cellKeyDown.emit($event); });
        core["ɵɵtemplate"](7, DictionaryLookupGridComponent_div_0_column_7_Template, 1, 3, "column", 7);
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var ctx_r641 = core["ɵɵnextContext"]();
        core["ɵɵadvance"](5);
        core["ɵɵproperty"]("selection", ctx_r641.selectedDictionaryRow)("filter", true)("lazy", true)("settingsKey", "dictionary-lookup-" + ctx_r641.key);
        core["ɵɵadvance"](2);
        core["ɵɵproperty"]("ngForOf", ctx_r641.columns);
    } }
    var DictionaryLookupGridComponent = /** @class */ (function (_super) {
        __extends(DictionaryLookupGridComponent, _super);
        function DictionaryLookupGridComponent(dictionaryService) {
            var _this = _super.call(this) || this;
            _this.dictionaryService = dictionaryService;
            _this.global = false;
            _this.rowDoubleClick = new core.EventEmitter();
            _this.cellKeyDown = new core.EventEmitter();
            _this._header = 'Справочник';
            return _this;
        }
        Object.defineProperty(DictionaryLookupGridComponent.prototype, "selectedValue", {
            get: function () {
                return this.selectedDictionaryRow;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DictionaryLookupGridComponent.prototype, "header", {
            get: function () {
                return this._header;
            },
            enumerable: true,
            configurable: true
        });
        DictionaryLookupGridComponent.prototype.ngOnInit = function () {
            return __awaiter(this, void 0, void 0, function () {
                var dictionary, columns;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            if (!this.global) return [3 /*break*/, 2];
                            return [4 /*yield*/, this.dictionaryService.getMetaInf(this.key)];
                        case 1:
                            dictionary = _a.sent();
                            columns = dictionary.columns;
                            if (dictionary.header) {
                                this._header = dictionary.header;
                            }
                            this.columns = columns.map(function (c) { return Column.create(c.field, c.header, c.type); });
                            return [3 /*break*/, 3];
                        case 2:
                            this.columns = [
                                Column.create('code', 'Код'),
                                Column.create('value', 'Значение')
                            ];
                            _a.label = 3;
                        case 3: return [2 /*return*/];
                    }
                });
            });
        };
        DictionaryLookupGridComponent.prototype.onLoad = function (event) {
            return __awaiter(this, void 0, void 0, function () {
                var filters, dictionaries, dictionaries, e_1;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            filters = __assign({}, event.filters);
                            if (this.query) {
                                filters['@query'] = { value: this.query };
                            }
                            _a.label = 1;
                        case 1:
                            _a.trys.push([1, 6, , 7]);
                            if (!this.global) return [3 /*break*/, 3];
                            return [4 /*yield*/, this.dictionaryService.searchDictionary(event.pageQuery.clone({ filters: filters }), this.key, this.filter, this.filterParams, this.url)];
                        case 2:
                            dictionaries = _a.sent();
                            event.successCallback(dictionaries.items, dictionaries.total);
                            return [3 /*break*/, 5];
                        case 3: return [4 /*yield*/, this.dictionaryService.searchLocalDictionary(event.pageQuery.clone({ filters: filters }), this.key, this.url)];
                        case 4:
                            dictionaries = _a.sent();
                            event.successCallback(dictionaries.items, dictionaries.total);
                            _a.label = 5;
                        case 5: return [3 /*break*/, 7];
                        case 6:
                            e_1 = _a.sent();
                            event.failCallback();
                            throw e_1;
                        case 7: return [2 /*return*/];
                    }
                });
            });
        };
        DictionaryLookupGridComponent.ɵfac = function DictionaryLookupGridComponent_Factory(t) { return new (t || DictionaryLookupGridComponent)(core["ɵɵdirectiveInject"](DictionaryService)); };
        DictionaryLookupGridComponent.ɵcmp = core["ɵɵdefineComponent"]({ type: DictionaryLookupGridComponent, selectors: [["app-dictionary-lookup-grid"]], inputs: { key: "key", global: "global", textField: "textField", filter: "filter", filterParams: "filterParams", query: "query", url: "url" }, outputs: { rowDoubleClick: "rowDoubleClick", cellKeyDown: "cellKeyDown" }, features: [core["ɵɵProvidersFeature"]([
                    { provide: LookupBaseComponent, useExisting: core.forwardRef(function () { return DictionaryLookupGridComponent; }) }
                ]), core["ɵɵInheritDefinitionFeature"]], decls: 1, vars: 1, consts: [["class", "v-flex", 4, "ngIf"], [1, "v-flex"], [1, "ui-toolbar-group-left"], ["type", "button", "pButton", "", "icon", "fa fa-sync-alt", "pTooltip", "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0442\u0430\u0431\u043B\u0438\u0446\u0443", 3, "click"], [1, "v-flex-grow"], ["selectionMode", "single", 3, "selection", "filter", "lazy", "settingsKey", "selectionChange", "onLazyLoad", "rowDoubleClicked", "cellKeyDown"], ["table", ""], [3, "field", "header", "type", 4, "ngFor", "ngForOf"], [3, "field", "header", "type"]], template: function DictionaryLookupGridComponent_Template(rf, ctx) { if (rf & 1) {
                core["ɵɵtemplate"](0, DictionaryLookupGridComponent_div_0_Template, 8, 5, "div", 0);
            } if (rf & 2) {
                core["ɵɵproperty"]("ngIf", ctx.columns);
            } }, directives: [common.NgIf, toolbar.Toolbar, button.ButtonDirective, TooltipExtDirective, tooltip.Tooltip, Table2Component, common.NgForOf, Column], encapsulation: 2 });
        return DictionaryLookupGridComponent;
    }(LookupBaseComponent));
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](DictionaryLookupGridComponent, [{
            type: core.Component,
            args: [{
                    selector: 'app-dictionary-lookup-grid',
                    templateUrl: './dictionary-lookup-grid.component.html',
                    providers: [
                        { provide: LookupBaseComponent, useExisting: core.forwardRef(function () { return DictionaryLookupGridComponent; }) }
                    ]
                }]
        }], function () { return [{ type: DictionaryService }]; }, { key: [{
                type: core.Input
            }], global: [{
                type: core.Input
            }], textField: [{
                type: core.Input
            }], filter: [{
                type: core.Input
            }], filterParams: [{
                type: core.Input
            }], query: [{
                type: core.Input
            }], url: [{
                type: core.Input
            }], rowDoubleClick: [{
                type: core.Output
            }], cellKeyDown: [{
                type: core.Output
            }] }); })();

    var _c0$g = ["autocomplete"];
    var _c1$9 = ["dialog"];
    var _c2$7 = ["grid"];
    function DictionaryLookupComponent_button_4_Template(rf, ctx) { if (rf & 1) {
        var _r657 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "button", 9);
        core["ɵɵlistener"]("click", function DictionaryLookupComponent_button_4_Template_button_click_0_listener() { core["ɵɵrestoreView"](_r657); var ctx_r656 = core["ɵɵnextContext"](); return ctx_r656.showForm(); });
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        core["ɵɵnextContext"]();
        var _r651 = core["ɵɵreference"](3);
        core["ɵɵproperty"]("disabled", _r651.disabled);
    } }
    function DictionaryLookupComponent_div_7_Template(rf, ctx) { if (rf & 1) {
        var _r660 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "div", 10);
        core["ɵɵelementStart"](1, "app-dictionary-lookup-grid", 11, 12);
        core["ɵɵlistener"]("rowDoubleClick", function DictionaryLookupComponent_div_7_Template_app_dictionary_lookup_grid_rowDoubleClick_1_listener() { core["ɵɵrestoreView"](_r660); var _r658 = core["ɵɵreference"](2); var ctx_r659 = core["ɵɵnextContext"](); return ctx_r659.select(_r658 == null ? null : _r658.selectedValue); })("cellKeyDown", function DictionaryLookupComponent_div_7_Template_app_dictionary_lookup_grid_cellKeyDown_1_listener($event) { core["ɵɵrestoreView"](_r660); var ctx_r661 = core["ɵɵnextContext"](); return ctx_r661.onGridKeyDown($event); });
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var ctx_r654 = core["ɵɵnextContext"]();
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("global", ctx_r654.global)("key", ctx_r654.key)("textField", ctx_r654.textField)("filter", ctx_r654.filter)("filterParams", ctx_r654.filterParams)("query", ctx_r654.query)("url", ctx_r654.url);
    } }
    function DictionaryLookupComponent_p_footer_8_Template(rf, ctx) { if (rf & 1) {
        var _r663 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "p-footer");
        core["ɵɵelementStart"](1, "button", 13);
        core["ɵɵlistener"]("click", function DictionaryLookupComponent_p_footer_8_Template_button_click_1_listener() { core["ɵɵrestoreView"](_r663); var ctx_r662 = core["ɵɵnextContext"](); return ctx_r662.select(ctx_r662.grid == null ? null : ctx_r662.grid.selectedValue); });
        core["ɵɵelementEnd"]();
        core["ɵɵelementStart"](2, "button", 14);
        core["ɵɵlistener"]("click", function DictionaryLookupComponent_p_footer_8_Template_button_click_2_listener() { core["ɵɵrestoreView"](_r663); var ctx_r664 = core["ɵɵnextContext"](); return ctx_r664.display = false; });
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var ctx_r655 = core["ɵɵnextContext"]();
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("disabled", !(ctx_r655.grid == null ? null : ctx_r655.grid.selectedValue));
    } }
    var _c3$2 = function () { return { width: "100%", display: "flex" }; };
    var _c4$2 = function () { return { flex: 1 }; };
    var _c5$1 = function () { return { width: "70vw", height: "80vh" }; };
    var _c6$1 = function () { return { "display": "flex", "min-height": "calc(100% - 7em)", "max-height": "calc(100% - 7em)" }; };
    var DictionaryLookupComponent = /** @class */ (function (_super) {
        __extends(DictionaryLookupComponent, _super);
        function DictionaryLookupComponent(dictionaryService) {
            var _this = _super.call(this) || this;
            _this.dictionaryService = dictionaryService;
            _this.global = true;
            _this.count = 15;
            _this.searchMode = 'startsWith';
            _this.suggestions = [];
            _this.loading = false;
            _this.token = new CancellationToken();
            return _this;
        }
        DictionaryLookupComponent.prototype.ngOnInit = function () {
        };
        DictionaryLookupComponent.prototype.ngAfterViewInit = function () {
            var _this = this;
            this.gridQuery.changes.subscribe(function () {
                var grid = _this.gridQuery.first;
                setTimeout(function () {
                    _this.grid = grid;
                });
            });
        };
        DictionaryLookupComponent.prototype.writeValue = function (obj) {
            this.autocomplete.writeValue(obj);
        };
        DictionaryLookupComponent.prototype.registerOnChange = function (fn) {
            this.onChange = fn;
            this.autocomplete.registerOnChange(this.onChange);
        };
        DictionaryLookupComponent.prototype.registerOnTouched = function (fn) {
            this.autocomplete.registerOnTouched(fn);
        };
        DictionaryLookupComponent.prototype.setValue = function (value) {
            this.writeValue(value);
            this.onChange(value);
        };
        DictionaryLookupComponent.prototype.showForm = function () {
            this.display = true;
        };
        DictionaryLookupComponent.prototype.setDisabledState = function (isDisabled) {
            this.autocomplete.setDisabledState(isDisabled);
        };
        DictionaryLookupComponent.prototype.searchLocalDictionary = function (event, dictKey) {
            return __awaiter(this, void 0, void 0, function () {
                var filters, _a;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            filters = {};
                            filters['value'] = { matchMode: this.searchMode, value: event.query };
                            if (this.query) {
                                filters['@query'] = { value: this.query };
                            }
                            _a = this;
                            return [4 /*yield*/, this.dictionaryService.searchLocalDictionary(new PageQuery({
                                    first: 0,
                                    rows: this.count,
                                    sorts: [{ field: 'value' }],
                                    filters: filters
                                }), dictKey, this.url).autoCancel(this.token)];
                        case 1:
                            _a.suggestions = (_b.sent()).items;
                            this.inputText = event.query;
                            return [2 /*return*/];
                    }
                });
            });
        };
        DictionaryLookupComponent.prototype.getElementByPressEnter = function (keyEvent) {
            return __awaiter(this, void 0, void 0, function () {
                var fetchingElement_1, compareLine_1;
                var _this = this;
                return __generator(this, function (_a) {
                    if (keyEvent.key == 'Enter') {
                        this.sortField ? compareLine_1 = this.sortField : compareLine_1 = this.textField;
                        this.suggestions.forEach(function (e) {
                            e[compareLine_1].toString().toLowerCase() == _this.inputText.toString().toLowerCase() ? fetchingElement_1 = e : e;
                        });
                        if (fetchingElement_1) {
                            this.autocomplete.inputFieldValue = fetchingElement_1[this.textField];
                            this.autocomplete.value = fetchingElement_1;
                            this.select(this.autocomplete.value);
                        }
                        this.autocomplete.hide();
                    }
                    return [2 /*return*/];
                });
            });
        };
        DictionaryLookupComponent.prototype.searchDictionary = function (event, dictKey, dictField) {
            return __awaiter(this, void 0, void 0, function () {
                var filters, _a;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            filters = {};
                            filters[dictField] = { matchMode: this.searchMode, value: event.query };
                            if (this.query) {
                                filters['@query'] = { value: this.query };
                            }
                            _a = this;
                            return [4 /*yield*/, this.dictionaryService.searchDictionary(new PageQuery({
                                    first: 0,
                                    rows: this.count,
                                    sorts: this.sortField ? [{ field: this.sortField }] : [{ field: dictField }],
                                    filters: filters
                                }), dictKey, this.filter, this.filterParams, this.url).autoCancel(this.token)];
                        case 1:
                            _a.suggestions = (_b.sent()).items;
                            this.inputText = event.query;
                            return [2 /*return*/];
                    }
                });
            });
        };
        DictionaryLookupComponent.prototype.onresize = function (e) {
            var _this = this;
            if (this.dialog.maximized) {
                return;
            }
            setTimeout(function () {
                if (_this.dialog.container) {
                    _this.dialog.container.style.left = 'unset';
                    _this.dialog.container.style.top = 'unset';
                }
            });
        };
        DictionaryLookupComponent.prototype.select = function (value) {
            return __awaiter(this, void 0, void 0, function () {
                var _a;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            this.loading = true;
                            if (!this.view) return [3 /*break*/, 2];
                            _a = this.setValue;
                            return [4 /*yield*/, this.dictionaryService.getViewValue(value.id, this.view)];
                        case 1:
                            _a.apply(this, [_b.sent()]);
                            return [3 /*break*/, 3];
                        case 2:
                            this.setValue(value);
                            _b.label = 3;
                        case 3:
                            this.display = false;
                            this.loading = false;
                            return [2 /*return*/];
                    }
                });
            });
        };
        DictionaryLookupComponent.prototype.onGridKeyDown = function (key) {
            if (key.key === 'Enter' && this.grid.selectedValue) {
                this.select(this.grid.selectedValue);
                key.preventDefault();
                key.stopPropagation();
            }
        };
        DictionaryLookupComponent.ɵfac = function DictionaryLookupComponent_Factory(t) { return new (t || DictionaryLookupComponent)(core["ɵɵdirectiveInject"](DictionaryService)); };
        DictionaryLookupComponent.ɵcmp = core["ɵɵdefineComponent"]({ type: DictionaryLookupComponent, selectors: [["app-dictionary-lookup"]], viewQuery: function DictionaryLookupComponent_Query(rf, ctx) { if (rf & 1) {
                core["ɵɵstaticViewQuery"](_c0$g, true);
                core["ɵɵviewQuery"](_c1$9, true);
                core["ɵɵviewQuery"](_c2$7, true);
            } if (rf & 2) {
                var _t;
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.autocomplete = _t.first);
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.dialog = _t.first);
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.gridQuery = _t);
            } }, inputs: { global: "global", key: "key", view: "view", textField: "textField", display: "display", style: "style", readonly: "readonly", count: "count", searchMode: "searchMode", filter: "filter", filterParams: "filterParams", query: "query", sortField: "sortField", url: "url" }, features: [core["ɵɵProvidersFeature"]([
                    {
                        provide: forms.NG_VALUE_ACCESSOR,
                        useExisting: core.forwardRef(function () { return DictionaryLookupComponent; }),
                        multi: true
                    }
                ]), core["ɵɵInheritDefinitionFeature"]], decls: 9, vars: 24, consts: [[1, "ui-inputgroup", 3, "ngStyle"], [2, "flex", "1"], ["name", "autoComplete", "appendTo", "body", "placeholder", "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435", "emptyMessage", "\u041D\u0438\u0447\u0435\u0433\u043E \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E", 3, "suggestions", "field", "dropdown", "forceSelection", "inputStyle", "completeMethod", "onClear", "onKeyUp"], ["autocomplete", ""], ["type", "button", "pButton", "", "icon", "fa fa-ellipsis-h", "style", "box-shadow: none", "pTooltip", "\u041D\u0430\u0439\u0442\u0438 \u0432 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0435", 3, "disabled", "click", 4, "ngIf"], [3, "header", "modal", "maximizable", "visible", "resizable", "loading", "contentStyle", "visibleChange", "onHide", "resize"], ["dialog", ""], ["style", "width: 100%", 4, "ngIf"], [4, "ngIf"], ["type", "button", "pButton", "", "icon", "fa fa-ellipsis-h", "pTooltip", "\u041D\u0430\u0439\u0442\u0438 \u0432 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0435", 2, "box-shadow", "none", 3, "disabled", "click"], [2, "width", "100%"], [3, "global", "key", "textField", "filter", "filterParams", "query", "url", "rowDoubleClick", "cellKeyDown"], ["grid", ""], ["type", "submit", "pButton", "", "icon", "fa fa-check", "label", "\u0412\u044B\u0431\u0440\u0430\u0442\u044C", 3, "disabled", "click"], ["type", "reset", "pButton", "", "icon", "fa fa-times", "label", "\u041E\u0442\u043C\u0435\u043D\u0430", 1, "ui-button-secondary", 3, "click"]], template: function DictionaryLookupComponent_Template(rf, ctx) { if (rf & 1) {
                var _r665 = core["ɵɵgetCurrentView"]();
                core["ɵɵelementStart"](0, "div", 0);
                core["ɵɵelementStart"](1, "div", 1);
                core["ɵɵelementStart"](2, "p-autoComplete", 2, 3);
                core["ɵɵlistener"]("completeMethod", function DictionaryLookupComponent_Template_p_autoComplete_completeMethod_2_listener($event) { return ctx.global ? ctx.searchDictionary($event, ctx.view ? ctx.view : ctx.key, ctx.textField) : ctx.searchLocalDictionary($event, ctx.key); })("onClear", function DictionaryLookupComponent_Template_p_autoComplete_onClear_2_listener() { return ctx.setValue(null); })("onKeyUp", function DictionaryLookupComponent_Template_p_autoComplete_onKeyUp_2_listener($event) { return ctx.getElementByPressEnter($event); });
                core["ɵɵelementEnd"]();
                core["ɵɵelementEnd"]();
                core["ɵɵtemplate"](4, DictionaryLookupComponent_button_4_Template, 1, 1, "button", 4);
                core["ɵɵelementEnd"]();
                core["ɵɵelementStart"](5, "p-dialog", 5, 6);
                core["ɵɵlistener"]("visibleChange", function DictionaryLookupComponent_Template_p_dialog_visibleChange_5_listener($event) { return ctx.display = $event; })("onHide", function DictionaryLookupComponent_Template_p_dialog_onHide_5_listener() { core["ɵɵrestoreView"](_r665); var _r651 = core["ɵɵreference"](3); return _r651.inputEL.nativeElement.focus(); })("resize", function DictionaryLookupComponent_Template_p_dialog_resize_5_listener($event) { return ctx.onresize($event); }, false, core["ɵɵresolveWindow"]);
                core["ɵɵtemplate"](7, DictionaryLookupComponent_div_7_Template, 3, 7, "div", 7);
                core["ɵɵtemplate"](8, DictionaryLookupComponent_p_footer_8_Template, 3, 1, "p-footer", 8);
                core["ɵɵelementEnd"]();
            } if (rf & 2) {
                core["ɵɵproperty"]("ngStyle", ctx.style);
                core["ɵɵadvance"](2);
                core["ɵɵstyleMap"](core["ɵɵpureFunction0"](20, _c3$2));
                core["ɵɵproperty"]("suggestions", ctx.suggestions)("field", ctx.textField)("dropdown", true)("forceSelection", true)("inputStyle", core["ɵɵpureFunction0"](21, _c4$2));
                core["ɵɵadvance"](2);
                core["ɵɵproperty"]("ngIf", !ctx.readonly);
                core["ɵɵadvance"](1);
                core["ɵɵstyleMap"](core["ɵɵpureFunction0"](22, _c5$1));
                core["ɵɵproperty"]("header", ctx.grid == null ? null : ctx.grid.header)("modal", true)("maximizable", true)("visible", ctx.display)("resizable", false)("loading", ctx.loading)("contentStyle", core["ɵɵpureFunction0"](23, _c6$1));
                core["ɵɵadvance"](2);
                core["ɵɵproperty"]("ngIf", ctx.display);
                core["ɵɵadvance"](1);
                core["ɵɵproperty"]("ngIf", ctx.display);
            } }, directives: [common.NgStyle, AutocompleteFixDirective, autocomplete.AutoComplete, common.NgIf, DialogExtDirective, dialog.Dialog, button.ButtonDirective, TooltipExtDirective, tooltip.Tooltip, DictionaryLookupGridComponent, api.Footer], styles: [".ui-inputgroup[_ngcontent-%COMP%]{display:-webkit-box;display:flex}"] });
        return DictionaryLookupComponent;
    }(LookupBaseComponent));
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](DictionaryLookupComponent, [{
            type: core.Component,
            args: [{
                    selector: 'app-dictionary-lookup',
                    templateUrl: './dictionary-lookup.component.html',
                    styleUrls: ['./dictionary-lookup.component.css'],
                    providers: [
                        {
                            provide: forms.NG_VALUE_ACCESSOR,
                            useExisting: core.forwardRef(function () { return DictionaryLookupComponent; }),
                            multi: true
                        }
                    ]
                }]
        }], function () { return [{ type: DictionaryService }]; }, { global: [{
                type: core.Input
            }], key: [{
                type: core.Input
            }], view: [{
                type: core.Input
            }], textField: [{
                type: core.Input
            }], display: [{
                type: core.Input
            }], style: [{
                type: core.Input
            }], readonly: [{
                type: core.Input
            }], count: [{
                type: core.Input
            }], searchMode: [{
                type: core.Input
            }], filter: [{
                type: core.Input
            }], filterParams: [{
                type: core.Input
            }], query: [{
                type: core.Input
            }], sortField: [{
                type: core.Input
            }], url: [{
                type: core.Input
            }], autocomplete: [{
                type: core.ViewChild,
                args: ['autocomplete', { static: true }]
            }], dialog: [{
                type: core.ViewChild,
                args: ['dialog']
            }], gridQuery: [{
                type: core.ViewChildren,
                args: ['grid']
            }] }); })();

    var FileViewerService = /** @class */ (function () {
        function FileViewerService(dialogService, fileLoadService) {
            this.dialogService = dialogService;
            this.fileLoadService = fileLoadService;
        }
        FileViewerService.prototype.showOrSaveFile = function (response, serveType, filename, onHide) {
            return __awaiter(this, void 0, void 0, function () {
                var mediaType, body, headers_1, re, extention, _a, _b, pdfVersion, firefoxVersion, versionNumber, dialog;
                return __generator(this, function (_c) {
                    switch (_c.label) {
                        case 0:
                            filename = filename || this.getFleName(response.headers);
                            return [4 /*yield*/, this.getMediaType(response)];
                        case 1:
                            mediaType = _c.sent();
                            if (!mediaType) return [3 /*break*/, 3];
                            body = response.body.slice(0, response.body.size, mediaType);
                            headers_1 = response.headers.set('Content-Type', [mediaType + ';charset=UTF-8'])
                                .set('Content-Disposition', 'inline; filename="' + filename + '"');
                            if (!!headers_1['lazyInit']) {
                                headers_1['lazyInit'].forEach(function (init) {
                                    return headers_1['init'](init);
                                });
                                headers_1['lazyInit'] = null;
                            }
                            if (!!headers_1['lazyUpdate']) {
                                headers_1['lazyUpdate'].forEach(function (update) {
                                    return headers_1['applyUpdate'](update);
                                });
                                headers_1['lazyUpdate'] = null;
                            }
                            return [4 /*yield*/, response.clone({ headers: headers_1, body: body })];
                        case 2:
                            response = _c.sent();
                            return [3 /*break*/, 4];
                        case 3:
                            re = /(?:\.([^.]+))?$/;
                            extention = re.exec(filename)[1];
                            // do something with extension
                            switch (extention) {
                                case 'exe':
                                    break;
                            }
                            _c.label = 4;
                        case 4:
                            _a = serveType;
                            switch (_a) {
                                case exports.ServeFileType.VIEW: return [3 /*break*/, 5];
                                case exports.ServeFileType.SAVE: return [3 /*break*/, 11];
                            }
                            return [3 /*break*/, 11];
                        case 5:
                            _b = mediaType;
                            switch (_b) {
                                case 'application/pdf': return [3 /*break*/, 6];
                                case 'image/jpg': return [3 /*break*/, 8];
                                case 'image/jpeg': return [3 /*break*/, 8];
                                case 'image/png': return [3 /*break*/, 8];
                                case 'image/bmp': return [3 /*break*/, 8];
                                case 'image/gif': return [3 /*break*/, 8];
                                case 'image/tif': return [3 /*break*/, 8];
                                case 'image/tiff': return [3 /*break*/, 8];
                            }
                            return [3 /*break*/, 9];
                        case 6: return [4 /*yield*/, this.getPdfVersionNumber(response)];
                        case 7:
                            pdfVersion = _c.sent();
                            firefoxVersion = this.getUserAgentMap().get('Firefox');
                            if (pdfVersion && pdfVersion > 1.5 && firefoxVersion) {
                                versionNumber = parseFloat(firefoxVersion);
                                if (!isNaN(versionNumber) && versionNumber < 53.0) {
                                    fileSaver.saveAs(response.body, decodeURIComponent(filename));
                                    return [3 /*break*/, 10];
                                }
                            }
                            _c.label = 8;
                        case 8:
                            dialog = this.dialogService.createDialog(FileViewerComponent);
                            dialog.init(response.body, mediaType, filename);
                            dialog.visible = true;
                            dialog.onHide.subscribe(function () {
                                if (!!onHide) {
                                    onHide();
                                }
                            });
                            return [3 /*break*/, 10];
                        case 9:
                            fileSaver.saveAs(response.body, decodeURIComponent(filename));
                            return [3 /*break*/, 10];
                        case 10: return [3 /*break*/, 12];
                        case 11:
                            fileSaver.saveAs(response.body, decodeURIComponent(filename));
                            return [3 /*break*/, 12];
                        case 12: return [2 /*return*/];
                    }
                });
            });
        };
        FileViewerService.prototype.getFleName = function (headers) {
            var result = 'empty';
            var contentDisposition = headers.get('Content-Disposition');
            try {
                var filename = contentDisposition.split(';')[1].trim().split('=')[1];
                result = filename.replace(/"/g, '');
            }
            catch (e) {
            }
            return decodeURI(result).replace(/\+/g, ' ');
        };
        FileViewerService.prototype.getMediaType = function (response) {
            return __awaiter(this, void 0, void 0, function () {
                var result, contentDisposition, data, arr, header, hex, i, headersRegexMap, _a, _b, key, _c, _d, pattern;
                var e_1, _e, e_2, _f;
                return __generator(this, function (_g) {
                    switch (_g.label) {
                        case 0:
                            result = null;
                            contentDisposition = response.headers.get('Content-Type');
                            try {
                                result = contentDisposition.split(';')[0];
                            }
                            catch (e) {
                            }
                            if (!(!result || result.toLowerCase().indexOf('application/json') >= 0)) return [3 /*break*/, 2];
                            return [4 /*yield*/, this.fileLoadService.readFileAsync(response.body)];
                        case 1:
                            data = _g.sent();
                            arr = (new Uint8Array(data).subarray(0, 4));
                            header = '';
                            hex = void 0;
                            for (i = 0; i < arr.length; i++) {
                                hex = arr[i].toString(16);
                                while (hex.length < 2) {
                                    hex = '0' + hex;
                                }
                                header += hex;
                            }
                            console.log('file header: ' + header);
                            headersRegexMap = new Map();
                            headersRegexMap.set('application/pdf', ['^25504446$']);
                            headersRegexMap.set('image/tiff', ['^(4d4d|4949).{0,2}2a.{0,2}$']);
                            headersRegexMap.set('image/png', ['^89504e47$']);
                            headersRegexMap.set('image/jpeg', ['^ffd8ffe0$', '^ffd8ffe1$', '^ffd8ffe2$', '^ffd8ffe3$', '^ffd8ffe8$']);
                            headersRegexMap.set('image/gif', ['^47494638$']);
                            try {
                                for (_a = __values(Array.from(headersRegexMap.keys())), _b = _a.next(); !_b.done; _b = _a.next()) {
                                    key = _b.value;
                                    try {
                                        for (_c = (e_2 = void 0, __values(headersRegexMap.get(key))), _d = _c.next(); !_d.done; _d = _c.next()) {
                                            pattern = _d.value;
                                            if (header.match(pattern)) {
                                                return [2 /*return*/, key];
                                            }
                                        }
                                    }
                                    catch (e_2_1) { e_2 = { error: e_2_1 }; }
                                    finally {
                                        try {
                                            if (_d && !_d.done && (_f = _c.return)) _f.call(_c);
                                        }
                                        finally { if (e_2) throw e_2.error; }
                                    }
                                }
                            }
                            catch (e_1_1) { e_1 = { error: e_1_1 }; }
                            finally {
                                try {
                                    if (_b && !_b.done && (_e = _a.return)) _e.call(_a);
                                }
                                finally { if (e_1) throw e_1.error; }
                            }
                            return [2 /*return*/, response.body.type];
                        case 2: return [2 /*return*/, result];
                    }
                });
            });
        };
        FileViewerService.prototype.getPdfVersionNumber = function (response) {
            return __awaiter(this, void 0, void 0, function () {
                var data, arr, version;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.fileLoadService.readFileAsync(response.body)];
                        case 1:
                            data = _a.sent();
                            arr = (new Uint8Array(data).subarray(5, 9));
                            version = parseFloat(String.fromCharCode.apply(String, __spread(Array.from(arr))));
                            return [2 /*return*/, isNaN(version) ? null : version];
                    }
                });
            });
        };
        FileViewerService.prototype.getUserAgentMap = function () {
            var agentVersionMap = new Map();
            var agents = window.navigator.userAgent.match(/\w+\/[.0-9]+/g);
            agents.forEach(function (agent) {
                var elems = agent.split('/');
                agentVersionMap.set(elems[0], elems[1]);
            });
            return agentVersionMap;
        };
        FileViewerService.ɵfac = function FileViewerService_Factory(t) { return new (t || FileViewerService)(core["ɵɵinject"](DialogService), core["ɵɵinject"](FileLoadService)); };
        FileViewerService.ɵprov = core["ɵɵdefineInjectable"]({ token: FileViewerService, factory: FileViewerService.ɵfac, providedIn: 'root' });
        return FileViewerService;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](FileViewerService, [{
            type: core.Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: DialogService }, { type: FileLoadService }]; }, null); })();

    var TextareaDirective = /** @class */ (function () {
        function TextareaDirective(input) {
            var _this = this;
            this.input = input;
            this.emptyStringEqualsNull = true;
            var resize = this.input.resize.bind(this.input);
            this.input.resize = function (event) {
                if (_this.input.el.nativeElement.value != _this.oldValue
                    || _this.input.el.nativeElement.clientWidth != _this.oldWidth) {
                    resize(event);
                    _this.oldValue = _this.input.el.nativeElement.value;
                    _this.oldWidth = _this.input.el.nativeElement.clientWidth;
                }
            };
        }
        TextareaDirective.prototype.onChange = function (event) {
            if (this.emptyStringEqualsNull) {
                if (event.target.value === '') {
                    this.input.ngModel.valueAccessor.writeValue(null);
                    this.input.ngModel.viewToModelUpdate(null);
                }
            }
        };
        TextareaDirective.ɵfac = function TextareaDirective_Factory(t) { return new (t || TextareaDirective)(core["ɵɵdirectiveInject"](primeng.InputTextarea)); };
        TextareaDirective.ɵdir = core["ɵɵdefineDirective"]({ type: TextareaDirective, selectors: [["textarea", "pInputTextarea", ""]], hostBindings: function TextareaDirective_HostBindings(rf, ctx) { if (rf & 1) {
                core["ɵɵlistener"]("change", function TextareaDirective_change_HostBindingHandler($event) { return ctx.onChange($event); });
            } }, inputs: { emptyStringEqualsNull: "emptyStringEqualsNull" } });
        return TextareaDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](TextareaDirective, [{
            type: core.Directive,
            args: [{
                    selector: 'textarea [pInputTextarea]'
                }]
        }], function () { return [{ type: primeng.InputTextarea }]; }, { emptyStringEqualsNull: [{
                type: core.Input
            }], onChange: [{
                type: core.HostListener,
                args: ['change', ['$event']]
            }] }); })();

    function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_2_ng_container_1_div_1_Template(rf, ctx) { if (rf & 1) {
        var _r683 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "div", 5);
        core["ɵɵelementStart"](1, "label");
        core["ɵɵtext"](2);
        core["ɵɵelementEnd"]();
        core["ɵɵelementStart"](3, "input", 6);
        core["ɵɵlistener"]("ngModelChange", function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_2_ng_container_1_div_1_Template_input_ngModelChange_3_listener($event) { core["ɵɵrestoreView"](_r683); var extraField_r668 = core["ɵɵnextContext"](3).$implicit; var ctx_r682 = core["ɵɵnextContext"](2); return (ctx_r682.entity.extension[extraField_r668.name] = $event); });
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var extraField_r668 = core["ɵɵnextContext"](3).$implicit;
        var ctx_r681 = core["ɵɵnextContext"](2);
        core["ɵɵadvance"](2);
        core["ɵɵtextInterpolate1"]("", extraField_r668.caption, ":");
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngModel", ctx_r681.entity.extension[extraField_r668.name])("name", extraField_r668.name);
    } }
    function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_2_ng_container_1_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainerStart"](0);
        core["ɵɵtemplate"](1, ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_2_ng_container_1_div_1_Template, 4, 3, "div", 4);
        core["ɵɵelementContainerEnd"]();
    } if (rf & 2) {
        var extraField_r668 = core["ɵɵnextContext"](2).$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("appFieldConfig", extraField_r668.name);
    } }
    function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_2_ng_container_2_div_1_Template(rf, ctx) { if (rf & 1) {
        var _r689 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "div", 5);
        core["ɵɵelementStart"](1, "label");
        core["ɵɵtext"](2);
        core["ɵɵelementEnd"]();
        core["ɵɵelementStart"](3, "textarea", 7);
        core["ɵɵlistener"]("ngModelChange", function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_2_ng_container_2_div_1_Template_textarea_ngModelChange_3_listener($event) { core["ɵɵrestoreView"](_r689); var extraField_r668 = core["ɵɵnextContext"](3).$implicit; var ctx_r688 = core["ɵɵnextContext"](2); return (ctx_r688.entity.extension[extraField_r668.name] = $event); });
        core["ɵɵtext"](4, "            ");
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var extraField_r668 = core["ɵɵnextContext"](3).$implicit;
        var ctx_r687 = core["ɵɵnextContext"](2);
        core["ɵɵadvance"](2);
        core["ɵɵtextInterpolate1"]("", extraField_r668.caption, ":");
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngModel", ctx_r687.entity.extension[extraField_r668.name])("name", extraField_r668.name)("autoResize", true);
    } }
    function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_2_ng_container_2_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainerStart"](0);
        core["ɵɵtemplate"](1, ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_2_ng_container_2_div_1_Template, 5, 4, "div", 4);
        core["ɵɵelementContainerEnd"]();
    } if (rf & 2) {
        var extraField_r668 = core["ɵɵnextContext"](2).$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("appFieldConfig", extraField_r668.name);
    } }
    function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_2_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainerStart"](0);
        core["ɵɵtemplate"](1, ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_2_ng_container_1_Template, 2, 1, "ng-container", 0);
        core["ɵɵtemplate"](2, ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_2_ng_container_2_Template, 2, 1, "ng-container", 0);
        core["ɵɵelementContainerEnd"]();
    } if (rf & 2) {
        var extraField_r668 = core["ɵɵnextContext"]().$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", (extraField_r668 == null ? null : extraField_r668.options == null ? null : extraField_r668.options.text) != "true");
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", (extraField_r668 == null ? null : extraField_r668.options == null ? null : extraField_r668.options.text) == "true");
    } }
    function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_3_div_1_Template(rf, ctx) { if (rf & 1) {
        var _r696 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "div", 5);
        core["ɵɵelementStart"](1, "label");
        core["ɵɵtext"](2);
        core["ɵɵelementEnd"]();
        core["ɵɵelementStart"](3, "input", 8);
        core["ɵɵlistener"]("ngModelChange", function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_3_div_1_Template_input_ngModelChange_3_listener($event) { core["ɵɵrestoreView"](_r696); var extraField_r668 = core["ɵɵnextContext"](2).$implicit; var ctx_r695 = core["ɵɵnextContext"](2); return (ctx_r695.entity.extension[extraField_r668.name] = $event); });
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var extraField_r668 = core["ɵɵnextContext"](2).$implicit;
        var ctx_r694 = core["ɵɵnextContext"](2);
        core["ɵɵadvance"](2);
        core["ɵɵtextInterpolate1"]("", extraField_r668.caption, ":");
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngModel", ctx_r694.entity.extension[extraField_r668.name])("name", extraField_r668.name)("pMayBeEmpty", extraField_r668.mayBeEmpty);
    } }
    function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_3_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainerStart"](0);
        core["ɵɵtemplate"](1, ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_3_div_1_Template, 4, 4, "div", 4);
        core["ɵɵelementContainerEnd"]();
    } if (rf & 2) {
        var extraField_r668 = core["ɵɵnextContext"]().$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("appFieldConfig", extraField_r668.name);
    } }
    function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_4_div_1_Template(rf, ctx) { if (rf & 1) {
        var _r702 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "div", 5);
        core["ɵɵelementStart"](1, "label");
        core["ɵɵtext"](2);
        core["ɵɵelementEnd"]();
        core["ɵɵelementStart"](3, "p-checkbox", 9);
        core["ɵɵlistener"]("ngModelChange", function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_4_div_1_Template_p_checkbox_ngModelChange_3_listener($event) { core["ɵɵrestoreView"](_r702); var extraField_r668 = core["ɵɵnextContext"](2).$implicit; var ctx_r701 = core["ɵɵnextContext"](2); return (ctx_r701.entity.extension[extraField_r668.name] = $event); });
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var extraField_r668 = core["ɵɵnextContext"](2).$implicit;
        var ctx_r700 = core["ɵɵnextContext"](2);
        core["ɵɵadvance"](2);
        core["ɵɵtextInterpolate1"]("", extraField_r668.caption, ":");
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngModel", ctx_r700.entity.extension[extraField_r668.name])("name", extraField_r668.name);
    } }
    function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_4_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainerStart"](0);
        core["ɵɵtemplate"](1, ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_4_div_1_Template, 4, 3, "div", 4);
        core["ɵɵelementContainerEnd"]();
    } if (rf & 2) {
        var extraField_r668 = core["ɵɵnextContext"]().$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("appFieldConfig", extraField_r668.name);
    } }
    function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_5_div_1_Template(rf, ctx) { if (rf & 1) {
        var _r708 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "div", 5);
        core["ɵɵelementStart"](1, "label");
        core["ɵɵtext"](2);
        core["ɵɵelementEnd"]();
        core["ɵɵelementStart"](3, "input", 10);
        core["ɵɵlistener"]("ngModelChange", function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_5_div_1_Template_input_ngModelChange_3_listener($event) { core["ɵɵrestoreView"](_r708); var extraField_r668 = core["ɵɵnextContext"](2).$implicit; var ctx_r707 = core["ɵɵnextContext"](2); return (ctx_r707.entity.extension[extraField_r668.name] = $event); });
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var extraField_r668 = core["ɵɵnextContext"](2).$implicit;
        var ctx_r706 = core["ɵɵnextContext"](2);
        core["ɵɵadvance"](2);
        core["ɵɵtextInterpolate1"]("", extraField_r668.caption, ":");
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngModel", ctx_r706.entity.extension[extraField_r668.name])("name", extraField_r668.name)("disabled", false);
    } }
    function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_5_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainerStart"](0);
        core["ɵɵtemplate"](1, ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_5_div_1_Template, 4, 4, "div", 4);
        core["ɵɵelementContainerEnd"]();
    } if (rf & 2) {
        var extraField_r668 = core["ɵɵnextContext"]().$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("appFieldConfig", extraField_r668.name);
    } }
    var _c0$h = function () { return { width: "80%" }; };
    function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_6_div_1_Template(rf, ctx) { if (rf & 1) {
        var _r714 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "div", 5);
        core["ɵɵelementStart"](1, "label");
        core["ɵɵtext"](2);
        core["ɵɵelementEnd"]();
        core["ɵɵelementStart"](3, "p-calendar", 11);
        core["ɵɵlistener"]("ngModelChange", function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_6_div_1_Template_p_calendar_ngModelChange_3_listener($event) { core["ɵɵrestoreView"](_r714); var extraField_r668 = core["ɵɵnextContext"](2).$implicit; var ctx_r713 = core["ɵɵnextContext"](2); return (ctx_r713.entity.extension[extraField_r668.name] = $event); });
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var extraField_r668 = core["ɵɵnextContext"](2).$implicit;
        var ctx_r712 = core["ɵɵnextContext"](2);
        core["ɵɵadvance"](2);
        core["ɵɵtextInterpolate1"]("", extraField_r668.caption, ":");
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngModel", ctx_r712.entity.extension[extraField_r668.name])("inputStyle", core["ɵɵpureFunction0"](5, _c0$h))("name", extraField_r668.name)("showIcon", true);
    } }
    function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_6_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainerStart"](0);
        core["ɵɵtemplate"](1, ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_6_div_1_Template, 4, 6, "div", 4);
        core["ɵɵelementContainerEnd"]();
    } if (rf & 2) {
        var extraField_r668 = core["ɵɵnextContext"]().$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("appFieldConfig", extraField_r668.name);
    } }
    function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_7_div_1_Template(rf, ctx) { if (rf & 1) {
        var _r720 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "div", 5);
        core["ɵɵelementStart"](1, "label");
        core["ɵɵtext"](2);
        core["ɵɵelementEnd"]();
        core["ɵɵelementStart"](3, "app-dictionary-lookup", 12);
        core["ɵɵlistener"]("ngModelChange", function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_7_div_1_Template_app_dictionary_lookup_ngModelChange_3_listener($event) { core["ɵɵrestoreView"](_r720); var extraField_r668 = core["ɵɵnextContext"](2).$implicit; var ctx_r719 = core["ɵɵnextContext"](2); return (ctx_r719.entity.extension[extraField_r668.name] = $event); });
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var extraField_r668 = core["ɵɵnextContext"](2).$implicit;
        var ctx_r718 = core["ɵɵnextContext"](2);
        core["ɵɵadvance"](2);
        core["ɵɵtextInterpolate1"]("", extraField_r668.caption, ":");
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("name", extraField_r668.name)("ngModel", ctx_r718.entity.extension[extraField_r668.name])("global", false)("key", extraField_r668.options.key);
    } }
    function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_7_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainerStart"](0);
        core["ɵɵtemplate"](1, ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_7_div_1_Template, 4, 5, "div", 4);
        core["ɵɵelementContainerEnd"]();
    } if (rf & 2) {
        var extraField_r668 = core["ɵɵnextContext"]().$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("appFieldConfig", extraField_r668.name);
    } }
    function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_8_div_1_Template(rf, ctx) { if (rf & 1) {
        var _r726 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "div", 5);
        core["ɵɵelementStart"](1, "label");
        core["ɵɵtext"](2);
        core["ɵɵelementEnd"]();
        core["ɵɵelementStart"](3, "app-dictionary-lookup", 13);
        core["ɵɵlistener"]("ngModelChange", function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_8_div_1_Template_app_dictionary_lookup_ngModelChange_3_listener($event) { core["ɵɵrestoreView"](_r726); var extraField_r668 = core["ɵɵnextContext"](2).$implicit; var ctx_r725 = core["ɵɵnextContext"](2); return (ctx_r725.entity.extension[extraField_r668.name] = $event); });
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var extraField_r668 = core["ɵɵnextContext"](2).$implicit;
        var ctx_r724 = core["ɵɵnextContext"](2);
        core["ɵɵadvance"](2);
        core["ɵɵtextInterpolate1"]("", extraField_r668.caption, ":");
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("name", extraField_r668.name)("ngModel", ctx_r724.entity.extension[extraField_r668.name])("key", extraField_r668.options.key)("view", extraField_r668.options.view)("global", true)("textField", extraField_r668.options.field);
    } }
    function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_8_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainerStart"](0);
        core["ɵɵtemplate"](1, ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_8_div_1_Template, 4, 7, "div", 4);
        core["ɵɵelementContainerEnd"]();
    } if (rf & 2) {
        var extraField_r668 = core["ɵɵnextContext"]().$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("appFieldConfig", extraField_r668.name);
    } }
    var _c1$a = function () { return { width: "100%" }; };
    function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_9_div_1_Template(rf, ctx) { if (rf & 1) {
        var _r732 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "div", 5);
        core["ɵɵelementStart"](1, "label");
        core["ɵɵtext"](2);
        core["ɵɵelementEnd"]();
        core["ɵɵelementStart"](3, "p-dropdown", 14);
        core["ɵɵlistener"]("ngModelChange", function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_9_div_1_Template_p_dropdown_ngModelChange_3_listener($event) { core["ɵɵrestoreView"](_r732); var extraField_r668 = core["ɵɵnextContext"](2).$implicit; var ctx_r731 = core["ɵɵnextContext"](2); return (ctx_r731.entity.extension[extraField_r668.name] = $event); });
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var extraField_r668 = core["ɵɵnextContext"](2).$implicit;
        var ctx_r730 = core["ɵɵnextContext"](2);
        core["ɵɵadvance"](2);
        core["ɵɵtextInterpolate1"]("", extraField_r668.caption, ":");
        core["ɵɵadvance"](1);
        core["ɵɵstyleMap"](core["ɵɵpureFunction0"](7, _c1$a));
        core["ɵɵproperty"]("name", extraField_r668.name)("options", extraField_r668.options == null ? null : extraField_r668.options.values)("ngModel", ctx_r730.entity.extension[extraField_r668.name])("autoDisplayFirst", false);
    } }
    function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_9_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainerStart"](0);
        core["ɵɵtemplate"](1, ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_9_div_1_Template, 4, 8, "div", 4);
        core["ɵɵelementContainerEnd"]();
    } if (rf & 2) {
        var extraField_r668 = core["ɵɵnextContext"]().$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("appFieldConfig", extraField_r668.name);
    } }
    function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_10_div_1_Template(rf, ctx) { if (rf & 1) {
        var _r738 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "div", 5);
        core["ɵɵelementStart"](1, "label");
        core["ɵɵtext"](2);
        core["ɵɵelementEnd"]();
        core["ɵɵelementStart"](3, "p-multiSelect", 15);
        core["ɵɵlistener"]("ngModelChange", function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_10_div_1_Template_p_multiSelect_ngModelChange_3_listener($event) { core["ɵɵrestoreView"](_r738); var extraField_r668 = core["ɵɵnextContext"](2).$implicit; var ctx_r737 = core["ɵɵnextContext"](2); return (ctx_r737.entity.extension[extraField_r668.name] = $event); });
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var extraField_r668 = core["ɵɵnextContext"](2).$implicit;
        var ctx_r736 = core["ɵɵnextContext"](2);
        core["ɵɵadvance"](2);
        core["ɵɵtextInterpolate1"]("", extraField_r668.caption, ":");
        core["ɵɵadvance"](1);
        core["ɵɵstyleMap"](core["ɵɵpureFunction0"](7, _c1$a));
        core["ɵɵproperty"]("name", extraField_r668.name)("emptyFilterMessage", "\u041D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E")("options", extraField_r668.options == null ? null : extraField_r668.options.values)("ngModel", ctx_r736.entity.extension[extraField_r668.name]);
    } }
    function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_10_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainerStart"](0);
        core["ɵɵtemplate"](1, ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_10_div_1_Template, 4, 8, "div", 4);
        core["ɵɵelementContainerEnd"]();
    } if (rf & 2) {
        var extraField_r668 = core["ɵɵnextContext"]().$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("appFieldConfig", extraField_r668.name);
    } }
    function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_11_div_1_p_fileUpload_6_Template(rf, ctx) { if (rf & 1) {
        var _r748 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "p-fileUpload", 20, 21);
        core["ɵɵlistener"]("onSelect", function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_11_div_1_p_fileUpload_6_Template_p_fileUpload_onSelect_0_listener() { core["ɵɵrestoreView"](_r748); var extraField_r668 = core["ɵɵnextContext"](3).$implicit; var ctx_r746 = core["ɵɵnextContext"](2); return ctx_r746.onSelectFile(extraField_r668.name); })("onUpload", function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_11_div_1_p_fileUpload_6_Template_p_fileUpload_onUpload_0_listener($event) { core["ɵɵrestoreView"](_r748); var extraField_r668 = core["ɵɵnextContext"](3).$implicit; var ctx_r749 = core["ɵɵnextContext"](2); return ctx_r749.onUploadFile(extraField_r668.name, $event.originalEvent.body); })("onError", function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_11_div_1_p_fileUpload_6_Template_p_fileUpload_onError_0_listener() { core["ɵɵrestoreView"](_r748); var extraField_r668 = core["ɵɵnextContext"](3).$implicit; var ctx_r751 = core["ɵɵnextContext"](2); return ctx_r751.onUploadError(extraField_r668.name); });
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var _r745 = core["ɵɵreference"](1);
        var extraField_r668 = core["ɵɵnextContext"](3).$implicit;
        core["ɵɵstyleMap"](core["ɵɵpureFunction0"](10, _c1$a));
        core["ɵɵproperty"]("disabled", _r745.uploading)("name", "file")("auto", true)("url", extraField_r668.options == null ? null : extraField_r668.options.url)("withCredentials", true)("showUploadButton", true)("multiple", false)("chooseLabel", "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0444\u0430\u0439\u043B");
    } }
    function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_11_div_1_Template(rf, ctx) { if (rf & 1) {
        var _r755 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "div", 5);
        core["ɵɵelementStart"](1, "label");
        core["ɵɵtext"](2);
        core["ɵɵelementEnd"]();
        core["ɵɵelementStart"](3, "div", 16);
        core["ɵɵlistener"]("click", function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_11_div_1_Template_div_click_3_listener() { core["ɵɵrestoreView"](_r755); var extraField_r668 = core["ɵɵnextContext"](2).$implicit; var ctx_r754 = core["ɵɵnextContext"](2); return ctx_r754.entity.extension[extraField_r668.name] ? ctx_r754.downloadFile(extraField_r668.name, extraField_r668.options == null ? null : extraField_r668.options.url) : null; });
        core["ɵɵelement"](4, "input", 17, 18);
        core["ɵɵelementEnd"]();
        core["ɵɵtemplate"](6, ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_11_div_1_p_fileUpload_6_Template, 2, 11, "p-fileUpload", 19);
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var _r743 = core["ɵɵreference"](5);
        var extraField_r668 = core["ɵɵnextContext"](2).$implicit;
        var ctx_r742 = core["ɵɵnextContext"](2);
        core["ɵɵadvance"](2);
        core["ɵɵtextInterpolate1"]("", extraField_r668.caption, ":");
        core["ɵɵadvance"](2);
        core["ɵɵproperty"]("ngModel", ctx_r742.getFileName(extraField_r668.name))("name", extraField_r668.name);
        core["ɵɵadvance"](2);
        core["ɵɵproperty"]("ngIf", !_r743.disabled);
    } }
    function ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_11_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainerStart"](0);
        core["ɵɵtemplate"](1, ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_11_div_1_Template, 7, 4, "div", 4);
        core["ɵɵelementContainerEnd"]();
    } if (rf & 2) {
        var extraField_r668 = core["ɵɵnextContext"]().$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("appFieldConfig", extraField_r668.name);
    } }
    function ExtensionAttributesComponent_ng_container_0_ng_container_1_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainerStart"](0);
        core["ɵɵelementContainerStart"](1, 2);
        core["ɵɵtemplate"](2, ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_2_Template, 3, 2, "ng-container", 3);
        core["ɵɵtemplate"](3, ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_3_Template, 2, 1, "ng-container", 3);
        core["ɵɵtemplate"](4, ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_4_Template, 2, 1, "ng-container", 3);
        core["ɵɵtemplate"](5, ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_5_Template, 2, 1, "ng-container", 3);
        core["ɵɵtemplate"](6, ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_6_Template, 2, 1, "ng-container", 3);
        core["ɵɵtemplate"](7, ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_7_Template, 2, 1, "ng-container", 3);
        core["ɵɵtemplate"](8, ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_8_Template, 2, 1, "ng-container", 3);
        core["ɵɵtemplate"](9, ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_9_Template, 2, 1, "ng-container", 3);
        core["ɵɵtemplate"](10, ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_10_Template, 2, 1, "ng-container", 3);
        core["ɵɵtemplate"](11, ExtensionAttributesComponent_ng_container_0_ng_container_1_ng_container_11_Template, 2, 1, "ng-container", 3);
        core["ɵɵelementContainerEnd"]();
        core["ɵɵelementContainerEnd"]();
    } if (rf & 2) {
        var extraField_r668 = ctx.$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngSwitch", extraField_r668.type);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngSwitchCase", "string");
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngSwitchCase", "long");
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngSwitchCase", "bool");
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngSwitchCase", "decimal");
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngSwitchCase", "date");
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngSwitchCase", "local-dict");
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngSwitchCase", "dict");
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngSwitchCase", "enum");
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngSwitchCase", "multiselect");
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngSwitchCase", "file");
    } }
    function ExtensionAttributesComponent_ng_container_0_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementContainerStart"](0);
        core["ɵɵtemplate"](1, ExtensionAttributesComponent_ng_container_0_ng_container_1_Template, 12, 11, "ng-container", 1);
        core["ɵɵelementContainerEnd"]();
    } if (rf & 2) {
        var ctx_r666 = core["ɵɵnextContext"]();
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngForOf", ctx_r666.extraFields);
    } }
    var ExtensionAttributesComponent = /** @class */ (function () {
        function ExtensionAttributesComponent(entityConfigService, fileViewerService, httpClient, ngForm) {
            this.entityConfigService = entityConfigService;
            this.fileViewerService = fileViewerService;
            this.httpClient = httpClient;
            this.ngForm = ngForm;
            this.extraFields = [];
        }
        Object.defineProperty(ExtensionAttributesComponent.prototype, "entity", {
            get: function () {
                if (this._entity.extension == null) {
                    this._entity.extension = {};
                }
                return this._entity;
            },
            set: function (entity) {
                this._entity = entity;
            },
            enumerable: true,
            configurable: true
        });
        ExtensionAttributesComponent.prototype.ngOnInit = function () {
            var _this = this;
            if (this.entityName) {
                this.extraFields = this.entityConfigService.getEntityExtension(this.entityName);
            }
            if (this.extraFields) {
                this.extraFields.forEach(function (f) {
                    if (f.type === 'bool') {
                        _this.entity.extension[f.name] = _this.entity.extension[f.name] ? _this.entity.extension[f.name] : false;
                    }
                });
            }
        };
        ExtensionAttributesComponent.prototype.onSelectFile = function (fieldName) {
            var _a;
            (_a = this.ngForm.controls[fieldName]) === null || _a === void 0 ? void 0 : _a.markAsPending({ emitEvent: true });
            this.entity.extension[fieldName] = null;
        };
        ExtensionAttributesComponent.prototype.onUploadFile = function (fieldName, result) {
            var _a;
            (_a = this.ngForm.controls[fieldName]) === null || _a === void 0 ? void 0 : _a.updateValueAndValidity();
            this.entity.extension[fieldName] = result;
        };
        ExtensionAttributesComponent.prototype.onUploadError = function (fieldName) {
            var _a;
            (_a = this.ngForm.controls[fieldName]) === null || _a === void 0 ? void 0 : _a.updateValueAndValidity();
        };
        ExtensionAttributesComponent.prototype.getFileName = function (fieldName) {
            return this.entity.extension[fieldName] ? this.entity.extension[fieldName].split('/')[1] : '';
        };
        ExtensionAttributesComponent.prototype.downloadFile = function (fieldName, url) {
            return __awaiter(this, void 0, void 0, function () {
                var parts, data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            parts = this.entity.extension[fieldName].split('/');
                            return [4 /*yield*/, this.httpClient
                                    .get(url + "/" + parts[0] + "/" + parts[1], { observe: 'response', responseType: 'blob', params: new http.HttpParams() }).toPromise()];
                        case 1:
                            data = _a.sent();
                            return [4 /*yield*/, this.fileViewerService.showOrSaveFile(data, exports.ServeFileType.VIEW)];
                        case 2:
                            _a.sent();
                            return [2 /*return*/];
                    }
                });
            });
        };
        ExtensionAttributesComponent.ɵfac = function ExtensionAttributesComponent_Factory(t) { return new (t || ExtensionAttributesComponent)(core["ɵɵdirectiveInject"](EntityConfigService), core["ɵɵdirectiveInject"](FileViewerService), core["ɵɵdirectiveInject"](http.HttpClient), core["ɵɵdirectiveInject"](forms.NgForm)); };
        ExtensionAttributesComponent.ɵcmp = core["ɵɵdefineComponent"]({ type: ExtensionAttributesComponent, selectors: [["app-extension-attributes"]], inputs: { entity: "entity", entityName: "entityName", extraFields: "extraFields" }, features: [core["ɵɵProvidersFeature"]([], [{ provide: forms.ControlContainer, useExisting: forms.NgForm }])], decls: 1, vars: 1, consts: [[4, "ngIf"], [4, "ngFor", "ngForOf"], [3, "ngSwitch"], [4, "ngSwitchCase"], ["class", "form-row", 4, "appFieldConfig"], [1, "form-row"], ["pInputText", "", "placeholder", "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0442\u0435\u043A\u0441\u0442", 1, "input", 3, "ngModel", "name", "ngModelChange"], ["pInputTextarea", "", "placeholder", "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0442\u0435\u043A\u0441\u0442", 1, "input", 3, "ngModel", "name", "autoResize", "ngModelChange"], ["maxlength", "100", "pInputText", "", "pKeyFilter", "num", "placeholder", "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0447\u0438\u0441\u043B\u043E", 1, "input", 3, "ngModel", "name", "pMayBeEmpty", "ngModelChange"], ["binary", "true", 3, "ngModel", "name", "ngModelChange"], ["maxlength", "100", "pInputText", "", "placeholder", "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435", "pKeyFilter", "num", 1, "input", 3, "ngModel", "name", "disabled", "ngModelChange"], ["appendTo", "body", "dateFormat", "dd.mm.yy", "placeholder", "\u0434\u0434.\u043C\u043C.\u0433\u0433\u0433\u0433", "utcDate", "", 3, "ngModel", "inputStyle", "name", "showIcon", "ngModelChange"], ["textField", "value", 3, "name", "ngModel", "global", "key", "ngModelChange"], [3, "name", "ngModel", "key", "view", "global", "textField", "ngModelChange"], ["appendTo", "body", "showClear", "true", 3, "name", "options", "ngModel", "autoDisplayFirst", "ngModelChange"], ["selectedItemsLabel", "\u0412\u044B\u0431\u0440\u0430\u043D\u043E: {0}", "defaultLabel", "\u0412\u044B\u0431\u0440\u0430\u0442\u044C", "appendTo", "body", 3, "name", "emptyFilterMessage", "options", "ngModel", "ngModelChange"], [3, "click"], ["pInputText", "", "readonly", "", 1, "input", "clear-file-input", 2, "text-decoration", "underline", "color", "#3d60a1", "cursor", "pointer", 3, "ngModel", "name"], ["input", ""], ["mode", "basic", 3, "disabled", "name", "style", "auto", "url", "withCredentials", "showUploadButton", "multiple", "chooseLabel", "onSelect", "onUpload", "onError", 4, "ngIf"], ["mode", "basic", 3, "disabled", "name", "auto", "url", "withCredentials", "showUploadButton", "multiple", "chooseLabel", "onSelect", "onUpload", "onError"], ["fu", ""]], template: function ExtensionAttributesComponent_Template(rf, ctx) { if (rf & 1) {
                core["ɵɵtemplate"](0, ExtensionAttributesComponent_ng_container_0_Template, 2, 1, "ng-container", 0);
            } if (rf & 2) {
                core["ɵɵproperty"]("ngIf", ctx.entity);
            } }, directives: [common.NgIf, common.NgForOf, common.NgSwitch, common.NgSwitchCase, FieldConfigDirective, InputDirective, forms.DefaultValueAccessor, inputtext.InputText, ValidationMessageDirective, forms.NgControlStatus, forms.NgModel, TextareaDirective, primeng.InputTextarea, forms.MaxLengthValidator, PKeyFilterNumDirective, keyfilter.KeyFilter, checkbox.Checkbox, CalendarDirective, CalenderMaskDirective, calendar.Calendar, CalendarUtcDateDirective, DictionaryLookupComponent, dropdown.Dropdown, multiselect.MultiSelect, PFileUploadDirective, fileupload.FileUpload], styles: [".clear-file-input[_ngcontent-%COMP%]:disabled{border:none;background:0 0;opacity:1}"] });
        return ExtensionAttributesComponent;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](ExtensionAttributesComponent, [{
            type: core.Component,
            args: [{
                    selector: 'app-extension-attributes',
                    templateUrl: './extension-attributes.component.html',
                    styleUrls: ['./extension-attributes.component.css'],
                    viewProviders: [{ provide: forms.ControlContainer, useExisting: forms.NgForm }]
                }]
        }], function () { return [{ type: EntityConfigService }, { type: FileViewerService }, { type: http.HttpClient }, { type: forms.NgForm }]; }, { entity: [{
                type: core.Input
            }], entityName: [{
                type: core.Input
            }], extraFields: [{
                type: core.Input
            }] }); })();

    var SpinnerDirective = /** @class */ (function () {
        function SpinnerDirective(spinner) {
            var parseValue = function (val) {
                var value;
                if (val.trim() === '') {
                    value = null;
                }
                else {
                    if (this.precision)
                        value = parseFloat(val.replace(',', '.'));
                    else
                        value = parseInt(val, 10);
                    if (!isNaN(value)) {
                        if (this.max !== null && value > this.max) {
                            value = this.max;
                        }
                        if (this.min !== null && value < this.min) {
                            value = this.min;
                        }
                    }
                    else {
                        value = null;
                    }
                }
                return value;
            };
            spinner.parseValue = parseValue.bind(spinner);
        }
        SpinnerDirective.ɵfac = function SpinnerDirective_Factory(t) { return new (t || SpinnerDirective)(core["ɵɵdirectiveInject"](spinner.Spinner)); };
        SpinnerDirective.ɵdir = core["ɵɵdefineDirective"]({ type: SpinnerDirective, selectors: [["p-spinner", "min", ""]] });
        return SpinnerDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](SpinnerDirective, [{
            type: core.Directive,
            args: [{
                    selector: 'p-spinner[min]'
                }]
        }], function () { return [{ type: spinner.Spinner }]; }, null); })();

    var DistinctFilterDummyService = /** @class */ (function (_super) {
        __extends(DistinctFilterDummyService, _super);
        function DistinctFilterDummyService() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        Object.defineProperty(DistinctFilterDummyService.prototype, "isEnabled", {
            get: function () { return false; },
            enumerable: true,
            configurable: true
        });
        DistinctFilterDummyService.prototype.showFilterDialog = function (api, agColumn) { };
        DistinctFilterDummyService.ɵfac = function DistinctFilterDummyService_Factory(t) { return ɵDistinctFilterDummyService_BaseFactory(t || DistinctFilterDummyService); };
        DistinctFilterDummyService.ɵprov = core["ɵɵdefineInjectable"]({ token: DistinctFilterDummyService, factory: DistinctFilterDummyService.ɵfac });
        return DistinctFilterDummyService;
    }(DistinctFilterService));
    var ɵDistinctFilterDummyService_BaseFactory = core["ɵɵgetInheritedFactory"](DistinctFilterDummyService);
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](DistinctFilterDummyService, [{
            type: core.Injectable
        }], null, null); })();

    var _c0$i = ["dialog"];
    var _c1$b = ["table"];
    var _c2$8 = function () { return { width: "70vw", height: "80vh", "max-width": "500px" }; };
    var _c3$3 = function () { return { "display": "flex", "min-height": "calc(100% - 7em)", "max-height": "calc(100% - 7em)" }; };
    var DistinctFilterDialogComponent = /** @class */ (function (_super) {
        __extends(DistinctFilterDialogComponent, _super);
        function DistinctFilterDialogComponent() {
            var _this = _super.call(this) || this;
            _this.getRowId = function (row) { return _this.getValue(row); };
            _this.result = new core.EventEmitter();
            return _this;
        }
        DistinctFilterDialogComponent.prototype.ngOnInit = function () {
        };
        DistinctFilterDialogComponent.prototype.init = function (column, loader, initialFilter) {
            this.column = column;
            this.loader = loader;
            this.initialFilter = initialFilter;
            this.visible = true;
        };
        DistinctFilterDialogComponent.prototype.onLoad = function (e) {
            var filters = {};
            for (var key in e.filters) {
                if (e.filters.hasOwnProperty(key)) {
                    filters[key] = { filter: e.filters[key].value, type: e.filters[key].matchMode };
                }
            }
            var params = {
                request: {
                    startRow: e.first,
                    endRow: e.first + e.rows,
                    sortModel: e.multiSortMeta.map(function (f) { return ({
                        colId: f.field,
                        order: f.order === -1 ? 'desc' : f.order === 1 ? 'asc' : ''
                    }); }),
                    filterModel: filters,
                    rowGroupCols: [],
                    valueCols: [],
                    pivotCols: [],
                    pivotMode: false,
                    groupKeys: []
                },
                successCallback: e.successCallback,
                failCallback: e.failCallback,
                parentNode: null,
                context: { distinctColumn: this.column.field }
            };
            this.loader(params);
        };
        DistinctFilterDialogComponent.prototype.apply = function () {
            var _this = this;
            this.result.emit(this.selection.map(function (row) { return _this.getValue(row); }));
            this.visible = false;
        };
        DistinctFilterDialogComponent.prototype.getValue = function (row) {
            var props = this.column.field.split('.');
            return props.reduce(function (prev, curr) { return prev && prev[curr]; }, row);
        };
        DistinctFilterDialogComponent.prototype.cancel = function () {
            this.visible = false;
        };
        DistinctFilterDialogComponent.prototype.onDataSourceReady = function (api) {
            var _this = this;
            if (this.initialFilter) {
                var selection_1 = [];
                this.initialFilter.split(',').forEach(function (value) {
                    var rowData = {};
                    var curObj = rowData;
                    var parts = _this.column.field.split('.');
                    for (var i = 0; i < parts.length; i++) {
                        var field = parts[i];
                        if (i == parts.length - 1) {
                            curObj[field] = value;
                        }
                        else {
                            curObj[field] = {};
                        }
                        curObj = curObj[field];
                    }
                    selection_1.push(rowData);
                });
                this.selection = selection_1;
                selection_1.forEach(function (dataRow) {
                    var node = new agGridCommunity.RowNode();
                    node.id = _this.getValue(dataRow);
                    node.daemon = true;
                    node.level = 0;
                    node.setSelectedInitialValue(true);
                    node.data = dataRow;
                    var event = {
                        type: agGridCommunity.Events.EVENT_ROW_SELECTED,
                        api: api,
                        node: node
                    };
                    api.selectionController.eventService.dispatchEvent(event);
                });
            }
        };
        DistinctFilterDialogComponent.prototype.onresize = function (e) {
            var _this = this;
            if (this.dialog.maximized) {
                return;
            }
            setTimeout(function () {
                if (_this.dialog.container) {
                    _this.dialog.container.style.left = 'unset';
                    _this.dialog.container.style.top = 'unset';
                }
            });
        };
        DistinctFilterDialogComponent.ɵfac = function DistinctFilterDialogComponent_Factory(t) { return new (t || DistinctFilterDialogComponent)(); };
        DistinctFilterDialogComponent.ɵcmp = core["ɵɵdefineComponent"]({ type: DistinctFilterDialogComponent, selectors: [["lib-distinct-filter-dialog"]], viewQuery: function DistinctFilterDialogComponent_Query(rf, ctx) { if (rf & 1) {
                core["ɵɵviewQuery"](_c0$i, true);
                core["ɵɵviewQuery"](_c1$b, true);
            } if (rf & 2) {
                var _t;
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.dialog = _t.first);
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.table = _t.first);
            } }, outputs: { result: "result" }, features: [core["ɵɵProvidersFeature"]([{
                        provide: DistinctFilterService,
                        useClass: DistinctFilterDummyService
                    }]), core["ɵɵInheritDefinitionFeature"]], decls: 9, vars: 17, consts: [[3, "header", "contentStyle", "resize"], ["dialog", ""], [2, "width", "100%"], ["selectionMode", "multiple", 3, "checkboxSelection", "filter", "selection", "lazy", "getRowId", "keepSelectionAfterFilter", "selectionChange", "onDataSourceReady", "onLazyLoad"], ["table", ""], [3, "field", "header", "type", "enum", "width"], ["pButton", "", "label", "\u041F\u0440\u0438\u043C\u0435\u043D\u0438\u0442\u044C", 3, "click"], ["pButton", "", "label", "\u041E\u0442\u043C\u0435\u043D\u0430", 1, "ui-button-secondary", 3, "click"]], template: function DistinctFilterDialogComponent_Template(rf, ctx) { if (rf & 1) {
                core["ɵɵelementStart"](0, "p-dialog", 0, 1);
                core["ɵɵlistener"]("resize", function DistinctFilterDialogComponent_Template_p_dialog_resize_0_listener($event) { return ctx.onresize($event); }, false, core["ɵɵresolveWindow"]);
                core["ɵɵelementStart"](2, "div", 2);
                core["ɵɵelementStart"](3, "app-table2", 3, 4);
                core["ɵɵlistener"]("selectionChange", function DistinctFilterDialogComponent_Template_app_table2_selectionChange_3_listener($event) { return ctx.selection = $event; })("onDataSourceReady", function DistinctFilterDialogComponent_Template_app_table2_onDataSourceReady_3_listener($event) { return ctx.onDataSourceReady($event); })("onLazyLoad", function DistinctFilterDialogComponent_Template_app_table2_onLazyLoad_3_listener($event) { return ctx.onLoad($event); });
                core["ɵɵelement"](5, "column", 5);
                core["ɵɵelementEnd"]();
                core["ɵɵelementEnd"]();
                core["ɵɵelementStart"](6, "p-footer");
                core["ɵɵelementStart"](7, "button", 6);
                core["ɵɵlistener"]("click", function DistinctFilterDialogComponent_Template_button_click_7_listener() { return ctx.apply(); });
                core["ɵɵelementEnd"]();
                core["ɵɵelementStart"](8, "button", 7);
                core["ɵɵlistener"]("click", function DistinctFilterDialogComponent_Template_button_click_8_listener() { return ctx.cancel(); });
                core["ɵɵelementEnd"]();
                core["ɵɵelementEnd"]();
                core["ɵɵelementEnd"]();
            } if (rf & 2) {
                core["ɵɵstyleMap"](core["ɵɵpureFunction0"](15, _c2$8));
                core["ɵɵproperty"]("header", "\u041F\u043E\u0434\u0431\u043E\u0440 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u0438\u0437 \u043A\u043E\u043B\u043E\u043D\u043A\u0438")("contentStyle", core["ɵɵpureFunction0"](16, _c3$3));
                core["ɵɵadvance"](3);
                core["ɵɵproperty"]("checkboxSelection", true)("filter", true)("selection", ctx.selection)("lazy", true)("getRowId", ctx.getRowId)("keepSelectionAfterFilter", true);
                core["ɵɵadvance"](2);
                core["ɵɵproperty"]("field", ctx.column.field)("header", ctx.column.header)("type", ctx.column.type)("enum", ctx.column.enum)("width", 380);
            } }, directives: [DialogExtDirective, dialog.Dialog, Table2Component, Column, api.Footer, ButtonDirective, button.ButtonDirective], styles: [""] });
        return DistinctFilterDialogComponent;
    }(DialogComponent));
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](DistinctFilterDialogComponent, [{
            type: core.Component,
            args: [{
                    selector: 'lib-distinct-filter-dialog',
                    templateUrl: './distinct-filter-dialog.component.html',
                    styleUrls: ['./distinct-filter-dialog.component.css'],
                    providers: [{
                            provide: DistinctFilterService,
                            useClass: DistinctFilterDummyService
                        }]
                }]
        }], function () { return []; }, { result: [{
                type: core.Output
            }], dialog: [{
                type: core.ViewChild,
                args: ['dialog']
            }], table: [{
                type: core.ViewChild,
                args: ['table']
            }] }); })();

    var DistinctFilterDialogService = /** @class */ (function (_super) {
        __extends(DistinctFilterDialogService, _super);
        function DistinctFilterDialogService(dialogService) {
            var _this = _super.call(this) || this;
            _this.dialogService = dialogService;
            return _this;
        }
        DistinctFilterDialogService.prototype.showFilterDialog = function (api, agColumn) {
            var field = agColumn.getColDef().field;
            var dialog = this.dialogService.createDialog(DistinctFilterDialogComponent);
            var ds = api.getModel().datasource;
            var filterComponent = api.getFilterInstance(agColumn.getColId());
            var initFilter = null;
            if (filterComponent.getModel() && filterComponent.getModel().type == 'in') {
                initFilter = filterComponent.getModel().filter;
            }
            dialog.init(agColumn.getColDef().col, function (e) {
                var clone = __assign({}, api.getFilterModel());
                delete clone[field];
                e.request.filterModel = __assign(__assign({}, clone), e.request.filterModel);
                ds.getRows(e);
            }, initFilter);
            dialog.result.subscribe(function (values) {
                var filterComponent2 = api.getFilterInstance(agColumn.getColId());
                filterComponent2.setModel({
                    type: 'in',
                    filter: values.join(',')
                });
                api.onFilterChanged();
            });
        };
        DistinctFilterDialogService.ɵfac = function DistinctFilterDialogService_Factory(t) { return new (t || DistinctFilterDialogService)(core["ɵɵinject"](DialogService)); };
        DistinctFilterDialogService.ɵprov = core["ɵɵdefineInjectable"]({ token: DistinctFilterDialogService, factory: DistinctFilterDialogService.ɵfac });
        return DistinctFilterDialogService;
    }(DistinctFilterService));
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](DistinctFilterDialogService, [{
            type: core.Injectable
        }], function () { return [{ type: DialogService }]; }, null); })();

    var VerticalSplitSeparatorComponent = /** @class */ (function (_super) {
        __extends(VerticalSplitSeparatorComponent, _super);
        function VerticalSplitSeparatorComponent() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        VerticalSplitSeparatorComponent.prototype.ngAfterViewInit = function () {
            this.invisibleExtension.nativeElement.style.left =
                -(7 - this.thickness) / 2 + "px";
        };
        VerticalSplitSeparatorComponent.ɵfac = function VerticalSplitSeparatorComponent_Factory(t) { return ɵVerticalSplitSeparatorComponent_BaseFactory(t || VerticalSplitSeparatorComponent); };
        VerticalSplitSeparatorComponent.ɵcmp = core["ɵɵdefineComponent"]({ type: VerticalSplitSeparatorComponent, selectors: [["vertical-split-separator"]], hostVars: 2, hostBindings: function VerticalSplitSeparatorComponent_HostBindings(rf, ctx) { if (rf & 2) {
                core["ɵɵstyleProp"]("width", ctx.thickness, "px");
            } }, features: [core["ɵɵInheritDefinitionFeature"]], decls: 3, vars: 1, consts: [[1, "invisible-extension", 3, "hidden"], ["invisibleExtension", ""], [1, "handle"]], template: function VerticalSplitSeparatorComponent_Template(rf, ctx) { if (rf & 1) {
                core["ɵɵelement"](0, "div", 0, 1);
                core["ɵɵelement"](2, "div", 2);
            } if (rf & 2) {
                core["ɵɵproperty"]("hidden", ctx.thickness >= 7);
            } }, styles: ["[_nghost-%COMP%] {\n      background-color: #fff;\n      border-left: 1px solid #ddd;\n      cursor: ew-resize;\n      position: relative;\n    }\n    [_nghost-%COMP%]:hover {\n      background-color: #fafafa;\n    }\n\n    .invisible-extension[_ngcontent-%COMP%] {\n      position: absolute;\n      height: 100%;\n      width: 100%;\n      min-width: 7px;\n    }\n\n    .handle[_ngcontent-%COMP%] {\n      width: 100%;\n      height: 35px;\n      background-color: #eee;\n      position: absolute;\n      top: calc(50% - 17px);\n    }"] });
        return VerticalSplitSeparatorComponent;
    }(SplitSeparatorComponent));
    var ɵVerticalSplitSeparatorComponent_BaseFactory = core["ɵɵgetInheritedFactory"](VerticalSplitSeparatorComponent);
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](VerticalSplitSeparatorComponent, [{
            type: core.Component,
            args: [{
                    selector: 'vertical-split-separator',
                    styles: ["\n    :host {\n      background-color: #fff;\n      border-left: 1px solid #ddd;\n      cursor: ew-resize;\n      position: relative;\n    }\n    :host:hover {\n      background-color: #fafafa;\n    }\n\n    .invisible-extension {\n      position: absolute;\n      height: 100%;\n      width: 100%;\n      min-width: 7px;\n    }\n\n    .handle {\n      width: 100%;\n      height: 35px;\n      background-color: #eee;\n      position: absolute;\n      top: calc(50% - 17px);\n    }\n  "],
                    template: "\n    <!-- Used to extend the 'draggable' area in case the separator is too thin,\n    so it's not too hard to drag. -->\n    <div\n      #invisibleExtension\n      [hidden]=\"thickness >= 7\"\n      class=\"invisible-extension\"></div>\n\n    <div class=\"handle\"></div>\n  ",
                    host: {
                        '[style.width.px]': 'thickness'
                    }
                }]
        }], null, null); })();

    var _c0$j = ["outer"];
    var _c1$c = [[["", 8, "split-pane-content-primary"]], [["", 8, "split-pane-content-secondary"]]];
    var _c2$9 = [".split-pane-content-primary", ".split-pane-content-secondary"];
    var VerticalSplitPaneComponent = /** @class */ (function (_super) {
        __extends(VerticalSplitPaneComponent, _super);
        function VerticalSplitPaneComponent() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        VerticalSplitPaneComponent.prototype.getTotalSize = function () {
            return this.outerContainer.nativeElement.offsetWidth;
        };
        VerticalSplitPaneComponent.prototype.getPrimarySize = function () {
            return this.primaryComponent.nativeElement.offsetWidth;
        };
        VerticalSplitPaneComponent.prototype.getSecondarySize = function () {
            return this.secondaryComponent.nativeElement.offsetWidth;
        };
        VerticalSplitPaneComponent.prototype.dividerPosition = function (size) {
            var sizePct = (size / this.getTotalSize()) * 100;
            this.primaryComponent.nativeElement.style.width = sizePct + "%";
            this.secondaryComponent.nativeElement.style.width =
                "calc(" + (100 - sizePct) + "% - " +
                    (this.primaryToggledOff || this.secondaryToggledOff ? 0 : this.separatorThickness) + "px)";
        };
        VerticalSplitPaneComponent.prototype.onMousemove = function (event) {
            if (this.isResizing) {
                var coords = PositionService.offset(this.primaryComponent);
                this.applySizeChange(event.pageX - coords.left);
                return false;
            }
        };
        VerticalSplitPaneComponent.ɵfac = function VerticalSplitPaneComponent_Factory(t) { return ɵVerticalSplitPaneComponent_BaseFactory(t || VerticalSplitPaneComponent); };
        VerticalSplitPaneComponent.ɵcmp = core["ɵɵdefineComponent"]({ type: VerticalSplitPaneComponent, selectors: [["vertical-split-pane"]], viewQuery: function VerticalSplitPaneComponent_Query(rf, ctx) { if (rf & 1) {
                core["ɵɵstaticViewQuery"](_c0$j, true);
            } if (rf & 2) {
                var _t;
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.outerContainer = _t.first);
            } }, hostBindings: function VerticalSplitPaneComponent_HostBindings(rf, ctx) { if (rf & 1) {
                core["ɵɵlistener"]("mousemove", function VerticalSplitPaneComponent_mousemove_HostBindingHandler($event) { return ctx.onMousemove($event); });
            } }, features: [core["ɵɵInheritDefinitionFeature"]], ngContentSelectors: _c2$9, decls: 10, vars: 4, consts: [[1, "v-outer"], ["outer", ""], [1, "left-component", 3, "hidden"], ["primaryComponent", ""], [3, "hidden", "thickness", "notifyWillChangeSize"], ["separator", ""], [1, "right-component", 3, "hidden"], ["secondaryComponent", ""]], template: function VerticalSplitPaneComponent_Template(rf, ctx) { if (rf & 1) {
                core["ɵɵprojectionDef"](_c1$c);
                core["ɵɵelementStart"](0, "div", 0, 1);
                core["ɵɵelementStart"](2, "div", 2, 3);
                core["ɵɵprojection"](4);
                core["ɵɵelementEnd"]();
                core["ɵɵelementStart"](5, "vertical-split-separator", 4, 5);
                core["ɵɵlistener"]("notifyWillChangeSize", function VerticalSplitPaneComponent_Template_vertical_split_separator_notifyWillChangeSize_5_listener($event) { return ctx.notifyWillChangeSize($event); });
                core["ɵɵelementEnd"]();
                core["ɵɵelementStart"](7, "div", 6, 7);
                core["ɵɵprojection"](9, 1);
                core["ɵɵelementEnd"]();
                core["ɵɵelementEnd"]();
            } if (rf & 2) {
                core["ɵɵadvance"](2);
                core["ɵɵproperty"]("hidden", ctx.primaryToggledOff);
                core["ɵɵadvance"](3);
                core["ɵɵproperty"]("hidden", ctx.primaryToggledOff || ctx.secondaryToggledOff)("thickness", ctx.separatorThickness);
                core["ɵɵadvance"](2);
                core["ɵɵproperty"]("hidden", ctx.secondaryToggledOff);
            } }, directives: [VerticalSplitSeparatorComponent], styles: [".v-outer[_ngcontent-%COMP%] {\n      height: 100%;\n      width: 100%;\n      display: flex;\n    }\n\n    .left-component[_ngcontent-%COMP%] {\n      width: calc(50% - 4px);\n    }\n\n    .right-component[_ngcontent-%COMP%] {\n      width: calc(50% - 4px);\n    }"] });
        return VerticalSplitPaneComponent;
    }(SplitPaneComponent));
    var ɵVerticalSplitPaneComponent_BaseFactory = core["ɵɵgetInheritedFactory"](VerticalSplitPaneComponent);
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](VerticalSplitPaneComponent, [{
            type: core.Component,
            args: [{
                    selector: 'vertical-split-pane',
                    styles: ["\n    .v-outer {\n      height: 100%;\n      width: 100%;\n      display: flex;\n    }\n\n    .left-component {\n      width: calc(50% - 4px);\n    }\n\n    .right-component {\n      width: calc(50% - 4px);\n    }\n  "],
                    template: "\n  <div #outer class=\"v-outer\">\n    <div\n      #primaryComponent\n      [hidden]=\"primaryToggledOff\"\n      class=\"left-component\">\n      <ng-content select=\".split-pane-content-primary\"></ng-content>\n    </div>\n    <vertical-split-separator\n      #separator\n      [hidden]=\"primaryToggledOff ||\u00A0secondaryToggledOff\"\n      [thickness]=\"separatorThickness\"\n      (notifyWillChangeSize)=\"notifyWillChangeSize($event)\">\n    </vertical-split-separator>\n    <div\n      #secondaryComponent\n      [hidden]=\"secondaryToggledOff\"\n      class=\"right-component\">\n      <ng-content select=\".split-pane-content-secondary\"></ng-content>\n    </div>\n  </div>\n  ",
                }]
        }], null, { outerContainer: [{
                type: core.ViewChild,
                args: ['outer', { static: true }]
            }], onMousemove: [{
                type: core.HostListener,
                args: ['mousemove', ['$event']]
            }] }); })();

    function debounceValidation(control, validatorFn, options) {
        var _this = this;
        if (options === void 0) { options = null; }
        clearTimeout(control.$debounceValidationIntervalId);
        return new Promise(function (resolve, reject) {
            var _a, _b, _c, _d;
            if (!control.value && (_b = (_a = options) === null || _a === void 0 ? void 0 : _a.resolveOnEmpty, (_b !== null && _b !== void 0 ? _b : true))) {
                resolve(null);
            }
            control.$debounceValidationIntervalId = setTimeout(function () { return __awaiter(_this, void 0, void 0, function () {
                var _a, _b;
                return __generator(this, function (_c) {
                    try {
                        if (!control.value && (_b = (_a = options) === null || _a === void 0 ? void 0 : _a.resolveOnEmpty, (_b !== null && _b !== void 0 ? _b : true))) {
                            resolve(null);
                        }
                        else {
                            resolve(validatorFn(control));
                        }
                    }
                    catch (e) {
                        reject(e);
                        throw e;
                    }
                    return [2 /*return*/];
                });
            }); }, (_d = (_c = options) === null || _c === void 0 ? void 0 : _c.debounceTime, (_d !== null && _d !== void 0 ? _d : 500)));
        });
    }

    var ValidateDirective = /** @class */ (function () {
        function ValidateDirective() {
            this.debounce = false;
            this.debounceTime = 500;
        }
        Object.defineProperty(ValidateDirective.prototype, "changeDetect", {
            get: function () {
                return this._changeDetect;
            },
            set: function (value) {
                if (this.onValidatorChangeFn) {
                    this._changeDetect = value;
                    this.onValidatorChangeFn();
                }
            },
            enumerable: true,
            configurable: true
        });
        ValidateDirective.prototype.validate = function (control) {
            var _this = this;
            if (this.debounce
                && this.validator
                && this.debounceTime > 0) {
                return debounceValidation(control, function () { return _this.validateInternal(control); }, { debounceTime: this.debounceTime });
            }
            return this.validateInternal(control);
        };
        ValidateDirective.prototype.validateInternal = function (control) {
            if (!this.validator) {
                return new Promise(function (resolve) { return resolve(null); });
            }
            var res = this.validator(control);
            if (res instanceof Promise) {
                return res;
            }
            else if (res instanceof rxjs.Observable) {
                return res.toPromise();
            }
            return new Promise(function (resolve) { return resolve(res); });
        };
        ValidateDirective.prototype.registerOnValidatorChange = function (fn) {
            this.onValidatorChangeFn = fn;
        };
        ValidateDirective.ɵfac = function ValidateDirective_Factory(t) { return new (t || ValidateDirective)(); };
        ValidateDirective.ɵdir = core["ɵɵdefineDirective"]({ type: ValidateDirective, selectors: [["", "appValidate", ""]], inputs: { validator: ["appValidate", "validator"], debounce: ["appValidateDebounce", "debounce"], debounceTime: ["appValidateDebounceTime", "debounceTime"], changeDetect: ["appValidateChangeDetect", "changeDetect"] }, features: [core["ɵɵProvidersFeature"]([
                    { provide: forms.NG_ASYNC_VALIDATORS, useExisting: core.forwardRef(function () { return ValidateDirective; }), multi: true }
                ])] });
        return ValidateDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](ValidateDirective, [{
            type: core.Directive,
            args: [{
                    selector: '[appValidate]',
                    providers: [
                        { provide: forms.NG_ASYNC_VALIDATORS, useExisting: core.forwardRef(function () { return ValidateDirective; }), multi: true }
                    ]
                }]
        }], null, { validator: [{
                type: core.Input,
                args: ['appValidate']
            }], debounce: [{
                type: core.Input,
                args: ['appValidateDebounce']
            }], debounceTime: [{
                type: core.Input,
                args: ['appValidateDebounceTime']
            }], changeDetect: [{
                type: core.Input,
                args: ['appValidateChangeDetect']
            }] }); })();

    var _c0$k = ["input"];
    var _c1$d = function () { return { "p-inputnumber-button p-inputnumber-button-up": true }; };
    var _c2$a = function () { return { "p-inputnumber-button p-inputnumber-button-down": true }; };
    function InputNumber_span_3_Template(rf, ctx) { if (rf & 1) {
        var _r772 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "span", 5);
        core["ɵɵelementStart"](1, "button", 6);
        core["ɵɵlistener"]("mousedown", function InputNumber_span_3_Template_button_mousedown_1_listener($event) { core["ɵɵrestoreView"](_r772); var ctx_r771 = core["ɵɵnextContext"](); return ctx_r771.onUpButtonMouseDown($event); })("mouseup", function InputNumber_span_3_Template_button_mouseup_1_listener() { core["ɵɵrestoreView"](_r772); var ctx_r773 = core["ɵɵnextContext"](); return ctx_r773.onUpButtonMouseUp(); })("mouseleave", function InputNumber_span_3_Template_button_mouseleave_1_listener() { core["ɵɵrestoreView"](_r772); var ctx_r774 = core["ɵɵnextContext"](); return ctx_r774.onUpButtonMouseLeave(); })("keydown", function InputNumber_span_3_Template_button_keydown_1_listener($event) { core["ɵɵrestoreView"](_r772); var ctx_r775 = core["ɵɵnextContext"](); return ctx_r775.onUpButtonKeyDown($event); })("keyup", function InputNumber_span_3_Template_button_keyup_1_listener() { core["ɵɵrestoreView"](_r772); var ctx_r776 = core["ɵɵnextContext"](); return ctx_r776.onUpButtonKeyUp(); });
        core["ɵɵelementEnd"]();
        core["ɵɵelementStart"](2, "button", 6);
        core["ɵɵlistener"]("mousedown", function InputNumber_span_3_Template_button_mousedown_2_listener($event) { core["ɵɵrestoreView"](_r772); var ctx_r777 = core["ɵɵnextContext"](); return ctx_r777.onDownButtonMouseDown($event); })("mouseup", function InputNumber_span_3_Template_button_mouseup_2_listener() { core["ɵɵrestoreView"](_r772); var ctx_r778 = core["ɵɵnextContext"](); return ctx_r778.onDownButtonMouseUp(); })("mouseleave", function InputNumber_span_3_Template_button_mouseleave_2_listener() { core["ɵɵrestoreView"](_r772); var ctx_r779 = core["ɵɵnextContext"](); return ctx_r779.onDownButtonMouseLeave(); })("keydown", function InputNumber_span_3_Template_button_keydown_2_listener($event) { core["ɵɵrestoreView"](_r772); var ctx_r780 = core["ɵɵnextContext"](); return ctx_r780.onDownButtonKeyDown($event); })("keyup", function InputNumber_span_3_Template_button_keyup_2_listener() { core["ɵɵrestoreView"](_r772); var ctx_r781 = core["ɵɵnextContext"](); return ctx_r781.onDownButtonKeyUp(); });
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var ctx_r768 = core["ɵɵnextContext"]();
        core["ɵɵadvance"](1);
        core["ɵɵclassMap"](ctx_r768.incrementButtonClass);
        core["ɵɵproperty"]("ngClass", core["ɵɵpureFunction0"](10, _c1$d))("icon", ctx_r768.incrementButtonIcon)("disabled", ctx_r768.disabled);
        core["ɵɵadvance"](1);
        core["ɵɵclassMap"](ctx_r768.decrementButtonClass);
        core["ɵɵproperty"]("ngClass", core["ɵɵpureFunction0"](11, _c2$a))("icon", ctx_r768.decrementButtonIcon)("disabled", ctx_r768.disabled);
    } }
    function InputNumber_button_4_Template(rf, ctx) { if (rf & 1) {
        var _r783 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "button", 6);
        core["ɵɵlistener"]("mousedown", function InputNumber_button_4_Template_button_mousedown_0_listener($event) { core["ɵɵrestoreView"](_r783); var ctx_r782 = core["ɵɵnextContext"](); return ctx_r782.onUpButtonMouseDown($event); })("mouseup", function InputNumber_button_4_Template_button_mouseup_0_listener() { core["ɵɵrestoreView"](_r783); var ctx_r784 = core["ɵɵnextContext"](); return ctx_r784.onUpButtonMouseUp(); })("mouseleave", function InputNumber_button_4_Template_button_mouseleave_0_listener() { core["ɵɵrestoreView"](_r783); var ctx_r785 = core["ɵɵnextContext"](); return ctx_r785.onUpButtonMouseLeave(); })("keydown", function InputNumber_button_4_Template_button_keydown_0_listener($event) { core["ɵɵrestoreView"](_r783); var ctx_r786 = core["ɵɵnextContext"](); return ctx_r786.onUpButtonKeyDown($event); })("keyup", function InputNumber_button_4_Template_button_keyup_0_listener() { core["ɵɵrestoreView"](_r783); var ctx_r787 = core["ɵɵnextContext"](); return ctx_r787.onUpButtonKeyUp(); });
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var ctx_r769 = core["ɵɵnextContext"]();
        core["ɵɵclassMap"](ctx_r769.incrementButtonClass);
        core["ɵɵproperty"]("ngClass", core["ɵɵpureFunction0"](5, _c1$d))("icon", ctx_r769.incrementButtonIcon)("disabled", ctx_r769.disabled);
    } }
    function InputNumber_button_5_Template(rf, ctx) { if (rf & 1) {
        var _r789 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "button", 6);
        core["ɵɵlistener"]("mousedown", function InputNumber_button_5_Template_button_mousedown_0_listener($event) { core["ɵɵrestoreView"](_r789); var ctx_r788 = core["ɵɵnextContext"](); return ctx_r788.onDownButtonMouseDown($event); })("mouseup", function InputNumber_button_5_Template_button_mouseup_0_listener() { core["ɵɵrestoreView"](_r789); var ctx_r790 = core["ɵɵnextContext"](); return ctx_r790.onDownButtonMouseUp(); })("mouseleave", function InputNumber_button_5_Template_button_mouseleave_0_listener() { core["ɵɵrestoreView"](_r789); var ctx_r791 = core["ɵɵnextContext"](); return ctx_r791.onDownButtonMouseLeave(); })("keydown", function InputNumber_button_5_Template_button_keydown_0_listener($event) { core["ɵɵrestoreView"](_r789); var ctx_r792 = core["ɵɵnextContext"](); return ctx_r792.onDownButtonKeyDown($event); })("keyup", function InputNumber_button_5_Template_button_keyup_0_listener() { core["ɵɵrestoreView"](_r789); var ctx_r793 = core["ɵɵnextContext"](); return ctx_r793.onDownButtonKeyUp(); });
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var ctx_r770 = core["ɵɵnextContext"]();
        core["ɵɵclassMap"](ctx_r770.decrementButtonClass);
        core["ɵɵproperty"]("ngClass", core["ɵɵpureFunction0"](5, _c2$a))("icon", ctx_r770.decrementButtonIcon)("disabled", ctx_r770.disabled);
    } }
    var _c3$4 = function (a1, a2, a3) { return { "p-inputnumber p-component": true, "p-inputnumber-buttons-stacked": a1, "p-inputnumber-buttons-horizontal": a2, "p-inputnumber-buttons-vertical": a3 }; };
    var INPUTNUMBER_VALUE_ACCESSOR = {
        provide: forms.NG_VALUE_ACCESSOR,
        useExisting: core.forwardRef(function () { return InputNumber; }),
        multi: true
    };
    var InputNumber = /** @class */ (function () {
        function InputNumber(el, cd) {
            this.el = el;
            this.cd = cd;
            this.showButtons = false;
            this.format = true;
            this.buttonLayout = "stacked";
            this.incrementButtonIcon = 'pi pi-angle-up';
            this.decrementButtonIcon = 'pi pi-angle-down';
            this.step = 1;
            this.onInput = new core.EventEmitter();
            this.onFocus = new core.EventEmitter();
            this.onBlur = new core.EventEmitter();
            this.onModelChange = function () { };
            this.onModelTouched = function () { };
            this.groupChar = '';
            this._modeOption = "decimal";
            this._useGroupingOption = true;
        }
        Object.defineProperty(InputNumber.prototype, "locale", {
            get: function () {
                return this._localeOption;
            },
            set: function (localeOption) {
                this._localeOption = localeOption;
                this.updateConstructParser();
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(InputNumber.prototype, "localeMatcher", {
            get: function () {
                return this._localeMatcherOption;
            },
            set: function (localeMatcherOption) {
                this._localeMatcherOption = localeMatcherOption;
                this.updateConstructParser();
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(InputNumber.prototype, "mode", {
            get: function () {
                return this._modeOption;
            },
            set: function (modeOption) {
                this._modeOption = modeOption;
                this.updateConstructParser();
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(InputNumber.prototype, "currency", {
            get: function () {
                return this._currencyOption;
            },
            set: function (currencyOption) {
                this._currencyOption = currencyOption;
                this.updateConstructParser();
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(InputNumber.prototype, "currencyDisplay", {
            get: function () {
                return this._currencyDisplayOption;
            },
            set: function (currencyDisplayOption) {
                this._currencyDisplayOption = currencyDisplayOption;
                this.updateConstructParser();
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(InputNumber.prototype, "useGrouping", {
            get: function () {
                return this._useGroupingOption;
            },
            set: function (useGroupingOption) {
                this._useGroupingOption = useGroupingOption;
                this.updateConstructParser();
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(InputNumber.prototype, "minFractionDigits", {
            get: function () {
                return this._minFractionDigitsOption;
            },
            set: function (minFractionDigitsOption) {
                this._minFractionDigitsOption = minFractionDigitsOption;
                this.updateConstructParser();
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(InputNumber.prototype, "maxFractionDigits", {
            get: function () {
                return this._maxFractionDigitsOption;
            },
            set: function (maxFractionDigitsOption) {
                this._maxFractionDigitsOption = maxFractionDigitsOption;
                this.updateConstructParser();
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(InputNumber.prototype, "prefix", {
            get: function () {
                return this._prefixOption;
            },
            set: function (prefixOption) {
                this._prefixOption = prefixOption;
                this.updateConstructParser();
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(InputNumber.prototype, "suffix", {
            get: function () {
                return this._suffixOption;
            },
            set: function (suffixOption) {
                this._suffixOption = suffixOption;
                this.updateConstructParser();
            },
            enumerable: true,
            configurable: true
        });
        InputNumber.prototype.ngOnInit = function () {
            this.constructParser();
            this.initialized = true;
        };
        InputNumber.prototype.getOptions = function () {
            return {
                localeMatcher: this.localeMatcher,
                style: this.mode,
                currency: this.currency,
                currencyDisplay: this.currencyDisplay,
                useGrouping: this.useGrouping,
                minimumFractionDigits: this.minFractionDigits,
                maximumFractionDigits: this.maxFractionDigits
            };
        };
        InputNumber.prototype.constructParser = function () {
            this.numberFormat = new Intl.NumberFormat(this.locale, this.getOptions());
            var numerals = new Intl.NumberFormat(this.locale, { useGrouping: false }).format(9876543210).split('').reverse();
            var index = new Map(numerals.map(function (d, i) { return [d, i]; }));
            this._numeral = new RegExp("[" + numerals.join('') + "]", 'g');
            this._decimal = this.getDecimalExpression();
            this._group = this.getGroupingExpression();
            this._minusSign = this.getMinusSignExpression();
            this._currency = this.getCurrencyExpression();
            this._suffix = new RegExp("" + this.escapeRegExp(this.suffix || ''), 'g');
            this._prefix = new RegExp("" + this.escapeRegExp(this.prefix || ''), 'g');
            this._index = function (d) { return index.get(d); };
        };
        InputNumber.prototype.updateConstructParser = function () {
            if (this.initialized) {
                this.constructParser();
            }
        };
        InputNumber.prototype.escapeRegExp = function (text) {
            return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&');
        };
        InputNumber.prototype.getDecimalExpression = function () {
            var formatter = new Intl.NumberFormat(this.locale, { useGrouping: false });
            return new RegExp("[" + formatter.format(1.1).trim().replace(this._numeral, '') + "]", 'g');
        };
        InputNumber.prototype.getGroupingExpression = function () {
            var formatter = new Intl.NumberFormat(this.locale, { useGrouping: true });
            this.groupChar = formatter.format(1000000).trim().replace(this._numeral, '').charAt(0);
            return new RegExp("[" + this.groupChar + "]", 'g');
        };
        InputNumber.prototype.getMinusSignExpression = function () {
            var formatter = new Intl.NumberFormat(this.locale, { useGrouping: false });
            return new RegExp("[" + formatter.format(-1).trim().replace(this._numeral, '') + "]", 'g');
        };
        InputNumber.prototype.getCurrencyExpression = function () {
            if (this.currency) {
                var formatter = new Intl.NumberFormat(this.locale, { style: 'currency', currency: this.currency, currencyDisplay: this.currencyDisplay });
                return new RegExp("[" + formatter.format(1).replace(/\s/g, '').replace(this._numeral, '').replace(this._decimal, '').replace(this._group, '') + "]", 'g');
            }
            return new RegExp("[]", 'g');
        };
        InputNumber.prototype.formatValue = function (value) {
            if (value != null) {
                if (value === '-') { // Minus sign
                    return value;
                }
                if (this.format) {
                    var formatter = new Intl.NumberFormat(this.locale, this.getOptions());
                    var formattedValue = formatter.format(value);
                    if (this.prefix) {
                        formattedValue = this.prefix + formattedValue;
                    }
                    if (this.suffix) {
                        formattedValue = formattedValue + this.suffix;
                    }
                    return formattedValue;
                }
                return value;
            }
            return '';
        };
        InputNumber.prototype.parseValue = function (text) {
            var filteredText = text
                .replace(this._suffix, '')
                .replace(this._prefix, '')
                .trim()
                .replace(/\s/g, '')
                .replace(this._currency, '')
                .replace(this._group, '')
                .replace(this._minusSign, '-')
                .replace(this._decimal, '.')
                .replace(this._numeral, this._index);
            if (filteredText) {
                if (filteredText === '-') // Minus sign
                    return filteredText;
                var parsedValue = +filteredText;
                return isNaN(parsedValue) ? null : parsedValue;
            }
            return null;
        };
        InputNumber.prototype.repeat = function (event, interval, dir) {
            var _this = this;
            var i = interval || 500;
            this.clearTimer();
            this.timer = setTimeout(function () {
                _this.repeat(event, 40, dir);
            }, i);
            this.spin(event, dir);
        };
        InputNumber.prototype.spin = function (event, dir) {
            var step = this.step * dir;
            var currentValue = this.parseValue(this.input.nativeElement.value) || 0;
            var newValue = this.validateValue(currentValue + step);
            if (this.maxlength && this.maxlength < this.formatValue(newValue).length) {
                return;
            }
            this.updateInput(newValue, null, 'spin');
            this.updateModel(event, newValue);
            this.handleOnInput(event, currentValue, newValue);
        };
        InputNumber.prototype.onUpButtonMouseDown = function (event) {
            this.input.nativeElement.focus();
            this.repeat(event, null, 1);
            event.preventDefault();
        };
        InputNumber.prototype.onUpButtonMouseUp = function () {
            this.clearTimer();
        };
        InputNumber.prototype.onUpButtonMouseLeave = function () {
            this.clearTimer();
        };
        InputNumber.prototype.onUpButtonKeyDown = function (event) {
            if (event.keyCode === 32 || event.keyCode === 13) {
                this.repeat(event, null, 1);
            }
        };
        InputNumber.prototype.onUpButtonKeyUp = function () {
            this.clearTimer();
        };
        InputNumber.prototype.onDownButtonMouseDown = function (event) {
            this.input.nativeElement.focus();
            this.repeat(event, null, -1);
            event.preventDefault();
        };
        InputNumber.prototype.onDownButtonMouseUp = function () {
            this.clearTimer();
        };
        InputNumber.prototype.onDownButtonMouseLeave = function () {
            this.clearTimer();
        };
        InputNumber.prototype.onDownButtonKeyUp = function () {
            this.clearTimer();
        };
        InputNumber.prototype.onDownButtonKeyDown = function (event) {
            if (event.keyCode === 32 || event.keyCode === 13) {
                this.repeat(event, null, -1);
            }
        };
        InputNumber.prototype.onUserInput = function (event) {
            if (this.isSpecialChar) {
                event.target.value = this.lastValue;
            }
            this.isSpecialChar = false;
        };
        InputNumber.prototype.onInputKeyDown = function (event) {
            this.lastValue = event.target.value;
            if (event.shiftKey || event.altKey) {
                this.isSpecialChar = true;
                return;
            }
            var selectionStart = event.target.selectionStart;
            var selectionEnd = event.target.selectionEnd;
            var inputValue = event.target.value;
            var newValueStr = null;
            if (event.altKey) {
                event.preventDefault();
            }
            switch (event.which) {
                //up
                case 38:
                    this.spin(event, 1);
                    event.preventDefault();
                    break;
                //down
                case 40:
                    this.spin(event, -1);
                    event.preventDefault();
                    break;
                //left
                case 37:
                    if (!this.isNumeralChar(inputValue.charAt(selectionStart - 1))) {
                        event.preventDefault();
                    }
                    break;
                //right
                case 39:
                    if (!this.isNumeralChar(inputValue.charAt(selectionStart))) {
                        event.preventDefault();
                    }
                    break;
                //backspace
                case 8: {
                    event.preventDefault();
                    if (selectionStart === selectionEnd) {
                        var deleteChar = inputValue.charAt(selectionStart - 1);
                        var decimalCharIndex = inputValue.search(this._decimal);
                        this._decimal.lastIndex = 0;
                        if (this.isNumeralChar(deleteChar)) {
                            if (this._group.test(deleteChar)) {
                                this._group.lastIndex = 0;
                                newValueStr = inputValue.slice(0, selectionStart - 2) + inputValue.slice(selectionStart - 1);
                            }
                            else if (this._decimal.test(deleteChar)) {
                                this._decimal.lastIndex = 0;
                                this.input.nativeElement.setSelectionRange(selectionStart - 1, selectionStart - 1);
                            }
                            else if (decimalCharIndex > 0 && selectionStart > decimalCharIndex) {
                                newValueStr = inputValue.slice(0, selectionStart - 1) + '0' + inputValue.slice(selectionStart);
                            }
                            else if (decimalCharIndex > 0 && decimalCharIndex === 1) {
                                newValueStr = inputValue.slice(0, selectionStart - 1) + '0' + inputValue.slice(selectionStart);
                                newValueStr = this.parseValue(newValueStr) > 0 ? newValueStr : '';
                            }
                            else {
                                newValueStr = inputValue.slice(0, selectionStart - 1) + inputValue.slice(selectionStart);
                            }
                        }
                        this.updateValue(event, newValueStr, null, 'delete-single');
                    }
                    else {
                        newValueStr = this.deleteRange(inputValue, selectionStart, selectionEnd);
                        this.updateValue(event, newValueStr, null, 'delete-range');
                    }
                    break;
                }
                // del
                case 46:
                    event.preventDefault();
                    if (selectionStart === selectionEnd) {
                        var deleteChar = inputValue.charAt(selectionStart);
                        var decimalCharIndex = inputValue.search(this._decimal);
                        this._decimal.lastIndex = 0;
                        if (this.isNumeralChar(deleteChar)) {
                            if (this._group.test(deleteChar)) {
                                this._group.lastIndex = 0;
                                newValueStr = inputValue.slice(0, selectionStart) + inputValue.slice(selectionStart + 2);
                            }
                            else if (this._decimal.test(deleteChar)) {
                                this._decimal.lastIndex = 0;
                                this.input.nativeElement.setSelectionRange(selectionStart + 1, selectionStart + 1);
                            }
                            else if (decimalCharIndex > 0 && selectionStart > decimalCharIndex) {
                                newValueStr = inputValue.slice(0, selectionStart) + '0' + inputValue.slice(selectionStart + 1);
                            }
                            else if (decimalCharIndex > 0 && decimalCharIndex === 1) {
                                newValueStr = inputValue.slice(0, selectionStart) + '0' + inputValue.slice(selectionStart + 1);
                                newValueStr = this.parseValue(newValueStr) > 0 ? newValueStr : '';
                            }
                            else {
                                newValueStr = inputValue.slice(0, selectionStart) + inputValue.slice(selectionStart + 1);
                            }
                        }
                        this.updateValue(event, newValueStr, null, 'delete-back-single');
                    }
                    else {
                        newValueStr = this.deleteRange(inputValue, selectionStart, selectionEnd);
                        this.updateValue(event, newValueStr, null, 'delete-range');
                    }
                    break;
                default:
                    break;
            }
        };
        InputNumber.prototype.onInputKeyPress = function (event) {
            event.preventDefault();
            var code = event.which || event.keyCode;
            var char = String.fromCharCode(code);
            var isDecimalSign = this.isDecimalSign(char);
            var isMinusSign = this.isMinusSign(char);
            if ((48 <= code && code <= 57) || isMinusSign || isDecimalSign) {
                this.insert(event, char, { isDecimalSign: isDecimalSign, isMinusSign: isMinusSign });
            }
        };
        InputNumber.prototype.onPaste = function (event) {
            event.preventDefault();
            var data = (event.clipboardData || window['clipboardData']).getData('Text');
            if (data) {
                var filteredData = this.parseValue(data);
                if (filteredData != null) {
                    this.insert(event, filteredData.toString());
                }
            }
        };
        InputNumber.prototype.isMinusSign = function (char) {
            if (this._minusSign.test(char)) {
                this._minusSign.lastIndex = 0;
                return true;
            }
            return false;
        };
        InputNumber.prototype.isDecimalSign = function (char) {
            if (this._decimal.test(char)) {
                this._decimal.lastIndex = 0;
                return true;
            }
            return false;
        };
        InputNumber.prototype.insert = function (event, text, sign) {
            if (sign === void 0) { sign = { isDecimalSign: false, isMinusSign: false }; }
            var selectionStart = this.input.nativeElement.selectionStart;
            var selectionEnd = this.input.nativeElement.selectionEnd;
            var inputValue = this.input.nativeElement.value.trim();
            var decimalCharIndex = inputValue.search(this._decimal);
            this._decimal.lastIndex = 0;
            var minusCharIndex = inputValue.search(this._minusSign);
            this._minusSign.lastIndex = 0;
            var newValueStr;
            if (sign.isMinusSign) {
                if (selectionStart === 0) {
                    newValueStr = inputValue;
                    if (minusCharIndex === -1 || selectionEnd !== 0) {
                        newValueStr = this.insertText(inputValue, text, 0, selectionEnd);
                    }
                    this.updateValue(event, newValueStr, text, 'insert');
                }
            }
            else if (sign.isDecimalSign) {
                if (decimalCharIndex > 0 && selectionStart === decimalCharIndex) {
                    this.updateValue(event, inputValue, text, 'insert');
                }
                else if (decimalCharIndex > selectionStart && decimalCharIndex < selectionEnd) {
                    newValueStr = this.insertText(inputValue, text, selectionStart, selectionEnd);
                    this.updateValue(event, newValueStr, text, 'insert');
                }
            }
            else {
                var maxFractionDigits = this.numberFormat.resolvedOptions().maximumFractionDigits;
                if (decimalCharIndex > 0 && selectionStart > decimalCharIndex) {
                    if ((selectionStart + text.length - (decimalCharIndex + 1)) <= maxFractionDigits) {
                        newValueStr = inputValue.slice(0, selectionStart) + text + inputValue.slice(selectionStart + text.length);
                        this.updateValue(event, newValueStr, text, 'insert');
                    }
                }
                else {
                    newValueStr = this.insertText(inputValue, text, selectionStart, selectionEnd);
                    var operation = selectionStart !== selectionEnd ? 'range-insert' : 'insert';
                    this.updateValue(event, newValueStr, text, operation);
                }
            }
        };
        InputNumber.prototype.insertText = function (value, text, start, end) {
            var textSplit = text.split('.');
            if (textSplit.length == 2) {
                var decimalCharIndex = value.slice(start, end).search(this._decimal);
                this._decimal.lastIndex = 0;
                return (decimalCharIndex > 0) ? value.slice(0, start) + this.formatValue(text) + value.slice(end) : value;
            }
            else if ((end - start) === value.length) {
                return this.formatValue(text);
            }
            else if (start === 0) {
                return text + value.slice(end);
            }
            else if (end === value.length) {
                return value.slice(0, start) + text;
            }
            else {
                return value.slice(0, start) + text + value.slice(end);
            }
        };
        InputNumber.prototype.deleteRange = function (value, start, end) {
            var newValueStr;
            if ((end - start) === value.length)
                newValueStr = '';
            else if (start === 0)
                newValueStr = value.slice(end);
            else if (end === value.length)
                newValueStr = value.slice(0, start);
            else
                newValueStr = value.slice(0, start) + value.slice(end);
            return newValueStr;
        };
        InputNumber.prototype.initCursor = function () {
            var selectionStart = this.input.nativeElement.selectionStart;
            var inputValue = this.input.nativeElement.value;
            var valueLength = inputValue.length;
            var index = null;
            var char = inputValue.charAt(selectionStart);
            if (this.isNumeralChar(char)) {
                return;
            }
            //left
            var i = selectionStart - 1;
            while (i >= 0) {
                char = inputValue.charAt(i);
                if (this.isNumeralChar(char)) {
                    index = i;
                    break;
                }
                else {
                    i--;
                }
            }
            if (index !== null) {
                this.input.nativeElement.setSelectionRange(index + 1, index + 1);
            }
            else {
                i = selectionStart + 1;
                while (i < valueLength) {
                    char = inputValue.charAt(i);
                    if (this.isNumeralChar(char)) {
                        index = i;
                        break;
                    }
                    else {
                        i++;
                    }
                }
                if (index !== null) {
                    this.input.nativeElement.setSelectionRange(index, index);
                }
            }
        };
        InputNumber.prototype.onInputClick = function () {
            this.initCursor();
        };
        InputNumber.prototype.isNumeralChar = function (char) {
            if (char.length === 1 && (this._numeral.test(char) || this._decimal.test(char) || this._group.test(char) || this._minusSign.test(char))) {
                this.resetRegex();
                return true;
            }
            return false;
        };
        InputNumber.prototype.resetRegex = function () {
            this._numeral.lastIndex = 0;
            this._decimal.lastIndex = 0;
            this._group.lastIndex = 0;
            this._minusSign.lastIndex = 0;
        };
        InputNumber.prototype.updateValue = function (event, valueStr, insertedValueStr, operation) {
            var currentValue = this.input.nativeElement.value;
            var newValue = null;
            if (valueStr != null) {
                newValue = this.parseValue(valueStr);
                this.updateInput(newValue, insertedValueStr, operation);
            }
            this.handleOnInput(event, currentValue, newValue);
        };
        InputNumber.prototype.handleOnInput = function (event, currentValue, newValue) {
            if (this.isValueChanged(currentValue, newValue)) {
                this.onInput.emit({ originalEvent: event, value: newValue });
            }
        };
        InputNumber.prototype.isValueChanged = function (currentValue, newValue) {
            if (newValue === null && currentValue !== null) {
                return true;
            }
            if (newValue != null) {
                var parsedCurrentValue = (typeof currentValue === 'string') ? this.parseValue(currentValue) : currentValue;
                return newValue !== parsedCurrentValue;
            }
            return false;
        };
        InputNumber.prototype.validateValue = function (value) {
            if (this.min !== null && value < this.min) {
                return this.min;
            }
            if (this.max !== null && value > this.max) {
                return this.max;
            }
            if (value === '-') { // Minus sign
                return null;
            }
            return value;
        };
        InputNumber.prototype.updateInput = function (value, insertedValueStr, operation) {
            var inputValue = this.input.nativeElement.value;
            var newValue = this.formatValue(value);
            var currentLength = inputValue.length;
            if (currentLength === 0) {
                this.input.nativeElement.value = newValue;
                this.input.nativeElement.setSelectionRange(0, 0);
                this.initCursor();
                var prefixLength = (this.prefix || '').length;
                var selectionEnd = prefixLength + insertedValueStr.length;
                this.input.nativeElement.setSelectionRange(selectionEnd, selectionEnd);
            }
            else {
                var selectionStart = this.input.nativeElement.selectionStart;
                var selectionEnd = this.input.nativeElement.selectionEnd;
                if (this.maxlength && this.maxlength < newValue.length) {
                    return;
                }
                this.input.nativeElement.value = newValue;
                var newLength = newValue.length;
                if (operation === 'range-insert') {
                    var startValue = this.parseValue((inputValue || '').slice(0, selectionStart));
                    var startValueStr = startValue !== null ? startValue.toString() : '';
                    var startExpr = startValueStr.split('').join("(" + this.groupChar + ")?");
                    var sRegex = new RegExp(startExpr, 'g');
                    sRegex.test(newValue);
                    var tExpr = insertedValueStr.split('').join("(" + this.groupChar + ")?");
                    var tRegex = new RegExp(tExpr, 'g');
                    tRegex.test(newValue.slice(sRegex.lastIndex));
                    selectionEnd = sRegex.lastIndex + tRegex.lastIndex;
                    this.input.nativeElement.setSelectionRange(selectionEnd, selectionEnd);
                }
                else if (newLength === currentLength) {
                    if (operation === 'insert' || operation === 'delete-back-single')
                        this.input.nativeElement.setSelectionRange(selectionEnd + 1, selectionEnd + 1);
                    else if (operation === 'delete-single')
                        this.input.nativeElement.setSelectionRange(selectionEnd - 1, selectionEnd - 1);
                    else if (operation === 'delete-range' || operation === 'spin')
                        this.input.nativeElement.setSelectionRange(selectionEnd, selectionEnd);
                }
                else if (operation === 'delete-back-single') {
                    var prevChar = inputValue.charAt(selectionEnd - 1);
                    var nextChar = inputValue.charAt(selectionEnd);
                    var diff = currentLength - newLength;
                    var isGroupChar = this._group.test(nextChar);
                    if (isGroupChar && diff === 1) {
                        selectionEnd += 1;
                    }
                    else if (!isGroupChar && this.isNumeralChar(prevChar)) {
                        selectionEnd += (-1 * diff) + 1;
                    }
                    this._group.lastIndex = 0;
                    this.input.nativeElement.setSelectionRange(selectionEnd, selectionEnd);
                }
                else {
                    selectionEnd = selectionEnd + (newLength - currentLength);
                    this.input.nativeElement.setSelectionRange(selectionEnd, selectionEnd);
                }
            }
            this.input.nativeElement.setAttribute('aria-valuenow', value);
        };
        InputNumber.prototype.onInputFocus = function (event) {
            this.focused = true;
            this.onFocus.emit(event);
        };
        InputNumber.prototype.onInputBlur = function (event) {
            this.focused = false;
            var newValue = this.validateValue(this.parseValue(this.input.nativeElement.value));
            this.input.nativeElement.value = this.formatValue(newValue);
            this.input.nativeElement.setAttribute('aria-valuenow', newValue);
            this.updateModel(event, newValue);
            this.onBlur.emit(event);
        };
        InputNumber.prototype.formattedValue = function () {
            return this.formatValue(this.value);
        };
        InputNumber.prototype.updateModel = function (event, value) {
            if (this.value !== value) {
                this.value = value;
                this.onModelChange(value);
            }
            this.onModelTouched();
        };
        InputNumber.prototype.writeValue = function (value) {
            this.value = value;
            this.cd.markForCheck();
        };
        InputNumber.prototype.registerOnChange = function (fn) {
            this.onModelChange = fn;
        };
        InputNumber.prototype.registerOnTouched = function (fn) {
            this.onModelTouched = fn;
        };
        InputNumber.prototype.setDisabledState = function (val) {
            this.disabled = val;
            this.cd.markForCheck();
        };
        Object.defineProperty(InputNumber.prototype, "filled", {
            get: function () {
                return (this.value != null && this.value.toString().length > 0);
            },
            enumerable: true,
            configurable: true
        });
        InputNumber.prototype.clearTimer = function () {
            if (this.timer) {
                clearInterval(this.timer);
            }
        };
        InputNumber.ɵfac = function InputNumber_Factory(t) { return new (t || InputNumber)(core["ɵɵdirectiveInject"](core.ElementRef), core["ɵɵdirectiveInject"](core.ChangeDetectorRef)); };
        InputNumber.ɵcmp = core["ɵɵdefineComponent"]({ type: InputNumber, selectors: [["p-inputNumber"]], viewQuery: function InputNumber_Query(rf, ctx) { if (rf & 1) {
                core["ɵɵviewQuery"](_c0$k, true);
            } if (rf & 2) {
                var _t;
                core["ɵɵqueryRefresh"](_t = core["ɵɵloadQuery"]()) && (ctx.input = _t.first);
            } }, hostVars: 4, hostBindings: function InputNumber_HostBindings(rf, ctx) { if (rf & 2) {
                core["ɵɵclassProp"]("p-inputwrapper-filled", ctx.filled)("p-inputwrapper-focus", ctx.focused);
            } }, inputs: { showButtons: "showButtons", format: "format", buttonLayout: "buttonLayout", disabled: "disabled", inputId: "inputId", styleClass: "styleClass", style: "style", placeholder: "placeholder", size: "size", maxlength: "maxlength", tabindex: "tabindex", title: "title", ariaLabel: "ariaLabel", ariaRequired: "ariaRequired", name: "name", required: "required", autocomplete: "autocomplete", min: "min", max: "max", incrementButtonClass: "incrementButtonClass", decrementButtonClass: "decrementButtonClass", incrementButtonIcon: "incrementButtonIcon", decrementButtonIcon: "decrementButtonIcon", step: "step", inputStyle: "inputStyle", inputStyleClass: "inputStyleClass", locale: "locale", localeMatcher: "localeMatcher", mode: "mode", currency: "currency", currencyDisplay: "currencyDisplay", useGrouping: "useGrouping", minFractionDigits: "minFractionDigits", maxFractionDigits: "maxFractionDigits", prefix: "prefix", suffix: "suffix" }, outputs: { onInput: "onInput", onFocus: "onFocus", onBlur: "onBlur" }, features: [core["ɵɵProvidersFeature"]([INPUTNUMBER_VALUE_ACCESSOR])], decls: 6, vars: 30, consts: [[3, "ngClass", "ngStyle"], ["pInputText", "", 3, "ngClass", "ngStyle", "value", "disabled", "input", "keydown", "keypress", "paste", "click", "focus", "blur"], ["input", ""], ["class", "p-inputnumber-button-group", 4, "ngIf"], ["type", "button", "pButton", "", 3, "ngClass", "class", "icon", "disabled", "mousedown", "mouseup", "mouseleave", "keydown", "keyup", 4, "ngIf"], [1, "p-inputnumber-button-group"], ["type", "button", "pButton", "", 3, "ngClass", "icon", "disabled", "mousedown", "mouseup", "mouseleave", "keydown", "keyup"]], template: function InputNumber_Template(rf, ctx) { if (rf & 1) {
                core["ɵɵelementStart"](0, "span", 0);
                core["ɵɵelementStart"](1, "input", 1, 2);
                core["ɵɵlistener"]("input", function InputNumber_Template_input_input_1_listener($event) { return ctx.onUserInput($event); })("keydown", function InputNumber_Template_input_keydown_1_listener($event) { return ctx.onInputKeyDown($event); })("keypress", function InputNumber_Template_input_keypress_1_listener($event) { return ctx.onInputKeyPress($event); })("paste", function InputNumber_Template_input_paste_1_listener($event) { return ctx.onPaste($event); })("click", function InputNumber_Template_input_click_1_listener() { return ctx.onInputClick(); })("focus", function InputNumber_Template_input_focus_1_listener($event) { return ctx.onInputFocus($event); })("blur", function InputNumber_Template_input_blur_1_listener($event) { return ctx.onInputBlur($event); });
                core["ɵɵelementEnd"]();
                core["ɵɵtemplate"](3, InputNumber_span_3_Template, 3, 12, "span", 3);
                core["ɵɵtemplate"](4, InputNumber_button_4_Template, 1, 6, "button", 4);
                core["ɵɵtemplate"](5, InputNumber_button_5_Template, 1, 6, "button", 4);
                core["ɵɵelementEnd"]();
            } if (rf & 2) {
                core["ɵɵclassMap"](ctx.styleClass);
                core["ɵɵproperty"]("ngClass", core["ɵɵpureFunction3"](26, _c3$4, ctx.showButtons && ctx.buttonLayout === "stacked", ctx.showButtons && ctx.buttonLayout === "horizontal", ctx.showButtons && ctx.buttonLayout === "vertical"))("ngStyle", ctx.style);
                core["ɵɵadvance"](1);
                core["ɵɵclassMap"](ctx.inputStyleClass);
                core["ɵɵproperty"]("ngClass", "p-inputnumber-input")("ngStyle", ctx.inputStyle)("value", ctx.formattedValue())("disabled", ctx.disabled);
                core["ɵɵattribute"]("placeholder", ctx.placeholder)("title", ctx.title)("id", ctx.inputId)("size", ctx.size)("name", ctx.name)("autocomplete", ctx.autocomplete)("maxlength", ctx.maxlength)("tabindex", ctx.tabindex)("aria-label", ctx.ariaLabel)("aria-required", ctx.ariaRequired)("required", ctx.required)("aria-valumin", ctx.min)("aria-valuemax", ctx.max);
                core["ɵɵadvance"](2);
                core["ɵɵproperty"]("ngIf", ctx.showButtons && ctx.buttonLayout === "stacked");
                core["ɵɵadvance"](1);
                core["ɵɵproperty"]("ngIf", ctx.showButtons && ctx.buttonLayout !== "stacked");
                core["ɵɵadvance"](1);
                core["ɵɵproperty"]("ngIf", ctx.showButtons && ctx.buttonLayout !== "stacked");
            } }, directives: [common.NgClass, common.NgStyle, inputtext.InputText, common.NgIf, button.ButtonDirective], styles: [".p-inputnumber{display:-webkit-inline-box;display:inline-flex}.p-inputnumber-button{display:-webkit-box;display:flex;-webkit-box-align:center;align-items:center;-webkit-box-pack:center;justify-content:center;-webkit-box-flex:0;flex:0 0 auto}.p-inputnumber-buttons-horizontal .ui-button.p-inputnumber-button .ui-button-text,.p-inputnumber-buttons-stacked .ui-button.p-inputnumber-button .ui-button-text{display:none}.p-inputnumber-buttons-stacked p-button.p-inputnumber-button-up{border-top-left-radius:0;border-bottom-left-radius:0;border-bottom-right-radius:0;padding:0}.p-inputnumber-buttons-stacked .p-inputnumber-input{border-top-right-radius:0;border-bottom-right-radius:0}.p-inputnumber-buttons-stacked .ui-button.p-inputnumber-button-down{border-top-left-radius:0;border-top-right-radius:0;border-bottom-left-radius:0;padding:0}.p-inputnumber-buttons-stacked .p-inputnumber-button-group{display:-webkit-box;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;flex-direction:column}.p-inputnumber-buttons-stacked .p-inputnumber-button-group .ui-button.p-inputnumber-button{-webkit-box-flex:1;flex:1 1 auto}.p-inputnumber-buttons-horizontal .ui-button.p-inputnumber-button-up{-webkit-box-ordinal-group:4;order:3;border-top-left-radius:0;border-bottom-left-radius:0}.p-inputnumber-buttons-horizontal .p-inputnumber-input{-webkit-box-ordinal-group:3;order:2;border-radius:0}.p-inputnumber-buttons-horizontal .ui-button.p-inputnumber-button-down{-webkit-box-ordinal-group:2;order:1;border-top-right-radius:0;border-bottom-right-radius:0}.p-inputnumber-buttons-vertical{-webkit-box-orient:vertical;-webkit-box-direction:normal;flex-direction:column}.p-inputnumber-buttons-vertical .ui-button.p-inputnumber-button-up{-webkit-box-ordinal-group:2;order:1;border-bottom-left-radius:0;border-bottom-right-radius:0;width:100%}.p-inputnumber-buttons-vertical .p-inputnumber-input{-webkit-box-ordinal-group:3;order:2;border-radius:0;text-align:center}.p-inputnumber-buttons-vertical .ui-button.p-inputnumber-button-down{-webkit-box-ordinal-group:4;order:3;border-top-left-radius:0;border-top-right-radius:0;width:100%}.p-inputnumber-input{-webkit-box-flex:1;flex:1 1 auto}.p-fluid .p-inputnumber{width:100%}.p-fluid .p-inputnumber .p-inputnumber-input{width:1%}.p-fluid .p-inputnumber-buttons-vertical .p-inputnumber-input{width:100%}"], encapsulation: 2, changeDetection: 0 });
        return InputNumber;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](InputNumber, [{
            type: core.Component,
            args: [{
                    selector: 'p-inputNumber',
                    template: "\n        <span [ngClass]=\"{'p-inputnumber p-component': true,'p-inputnumber-buttons-stacked': this.showButtons && this.buttonLayout === 'stacked',\n                'p-inputnumber-buttons-horizontal': this.showButtons && this.buttonLayout === 'horizontal', 'p-inputnumber-buttons-vertical': this.showButtons && this.buttonLayout === 'vertical'}\"\n                [ngStyle]=\"style\" [class]=\"styleClass\">\n            <input #input [ngClass]=\"'p-inputnumber-input'\" [ngStyle]=\"inputStyle\" [class]=\"inputStyleClass\" pInputText [value]=\"formattedValue()\" [attr.placeholder]=\"placeholder\" [attr.title]=\"title\" [attr.id]=\"inputId\"\n                [attr.size]=\"size\" [attr.name]=\"name\" [attr.autocomplete]=\"autocomplete\" [attr.maxlength]=\"maxlength\" [attr.tabindex]=\"tabindex\" [attr.aria-label]=\"ariaLabel\"\n                [attr.aria-required]=\"ariaRequired\" [disabled]=\"disabled\" [attr.required]=\"required\" [attr.aria-valumin]=\"min\" [attr.aria-valuemax]=\"max\"\n                (input)=\"onUserInput($event)\" (keydown)=\"onInputKeyDown($event)\" (keypress)=\"onInputKeyPress($event)\" (paste)=\"onPaste($event)\" (click)=\"onInputClick()\"\n                (focus)=\"onInputFocus($event)\" (blur)=\"onInputBlur($event)\">\n            <span class=\"p-inputnumber-button-group\" *ngIf=\"showButtons && buttonLayout === 'stacked'\">\n                <button type=\"button\" pButton [ngClass]=\"{'p-inputnumber-button p-inputnumber-button-up': true}\" [class]=\"incrementButtonClass\" [icon]=\"incrementButtonIcon\" [disabled]=\"disabled\"\n                    (mousedown)=\"this.onUpButtonMouseDown($event)\" (mouseup)=\"onUpButtonMouseUp()\" (mouseleave)=\"onUpButtonMouseLeave()\" (keydown)=\"onUpButtonKeyDown($event)\" (keyup)=\"onUpButtonKeyUp()\"></button>\n                <button type=\"button\" pButton [ngClass]=\"{'p-inputnumber-button p-inputnumber-button-down': true}\" [class]=\"decrementButtonClass\" [icon]=\"decrementButtonIcon\" [disabled]=\"disabled\"\n                    (mousedown)=\"this.onDownButtonMouseDown($event)\" (mouseup)=\"onDownButtonMouseUp()\" (mouseleave)=\"onDownButtonMouseLeave()\" (keydown)=\"onDownButtonKeyDown($event)\" (keyup)=\"onDownButtonKeyUp()\"></button>\n            </span>\n            <button type=\"button\" pButton [ngClass]=\"{'p-inputnumber-button p-inputnumber-button-up': true}\" [class]=\"incrementButtonClass\" [icon]=\"incrementButtonIcon\" *ngIf=\"showButtons && buttonLayout !== 'stacked'\" [disabled]=\"disabled\"\n                (mousedown)=\"this.onUpButtonMouseDown($event)\" (mouseup)=\"onUpButtonMouseUp()\" (mouseleave)=\"onUpButtonMouseLeave()\" (keydown)=\"onUpButtonKeyDown($event)\" (keyup)=\"onUpButtonKeyUp()\"></button>\n            <button type=\"button\" pButton [ngClass]=\"{'p-inputnumber-button p-inputnumber-button-down': true}\" [class]=\"decrementButtonClass\" [icon]=\"decrementButtonIcon\" *ngIf=\"showButtons && buttonLayout !== 'stacked'\" [disabled]=\"disabled\"\n                (mousedown)=\"this.onDownButtonMouseDown($event)\" (mouseup)=\"onDownButtonMouseUp()\" (mouseleave)=\"onDownButtonMouseLeave()\" (keydown)=\"onDownButtonKeyDown($event)\" (keyup)=\"onDownButtonKeyUp()\"></button>\n        </span>\n    ",
                    changeDetection: core.ChangeDetectionStrategy.OnPush,
                    providers: [INPUTNUMBER_VALUE_ACCESSOR],
                    encapsulation: core.ViewEncapsulation.None,
                    styleUrls: ['./inputnumber.css'],
                    host: {
                        '[class.p-inputwrapper-filled]': 'filled',
                        '[class.p-inputwrapper-focus]': 'focused'
                    }
                }]
        }], function () { return [{ type: core.ElementRef }, { type: core.ChangeDetectorRef }]; }, { showButtons: [{
                type: core.Input
            }], format: [{
                type: core.Input
            }], buttonLayout: [{
                type: core.Input
            }], disabled: [{
                type: core.Input
            }], inputId: [{
                type: core.Input
            }], styleClass: [{
                type: core.Input
            }], style: [{
                type: core.Input
            }], placeholder: [{
                type: core.Input
            }], size: [{
                type: core.Input
            }], maxlength: [{
                type: core.Input
            }], tabindex: [{
                type: core.Input
            }], title: [{
                type: core.Input
            }], ariaLabel: [{
                type: core.Input
            }], ariaRequired: [{
                type: core.Input
            }], name: [{
                type: core.Input
            }], required: [{
                type: core.Input
            }], autocomplete: [{
                type: core.Input
            }], min: [{
                type: core.Input
            }], max: [{
                type: core.Input
            }], incrementButtonClass: [{
                type: core.Input
            }], decrementButtonClass: [{
                type: core.Input
            }], incrementButtonIcon: [{
                type: core.Input
            }], decrementButtonIcon: [{
                type: core.Input
            }], step: [{
                type: core.Input
            }], inputStyle: [{
                type: core.Input
            }], inputStyleClass: [{
                type: core.Input
            }], input: [{
                type: core.ViewChild,
                args: ['input']
            }], onInput: [{
                type: core.Output
            }], onFocus: [{
                type: core.Output
            }], onBlur: [{
                type: core.Output
            }], locale: [{
                type: core.Input
            }], localeMatcher: [{
                type: core.Input
            }], mode: [{
                type: core.Input
            }], currency: [{
                type: core.Input
            }], currencyDisplay: [{
                type: core.Input
            }], useGrouping: [{
                type: core.Input
            }], minFractionDigits: [{
                type: core.Input
            }], maxFractionDigits: [{
                type: core.Input
            }], prefix: [{
                type: core.Input
            }], suffix: [{
                type: core.Input
            }] }); })();
    var InputNumberModule = /** @class */ (function () {
        function InputNumberModule() {
        }
        InputNumberModule.ɵmod = core["ɵɵdefineNgModule"]({ type: InputNumberModule });
        InputNumberModule.ɵinj = core["ɵɵdefineInjector"]({ factory: function InputNumberModule_Factory(t) { return new (t || InputNumberModule)(); }, imports: [[common.CommonModule, inputtext.InputTextModule, button.ButtonModule]] });
        return InputNumberModule;
    }());
    (function () { (typeof ngJitMode === "undefined" || ngJitMode) && core["ɵɵsetNgModuleScope"](InputNumberModule, { declarations: [InputNumber], imports: [common.CommonModule, inputtext.InputTextModule, button.ButtonModule], exports: [InputNumber] }); })();
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](InputNumberModule, [{
            type: core.NgModule,
            args: [{
                    imports: [common.CommonModule, inputtext.InputTextModule, button.ButtonModule],
                    exports: [InputNumber],
                    declarations: [InputNumber]
                }]
        }], null, null); })();

    var InputNumberDirective = /** @class */ (function () {
        function InputNumberDirective(inputNumber, changeDetectorRef) {
            this.inputNumber = inputNumber;
            this.changeDetectorRef = changeDetectorRef;
            this.locale = 'ru-RU';
            this.useGrouping = false;
        }
        InputNumberDirective.prototype.ngOnInit = function () {
            var _this = this;
            this.inputNumber.locale = this.locale;
            this.inputNumber.useGrouping = this.useGrouping;
            if (this.locale === 'ru-RU') {
                this.inputNumber._decimal = /[,.]/g;
                this.inputNumber.getDecimalExpression = function () { return _this.getRussianDecimalExpression(); };
            }
            this.minFractionDigits = this.inputNumber.minFractionDigits;
            this.inputNumber.insert = function (event, text, sign) {
                if (sign === void 0) { sign = { isDecimalSign: false, isMinusSign: false }; }
                return _this.insert(event, text, sign);
            };
            this.inputNumber.onInputKeyDown = function (event) { return _this.onInputKeyDown(event); };
            this.inputNumber.insertText = function (value, text, start, end) { return _this.insertText(value, text, start, end); };
        };
        // bypass for Russian locale
        InputNumberDirective.prototype.getRussianDecimalExpression = function () {
            return new RegExp('[,.]', 'g');
        };
        InputNumberDirective.prototype.insert = function (event, text, sign) {
            if (sign === void 0) { sign = { isDecimalSign: false, isMinusSign: false }; }
            var selectionStart = this.inputNumber.input.nativeElement.selectionStart;
            var selectionEnd = this.inputNumber.input.nativeElement.selectionEnd;
            var inputValue = this.inputNumber.input.nativeElement.value.trim();
            var decimalCharIndex = inputValue.search(this.inputNumber._decimal);
            this.inputNumber._decimal.lastIndex = 0;
            var minusCharIndex = inputValue.search(this.inputNumber._minusSign);
            this.inputNumber._minusSign.lastIndex = 0;
            var newValueStr;
            if (sign.isMinusSign) {
                if (selectionStart === 0) {
                    newValueStr = inputValue;
                    if (minusCharIndex === -1 || selectionEnd !== 0) {
                        newValueStr = this.inputNumber.insertText(inputValue, text, 0, selectionEnd);
                    }
                    this.inputNumber.updateValue(event, newValueStr, text, 'insert');
                }
            }
            else if (sign.isDecimalSign) {
                if (decimalCharIndex > 0 && selectionStart === decimalCharIndex) {
                    this.inputNumber.updateValue(event, inputValue, text, 'insert');
                }
                else if (decimalCharIndex > selectionStart && decimalCharIndex < selectionEnd) {
                    newValueStr = this.inputNumber.insertText(inputValue, text, selectionStart, selectionEnd);
                    this.inputNumber.updateValue(event, newValueStr, text, 'insert');
                }
            }
            else {
                var maxFractionDigits = this.inputNumber.numberFormat.resolvedOptions().maximumFractionDigits;
                if (decimalCharIndex > 0 && selectionStart > decimalCharIndex) {
                    var resultingFractionDigits = selectionStart + text.length - (decimalCharIndex + 1) - (selectionEnd - selectionStart);
                    if (resultingFractionDigits <= maxFractionDigits) {
                        newValueStr = inputValue.slice(0, selectionStart) + text + inputValue.slice(selectionEnd);
                        if (resultingFractionDigits > this.inputNumber.minFractionDigits) {
                            this.setMinFractionDigits(resultingFractionDigits);
                        }
                    }
                }
                else {
                    newValueStr = this.inputNumber.insertText(inputValue, text, selectionStart, selectionEnd);
                    if ((decimalCharIndex > 0 && (selectionStart < decimalCharIndex && selectionEnd > decimalCharIndex)) || !inputValue) {
                        var newDecimalCharIndex = newValueStr.search(this.inputNumber._decimal);
                        this.inputNumber._decimal.lastIndex = 0;
                        if (newDecimalCharIndex === -1) {
                            this.setMinFractionDigits(this.minFractionDigits);
                        }
                        else {
                            var newFractionLength = newValueStr.length - (newDecimalCharIndex + 1);
                            this.setMinFractionDigits(newFractionLength <= this.minFractionDigits ? this.minFractionDigits :
                                (newFractionLength >= this.inputNumber.maxFractionDigits ? this.inputNumber.maxFractionDigits :
                                    newFractionLength));
                        }
                    }
                }
                var operation = selectionStart !== selectionEnd ? 'range-insert' : 'insert';
                this.inputNumber.updateValue(event, newValueStr, text, operation);
            }
        };
        InputNumberDirective.prototype.onInputKeyDown = function (event) {
            this.inputNumber.lastValue = event.target.value;
            if (event.shiftKey || event.altKey) {
                this.inputNumber.isSpecialChar = true;
                return;
            }
            var selectionStart = event.target.selectionStart;
            var selectionEnd = event.target.selectionEnd;
            var inputValue = event.target.value;
            var newValueStr = null;
            if (event.altKey) {
                event.preventDefault();
            }
            switch (event.which) {
                // up
                case 38:
                    this.inputNumber.spin(event, 1);
                    event.preventDefault();
                    break;
                // down
                case 40:
                    this.inputNumber.spin(event, -1);
                    event.preventDefault();
                    break;
                // left
                case 37:
                    if (!this.inputNumber.isNumeralChar(inputValue.charAt(selectionStart - 1))) {
                        event.preventDefault();
                    }
                    break;
                // right
                case 39:
                    if (!this.inputNumber.isNumeralChar(inputValue.charAt(selectionStart))) {
                        event.preventDefault();
                    }
                    break;
                // backspace
                case 8: {
                    event.preventDefault();
                    var decimalCharIndex = inputValue.search(this.inputNumber._decimal);
                    this.inputNumber._decimal.lastIndex = 0;
                    if (selectionStart === selectionEnd) {
                        var deleteChar = inputValue.charAt(selectionStart - 1);
                        if (this.inputNumber.isNumeralChar(deleteChar)) {
                            if (this.inputNumber._group.test(deleteChar)) {
                                this.inputNumber._group.lastIndex = 0;
                                newValueStr = inputValue.slice(0, selectionStart - 2) + inputValue.slice(selectionStart - 1);
                            }
                            else if (this.inputNumber._decimal.test(deleteChar)) {
                                this.inputNumber._decimal.lastIndex = 0;
                                this.inputNumber.input.nativeElement.setSelectionRange(selectionStart - 1, selectionStart - 1);
                            }
                            else if (decimalCharIndex > 0 && selectionStart > decimalCharIndex) {
                                if (this.inputNumber.minFractionDigits > this.minFractionDigits) {
                                    this.setMinFractionDigits(this.inputNumber.minFractionDigits - 1);
                                    newValueStr = inputValue.slice(0, selectionStart - 1) + inputValue.slice(selectionStart);
                                }
                                else {
                                    newValueStr = inputValue.slice(0, selectionStart - 1) + '0' + inputValue.slice(selectionStart);
                                }
                            }
                            else if (decimalCharIndex > 0 && decimalCharIndex === 1) {
                                newValueStr = inputValue.slice(0, selectionStart - 1) + '0' + inputValue.slice(selectionStart);
                                newValueStr = this.inputNumber.parseValue(newValueStr) > 0 ? newValueStr : '';
                            }
                            else {
                                newValueStr = inputValue.slice(0, selectionStart - 1) + inputValue.slice(selectionStart);
                            }
                        }
                        this.inputNumber.updateValue(event, newValueStr, null, 'delete-single');
                    }
                    else {
                        newValueStr = this.inputNumber.deleteRange(inputValue, selectionStart, selectionEnd);
                        if (decimalCharIndex > 0 && selectionStart > decimalCharIndex) {
                            this.setMinFractionDigits(this.inputNumber.minFractionDigits - (selectionEnd - selectionStart) > this.minFractionDigits
                                ? this.inputNumber.minFractionDigits - (selectionEnd - selectionStart) : this.minFractionDigits);
                        }
                        else if (decimalCharIndex > 0 && (selectionStart < decimalCharIndex && selectionEnd > decimalCharIndex)) {
                            this.setMinFractionDigits(this.minFractionDigits);
                        }
                        this.inputNumber.updateValue(event, newValueStr, null, 'delete-range');
                    }
                    break;
                }
                // del
                case 46: {
                    event.preventDefault();
                    var decimalCharIndex = inputValue.search(this.inputNumber._decimal);
                    this.inputNumber._decimal.lastIndex = 0;
                    if (selectionStart === selectionEnd) {
                        var deleteChar = inputValue.charAt(selectionStart);
                        if (this.inputNumber.isNumeralChar(deleteChar)) {
                            if (this.inputNumber._group.test(deleteChar)) {
                                this.inputNumber._group.lastIndex = 0;
                                newValueStr = inputValue.slice(0, selectionStart) + inputValue.slice(selectionStart + 2);
                            }
                            else if (this.inputNumber._decimal.test(deleteChar)) {
                                this.inputNumber._decimal.lastIndex = 0;
                                this.inputNumber.input.nativeElement.setSelectionRange(selectionStart + 1, selectionStart + 1);
                            }
                            else if (decimalCharIndex > 0 && selectionStart > decimalCharIndex) {
                                if (this.inputNumber.minFractionDigits > this.minFractionDigits) {
                                    this.setMinFractionDigits(this.inputNumber.minFractionDigits - 1);
                                    newValueStr = inputValue.slice(0, selectionStart) + inputValue.slice(selectionStart + 1);
                                }
                                else {
                                    newValueStr = inputValue.slice(0, selectionStart) + '0' + inputValue.slice(selectionStart + 1);
                                }
                            }
                            else if (decimalCharIndex > 0 && decimalCharIndex === 1) {
                                newValueStr = inputValue.slice(0, selectionStart) + '0' + inputValue.slice(selectionStart + 1);
                                newValueStr = this.inputNumber.parseValue(newValueStr) > 0 ? newValueStr : '';
                            }
                            else {
                                newValueStr = inputValue.slice(0, selectionStart) + inputValue.slice(selectionStart + 1);
                            }
                        }
                        this.inputNumber.updateValue(event, newValueStr, null, 'delete-back-single');
                    }
                    else {
                        newValueStr = this.inputNumber.deleteRange(inputValue, selectionStart, selectionEnd);
                        if (decimalCharIndex > 0 && selectionStart > decimalCharIndex) {
                            this.setMinFractionDigits(this.inputNumber.minFractionDigits - (selectionEnd - selectionStart) > this.minFractionDigits
                                ? this.inputNumber.minFractionDigits - (selectionEnd - selectionStart) : this.minFractionDigits);
                        }
                        else if (decimalCharIndex > 0 && (selectionStart < decimalCharIndex && selectionEnd > decimalCharIndex)) {
                            this.setMinFractionDigits(this.minFractionDigits);
                        }
                        this.inputNumber.updateValue(event, newValueStr, null, 'delete-range');
                    }
                    break;
                }
                default:
                    break;
            }
        };
        InputNumberDirective.prototype.insertText = function (value, text, start, end) {
            var textSplit = text.split('.');
            if (!value) {
                return this.inputNumber.formatValue(text);
            }
            if (textSplit.length === 2) {
                var decimalCharIndex = value.slice(start, end).search(this.inputNumber._decimal);
                this.inputNumber._decimal.lastIndex = 0;
                return (decimalCharIndex > 0) ? value.slice(0, start) + this.inputNumber.formatValue(text) + value.slice(end) : value;
            }
            else if ((end - start) === value.length) {
                return this.inputNumber.formatValue(text);
            }
            else if (start === 0) {
                return text + value.slice(end);
            }
            else if (end === value.length) {
                return value.slice(0, start) + text;
            }
            else {
                return value.slice(0, start) + text + value.slice(end);
            }
        };
        InputNumberDirective.prototype.setMinFractionDigits = function (value) {
            this.inputNumber.minFractionDigits = value;
            this.changeDetectorRef.detectChanges();
        };
        InputNumberDirective.ɵfac = function InputNumberDirective_Factory(t) { return new (t || InputNumberDirective)(core["ɵɵdirectiveInject"](InputNumber), core["ɵɵdirectiveInject"](core.ChangeDetectorRef)); };
        InputNumberDirective.ɵdir = core["ɵɵdefineDirective"]({ type: InputNumberDirective, selectors: [["p-inputNumber"]], inputs: { locale: "locale", useGrouping: "useGrouping", minFractionDigits: "minFractionDigits" } });
        return InputNumberDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](InputNumberDirective, [{
            type: core.Directive,
            args: [{
                    selector: 'p-inputNumber'
                }]
        }], function () { return [{ type: InputNumber }, { type: core.ChangeDetectorRef }]; }, { locale: [{
                type: core.Input
            }], useGrouping: [{
                type: core.Input
            }], minFractionDigits: [{
                type: core.Input
            }] }); })();

    var ButtonFormValidateDirective = /** @class */ (function () {
        function ButtonFormValidateDirective(button, form, messageService) {
            this.button = button;
            this.form = form;
            this.messageService = messageService;
            this.appSubmitForm = new core.EventEmitter();
        }
        ButtonFormValidateDirective.prototype.onClick = function ($event) {
            var _a;
            var form = this.appValidateForm || this.form;
            if ((_a = form) === null || _a === void 0 ? void 0 : _a.invalid) {
                Object.values(form.controls).forEach(function (c) {
                    if (c.invalid) {
                        c.markAsDirty();
                        c.updateValueAndValidity({ emitEvent: true });
                    }
                });
                var messageService = this.appValidateMessageService || this.messageService;
                if (messageService) {
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Ошибка',
                        detail: 'Заполните обязательные поля и проверьте корректность значений'
                    });
                }
                return;
            }
            if (this.appSubmitForm) {
                this.appSubmitForm.emit($event);
            }
        };
        ButtonFormValidateDirective.ɵfac = function ButtonFormValidateDirective_Factory(t) { return new (t || ButtonFormValidateDirective)(core["ɵɵdirectiveInject"](core.ElementRef), core["ɵɵdirectiveInject"](forms.NgForm, 8), core["ɵɵdirectiveInject"](primeng.MessageService, 8)); };
        ButtonFormValidateDirective.ɵdir = core["ɵɵdefineDirective"]({ type: ButtonFormValidateDirective, selectors: [["button", "appSubmitForm", ""], ["button", "appValidateForm", ""], ["p-button", "appSubmitForm", ""], ["p-button", "appValidateForm", ""]], hostBindings: function ButtonFormValidateDirective_HostBindings(rf, ctx) { if (rf & 1) {
                core["ɵɵlistener"]("click", function ButtonFormValidateDirective_click_HostBindingHandler($event) { return ctx.onClick($event); });
            } }, inputs: { appValidateForm: "appValidateForm", appValidateMessageService: "appValidateMessageService" }, outputs: { appSubmitForm: "appSubmitForm" } });
        return ButtonFormValidateDirective;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](ButtonFormValidateDirective, [{
            type: core.Directive,
            args: [{
                    selector: 'button[appSubmitForm],button[appValidateForm],p-button[appSubmitForm],p-button[appValidateForm]'
                }]
        }], function () { return [{ type: core.ElementRef }, { type: forms.NgForm, decorators: [{
                    type: core.Optional
                }] }, { type: primeng.MessageService, decorators: [{
                    type: core.Optional
                }] }]; }, { appValidateForm: [{
                type: core.Input
            }], appValidateMessageService: [{
                type: core.Input
            }], appSubmitForm: [{
                type: core.Output
            }], onClick: [{
                type: core.HostListener,
                args: ['click', ['$event']]
            }] }); })();

    // @ts-ignore
    // @ts-nocheck
    var __decorate$1 = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function")
            r = Reflect.decorate(decorators, target, key, desc);
        else
            for (var i = decorators.length - 1; i >= 0; i--)
                if (d = decorators[i])
                    r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var ClipboardService = /** @class */ (function () {
        function ClipboardService() {
        }
        ClipboardService.prototype.registerGridCore = function (gridCore) {
            this.gridCore = gridCore;
        };
        ClipboardService.prototype.init = function () {
            this.logger = this.loggerFactory.create('ClipboardService');
            if (this.rowModel.getType() === agGridCommunity.Constants.ROW_MODEL_TYPE_CLIENT_SIDE) {
                this.clientSideRowModel = this.rowModel;
            }
        };
        ClipboardService.prototype.pasteFromClipboard = function () {
            var _this = this;
            this.logger.log('pasteFromClipboard');
            this.executeOnTempElement(function (textArea) {
                textArea.focus();
            }, function (element) {
                var data = element.value;
                if (agGridCommunity._.missingOrEmpty(data)) {
                    return;
                }
                var parsedData = _this.dataToArray(data);
                var userFunc = _this.gridOptionsWrapper.getProcessDataFromClipboardFunc();
                if (userFunc) {
                    parsedData = userFunc({ data: parsedData });
                }
                if (agGridCommunity._.missingOrEmpty(parsedData)) {
                    return;
                }
                var pasteOperation = function (cellsToFlash, updatedRowNodes, focusedCell, changedPath) {
                    var singleCellInClipboard = parsedData.length == 1 && parsedData[0].length == 1;
                    var rangeActive = _this.rangeController && _this.rangeController.isMoreThanOneCell();
                    var pasteIntoRange = rangeActive && !singleCellInClipboard;
                    if (pasteIntoRange) {
                        _this.pasteIntoActiveRange(parsedData, cellsToFlash, updatedRowNodes, changedPath);
                    }
                    else {
                        _this.pasteStartingFromFocusedCell(parsedData, cellsToFlash, updatedRowNodes, focusedCell, changedPath);
                    }
                };
                _this.doPasteOperation(pasteOperation);
            });
        };
        // common code to paste operations, eg past to cell, paste to range, and copy range down
        ClipboardService.prototype.doPasteOperation = function (pasteOperationFunc) {
            this.eventService.dispatchEvent({
                type: agGridCommunity.Events.EVENT_PASTE_START,
                api: this.gridOptionsWrapper.getApi(),
                columnApi: this.gridOptionsWrapper.getColumnApi(),
                source: 'clipboard'
            });
            var changedPath;
            if (this.clientSideRowModel) {
                var onlyChangedColumns = this.gridOptionsWrapper.isAggregateOnlyChangedColumns();
                changedPath = new agGridCommunity.ChangedPath(onlyChangedColumns, this.clientSideRowModel.getRootNode());
            }
            var cellsToFlash = {};
            var updatedRowNodes = [];
            var focusedCell = this.focusedCellController.getFocusedCell();
            pasteOperationFunc(cellsToFlash, updatedRowNodes, focusedCell, changedPath);
            if (changedPath) {
                this.clientSideRowModel.doAggregate(changedPath);
            }
            this.rowRenderer.refreshCells();
            this.dispatchFlashCells(cellsToFlash);
            this.fireRowChanged(updatedRowNodes);
            if (focusedCell) {
                this.focusedCellController.setFocusedCell(focusedCell.rowIndex, focusedCell.column, focusedCell.rowPinned, true);
            }
            this.eventService.dispatchEvent({
                type: agGridCommunity.Events.EVENT_PASTE_END,
                api: this.gridOptionsWrapper.getApi(),
                columnApi: this.gridOptionsWrapper.getColumnApi(),
                source: 'clipboard'
            });
        };
        ClipboardService.prototype.pasteIntoActiveRange = function (clipboardData, cellsToFlash, updatedRowNodes, changedPath) {
            var _this = this;
            // true if clipboard data can be evenly pasted into range, otherwise false
            var abortRepeatingPasteIntoRows = this.rangeSize() % clipboardData.length != 0;
            var indexOffset = 0, dataRowIndex = 0;
            var rowCallback = function (currentRow, rowNode, columns, index, isLastRow) {
                var atEndOfClipboardData = index - indexOffset >= clipboardData.length;
                if (atEndOfClipboardData) {
                    if (abortRepeatingPasteIntoRows) {
                        return;
                    }
                    // increment offset and reset data index to repeat paste of data
                    indexOffset += dataRowIndex;
                    dataRowIndex = 0;
                }
                var currentRowData = clipboardData[index - indexOffset];
                // otherwise we are not the first row, so copy
                updatedRowNodes.push(rowNode);
                columns.forEach(function (column, idx) {
                    if (!column.isCellEditable(rowNode) || column.isSuppressPaste(rowNode)) {
                        return;
                    }
                    // repeat data for columns we don't have data for - happens when to range is bigger than copied data range
                    if (idx >= currentRowData.length) {
                        idx = idx % currentRowData.length;
                    }
                    var newValue = currentRowData[idx];
                    var processCellFromClipboardFunc = _this.gridOptionsWrapper.getProcessCellFromClipboardFunc();
                    newValue = _this.userProcessCell(rowNode, column, newValue, processCellFromClipboardFunc, agGridCommunity.Constants.EXPORT_TYPE_DRAG_COPY);
                    _this.valueService.setValue(rowNode, column, newValue, agGridCommunity.Constants.SOURCE_PASTE);
                    if (changedPath) {
                        changedPath.addParentNode(rowNode.parent, [column]);
                    }
                    var cellId = _this.cellPositionUtils.createIdFromValues(currentRow.rowIndex, column, currentRow.rowPinned);
                    cellsToFlash[cellId] = true;
                });
                dataRowIndex++;
            };
            this.iterateActiveRanges(false, rowCallback);
        };
        ClipboardService.prototype.pasteStartingFromFocusedCell = function (parsedData, cellsToFlash, updatedRowNodes, focusedCell, changedPath) {
            if (!focusedCell) {
                return;
            }
            var currentRow = { rowIndex: focusedCell.rowIndex, rowPinned: focusedCell.rowPinned };
            var columnsToPasteInto = this.columnController.getDisplayedColumnsStartingAt(focusedCell.column);
            var onlyOneValueToPaste = parsedData.length === 1 && parsedData[0].length === 1;
            if (onlyOneValueToPaste) {
                this.pasteSingleValue(parsedData, updatedRowNodes, cellsToFlash, changedPath);
            }
            else {
                this.pasteMultipleValues(parsedData, currentRow, updatedRowNodes, columnsToPasteInto, cellsToFlash, agGridCommunity.Constants.EXPORT_TYPE_CLIPBOARD, changedPath);
            }
        };
        ClipboardService.prototype.copyRangeDown = function () {
            var _this = this;
            if (!this.rangeController || this.rangeController.isEmpty()) {
                return;
            }
            var firstRowValues = [];
            var pasteOperation = function (cellsToFlash, updatedRowNodes, focusedCell, changedPath) {
                var rowCallback = function (currentRow, rowNode, columns, index, isLastRow) {
                    // take reference of first row, this is the one we will be using to copy from
                    if (!firstRowValues.length) {
                        // two reasons for looping through columns
                        columns.forEach(function (column) {
                            // get the initial values to copy down
                            var value = _this.valueService.getValue(column, rowNode);
                            var processCellForClipboardFunc = _this.gridOptionsWrapper.getProcessCellForClipboardFunc();
                            value = _this.userProcessCell(rowNode, column, value, processCellForClipboardFunc, agGridCommunity.Constants.EXPORT_TYPE_DRAG_COPY);
                            firstRowValues.push(value);
                        });
                    }
                    else {
                        // otherwise we are not the first row, so copy
                        updatedRowNodes.push(rowNode);
                        columns.forEach(function (column, index) {
                            if (!column.isCellEditable(rowNode)) {
                                return;
                            }
                            var firstRowValue = firstRowValues[index];
                            var processCellFromClipboardFunc = _this.gridOptionsWrapper.getProcessCellFromClipboardFunc();
                            firstRowValue = _this.userProcessCell(rowNode, column, firstRowValue, processCellFromClipboardFunc, agGridCommunity.Constants.EXPORT_TYPE_DRAG_COPY);
                            _this.valueService.setValue(rowNode, column, firstRowValue, agGridCommunity.Constants.SOURCE_PASTE);
                            if (changedPath) {
                                changedPath.addParentNode(rowNode.parent, [column]);
                            }
                            var cellId = _this.cellPositionUtils.createIdFromValues(currentRow.rowIndex, column, currentRow.rowPinned);
                            cellsToFlash[cellId] = true;
                        });
                    }
                };
                _this.iterateActiveRanges(true, rowCallback);
            };
            this.doPasteOperation(pasteOperation);
        };
        ClipboardService.prototype.fireRowChanged = function (rowNodes) {
            var _this = this;
            if (!this.gridOptionsWrapper.isFullRowEdit()) {
                return;
            }
            rowNodes.forEach(function (rowNode) {
                var event = {
                    type: agGridCommunity.Events.EVENT_ROW_VALUE_CHANGED,
                    node: rowNode,
                    data: rowNode.data,
                    rowIndex: rowNode.rowIndex,
                    rowPinned: rowNode.rowPinned,
                    context: _this.gridOptionsWrapper.getContext(),
                    api: _this.gridOptionsWrapper.getApi(),
                    columnApi: _this.gridOptionsWrapper.getColumnApi()
                };
                _this.eventService.dispatchEvent(event);
            });
        };
        ClipboardService.prototype.pasteMultipleValues = function (clipboardGridData, currentRow, updatedRowNodes, columnsToPasteInto, cellsToFlash, type, changedPath) {
            var _this = this;
            clipboardGridData.forEach(function (clipboardRowData) {
                // if we have come to end of rows in grid, then skip
                if (!currentRow) {
                    return;
                }
                var rowNode = _this.rowPositionUtils.getRowNode(currentRow);
                if (rowNode) {
                    updatedRowNodes.push(rowNode);
                    clipboardRowData.forEach(function (value, index) {
                        var column = columnsToPasteInto[index];
                        _this.updateCellValue(rowNode, column, value, currentRow, cellsToFlash, type, changedPath);
                    });
                    // move to next row down for next set of values
                    currentRow = _this.cellNavigationService.getRowBelow({ rowPinned: currentRow.rowPinned, rowIndex: currentRow.rowIndex });
                }
            });
            return currentRow;
        };
        ClipboardService.prototype.pasteSingleValue = function (parsedData, updatedRowNodes, cellsToFlash, changedPath) {
            var _this = this;
            var value = parsedData[0][0];
            var rowCallback = function (currentRow, rowNode, columns) {
                updatedRowNodes.push(rowNode);
                columns.forEach(function (column) {
                    _this.updateCellValue(rowNode, column, value, currentRow, cellsToFlash, agGridCommunity.Constants.EXPORT_TYPE_CLIPBOARD, changedPath);
                });
            };
            this.iterateActiveRanges(false, rowCallback);
        };
        ClipboardService.prototype.updateCellValue = function (rowNode, column, value, currentRow, cellsToFlash, type, changedPath) {
            if (!rowNode ||
                !currentRow ||
                !column ||
                !column.isCellEditable ||
                column.isSuppressPaste(rowNode)) {
                return;
            }
            var processedValue = this.userProcessCell(rowNode, column, value, this.gridOptionsWrapper.getProcessCellFromClipboardFunc(), type);
            this.valueService.setValue(rowNode, column, processedValue, agGridCommunity.Constants.SOURCE_PASTE);
            var cellId = this.cellPositionUtils.createIdFromValues(currentRow.rowIndex, column, currentRow.rowPinned);
            cellsToFlash[cellId] = true;
            if (changedPath) {
                changedPath.addParentNode(rowNode.parent, [column]);
            }
        };
        ClipboardService.prototype.copyToClipboard = function (includeHeaders) {
            this.logger.log("copyToClipboard: includeHeaders = " + includeHeaders);
            // don't override 'includeHeaders' if it has been explicitly set to 'false'
            if (typeof includeHeaders === 'undefined') {
                includeHeaders = this.gridOptionsWrapper.isCopyHeadersToClipboard();
            }
            var selectedRowsToCopy = !this.selectionController.isEmpty()
                && !this.gridOptionsWrapper.isSuppressCopyRowsToClipboard();
            // default is copy range if exists, otherwise rows
            if (this.rangeController && this.rangeController.isMoreThanOneCell()) {
                this.copySelectedRangeToClipboard(includeHeaders);
            }
            else if (selectedRowsToCopy) {
                // otherwise copy selected rows if they exist
                this.copySelectedRowsToClipboard(includeHeaders);
            }
            else if (this.focusedCellController.isAnyCellFocused()) {
                // if there is a focused cell, copy this
                this.copyFocusedCellToClipboard(includeHeaders);
            }
            else {
                // lastly if no focused cell, try range again. this can happen
                // if use has cellSelection turned off (so no focused cell)
                // but has a cell clicked, so there exists a cell range
                // of exactly one cell (hence the first 'if' above didn't
                // get executed).
                this.copySelectedRangeToClipboard(includeHeaders);
            }
        };
        ClipboardService.prototype.iterateActiveRanges = function (onlyFirst, rowCallback, columnCallback) {
            var _this = this;
            if (!this.rangeController || this.rangeController.isEmpty()) {
                return;
            }
            var cellRanges = this.rangeController.getCellRanges();
            if (onlyFirst) {
                var range = cellRanges[0];
                this.iterateActiveRange(range, rowCallback, columnCallback, true);
            }
            else {
                cellRanges.forEach(function (range, idx) { return _this.iterateActiveRange(range, rowCallback, columnCallback, idx === cellRanges.length - 1); });
            }
        };
        ClipboardService.prototype.iterateActiveRange = function (range, rowCallback, columnCallback, isLastRange) {
            if (!this.rangeController) {
                return;
            }
            var currentRow = this.rangeController.getRangeStartRow(range);
            var lastRow = this.rangeController.getRangeEndRow(range);
            if (columnCallback && agGridCommunity._.exists(columnCallback) && range.columns) {
                columnCallback(range.columns);
            }
            var rangeIndex = 0;
            var isLastRow = false;
            // the currentRow could be missing if the user sets the active range manually, and sets a range
            // that is outside of the grid (eg. sets range rows 0 to 100, but grid has only 20 rows).
            while (!isLastRow && !agGridCommunity._.missing(currentRow) && currentRow) {
                var rowNode = this.rowPositionUtils.getRowNode(currentRow);
                isLastRow = this.rowPositionUtils.sameRow(currentRow, lastRow);
                rowCallback(currentRow, rowNode, range.columns, rangeIndex++, isLastRow && isLastRange);
                currentRow = this.cellNavigationService.getRowBelow(currentRow);
            }
        };
        ClipboardService.prototype.copySelectedRangeToClipboard = function (includeHeaders) {
            var _this = this;
            if (includeHeaders === void 0) {
                includeHeaders = false;
            }
            if (!this.rangeController || this.rangeController.isEmpty()) {
                return;
            }
            var deliminator = this.gridOptionsWrapper.getClipboardDeliminator();
            var data = '';
            var cellsToFlash = {};
            // adds columns to the data
            var columnCallback = function (columns) {
                if (!includeHeaders) {
                    return;
                }
                columns.forEach(function (column, index) {
                    var value = _this.columnController.getDisplayNameForColumn(column, 'clipboard', true);
                    var processedValue = _this.userProcessHeader(column, value, _this.gridOptionsWrapper.getProcessHeaderForClipboardFunc());
                    if (index != 0) {
                        data += deliminator;
                    }
                    if (agGridCommunity._.exists(processedValue)) {
                        data += processedValue;
                    }
                });
                data += '\r\n';
            };
            // adds cell values to the data
            var rowCallback = function (currentRow, rowNode, columns, index, isLastRow) {
                columns.forEach(function (column, index) {
                    var value = _this.valueService.getValue(column, rowNode);
                    var processedValue = _this.userProcessCell(rowNode, column, value, _this.gridOptionsWrapper.getProcessCellForClipboardFunc(), agGridCommunity.Constants.EXPORT_TYPE_CLIPBOARD);
                    if (index != 0) {
                        data += deliminator;
                    }
                    if (agGridCommunity._.exists(processedValue)) {
                        data += processedValue;
                    }
                    var cellId = _this.cellPositionUtils.createIdFromValues(currentRow.rowIndex, column, currentRow.rowPinned);
                    cellsToFlash[cellId] = true;
                });
                if (!isLastRow) {
                    data += '\r\n';
                }
            };
            this.iterateActiveRanges(false, rowCallback, columnCallback);
            this.copyDataToClipboard(data);
            this.dispatchFlashCells(cellsToFlash);
        };
        ClipboardService.prototype.copyFocusedCellToClipboard = function (includeHeaders) {
            var _a;
            if (includeHeaders === void 0) {
                includeHeaders = false;
            }
            var focusedCell = this.focusedCellController.getFocusedCell();
            if (agGridCommunity._.missing(focusedCell)) {
                return;
            }
            var cellId = this.cellPositionUtils.createId(focusedCell);
            var currentRow = { rowPinned: focusedCell.rowPinned, rowIndex: focusedCell.rowIndex };
            var rowNode = this.rowPositionUtils.getRowNode(currentRow);
            var column = focusedCell.column;
            var value = this.valueService.getValue(column, rowNode);
            var processedValue = this.userProcessCell(rowNode, column, value, this.gridOptionsWrapper.getProcessCellForClipboardFunc(), agGridCommunity.Constants.EXPORT_TYPE_CLIPBOARD);
            if (agGridCommunity._.missing(processedValue)) {
                // copy the new line character to clipboard instead of an empty string, as the 'execCommand' will ignore it.
                // this behaviour is consistent with how Excel works!
                processedValue = '\t';
            }
            var data = '';
            if (includeHeaders) {
                var headerValue = this.columnController.getDisplayNameForColumn(column, 'clipboard', true);
                data = this.userProcessHeader(column, headerValue, this.gridOptionsWrapper.getProcessHeaderForClipboardFunc());
                data += '\r\n';
            }
            data += processedValue.toString();
            this.copyDataToClipboard(data);
            this.dispatchFlashCells((_a = {}, _a[cellId] = true, _a));
        };
        ClipboardService.prototype.dispatchFlashCells = function (cellsToFlash) {
            var _this = this;
            window.setTimeout(function () {
                var event = {
                    type: agGridCommunity.Events.EVENT_FLASH_CELLS,
                    cells: cellsToFlash,
                    api: _this.gridApi,
                    columnApi: _this.columnApi
                };
                _this.eventService.dispatchEvent(event);
            }, 0);
        };
        ClipboardService.prototype.userProcessCell = function (rowNode, column, value, func, type) {
            if (func) {
                var params = {
                    column: column,
                    node: rowNode,
                    value: value,
                    api: this.gridOptionsWrapper.getApi(),
                    columnApi: this.gridOptionsWrapper.getColumnApi(),
                    context: this.gridOptionsWrapper.getContext(),
                    type: type
                };
                return func(params);
            }
            return value;
        };
        ClipboardService.prototype.userProcessHeader = function (column, value, func) {
            if (func) {
                var params = {
                    column: column,
                    api: this.gridOptionsWrapper.getApi(),
                    columnApi: this.gridOptionsWrapper.getColumnApi(),
                    context: this.gridOptionsWrapper.getContext()
                };
                return func(params);
            }
            return value;
        };
        ClipboardService.prototype.copySelectedRowsToClipboard = function (includeHeaders, columnKeys) {
            if (includeHeaders === void 0) {
                includeHeaders = false;
            }
            var skipHeader = !includeHeaders;
            var deliminator = this.gridOptionsWrapper.getClipboardDeliminator();
            var params = {
                columnKeys: columnKeys,
                skipHeader: skipHeader,
                skipFooters: true,
                suppressQuotes: true,
                columnSeparator: deliminator,
                onlySelected: true,
                processCellCallback: this.gridOptionsWrapper.getProcessCellForClipboardFunc(),
                processHeaderCallback: this.gridOptionsWrapper.getProcessHeaderForClipboardFunc()
            };
            var data = this.csvCreator.getDataAsCsv(params);
            this.copyDataToClipboard(data);
        };
        ClipboardService.prototype.copyDataToClipboard = function (data) {
            var userProvidedFunc = this.gridOptionsWrapper.getSendToClipboardFunc();
            if (userProvidedFunc && agGridCommunity._.exists(userProvidedFunc)) {
                var params = { data: data };
                userProvidedFunc(params);
            }
            else {
                this.executeOnTempElement(function (element) {
                    element.value = data;
                    element.select();
                    element.focus();
                    var result = document.execCommand('copy');
                    if (!result) {
                        console.warn('ag-grid: Browser did not allow document.execCommand(\'copy\'). Ensure ' +
                            'api.copySelectedRowsToClipboard() is invoked via a user event, i.e. button click, otherwise ' +
                            'the browser will prevent it for security reasons.');
                    }
                });
            }
        };
        ClipboardService.prototype.executeOnTempElement = function (callbackNow, callbackAfter) {
            var eTempInput = document.createElement('textarea');
            eTempInput.style.width = '1px';
            eTempInput.style.height = '1px';
            eTempInput.style.top = '0px';
            eTempInput.style.left = '0px';
            eTempInput.style.position = 'absolute';
            eTempInput.style.opacity = '0.0';
            var guiRoot = this.gridCore.getRootGui();
            guiRoot.appendChild(eTempInput);
            try {
                callbackNow(eTempInput);
            }
            catch (err) {
                console.warn('ag-grid: Browser does not support document.execCommand(\'copy\') for clipboard operations');
            }
            //It needs 100 otherwise OS X seemed to not always be able to paste... Go figure...
            if (callbackAfter) {
                window.setTimeout(function () {
                    callbackAfter(eTempInput);
                    guiRoot.removeChild(eTempInput);
                }, 100);
            }
            else {
                guiRoot.removeChild(eTempInput);
            }
        };
        // From http://stackoverflow.com/questions/1293147/javascript-code-to-parse-csv-data
        // This will parse a delimited string into an array of arrays.
        // Note: this code fixes an issue with the example posted on stack overflow where it doesn't correctly handle
        // empty values in the first cell.
        ClipboardService.prototype.dataToArray = function (strData) {
            var delimiter = this.gridOptionsWrapper.getClipboardDeliminator();
            // Create a regular expression to parse the CSV values.
            var objPattern = new RegExp((
            // Delimiters.
            '(\\' + delimiter + '|\\r?\\n|\\r|^)' +
                // Quoted fields.
                '(?:"([^\"]*(?:""[^\"]*)*)"|' +
                // Standard fields.
                '([^\\' + delimiter + '\\r\\n]*))'), "gi");
            // Create an array to hold our data. Give the array
            // a default empty first row.
            var arrData = [[]];
            // Create an array to hold our individual pattern matching groups.
            var arrMatches;
            // Required for handling edge case on first row copy
            var atFirstRow = true;
            // Keep looping over the regular expression matches
            // until we can no longer find a match.
            while (arrMatches = objPattern.exec(strData)) {
                // Get the delimiter that was found.
                var strMatchedDelimiter = arrMatches[1];
                // Handles case when first row is an empty cell, insert an empty string before delimiter
                if ((atFirstRow && strMatchedDelimiter) || !arrMatches.index && arrMatches[0].charAt(0) === delimiter) {
                    arrData[0].push('');
                }
                // Check to see if the given delimiter has a length
                // (is not the start of string) and if it matches
                // field delimiter. If id does not, then we know
                // that this delimiter is a row delimiter.
                if (strMatchedDelimiter.length && strMatchedDelimiter !== delimiter) {
                    // Since we have reached a new row of data,
                    // add an empty row to our data array.
                    arrData.push([]);
                }
                var strMatchedValue = void 0;
                // Now that we have our delimiter out of the way,
                // let's check to see which kind of value we
                // captured (quoted or unquoted).
                if (arrMatches[2]) {
                    // We found a quoted value. When we capture
                    // this value, unescaped any double quotes.
                    strMatchedValue = arrMatches[2].replace(new RegExp('""', 'g'), '"');
                }
                else {
                    // We found a non-quoted value.
                    strMatchedValue = arrMatches[3];
                }
                // Now that we have our value string, let's add
                // it to the data array.
                var lastItem = agGridCommunity._.last(arrData);
                if (lastItem) {
                    lastItem.push(strMatchedValue);
                }
                atFirstRow = false;
            }
            // Return the parsed data.
            return arrData;
        };
        ClipboardService.prototype.rangeSize = function () {
            var ranges = this.rangeController.getCellRanges();
            var startRangeIndex;
            var endRangeIndex;
            if (ranges.length > 0) {
                startRangeIndex = 0;
                endRangeIndex = 0;
            }
            else {
                startRangeIndex = this.rangeController.getRangeStartRow(ranges[0]).rowIndex;
                endRangeIndex = this.rangeController.getRangeEndRow(ranges[0]).rowIndex;
            }
            return startRangeIndex - endRangeIndex + 1;
        };
        __decorate$1([
            agGridCommunity.Autowired('csvCreator')
        ], ClipboardService.prototype, "csvCreator", void 0);
        __decorate$1([
            agGridCommunity.Autowired('loggerFactory')
        ], ClipboardService.prototype, "loggerFactory", void 0);
        __decorate$1([
            agGridCommunity.Autowired('selectionController')
        ], ClipboardService.prototype, "selectionController", void 0);
        __decorate$1([
            agGridCommunity.Optional('rangeController')
        ], ClipboardService.prototype, "rangeController", void 0);
        __decorate$1([
            agGridCommunity.Autowired('rowModel')
        ], ClipboardService.prototype, "rowModel", void 0);
        __decorate$1([
            agGridCommunity.Autowired('valueService')
        ], ClipboardService.prototype, "valueService", void 0);
        __decorate$1([
            agGridCommunity.Autowired('focusedCellController')
        ], ClipboardService.prototype, "focusedCellController", void 0);
        __decorate$1([
            agGridCommunity.Autowired('rowRenderer')
        ], ClipboardService.prototype, "rowRenderer", void 0);
        __decorate$1([
            agGridCommunity.Autowired('columnController')
        ], ClipboardService.prototype, "columnController", void 0);
        __decorate$1([
            agGridCommunity.Autowired('eventService')
        ], ClipboardService.prototype, "eventService", void 0);
        __decorate$1([
            agGridCommunity.Autowired('cellNavigationService')
        ], ClipboardService.prototype, "cellNavigationService", void 0);
        __decorate$1([
            agGridCommunity.Autowired('gridOptionsWrapper')
        ], ClipboardService.prototype, "gridOptionsWrapper", void 0);
        __decorate$1([
            agGridCommunity.Autowired('columnApi')
        ], ClipboardService.prototype, "columnApi", void 0);
        __decorate$1([
            agGridCommunity.Autowired('gridApi')
        ], ClipboardService.prototype, "gridApi", void 0);
        __decorate$1([
            agGridCommunity.Autowired('cellPositionUtils')
        ], ClipboardService.prototype, "cellPositionUtils", void 0);
        __decorate$1([
            agGridCommunity.Autowired('rowPositionUtils')
        ], ClipboardService.prototype, "rowPositionUtils", void 0);
        __decorate$1([
            agGridCommunity.PostConstruct
        ], ClipboardService.prototype, "init", null);
        ClipboardService = __decorate$1([
            agGridCommunity.Bean('clipboardService')
        ], ClipboardService);
        return ClipboardService;
    }());

    var ClipboardModule = {
        moduleName: agGridCommunity.ModuleNames.ClipboardModule,
        beans: [ClipboardService]
    };

    function MenuSquareComponent_div_1_h4_1_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementStart"](0, "h4");
        core["ɵɵtext"](1);
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var group_r795 = core["ɵɵnextContext"]().$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵtextInterpolate1"]("", group_r795.title, ":");
    } }
    var _c0$l = function (a0, a1) { return { "background-color": a0, "border-color": a1 }; };
    function MenuSquareComponent_div_1_div_2_div_1_Template(rf, ctx) { if (rf & 1) {
        var _r803 = core["ɵɵgetCurrentView"]();
        core["ɵɵelementStart"](0, "div", 6);
        core["ɵɵelementStart"](1, "button", 7);
        core["ɵɵlistener"]("mouseover", function MenuSquareComponent_div_1_div_2_div_1_Template_button_mouseover_1_listener() { core["ɵɵrestoreView"](_r803); var item_r801 = ctx.$implicit; var ctx_r802 = core["ɵɵnextContext"](3); return ctx_r802.mouseOver(item_r801); })("mouseout", function MenuSquareComponent_div_1_div_2_div_1_Template_button_mouseout_1_listener() { core["ɵɵrestoreView"](_r803); var item_r801 = ctx.$implicit; var ctx_r804 = core["ɵɵnextContext"](3); return ctx_r804.mouseOut(item_r801); })("click", function MenuSquareComponent_div_1_div_2_div_1_Template_button_click_1_listener($event) { core["ɵɵrestoreView"](_r803); var item_r801 = ctx.$implicit; var ctx_r805 = core["ɵɵnextContext"](3); return ctx_r805.useRouterLink ? undefined : ctx_r805.onClick(item_r801, $event); });
        core["ɵɵelementStart"](2, "div", 8);
        core["ɵɵelement"](3, "i");
        core["ɵɵtext"](4);
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var item_r801 = ctx.$implicit;
        var ctx_r800 = core["ɵɵnextContext"](3);
        core["ɵɵclassMapInterpolate1"]("ui-g-", 12 / (ctx_r800.colNum || 3), "");
        core["ɵɵadvance"](1);
        core["ɵɵclassMap"](item_r801.url ? "" : "disabled");
        core["ɵɵproperty"]("ngStyle", !ctx_r800.hovers[item_r801.url] ? core["ɵɵpureFunction2"](11, _c0$l, item_r801.color, item_r801.color) : core["ɵɵpureFunction2"](14, _c0$l, item_r801.hoverColor, item_r801.hoverColor))("disabled", !item_r801.url)("routerLink", ctx_r800.useRouterLink ? item_r801.url : undefined);
        core["ɵɵadvance"](2);
        core["ɵɵclassMap"](item_r801.icon);
        core["ɵɵadvance"](1);
        core["ɵɵtextInterpolate1"](" ", item_r801.label, " ");
    } }
    function MenuSquareComponent_div_1_div_2_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementStart"](0, "div", 4);
        core["ɵɵtemplate"](1, MenuSquareComponent_div_1_div_2_div_1_Template, 5, 17, "div", 5);
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var lines_r799 = ctx.$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngForOf", lines_r799);
    } }
    function MenuSquareComponent_div_1_Template(rf, ctx) { if (rf & 1) {
        core["ɵɵelementStart"](0, "div", 1);
        core["ɵɵtemplate"](1, MenuSquareComponent_div_1_h4_1_Template, 2, 1, "h4", 2);
        core["ɵɵtemplate"](2, MenuSquareComponent_div_1_div_2_Template, 2, 1, "div", 3);
        core["ɵɵelementEnd"]();
    } if (rf & 2) {
        var group_r795 = ctx.$implicit;
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngIf", !!group_r795.title);
        core["ɵɵadvance"](1);
        core["ɵɵproperty"]("ngForOf", group_r795.lines);
    } }
    var MenuSquareComponent = /** @class */ (function () {
        function MenuSquareComponent() {
            this.hovers = {};
            this.squareMenu = { groups: [] };
        }
        MenuSquareComponent.prototype.ngOnInit = function () {
            this.squareMenu.groups = this.getSquareMenuGroups();
            for (var i = 0; i < this.squareMenu.groups.length; i++) {
                this.squareMenu.groups[i].lines = this.getSquareMenuItemLines(this.squareMenu.groups[i].items);
            }
        };
        MenuSquareComponent.prototype.mouseOver = function (item) {
            this.hovers[item.url] = true;
        };
        MenuSquareComponent.prototype.mouseOut = function (item) {
            this.hovers[item.url] = false;
        };
        MenuSquareComponent.prototype.onClick = function (item, event) {
            if (!!item['url']) {
                if (event.ctrlKey) {
                    window.open(item['url']);
                }
                else {
                    window.open(item['url'], '_self');
                }
            }
        };
        MenuSquareComponent.prototype.getSquareMenuGroups = function () {
            var e_1, _a, e_2, _b;
            var _this = this;
            var squareMenuGroups = [];
            var groups = [];
            var _loop_1 = function (menuGroup) {
                var findGroupIndex = groups.findIndex(function (group) { return group.title === menuGroup.title; });
                if (findGroupIndex == -1) {
                    groups.push(menuGroup);
                }
                else {
                    if (menuGroup.color !== groups[findGroupIndex].color && menuGroup.color && !groups[findGroupIndex].color) {
                        groups[findGroupIndex].color = menuGroup.color;
                    }
                }
            };
            try {
                for (var _c = __values(this.items.filter(function (item) { return !!item.squareMenuGroup; }).map(function (item) { return item.squareMenuGroup; })), _d = _c.next(); !_d.done; _d = _c.next()) {
                    var menuGroup = _d.value;
                    _loop_1(menuGroup);
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (_d && !_d.done && (_a = _c.return)) _a.call(_c);
                }
                finally { if (e_1) throw e_1.error; }
            }
            var _loop_2 = function (group) {
                squareMenuGroups.push({
                    lines: [],
                    title: group.title,
                    items: __spread(this_1.items).filter(function (item) { return item.squareMenuGroup.title === group.title; })
                        .map(function (item) {
                        return {
                            label: item.squareMenuLabel || item.label,
                            color: item.squareMenuColor || group.color || _this.baseColor || '#3d60a1',
                            hoverColor: new Color(item.squareMenuColor || group.color || _this.baseColor || '#3d60a1').lighten(0.5).hexString(),
                            icon: item.squareMenuIcon || item.icon,
                            url: item.routerLink || item.url
                        };
                    })
                });
            };
            var this_1 = this;
            try {
                for (var groups_1 = __values(groups), groups_1_1 = groups_1.next(); !groups_1_1.done; groups_1_1 = groups_1.next()) {
                    var group = groups_1_1.value;
                    _loop_2(group);
                }
            }
            catch (e_2_1) { e_2 = { error: e_2_1 }; }
            finally {
                try {
                    if (groups_1_1 && !groups_1_1.done && (_b = groups_1.return)) _b.call(groups_1);
                }
                finally { if (e_2) throw e_2.error; }
            }
            return squareMenuGroups;
        };
        MenuSquareComponent.prototype.getSquareMenuItemLines = function (items) {
            var e_3, _a;
            var columnNumbers = this.colNum || 3;
            var lines = [];
            var line = [];
            var itemCount = columnNumbers;
            try {
                for (var items_1 = __values(items), items_1_1 = items_1.next(); !items_1_1.done; items_1_1 = items_1.next()) {
                    var item = items_1_1.value;
                    line.push(item);
                    itemCount--;
                    if (itemCount === 0) {
                        lines.push(line);
                        line = [];
                        itemCount = columnNumbers;
                    }
                }
            }
            catch (e_3_1) { e_3 = { error: e_3_1 }; }
            finally {
                try {
                    if (items_1_1 && !items_1_1.done && (_a = items_1.return)) _a.call(items_1);
                }
                finally { if (e_3) throw e_3.error; }
            }
            lines.push(line);
            lines.forEach(function (modLine, index, array) {
                if (modLine.length < columnNumbers && modLine.length > 1) {
                    var emptyItems = new Array(columnNumbers - modLine.length).fill({});
                    modLine.splice.apply(modLine, __spread([Math.round(modLine.length / 2), 0], emptyItems));
                }
            });
            return lines;
        };
        MenuSquareComponent.ɵfac = function MenuSquareComponent_Factory(t) { return new (t || MenuSquareComponent)(); };
        MenuSquareComponent.ɵcmp = core["ɵɵdefineComponent"]({ type: MenuSquareComponent, selectors: [["app-menu-square"]], inputs: { items: "items", colNum: "colNum", baseColor: "baseColor", useRouterLink: "useRouterLink" }, decls: 2, vars: 1, consts: [["name", "menu", "class", "v-flex-grow", 4, "ngFor", "ngForOf"], ["name", "menu", 1, "v-flex-grow"], [4, "ngIf"], ["name", "line", "class", "ui-g", 4, "ngFor", "ngForOf"], ["name", "line", 1, "ui-g"], ["name", "items", "style", "margin: auto", 3, "class", 4, "ngFor", "ngForOf"], ["name", "items", 2, "margin", "auto"], ["pButton", "", 3, "ngStyle", "disabled", "routerLink", "mouseover", "mouseout", "click"], [1, "v-flex-grow"]], template: function MenuSquareComponent_Template(rf, ctx) { if (rf & 1) {
                core["ɵɵelementStart"](0, "p-card");
                core["ɵɵtemplate"](1, MenuSquareComponent_div_1_Template, 3, 2, "div", 0);
                core["ɵɵelementEnd"]();
            } if (rf & 2) {
                core["ɵɵadvance"](1);
                core["ɵɵproperty"]("ngForOf", ctx.squareMenu.groups);
            } }, directives: [card.Card, common.NgForOf, common.NgIf, ButtonDirective, button.ButtonDirective, common.NgStyle, router.RouterLink], styles: ["p[_ngcontent-%COMP%]{text-align:center}button[_ngcontent-%COMP%]{width:100%!important;height:80px;padding-top:30px;text-transform:uppercase;font-family:Roboto,'Helvetica Neue, Helvetica, Arial',sans-serif;font-size:15pt}.outer[_ngcontent-%COMP%]{display:table;height:75vh;width:100%}.middle[_ngcontent-%COMP%]{display:table-cell;vertical-align:middle}.inner[_ngcontent-%COMP%]{margin-left:auto;margin-right:auto;max-width:800px}.disabled[_ngcontent-%COMP%]{background-color:#dce4ea;border:none;opacity:1!important;pointer-events:none}"] });
        return MenuSquareComponent;
    }());
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](MenuSquareComponent, [{
            type: core.Component,
            args: [{
                    selector: 'app-menu-square',
                    templateUrl: './menu-square.component.html',
                    styleUrls: ['./menu-square.component.css']
                }]
        }], null, { items: [{
                type: core.Input,
                args: ['items']
            }], colNum: [{
                type: core.Input,
                args: ['colNum']
            }], baseColor: [{
                type: core.Input,
                args: ['baseColor']
            }], useRouterLink: [{
                type: core.Input,
                args: ['useRouterLink']
            }] }); })();

    function initializer(authConfigurationService, authService) {
        var _this = this;
        return function () { return __awaiter(_this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        agGridCommunity.ModuleRegistry.register(ClipboardModule);
                        common.registerLocaleData(localRu);
                        return [4 /*yield*/, authConfigurationService.init()];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, authService.init()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        }); };
    }
    // @dynamic
    var CommonModule = /** @class */ (function () {
        function CommonModule() {
        }
        CommonModule.forRoot = function (env) {
            return {
                ngModule: CommonModule,
                providers: [
                    {
                        provide: APP_ENV,
                        useValue: env
                    },
                    {
                        provide: core.LOCALE_ID,
                        useValue: 'ru'
                    },
                    {
                        provide: core.ErrorHandler,
                        useClass: GlobalErrorHandler
                    },
                    {
                        provide: http.HTTP_INTERCEPTORS,
                        useClass: ApiInterceptorService,
                        multi: true
                    },
                    {
                        provide: http.HTTP_INTERCEPTORS,
                        useClass: RequestInterceptorService,
                        multi: true
                    },
                    {
                        provide: http.HTTP_INTERCEPTORS,
                        useClass: PersonalNumberInterceptorService,
                        multi: true
                    },
                    {
                        provide: http.HTTP_INTERCEPTORS,
                        useClass: DateInterceptorService,
                        multi: true
                    },
                    {
                        provide: core.APP_INITIALIZER,
                        useFactory: initializer,
                        deps: [ConfigurationService, AuthService],
                        multi: true
                    },
                    {
                        provide: DistinctFilterService,
                        useClass: DistinctFilterDialogService
                    },
                    ConfigurationService,
                    AuthService,
                    UserService,
                    EventBusService,
                    LoginGuard,
                    BaseService,
                    EntityConfigService,
                    DictionaryService,
                    api.MessageService,
                    DialogService,
                    api.ConfirmationService
                ]
            };
        };
        CommonModule.ɵmod = core["ɵɵdefineNgModule"]({ type: CommonModule });
        CommonModule.ɵinj = core["ɵɵdefineInjector"]({ factory: function CommonModule_Factory(t) { return new (t || CommonModule)(); }, imports: [[
                    angularOauth2Oidc.OAuthModule.forRoot(),
                    ngxLogger.LoggerModule.forRoot(null),
                    common.CommonModule,
                    http.HttpClientModule,
                    table.TableModule,
                    contextmenu.ContextMenuModule,
                    inputtext.InputTextModule,
                    primeng.InputTextareaModule,
                    button.ButtonModule,
                    dialog.DialogModule,
                    paginator.PaginatorModule,
                    tristatecheckbox.TriStateCheckboxModule,
                    picklist.PickListModule,
                    blockui.BlockUIModule,
                    panel.PanelModule,
                    menu.MenuModule,
                    tieredmenu.TieredMenuModule,
                    toolbar.ToolbarModule,
                    overlaypanel.OverlayPanelModule,
                    card.CardModule,
                    fileupload.FileUploadModule,
                    scrollpanel.ScrollPanelModule,
                    // SplitPaneModule,
                    agGridAngular.AgGridModule.withComponents([
                        TextFloatingFilterComponent,
                        DropdownFilterComponent,
                        DropdownFloatingFilterComponent,
                        CheckboxHeaderComponent,
                        TriStateCheckboxHeaderComponent,
                        CustomDetailComponent,
                        DateFilterComponent,
                        DateFloatingFilterComponent
                    ]),
                    dropdown.DropdownModule,
                    tooltip.TooltipModule,
                    toast.ToastModule,
                    confirmdialog.ConfirmDialogModule,
                    checkbox.CheckboxModule,
                    calendar.CalendarModule,
                    autocomplete.AutoCompleteModule,
                    keyfilter.KeyFilterModule,
                    multiselect.MultiSelectModule
                ]] });
        return CommonModule;
    }());
    (function () { (typeof ngJitMode === "undefined" || ngJitMode) && core["ɵɵsetNgModuleScope"](CommonModule, { declarations: [ToolbarComponent,
            RootComponent,
            TableComponent,
            SumPipe,
            BoolPipe,
            EnumPipe,
            Column,
            Cell,
            LookupComponent,
            ProgressPanelComponent,
            FileViewerComponent,
            SizeableTreeDirective,
            AutocompleteFixDirective,
            CalendarDirective,
            CalendarUtcDateDirective,
            DialogExtDirective,
            DialogBreakpointsDirective,
            TableFrozenFixDirective,
            HorizontalSplitPaneFix,
            PDataViewDirective,
            PFileUploadDirective,
            RequiredIfDirective,
            MenuDirective,
            MenuItemDirective,
            AgGridDirective,
            AgGridAutoGroupColumn,
            AgGridColumnDirective,
            Table2Component,
            TextFloatingFilterComponent,
            DropdownFilterComponent,
            DropdownFloatingFilterComponent,
            EntityConfigDirective,
            FieldConfigDirective,
            DictionaryLookupComponent,
            ExtensionAttributesComponent,
            SpinnerDirective,
            DictionaryLookupGridComponent,
            InvalidIfDirective,
            PKeyFilterNumDirective,
            DistinctFilterDialogComponent,
            HorizontalSplitPaneComponent,
            VerticalSplitPaneComponent,
            HorizontalSplitSeparatorComponent,
            VerticalSplitSeparatorComponent,
            SplitSeparatorComponent,
            SplitPaneComponent,
            ValidateDirective,
            ValidationMessageDirective,
            CalenderMaskDirective,
            CheckboxHeaderComponent,
            TriStateCheckboxHeaderComponent,
            InputDirective,
            InputNumberDirective,
            ButtonDirective,
            ButtonFormValidateDirective,
            CustomDetailComponent,
            TooltipExtDirective,
            TextareaDirective,
            DateFilterComponent,
            DateFloatingFilterComponent,
            MenuSquareComponent], imports: [angularOauth2Oidc.OAuthModule, ngxLogger.LoggerModule, common.CommonModule,
            http.HttpClientModule,
            table.TableModule,
            contextmenu.ContextMenuModule,
            inputtext.InputTextModule,
            primeng.InputTextareaModule,
            button.ButtonModule,
            dialog.DialogModule,
            paginator.PaginatorModule,
            tristatecheckbox.TriStateCheckboxModule,
            picklist.PickListModule,
            blockui.BlockUIModule,
            panel.PanelModule,
            menu.MenuModule,
            tieredmenu.TieredMenuModule,
            toolbar.ToolbarModule,
            overlaypanel.OverlayPanelModule,
            card.CardModule,
            fileupload.FileUploadModule,
            scrollpanel.ScrollPanelModule, agGridAngular.AgGridModule, dropdown.DropdownModule,
            tooltip.TooltipModule,
            toast.ToastModule,
            confirmdialog.ConfirmDialogModule,
            checkbox.CheckboxModule,
            calendar.CalendarModule,
            autocomplete.AutoCompleteModule,
            keyfilter.KeyFilterModule,
            multiselect.MultiSelectModule], exports: [ToolbarComponent,
            RootComponent,
            TableComponent,
            SumPipe,
            BoolPipe,
            EnumPipe,
            Column,
            Cell,
            LookupComponent,
            ProgressPanelComponent,
            SizeableTreeDirective,
            AutocompleteFixDirective,
            CalendarDirective,
            CalendarUtcDateDirective,
            DialogExtDirective,
            DialogBreakpointsDirective,
            TableFrozenFixDirective,
            HorizontalSplitPaneFix,
            PDataViewDirective,
            PFileUploadDirective,
            RequiredIfDirective,
            FileViewerComponent,
            MenuDirective,
            MenuItemDirective,
            AgGridDirective,
            AgGridAutoGroupColumn,
            Table2Component,
            TextFloatingFilterComponent,
            DropdownFilterComponent,
            DropdownFloatingFilterComponent,
            DateFilterComponent,
            DateFloatingFilterComponent,
            EntityConfigDirective,
            FieldConfigDirective,
            DictionaryLookupComponent,
            ExtensionAttributesComponent,
            SpinnerDirective,
            InvalidIfDirective,
            PKeyFilterNumDirective,
            HorizontalSplitPaneComponent,
            VerticalSplitPaneComponent,
            ValidateDirective,
            ValidationMessageDirective,
            CalenderMaskDirective,
            InputDirective,
            InputNumberDirective,
            ButtonDirective,
            ButtonFormValidateDirective,
            TooltipExtDirective,
            TextareaDirective,
            MenuSquareComponent] }); })();
    /*@__PURE__*/ (function () { core["ɵsetClassMetadata"](CommonModule, [{
            type: core.NgModule,
            args: [{
                    declarations: [
                        ToolbarComponent,
                        RootComponent,
                        TableComponent,
                        SumPipe,
                        BoolPipe,
                        EnumPipe,
                        Column,
                        Cell,
                        LookupComponent,
                        ProgressPanelComponent,
                        FileViewerComponent,
                        SizeableTreeDirective,
                        AutocompleteFixDirective,
                        CalendarDirective,
                        CalendarUtcDateDirective,
                        DialogExtDirective,
                        DialogBreakpointsDirective,
                        TableFrozenFixDirective,
                        HorizontalSplitPaneFix,
                        PDataViewDirective,
                        PFileUploadDirective,
                        RequiredIfDirective,
                        MenuDirective,
                        MenuItemDirective,
                        AgGridDirective,
                        AgGridAutoGroupColumn,
                        AgGridColumnDirective,
                        Table2Component,
                        TextFloatingFilterComponent,
                        DropdownFilterComponent,
                        DropdownFloatingFilterComponent,
                        EntityConfigDirective,
                        FieldConfigDirective,
                        DictionaryLookupComponent,
                        ExtensionAttributesComponent,
                        SpinnerDirective,
                        DictionaryLookupGridComponent,
                        InvalidIfDirective,
                        PKeyFilterNumDirective,
                        DistinctFilterDialogComponent,
                        HorizontalSplitPaneComponent,
                        VerticalSplitPaneComponent,
                        HorizontalSplitSeparatorComponent,
                        VerticalSplitSeparatorComponent,
                        SplitSeparatorComponent,
                        SplitPaneComponent,
                        ValidateDirective,
                        ValidationMessageDirective,
                        CalenderMaskDirective,
                        CheckboxHeaderComponent,
                        TriStateCheckboxHeaderComponent,
                        InputDirective,
                        InputNumberDirective,
                        ButtonDirective,
                        ButtonFormValidateDirective,
                        CustomDetailComponent,
                        TooltipExtDirective,
                        TextareaDirective,
                        DateFilterComponent,
                        DateFloatingFilterComponent,
                        MenuSquareComponent,
                    ],
                    imports: [
                        angularOauth2Oidc.OAuthModule.forRoot(),
                        ngxLogger.LoggerModule.forRoot(null),
                        common.CommonModule,
                        http.HttpClientModule,
                        table.TableModule,
                        contextmenu.ContextMenuModule,
                        inputtext.InputTextModule,
                        primeng.InputTextareaModule,
                        button.ButtonModule,
                        dialog.DialogModule,
                        paginator.PaginatorModule,
                        tristatecheckbox.TriStateCheckboxModule,
                        picklist.PickListModule,
                        blockui.BlockUIModule,
                        panel.PanelModule,
                        menu.MenuModule,
                        tieredmenu.TieredMenuModule,
                        toolbar.ToolbarModule,
                        overlaypanel.OverlayPanelModule,
                        card.CardModule,
                        fileupload.FileUploadModule,
                        scrollpanel.ScrollPanelModule,
                        // SplitPaneModule,
                        agGridAngular.AgGridModule.withComponents([
                            TextFloatingFilterComponent,
                            DropdownFilterComponent,
                            DropdownFloatingFilterComponent,
                            CheckboxHeaderComponent,
                            TriStateCheckboxHeaderComponent,
                            CustomDetailComponent,
                            DateFilterComponent,
                            DateFloatingFilterComponent
                        ]),
                        dropdown.DropdownModule,
                        tooltip.TooltipModule,
                        toast.ToastModule,
                        confirmdialog.ConfirmDialogModule,
                        checkbox.CheckboxModule,
                        calendar.CalendarModule,
                        autocomplete.AutoCompleteModule,
                        keyfilter.KeyFilterModule,
                        multiselect.MultiSelectModule
                    ],
                    exports: [
                        ToolbarComponent,
                        RootComponent,
                        TableComponent,
                        SumPipe,
                        BoolPipe,
                        EnumPipe,
                        Column,
                        Cell,
                        LookupComponent,
                        ProgressPanelComponent,
                        SizeableTreeDirective,
                        AutocompleteFixDirective,
                        CalendarDirective,
                        CalendarUtcDateDirective,
                        DialogExtDirective,
                        DialogBreakpointsDirective,
                        TableFrozenFixDirective,
                        HorizontalSplitPaneFix,
                        PDataViewDirective,
                        PFileUploadDirective,
                        RequiredIfDirective,
                        FileViewerComponent,
                        MenuDirective,
                        MenuItemDirective,
                        AgGridDirective,
                        AgGridAutoGroupColumn,
                        Table2Component,
                        TextFloatingFilterComponent,
                        DropdownFilterComponent,
                        DropdownFloatingFilterComponent,
                        DateFilterComponent,
                        DateFloatingFilterComponent,
                        EntityConfigDirective,
                        FieldConfigDirective,
                        DictionaryLookupComponent,
                        ExtensionAttributesComponent,
                        SpinnerDirective,
                        InvalidIfDirective,
                        PKeyFilterNumDirective,
                        HorizontalSplitPaneComponent,
                        VerticalSplitPaneComponent,
                        ValidateDirective,
                        ValidationMessageDirective,
                        CalenderMaskDirective,
                        InputDirective,
                        InputNumberDirective,
                        ButtonDirective,
                        ButtonFormValidateDirective,
                        TooltipExtDirective,
                        TextareaDirective,
                        MenuSquareComponent,
                    ],
                    entryComponents: [DistinctFilterDialogComponent]
                }]
        }], null, null); })();

    function replaceArrayElement(arr, element, newElement) {
        if (!arr || !element || !newElement)
            return false;
        var ind = arr.indexOf(element);
        if (ind >= 0) {
            arr[ind] = newElement;
            return true;
        }
        return false;
    }

    var generateDataTree = function (data, itemInizialization) {
        var fields = [];
        for (var _i = 2; _i < arguments.length; _i++) {
            fields[_i - 2] = arguments[_i];
        }
        // генерация дерева
        // создадим рут левел и пробежимся по data
        var tree = data.reduce(function (result, type) {
            // напихаем в рут все ветки
            (function (root, treePath) {
                // обработаем все ветки, исходя из последовательностей fields
                // ключ может быть только типом string, ENUM работают сами,
                // для сложных объектов переопределите метод toString() возвращающий уникальный индекс объекта
                fields.reduce(function (treeItem, fieldName) {
                    var key = (treePath[fieldName]);
                    // если ветки не было, создадим новую
                    treeItem.childrens[key] = treeItem.childrens[key] || getTreeItem(key, itemInizialization, treePath, fieldName);
                    return treeItem.childrens[key];
                }, root);
            })(result, type);
            return result;
            // начало дерева root
        }, getTreeItem('root'));
        return tree;
    };
    // функция генерации элемента дерева
    var getTreeItem = function (key, itemInizialization, origin, field) {
        var result = {
            value: key,
            origin: origin,
            field: field,
            childrens: {},
            items: function () { return Object.keys(result.childrens).map(function (e) { return result.childrens[e]; }); },
            // функция вывода конкретной ветки по ее индексам, getItemsByLevels(0,1,0) покажет ветку 4 уровня см testTreeGenerator
            getItemsByLevels: function () {
                var args = [];
                for (var _i = 0; _i < arguments.length; _i++) {
                    args[_i] = arguments[_i];
                }
                var root = result;
                args.forEach(function (element, index, array) {
                    root = !!array ? root.items()[array[index]] : root;
                });
                return root.items();
            }
        };
        if (!!itemInizialization) {
            itemInizialization(result);
        }
        return result;
    };
    var logAsJson = function (value) {
        //console.log(JSON.stringify(value));
    };
    var testTreeGenerator = function () {
        var arr = [];
        arr.push({ isOutside: true, type: 'paper', state: 'copy', title: 'aaaacopy' });
        arr.push({ isOutside: false, type: 'paper', state: 'dublicate', title: 'aaaadublicate' });
        arr.push({ isOutside: true, type: 'device', state: 'copy', title: 'bbbbcopy' });
        arr.push({ isOutside: false, type: 'device', state: 'copy', title: 'bbbbdublicate' });
        arr.push({ isOutside: true, type: 'paper', state: 'dublicate', title: 'ccccdublicate' });
        arr.push({ isOutside: true, type: 'list', state: 'copy', title: 'ddddcopy' });
        arr.push({ isOutside: true, type: 'paper', state: 'copy', title: 'aaaacopy2' });
        arr.push({ isOutside: false, type: 'paper', state: 'dublicate', title: 'aaaadublicate2' });
        arr.push({ isOutside: true, type: 'device', state: 'copy', title: 'bbbbcopy2' });
        arr.push({ isOutside: false, type: 'device', state: 'copy', title: 'bbbbdublicate2' });
        arr.push({ isOutside: true, type: 'paper', state: 'dublicate', title: 'ccccdublicate2' });
        arr.push({ isOutside: true, type: 'list', state: 'copy', title: 'ddddcopy2' });
        var tree = generateDataTree(arr, function (e) { }, 'isOutside', 'type', 'state', 'title');
        logAsJson(tree.getItemsByLevels());
        logAsJson(tree.getItemsByLevels(0));
        logAsJson(tree.getItemsByLevels(0, 0));
        logAsJson(tree.getItemsByLevels(0, 0, 0));
    };

    function copyTextToClipboard(text) {
        // document.execCommand() позволяет копировать в буфер только из активного текствого поля
        var clipboardTextField = document.createElement('textarea');
        clipboardTextField.style.opacity = '0';
        clipboardTextField.value = text;
        document.body.appendChild(clipboardTextField);
        clipboardTextField.focus();
        clipboardTextField.select();
        try {
            document.execCommand('copy');
        }
        catch (err) {
            console.log(err);
        }
        finally {
            document.body.removeChild(clipboardTextField);
        }
    }

    var Dictionary = /** @class */ (function () {
        function Dictionary() {
        }
        return Dictionary;
    }());

    var QueryToken = /** @class */ (function () {
        function QueryToken() {
            this.value = Number.MAX_VALUE;
        }
        QueryToken.prototype.next = function () {
            var token = new QueryToken();
            if (this.value === Number.MAX_VALUE) {
                this.value = 0;
            }
            token.value = ++this.value;
            return token;
        };
        QueryToken.prototype.equals = function (token) {
            return this.value === token.value;
        };
        return QueryToken;
    }());


    (function (CustomHeaders) {
        CustomHeaders["CHECKBOX"] = "checkboxHeaderComponent";
        CustomHeaders["TRI_STATE_CHECKBOX"] = "triStateCheckboxHeaderComponent";
    })(exports.CustomHeaders || (exports.CustomHeaders = {}));

    var ToolbarTemplate = /** @class */ (function () {
        function ToolbarTemplate() {
        }
        return ToolbarTemplate;
    }());


    (function (DetailCellRenderer) {
        DetailCellRenderer["CUSTOM"] = "customDetailComponent";
    })(exports.DetailCellRenderer || (exports.DetailCellRenderer = {}));

    exports.AgGridAutoGroupColumn = AgGridAutoGroupColumn;
    exports.AgGridDirective = AgGridDirective;
    exports.AuthEventbusEvent = AuthEventbusEvent;
    exports.AuthService = AuthService;
    exports.AutocompleteFixDirective = AutocompleteFixDirective;
    exports.BaseService = BaseService;
    exports.BoolPipe = BoolPipe;
    exports.ButtonDirective = ButtonDirective;
    exports.ButtonFormValidateDirective = ButtonFormValidateDirective;
    exports.CalendarDirective = CalendarDirective;
    exports.CalendarUtcDateDirective = CalendarUtcDateDirective;
    exports.CalenderMaskDirective = CalenderMaskDirective;
    exports.CancellationToken = CancellationToken;
    exports.Cell = Cell;
    exports.Column = Column;
    exports.CommonModule = CommonModule;
    exports.ConfigurationService = ConfigurationService;
    exports.DataSource = DataSource;
    exports.DateFilterComponent = DateFilterComponent;
    exports.DateFloatingFilterComponent = DateFloatingFilterComponent;
    exports.DialogBreakpointsDirective = DialogBreakpointsDirective;
    exports.DialogComponent = DialogComponent;
    exports.DialogExtDirective = DialogExtDirective;
    exports.DialogService = DialogService;
    exports.Dictionary = Dictionary;
    exports.DictionaryLookupComponent = DictionaryLookupComponent;
    exports.DictionaryService = DictionaryService;
    exports.DropdownFilterComponent = DropdownFilterComponent;
    exports.DropdownFloatingFilterComponent = DropdownFloatingFilterComponent;
    exports.EntityConfigDirective = EntityConfigDirective;
    exports.EntityConfigService = EntityConfigService;
    exports.EnumPipe = EnumPipe;
    exports.EventBusService = EventBusService;
    exports.ExtensionAttributesComponent = ExtensionAttributesComponent;
    exports.FieldConfigDirective = FieldConfigDirective;
    exports.FileViewerComponent = FileViewerComponent;
    exports.FileViewerService = FileViewerService;
    exports.HTTPError = HTTPError;
    exports.HorizontalSplitPaneComponent = HorizontalSplitPaneComponent;
    exports.HorizontalSplitPaneFix = HorizontalSplitPaneFix;
    exports.HorizontalSplitSeparatorComponent = HorizontalSplitSeparatorComponent;
    exports.HttpEventbusEvent = HttpEventbusEvent;
    exports.INPUTNUMBER_VALUE_ACCESSOR = INPUTNUMBER_VALUE_ACCESSOR;
    exports.InputDirective = InputDirective;
    exports.InputNumber = InputNumber;
    exports.InputNumberDirective = InputNumberDirective;
    exports.InputNumberModule = InputNumberModule;
    exports.InvalidIfDirective = InvalidIfDirective;
    exports.LazyLoadEvent = LazyLoadEvent;
    exports.LoginGuard = LoginGuard;
    exports.LookupBaseComponent = LookupBaseComponent;
    exports.LookupComponent = LookupComponent;
    exports.MenuDirective = MenuDirective;
    exports.MenuItemDirective = MenuItemDirective;
    exports.MenuSquareComponent = MenuSquareComponent;
    exports.PDataViewDirective = PDataViewDirective;
    exports.PFileUploadDirective = PFileUploadDirective;
    exports.PKeyFilterNumDirective = PKeyFilterNumDirective;
    exports.PageQuery = PageQuery;
    exports.ProgressPanelComponent = ProgressPanelComponent;
    exports.PromiseCanceled = PromiseCanceled;
    exports.QueryToken = QueryToken;
    exports.RequiredIfDirective = RequiredIfDirective;
    exports.RootComponent = RootComponent;
    exports.SizeableTreeDirective = SizeableTreeDirective;
    exports.SpinnerDirective = SpinnerDirective;
    exports.SumPipe = SumPipe;
    exports.Table2Component = Table2Component;
    exports.TableComponent = TableComponent;
    exports.TableFrozenFixDirective = TableFrozenFixDirective;
    exports.TextFloatingFilterComponent = TextFloatingFilterComponent;
    exports.TextareaDirective = TextareaDirective;
    exports.ToolbarComponent = ToolbarComponent;
    exports.ToolbarTemplate = ToolbarTemplate;
    exports.TooltipExtDirective = TooltipExtDirective;
    exports.User = User;
    exports.UserService = UserService;
    exports.ValidateDirective = ValidateDirective;
    exports.ValidationMessageDirective = ValidationMessageDirective;
    exports.VerticalSplitPaneComponent = VerticalSplitPaneComponent;
    exports.VerticalSplitSeparatorComponent = VerticalSplitSeparatorComponent;
    exports.columnTypeFilterMatchModes = columnTypeFilterMatchModes;
    exports.copyTextToClipboard = copyTextToClipboard;
    exports.debounceValidation = debounceValidation;
    exports.generateDataTree = generateDataTree;
    exports.getFilterModesTitle = getFilterModesTitle;
    exports.initializer = initializer;
    exports.localeColumnFilterModes = localeColumnFilterModes;
    exports.logAsJson = logAsJson;
    exports.replaceArrayElement = replaceArrayElement;
    exports.tableProviderFactory = tableProviderFactory;
    exports.testTreeGenerator = testTreeGenerator;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=prism-common.umd.js.map
