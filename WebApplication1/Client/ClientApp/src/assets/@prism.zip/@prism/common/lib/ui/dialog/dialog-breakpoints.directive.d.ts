import { OnInit } from '@angular/core';
import { Dialog } from 'primeng/dialog';
import * as i0 from "@angular/core";
export declare class DialogBreakpointsDirective implements OnInit {
    private dialog;
    private _breakpoints;
    constructor(dialog: Dialog);
    set breakpoints(breakpoints: string[]);
    ngOnInit(): void;
    onWindowResize(): void;
    private updateSize;
    private getPixelWidth;
    static ɵfac: i0.ɵɵFactoryDef<DialogBreakpointsDirective>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<DialogBreakpointsDirective, "p-dialog[breakpoints]", never, { "breakpoints": "breakpoints"; }, {}, never>;
}
