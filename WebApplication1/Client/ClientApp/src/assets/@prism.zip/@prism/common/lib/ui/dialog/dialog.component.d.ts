import { AfterContentInit, EventEmitter } from '@angular/core';
import { Dialog } from 'primeng/dialog';
import { DialogExtDirective } from './dialog-ext.directive';
import * as i0 from "@angular/core";
export declare class DialogComponent implements AfterContentInit {
    private _shown;
    get visible(): boolean;
    set visible(visible: boolean);
    get loading(): boolean;
    set loading(loading: boolean);
    get shown(): boolean;
    visibleChange: EventEmitter<boolean>;
    onShow: EventEmitter<void>;
    onHide: EventEmitter<void>;
    dialog: Dialog;
    dialogExt: DialogExtDirective;
    ngAfterContentInit(): void;
    private showInternal;
    private hideInternal;
    static ɵfac: i0.ɵɵFactoryDef<DialogComponent>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<DialogComponent, never, never, { "visible": "visible"; "loading": "loading"; }, { "visibleChange": "visibleChange"; "onShow": "onShow"; "onHide": "onHide"; }, never>;
}
