import * as i0 from "@angular/core";
export declare class FileLoadService {
    readFileAsync(file: any): Promise<unknown>;
    static ɵfac: i0.ɵɵFactoryDef<FileLoadService>;
    static ɵprov: i0.ɵɵInjectableDef<FileLoadService>;
}
