import { AfterViewInit } from '@angular/core';
import { Table } from 'primeng/table';
import * as i0 from "@angular/core";
export declare class TableFrozenFixDirective implements AfterViewInit {
    private table;
    constructor(table: Table);
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDef<TableFrozenFixDirective>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<TableFrozenFixDirective, "p-table", never, {}, {}, never>;
}
