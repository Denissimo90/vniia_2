import { Location } from '@angular/common';
import { AuthConfig, OAuthService } from 'angular-oauth2-oidc';
import { User } from './User';
import { EventBusService } from '../events/eventbus.service';
import { ConfigurationService } from '../config/configuration.service';
import { NGXLogger } from 'ngx-logger';
import * as i0 from "@angular/core";
export declare class AuthService {
    private oauthService;
    private configurationService;
    protected bus: EventBusService;
    private location;
    private _logger;
    private _user;
    private storage;
    constructor(oauthService: OAuthService, configurationService: ConfigurationService, bus: EventBusService, location: Location, _logger: NGXLogger);
    get logger(): any;
    init(): Promise<void>;
    getAutoConfig(configurationService: ConfigurationService, location: Location): AuthConfig;
    getStorage(autoConfig: any): {
        getItem: (key: string) => string;
        removeItem: (key: string) => void;
        setItem: (key: string, data: string) => void;
    };
    initLogger(): void;
    login(tryRefreshToken?: boolean, redirectUri?: string): Promise<boolean>;
    private readToken;
    getAccessToken(): string;
    get user(): User;
    isLoggedIn(): boolean;
    logout(postLogoutRedirectUri?: string): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDef<AuthService>;
    static ɵprov: i0.ɵɵInjectableDef<AuthService>;
}
