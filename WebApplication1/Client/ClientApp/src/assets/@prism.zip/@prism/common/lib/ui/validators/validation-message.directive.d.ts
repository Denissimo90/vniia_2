import { AfterViewInit, ElementRef, NgZone, OnDestroy } from '@angular/core';
import { NgControl } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class ValidationMessageDirective implements AfterViewInit, OnDestroy {
    private errorRowDiv;
    private errorDiv;
    private sub;
    constructor(el: ElementRef, control: NgControl, ngZone: NgZone);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDef<ValidationMessageDirective>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<ValidationMessageDirective, "[ngModel], [formControl]", never, {}, {}, never>;
}
