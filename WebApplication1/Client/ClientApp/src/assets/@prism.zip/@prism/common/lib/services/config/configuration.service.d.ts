import { HttpClient } from '@angular/common/http';
import { NgxLoggerLevel } from 'ngx-logger';
import * as i0 from "@angular/core";
export interface Config {
    condition: string;
    api: string;
    auth: string;
    clientId: string;
    version: string;
    serverLoggingUrl: string;
    serverLogLevel: NgxLoggerLevel;
    logLevel: NgxLoggerLevel;
    offlineMode: boolean;
    restConfig: boolean;
    noLogo: boolean;
    noInformationMenu: boolean;
    noLogsMenu: boolean;
}
export declare class ConfigurationService {
    private http;
    private env;
    private _config;
    constructor(http: HttpClient, env: String);
    get config(): Config;
    appendConfig(config: any): void;
    getRestConfig(uri: string): Promise<void>;
    get storagePrefix(): string;
    init(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDef<ConfigurationService>;
    static ɵprov: i0.ɵɵInjectableDef<ConfigurationService>;
}
