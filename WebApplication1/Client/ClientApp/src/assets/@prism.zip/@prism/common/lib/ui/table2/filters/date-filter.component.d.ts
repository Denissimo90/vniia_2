import { AgFrameworkComponent, IFilterAngularComp } from 'ag-grid-angular';
import { IDoesFilterPassParams, IFilterParams } from 'ag-grid-community';
import { FilterMatchModes } from 'ag-grid-community/dist/lib/main';
import * as i0 from "@angular/core";
export interface IDateFilterParams extends IFilterParams {
    type?: FilterMatchModes;
}
export declare class DateFilterComponent implements IFilterAngularComp, AgFrameworkComponent<IDateFilterParams> {
    private local;
    constructor(local: string);
    calendarValue: Date | Date[];
    params: IDateFilterParams;
    agInit(params: IDateFilterParams): void;
    doesFilterPass(params: IDoesFilterPassParams): boolean;
    getModel(): any;
    isFilterActive(): boolean;
    setModel(model: any): void;
    onFloatingFilterChanged(type: FilterMatchModes, calendarValue: Date | Date[]): void;
    static ɵfac: i0.ɵɵFactoryDef<DateFilterComponent>;
    static ɵcmp: i0.ɵɵComponentDefWithMeta<DateFilterComponent, "ng-component", never, {}, {}, never>;
}
