import { IFloatingFilter, IFloatingFilterParams, TextFilterModel } from 'ag-grid-community';
import { AgFrameworkComponent } from 'ag-grid-angular';
import { FilterMatchModes } from 'ag-grid-community/dist/lib/main';
import * as i0 from "@angular/core";
export interface DropdownFloatingFilterParams extends IFloatingFilterParams {
    type?: string;
    enum: any[];
}
export declare class DropdownFloatingFilterComponent implements IFloatingFilter, AgFrameworkComponent<DropdownFloatingFilterParams> {
    params: DropdownFloatingFilterParams;
    isEnum: boolean;
    currentValue: any;
    value: any;
    type: {
        key: FilterMatchModes;
        title: string;
        sign: string;
    };
    types: {
        key: FilterMatchModes;
        title: string;
        sign: string;
    }[];
    getFilterModesTitle: (localFilterMode: {
        title: string;
        sign: string;
    }) => string;
    agInit(params: DropdownFloatingFilterParams): void;
    isFilterActive(): boolean;
    valueChanged(): void;
    applyFilterMode(type: any): void;
    apply(): void;
    onParentModelChanged(parentModel: TextFilterModel): void;
    static ɵfac: i0.ɵɵFactoryDef<DropdownFloatingFilterComponent>;
    static ɵcmp: i0.ɵɵComponentDefWithMeta<DropdownFloatingFilterComponent, "ng-component", never, {}, {}, never>;
}
