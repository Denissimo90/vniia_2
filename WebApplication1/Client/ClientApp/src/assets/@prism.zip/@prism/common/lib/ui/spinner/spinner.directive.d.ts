import { Spinner } from 'primeng/spinner';
import * as i0 from "@angular/core";
export declare class SpinnerDirective {
    constructor(spinner: Spinner);
    static ɵfac: i0.ɵɵFactoryDef<SpinnerDirective>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<SpinnerDirective, "p-spinner[min]", never, {}, {}, never>;
}
