import { AfterViewInit } from '@angular/core';
import { TreeTable } from 'primeng/treetable';
import * as i0 from "@angular/core";
export declare class SizeableTreeDirective implements AfterViewInit {
    private treeTable;
    iframe: any;
    unfrozenView: any;
    unfrozenBody: any;
    constructor(treeTable: TreeTable);
    ngAfterViewInit(): void;
    onColumnResize(): void;
    static ɵfac: i0.ɵɵFactoryDef<SizeableTreeDirective>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<SizeableTreeDirective, "p-treeTable", never, {}, {}, never>;
}
