import { Event } from './eventbus.service';
export declare enum HTTPErrors {
    TYPE_INTERNAL_SERVER_ERROR = 500,
    TYPE_NOT_IMPLEMENTED = 501,
    TYPE_BAD_GATEWAY = 502,
    TYPE_SERVICE_UNAVAILABLE = 503,
    TYPE_GATEWAY_TIMEOUT = 504,
    TYPE_HTTP_VERSION_NOT_SUPPORTED = 505,
    TYPE_INSUFFICIENT_STORAGE = 507,
    TYPE_NOT_EXTENDED = 510,
    TYPE_NETWORK_AUTHENTICATION_REQUIRED = 511,
    TYPE_BAD_REQUEST = 400,
    TYPE_UNAUTHORIZED = 401,
    TYPE_FORBIDDEN = 403,
    TYPE_NOT_FOUND = 404,
    TYPE_METHOD_NOT_ALLOWED = 405,
    TYPE_NOT_ACCEPTABLE = 406,
    TYPE_REQUEST_TIMEOUT = 408,
    TYPE_CONFLICT = 409,
    TYPE_PRECONDITION_FAILED = 412,
    TYPE_EXPECTATION_FAILED = 417,
    TYPE_PAYLOAD_TOO_LARGE = 413,
    TYPE_URI_TOO_LONG = 414,
    TYPE_UNSUPPORTED_MEDIA_TYPE = 415,
    TYPE_UNPROCESSABLE_ENTITY = 422,
    TYPE_LOCKED = 423,
    TYPE_FAILED_DEPENDENCY = 424,
    TYPE_UPGRADE_REQUIRED = 426,
    TYPE_PRECONDITION_REQUIRED = 428,
    TYPE_TOO_MANY_REQUESTS = 429,
    TYPE_REQUEST_HEADER_FIELDS_TOO_LARGE = 431,
    TYPE_REQUESTED_HOST_UNAVAILABLE = 434,
    TYPE_RETRY_WITH = 449,
    TYPE_UNAVAILABLE_FOR_LEGAL_REASONS = 451,
    TYPE_UNCKNOW_ERROR = 999,
    TYPE_NETWROK_IO_ERROR = 10001,
    TYPE_SEE_OTHER = 303
}
export declare class HTTPError {
    static getHttpErrorByType(code: number): HTTPErrors;
    static getHttpErrorByName(name: string): HTTPErrors;
}
export declare class HttpEventbusEvent implements Event {
    code: string;
    type: string;
    httpError: HTTPErrors;
    message: string;
    callback: () => void;
    constructor(httpError?: HTTPErrors, message?: string, code?: string, callback?: any);
}
