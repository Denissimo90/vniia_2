import { EventEmitter, OnInit } from '@angular/core';
import { DialogComponent } from '../../dialog/dialog.component';
import { Column } from '../../table/column';
import { IServerSideGetRowsParams } from 'ag-grid-community';
import { LazyLoadEvent, Table2Component } from '../table2.component';
import { Dialog } from 'primeng/dialog';
import * as i0 from "@angular/core";
export declare class DistinctFilterDialogComponent extends DialogComponent implements OnInit {
    column: Column;
    selection: any[];
    loader: (e: IServerSideGetRowsParams) => void;
    initialFilter: string;
    getRowId: (row: any) => any;
    result: EventEmitter<string[]>;
    dialog: Dialog;
    table: Table2Component;
    constructor();
    ngOnInit(): void;
    init(column: Column, loader: (e: IServerSideGetRowsParams) => void, initialFilter: string): void;
    onLoad(e: LazyLoadEvent): void;
    apply(): void;
    getValue(row: any): any;
    cancel(): void;
    onDataSourceReady(api: any): void;
    onresize(e: any): void;
    static ɵfac: i0.ɵɵFactoryDef<DistinctFilterDialogComponent>;
    static ɵcmp: i0.ɵɵComponentDefWithMeta<DistinctFilterDialogComponent, "lib-distinct-filter-dialog", never, {}, { "result": "result"; }, never>;
}
