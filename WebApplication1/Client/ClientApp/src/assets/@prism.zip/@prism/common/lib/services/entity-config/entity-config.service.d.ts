import { HttpClient } from '@angular/common/http';
import { AuthService } from '../auth/auth.service';
import { EventBusService } from '../events/eventbus.service';
import { FieldConfig } from '../../ui/entity/config/FieldConfig';
import { TableExtensionField } from '../../ui/entity/extension/TableExtensionField';
import { EntityFieldConfig } from '../../ui/entity/config/EntityFieldConfig';
import { BaseService } from '../http/base.service';
import { ConfigurationService } from '../config/configuration.service';
import * as i0 from "@angular/core";
export declare class EntityConfigService extends BaseService {
    protected httpClient: HttpClient;
    protected authService: AuthService;
    protected bus: EventBusService;
    protected configurationService: ConfigurationService;
    private extensions;
    private configs;
    constructor(httpClient: HttpClient, authService: AuthService, bus: EventBusService, configurationService: ConfigurationService);
    init(): Promise<void>;
    getEntityConfig(entityName: string, domain: any): {
        [key: string]: FieldConfig;
    };
    getEntityExtension(entityName: string): TableExtensionField[];
    getExtensions(): Promise<{
        [key: string]: TableExtensionField[];
    }>;
    getConfigs(): Promise<{
        [key: string]: EntityFieldConfig[];
    }>;
    static ɵfac: i0.ɵɵFactoryDef<EntityConfigService>;
    static ɵprov: i0.ɵɵInjectableDef<EntityConfigService>;
}
