import { Column as AgColumn, GridApi } from 'ag-grid-community';
export declare abstract class DistinctFilterService {
    get isEnabled(): boolean;
    abstract showFilterDialog(api: GridApi, agColumn: AgColumn): any;
}
