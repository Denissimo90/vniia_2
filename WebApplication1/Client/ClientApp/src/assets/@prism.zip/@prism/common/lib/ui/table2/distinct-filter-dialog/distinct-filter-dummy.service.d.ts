import { DistinctFilterService } from './distinct-filter.service';
import { Column, GridApi } from 'ag-grid-community';
import * as i0 from "@angular/core";
export declare class DistinctFilterDummyService extends DistinctFilterService {
    get isEnabled(): boolean;
    showFilterDialog(api: GridApi, agColumn: Column): void;
    static ɵfac: i0.ɵɵFactoryDef<DistinctFilterDummyService>;
    static ɵprov: i0.ɵɵInjectableDef<DistinctFilterDummyService>;
}
