import { OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { EntityConfigService } from '../../../../services/entity-config/entity-config.service';
import { FileViewerService } from '../../../file-viewer/file-viewer.service';
import { HttpClient } from '@angular/common/http';
import * as i0 from "@angular/core";
export declare class ExtensionAttributesComponent implements OnInit {
    private entityConfigService;
    private fileViewerService;
    private httpClient;
    private ngForm;
    private _entity;
    get entity(): {
        extension: any;
    };
    set entity(entity: {
        extension: any;
    });
    entityName: string;
    extraFields: any[];
    constructor(entityConfigService: EntityConfigService, fileViewerService: FileViewerService, httpClient: HttpClient, ngForm: NgForm);
    ngOnInit(): void;
    onSelectFile(fieldName: string): void;
    onUploadFile(fieldName: string, result: string): void;
    onUploadError(fieldName: string): void;
    getFileName(fieldName: string): any;
    downloadFile(fieldName: string, url: string): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDef<ExtensionAttributesComponent>;
    static ɵcmp: i0.ɵɵComponentDefWithMeta<ExtensionAttributesComponent, "app-extension-attributes", never, { "entity": "entity"; "entityName": "entityName"; "extraFields": "extraFields"; }, {}, never>;
}
