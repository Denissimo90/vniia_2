import { OnChanges, SimpleChanges } from '@angular/core';
import { AbstractControl, Validator } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class RequiredIfDirective implements Validator, OnChanges {
    constructor();
    private _requiredIf;
    get requiredIf(): boolean;
    set requiredIf(value: boolean);
    private _onChange;
    validate(c: AbstractControl): {
        requiredIf: {
            condition: true;
        };
    };
    registerOnChange(fn: any): void;
    registerOnValidatorChange(fn: () => void): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDef<RequiredIfDirective>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<RequiredIfDirective, "[requiredIf]", never, { "requiredIf": "requiredIf"; }, {}, never>;
}
