import { AbstractControl, AsyncValidator, AsyncValidatorFn, ValidationErrors, ValidatorFn } from '@angular/forms';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class ValidateDirective implements AsyncValidator {
    private onValidatorChangeFn;
    private _changeDetect;
    private debounceIntervalId;
    validator: ValidatorFn | AsyncValidatorFn;
    debounce: boolean;
    debounceTime: number;
    get changeDetect(): any;
    set changeDetect(value: any);
    validate(control: AbstractControl): Promise<ValidationErrors | null> | Observable<ValidationErrors | null> | null;
    private validateInternal;
    registerOnValidatorChange?(fn: () => void): void;
    static ɵfac: i0.ɵɵFactoryDef<ValidateDirective>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<ValidateDirective, "[appValidate]", never, { "validator": "appValidate"; "debounce": "appValidateDebounce"; "debounceTime": "appValidateDebounceTime"; "changeDetect": "appValidateChangeDetect"; }, {}, never>;
}
