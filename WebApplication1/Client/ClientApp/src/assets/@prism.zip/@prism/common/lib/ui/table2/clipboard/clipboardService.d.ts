declare var ClipboardService: () => void;
export { ClipboardService };
