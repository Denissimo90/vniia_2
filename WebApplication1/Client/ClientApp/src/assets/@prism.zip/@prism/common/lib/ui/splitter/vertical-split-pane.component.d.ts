import { ElementRef } from '@angular/core';
import { SplitPaneComponent } from './split-pane.component';
import * as i0 from "@angular/core";
export declare class VerticalSplitPaneComponent extends SplitPaneComponent {
    outerContainer: ElementRef;
    getTotalSize(): number;
    getPrimarySize(): number;
    getSecondarySize(): number;
    dividerPosition(size: number): void;
    onMousemove(event: MouseEvent): boolean;
    static ɵfac: i0.ɵɵFactoryDef<VerticalSplitPaneComponent>;
    static ɵcmp: i0.ɵɵComponentDefWithMeta<VerticalSplitPaneComponent, "vertical-split-pane", never, {}, {}, never>;
}
