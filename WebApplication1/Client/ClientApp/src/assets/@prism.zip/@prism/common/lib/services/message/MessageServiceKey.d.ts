export declare enum MessageServiceKey {
    OK = "MESSAGE_SERVICE_OK_KEY"
}
