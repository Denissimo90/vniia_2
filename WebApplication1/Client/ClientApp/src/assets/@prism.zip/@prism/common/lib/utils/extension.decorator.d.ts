export declare function Extension(ctr: any): (target: any, propertyKey: string, descriptor: PropertyDescriptor) => void;
