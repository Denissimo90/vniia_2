import { ApplicationRef, ComponentFactoryResolver, Injector, Type } from '@angular/core';
import { DialogComponent } from './dialog.component';
import * as i0 from "@angular/core";
export declare class DialogService {
    private componentFactoryResolver;
    private appRef;
    private injector;
    openDialogs: any[];
    constructor(componentFactoryResolver: ComponentFactoryResolver, appRef: ApplicationRef, injector: Injector);
    createDialog<T extends DialogComponent>(component: Type<T>): T;
    static ɵfac: i0.ɵɵFactoryDef<DialogService>;
    static ɵprov: i0.ɵɵInjectableDef<DialogService>;
}
