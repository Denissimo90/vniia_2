import { OnInit, EventEmitter, ElementRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class SplitSeparatorComponent implements OnInit {
    thickness: number;
    notifyWillChangeSize: EventEmitter<boolean>;
    invisibleExtension: ElementRef;
    constructor();
    ngOnInit(): void;
    onMousedown(event: any): boolean;
    static ɵfac: i0.ɵɵFactoryDef<SplitSeparatorComponent>;
    static ɵcmp: i0.ɵɵComponentDefWithMeta<SplitSeparatorComponent, "ng-component", never, { "thickness": "thickness"; }, { "notifyWillChangeSize": "notifyWillChangeSize"; }, never>;
}
