import { AgGridColumn } from 'ag-grid-angular';
import { Column } from '../table/column';
import * as i0 from "@angular/core";
export declare class AgGridColumnDirective {
    col: Column;
    constructor(column: AgGridColumn);
    static ɵfac: i0.ɵɵFactoryDef<AgGridColumnDirective>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<AgGridColumnDirective, "ag-grid-column", never, { "col": "col"; }, {}, never>;
}
