export declare enum CustomHeaders {
    CHECKBOX = "checkboxHeaderComponent",
    TRI_STATE_CHECKBOX = "triStateCheckboxHeaderComponent"
}
