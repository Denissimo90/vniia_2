export declare class User {
    private clientId;
    username: string;
    name: string;
    employeeId: string;
    personId: number;
    depnum: string;
    description: string;
    changePassword: boolean;
    authorities: Array<any>;
    private _roles;
    constructor(clientId: string, username: string, name: string, employeeId: string, personId: number, depnum: string, description: string, changePassword: boolean, authorities: Array<any>);
    get roles(): any;
    get shortname(): string;
    private mapRole;
}
