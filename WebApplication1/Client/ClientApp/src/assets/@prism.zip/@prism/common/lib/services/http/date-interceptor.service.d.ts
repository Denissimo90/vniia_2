import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class DateInterceptorService implements HttpInterceptor {
    dateRegEx: RegExp;
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    convertToDate(body: any, path: string, typesCache: Map<string, string>): void;
    static ɵfac: i0.ɵɵFactoryDef<DateInterceptorService>;
    static ɵprov: i0.ɵɵInjectableDef<DateInterceptorService>;
}
