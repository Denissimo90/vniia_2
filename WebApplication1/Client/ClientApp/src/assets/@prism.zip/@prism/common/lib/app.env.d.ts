import { InjectionToken } from '@angular/core';
export declare let APP_ENV: InjectionToken<string>;
