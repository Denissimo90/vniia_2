export declare class UserEmployment {
    id: number;
    personId: number;
    lastName: string;
    firstName: string;
    middleName: string;
    birthDate: Date;
    personalNumber: string;
    positionId: number;
    positionCode: string;
    positionName: string;
    departmentId: number;
    departmentCode: string;
    departmentName: string;
    placeId: number;
    placeCode: string;
    placeName: string;
    beginDate: Date;
    endDate: Date;
    shortName: string;
    fullName: string;
}
