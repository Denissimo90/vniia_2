import { DoCheck, EventEmitter, KeyValueDiffers } from '@angular/core';
import { FieldConfig } from './FieldConfig';
import { EntityConfigService } from '../../../services/entity-config/entity-config.service';
import * as i0 from "@angular/core";
export declare class EntityConfigDirective implements DoCheck {
    private entityConfigService;
    private keyValueDiffers;
    private _fieldConfigs;
    private configName;
    private entity;
    private differ;
    private differ2;
    constructor(entityConfigService: EntityConfigService, keyValueDiffers: KeyValueDiffers);
    get fieldConfigs(): {
        [key: string]: FieldConfig;
    };
    set appEntityConfigName(configName: any);
    set appEntityConfig(config: any);
    get appEntity(): any;
    set appEntity(entity: any);
    entityChanged: EventEmitter<any>;
    ngDoCheck(): void;
    private loadConfig;
    static ɵfac: i0.ɵɵFactoryDef<EntityConfigDirective>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<EntityConfigDirective, "form[appEntityConfigName], form[appEntityConfig]", never, { "appEntityConfigName": "appEntityConfigName"; "appEntityConfig": "appEntityConfig"; "appEntity": "appEntity"; }, {}, never>;
}
