import { AfterViewInit, ElementRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ButtonDirective implements AfterViewInit {
    private button;
    constructor(button: ElementRef);
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDef<ButtonDirective>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<ButtonDirective, "button:not([type]), p-button:not([type])", never, {}, {}, never>;
}
