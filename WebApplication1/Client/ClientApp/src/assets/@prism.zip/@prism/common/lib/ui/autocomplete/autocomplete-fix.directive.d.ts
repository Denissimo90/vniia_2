import { AutoComplete } from 'primeng/autocomplete';
import * as i0 from "@angular/core";
export declare class AutocompleteFixDirective {
    constructor(autocomplete: AutoComplete);
    static ɵfac: i0.ɵɵFactoryDef<AutocompleteFixDirective>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<AutocompleteFixDirective, "p-autoComplete", never, {}, {}, never>;
}
