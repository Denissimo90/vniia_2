declare global {
    export interface Promise<T> {
        autoCancel(token: CancellationToken): Promise<T>;
    }
}
export declare class PromiseCanceled implements Error {
    private isPromiseCanceled;
    readonly name = "PromiseCanceled";
    readonly message = "PROMISE CANCELLED";
}
export declare class CancellationToken {
    private promise;
    private reject;
    static autoCancel<T>(promise: Promise<T>, token: CancellationToken): Promise<T | Promise<T>>;
    next(): Promise<any>;
    cancel(): void;
}
