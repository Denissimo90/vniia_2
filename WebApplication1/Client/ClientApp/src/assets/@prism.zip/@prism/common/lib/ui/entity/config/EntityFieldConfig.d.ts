export declare class EntityFieldConfig {
    name: string;
    visible: string;
    required: string;
    readonly: string;
}
