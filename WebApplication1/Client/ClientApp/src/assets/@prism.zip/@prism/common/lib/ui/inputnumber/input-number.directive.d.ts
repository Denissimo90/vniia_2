import { ChangeDetectorRef, OnInit } from '@angular/core';
import { InputNumber } from './inputnumber';
import * as i0 from "@angular/core";
export declare class InputNumberDirective implements OnInit {
    private inputNumber;
    private changeDetectorRef;
    locale: string;
    useGrouping: boolean;
    minFractionDigits: number;
    constructor(inputNumber: InputNumber, changeDetectorRef: ChangeDetectorRef);
    ngOnInit(): void;
    getRussianDecimalExpression(): RegExp;
    insert(event: any, text: any, sign?: {
        isDecimalSign: boolean;
        isMinusSign: boolean;
    }): void;
    onInputKeyDown(event: any): void;
    insertText(value: any, text: any, start: any, end: any): any;
    setMinFractionDigits(value: any): void;
    static ɵfac: i0.ɵɵFactoryDef<InputNumberDirective>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<InputNumberDirective, "p-inputNumber", never, { "locale": "locale"; "useGrouping": "useGrouping"; "minFractionDigits": "minFractionDigits"; }, {}, never>;
}
