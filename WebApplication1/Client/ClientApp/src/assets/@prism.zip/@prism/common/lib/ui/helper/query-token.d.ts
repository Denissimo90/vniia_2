export declare class QueryToken {
    private value;
    next(): QueryToken;
    equals(token: QueryToken): boolean;
}
