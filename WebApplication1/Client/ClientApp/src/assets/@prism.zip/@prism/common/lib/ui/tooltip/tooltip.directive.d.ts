import { DoCheck } from '@angular/core';
import { Tooltip } from 'primeng';
import * as i0 from "@angular/core";
export declare class TooltipExtDirective implements DoCheck {
    private tooltip;
    constructor(tooltip: Tooltip);
    ngDoCheck(): void;
    static ɵfac: i0.ɵɵFactoryDef<TooltipExtDirective>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<TooltipExtDirective, "[pTooltip]", never, {}, {}, never>;
}
