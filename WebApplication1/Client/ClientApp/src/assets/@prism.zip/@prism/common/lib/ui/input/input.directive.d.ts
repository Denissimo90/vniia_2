import { OnInit } from '@angular/core';
import { InputText } from 'primeng';
import * as i0 from "@angular/core";
export declare class InputDirective implements OnInit {
    private input;
    autocomplete: boolean;
    emptyStringEqualsNull: boolean;
    constructor(input: InputText);
    onChange(event: any): void;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDef<InputDirective>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<InputDirective, "input [pInputText]", never, { "autocomplete": "autocomplete"; "emptyStringEqualsNull": "emptyStringEqualsNull"; }, {}, never>;
}
