import { Calendar } from 'primeng/calendar';
import * as i0 from "@angular/core";
export declare class CalendarDirective {
    private calendar;
    constructor(calendar: Calendar);
    onClose(): void;
    static ɵfac: i0.ɵɵFactoryDef<CalendarDirective>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<CalendarDirective, "p-calendar", never, {}, {}, never>;
}
