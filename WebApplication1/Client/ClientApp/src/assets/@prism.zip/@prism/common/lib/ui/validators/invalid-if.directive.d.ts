import { AbstractControl, ValidationErrors, Validator } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class InvalidIfDirective implements Validator {
    private _appInvalidIf;
    private onValidatorChange;
    constructor();
    get appInvalidIf(): boolean;
    set appInvalidIf(value: boolean);
    appInvalidIfMessage: string;
    validate(control: AbstractControl): ValidationErrors | null;
    registerOnValidatorChange(fn: () => void): void;
    static ɵfac: i0.ɵɵFactoryDef<InvalidIfDirective>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<InvalidIfDirective, "[appInvalidIf]", never, { "appInvalidIf": "appInvalidIf"; "appInvalidIfMessage": "appInvalidIfMessage"; }, {}, never>;
}
