import { Location } from '@angular/common';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot } from '@angular/router';
import { AuthService } from '../services/auth/auth.service';
import { ConfigurationService } from '../services/config/configuration.service';
import * as i0 from "@angular/core";
export declare class LoginGuard implements CanActivate {
    private authService;
    private location;
    private configurationService;
    constructor(authService: AuthService, location: Location, configurationService: ConfigurationService);
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean> | boolean;
    static ɵfac: i0.ɵɵFactoryDef<LoginGuard>;
    static ɵprov: i0.ɵɵInjectableDef<LoginGuard>;
}
