import { AfterViewInit } from '@angular/core';
import { DataView } from 'primeng/dataview';
import * as i0 from "@angular/core";
export declare class PDataViewDirective implements AfterViewInit {
    private view;
    constructor(view: DataView);
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDef<PDataViewDirective>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<PDataViewDirective, "p-dataView", never, {}, {}, never>;
}
