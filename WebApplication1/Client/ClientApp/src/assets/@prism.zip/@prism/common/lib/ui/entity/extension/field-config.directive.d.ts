import { DoCheck, OnDestroy, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';
import { NgForm } from '@angular/forms';
import { EntityConfigDirective } from '../config/entity-config.directive';
import * as i0 from "@angular/core";
export declare class FieldConfigDirective implements OnInit, OnDestroy, DoCheck {
    private templateRef;
    private viewContainer;
    private ngForm;
    private entityConfigDirective;
    private visible;
    private required;
    private readOnly;
    private fieldName;
    private valuesChangeSubscription;
    private validator;
    private changed;
    private label;
    constructor(templateRef: TemplateRef<any>, viewContainer: ViewContainerRef, ngForm: NgForm, entityConfigDirective: EntityConfigDirective);
    set appFieldConfig(fieldName: string);
    ngOnInit(): void;
    ngOnDestroy(): void;
    ngDoCheck(): void;
    update(): void;
    private bindEntity;
    static ɵfac: i0.ɵɵFactoryDef<FieldConfigDirective>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<FieldConfigDirective, "[appFieldConfig]", never, { "appFieldConfig": "appFieldConfig"; }, {}, never>;
}
