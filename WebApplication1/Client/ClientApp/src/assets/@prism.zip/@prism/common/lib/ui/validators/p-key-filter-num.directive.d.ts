import { AbstractControl, ValidationErrors, Validator } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class PKeyFilterNumDirective implements Validator {
    private _filter;
    private onValidatorChange;
    private _mayBeEmpty;
    numberMatchRegExp: RegExp;
    positiveNumberMatchRegExp: RegExp;
    constructor();
    get pKeyFilter(): string | RegExp;
    set pKeyFilter(value: string | RegExp);
    get pMayBeEmpty(): boolean;
    set pMayBeEmpty(value: boolean);
    validate(control: AbstractControl): ValidationErrors | null;
    registerOnValidatorChange(fn: () => void): void;
    static ɵfac: i0.ɵɵFactoryDef<PKeyFilterNumDirective>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<PKeyFilterNumDirective, "[pKeyFilter]", never, { "pKeyFilter": "pKeyFilter"; "pMayBeEmpty": "pMayBeEmpty"; }, {}, never>;
}
