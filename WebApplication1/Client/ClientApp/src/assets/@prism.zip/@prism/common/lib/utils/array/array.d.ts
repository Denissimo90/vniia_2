export declare function replaceArrayElement(arr: any[], element: any, newElement: any): boolean;
