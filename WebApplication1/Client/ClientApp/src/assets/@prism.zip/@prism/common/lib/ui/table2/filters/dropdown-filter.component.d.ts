import { IDoesFilterPassParams, IFilterParams } from 'ag-grid-community';
import { AgFrameworkComponent, IFilterAngularComp } from 'ag-grid-angular';
import * as i0 from "@angular/core";
export interface IDropdownFilterParams extends IFilterParams {
    type?: string;
    enum: any[];
}
export declare class DropdownFilterComponent implements IFilterAngularComp, AgFrameworkComponent<IDropdownFilterParams> {
    params: IDropdownFilterParams;
    value: any;
    agInit(params: IDropdownFilterParams): void;
    isFilterActive(): boolean;
    doesFilterPass(params: IDoesFilterPassParams): boolean;
    getModel(): any;
    setModel(model: any): void;
    onFloatingFilterChanged(type: string, filter: any): void;
    valueChanged(): void;
    static ɵfac: i0.ɵɵFactoryDef<DropdownFilterComponent>;
    static ɵcmp: i0.ɵɵComponentDefWithMeta<DropdownFilterComponent, "ng-component", never, {}, {}, never>;
}
