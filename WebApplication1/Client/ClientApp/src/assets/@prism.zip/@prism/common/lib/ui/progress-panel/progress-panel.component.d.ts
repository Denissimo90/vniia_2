import * as i0 from "@angular/core";
export declare class ProgressPanelComponent {
    blocked: boolean;
    style: any;
    styleClass: string;
    static ɵfac: i0.ɵɵFactoryDef<ProgressPanelComponent>;
    static ɵcmp: i0.ɵɵComponentDefWithMeta<ProgressPanelComponent, "app-progressPanel", never, { "blocked": "blocked"; "style": "style"; "styleClass": "styleClass"; }, {}, never>;
}
