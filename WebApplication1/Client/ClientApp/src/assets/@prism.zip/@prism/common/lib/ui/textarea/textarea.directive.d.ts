import { InputTextarea } from 'primeng';
import * as i0 from "@angular/core";
export declare class TextareaDirective {
    private input;
    private oldValue;
    private oldWidth;
    emptyStringEqualsNull: boolean;
    constructor(input: InputTextarea);
    onChange(event: any): void;
    static ɵfac: i0.ɵɵFactoryDef<TextareaDirective>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<TextareaDirective, "textarea [pInputTextarea]", never, { "emptyStringEqualsNull": "emptyStringEqualsNull"; }, {}, never>;
}
