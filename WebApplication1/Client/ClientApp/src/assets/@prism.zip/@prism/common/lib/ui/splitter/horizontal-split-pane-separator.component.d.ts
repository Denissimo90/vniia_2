import { OnInit } from '@angular/core';
import { SplitSeparatorComponent } from './split-pane-separator.component';
import * as i0 from "@angular/core";
export declare class HorizontalSplitSeparatorComponent extends SplitSeparatorComponent implements OnInit {
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDef<HorizontalSplitSeparatorComponent>;
    static ɵcmp: i0.ɵɵComponentDefWithMeta<HorizontalSplitSeparatorComponent, "horizontal-split-separator", never, {}, {}, never>;
}
