import { AfterContentInit, QueryList } from '@angular/core';
import { MenuItemDirective } from './menu-item.directive';
import { Menu } from 'primeng/menu';
import * as i0 from "@angular/core";
export declare class MenuDirective implements AfterContentInit {
    private menu;
    menuItems: QueryList<MenuItemDirective>;
    constructor(menu: Menu);
    ngAfterContentInit(): void;
    static ɵfac: i0.ɵɵFactoryDef<MenuDirective>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<MenuDirective, "p-menu", never, {}, {}, ["menuItems"]>;
}
