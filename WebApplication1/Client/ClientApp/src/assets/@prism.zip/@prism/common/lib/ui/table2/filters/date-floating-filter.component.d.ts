import { AgFrameworkComponent } from 'ag-grid-angular';
import { FilterChangedEvent, IFloatingFilter, IFloatingFilterParams } from 'ag-grid-community';
import { Calendar } from 'primeng/calendar';
import { FilterMatchModes } from 'ag-grid-community/dist/lib/main';
import * as i0 from "@angular/core";
export interface IDateFloatingFilterComponentParams extends IFloatingFilterParams {
    type?: {
        key: FilterMatchModes;
        title: string;
        sign: string;
    };
}
export declare class DateFloatingFilterComponent implements IFloatingFilter, AgFrameworkComponent<IDateFloatingFilterComponentParams> {
    calendar: Calendar;
    params?: IDateFloatingFilterComponentParams;
    types: {
        key: FilterMatchModes;
        title: string;
        sign: string;
    }[];
    calendarValue: Date | Date[];
    getFilterModesTitle: (localFilterMode: {
        title: string;
        sign: string;
    }) => string;
    agInit(params: IDateFloatingFilterComponentParams): void;
    onParentModelChanged(parentModel: any, filterChangedEvent?: FilterChangedEvent): void;
    applyFilterMode(typeKey: FilterMatchModes): void;
    onKeyPress(event: KeyboardEvent): void;
    onCloseCalendar(): void;
    onClearCalendar(): void;
    onRangeFocus(): void;
    onRangeBlur(): void;
    onSelectCalendar(changeDate: Date): void;
    apply(): void;
    static ɵfac: i0.ɵɵFactoryDef<DateFloatingFilterComponent>;
    static ɵcmp: i0.ɵɵComponentDefWithMeta<DateFloatingFilterComponent, "ng-component", never, {}, {}, never>;
}
