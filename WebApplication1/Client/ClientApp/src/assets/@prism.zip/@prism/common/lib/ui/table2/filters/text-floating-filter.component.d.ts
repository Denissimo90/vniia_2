import { FilterChangedEvent, IFloatingFilter, IFloatingFilterParams } from 'ag-grid-community';
import { AgFrameworkComponent } from 'ag-grid-angular';
import { Subject } from 'rxjs';
import { ColumnTypes, FilterMatchModes } from 'ag-grid-community/dist/lib/main';
import * as i0 from "@angular/core";
export interface TextFloatingFilterParams extends IFloatingFilterParams {
    type?: {
        key: FilterMatchModes;
        title: string;
        sign: string;
    };
}
export declare class TextFloatingFilterComponent implements IFloatingFilter, AgFrameworkComponent<TextFloatingFilterParams> {
    params: TextFloatingFilterParams;
    currentValue: string;
    value: string;
    type: {
        key: FilterMatchModes;
        title: string;
        sign: string;
    };
    debounceVal: Subject<string>;
    val: Subject<string>;
    keyFilter: RegExp;
    numberValidPattern: RegExp;
    isInvalid: boolean;
    types: {
        key: FilterMatchModes;
        title: string;
        sign: string;
    }[];
    getFilterModesTitle: (localFilterMode: {
        title: string;
        sign: string;
    }) => string;
    get isNumberColumn(): boolean;
    agInit(params: TextFloatingFilterParams): void;
    valueChanged(): void;
    applyFilterMode(type: FilterMatchModes): void;
    onKeyDown(event: any): void;
    onBlur(): void;
    apply(): void;
    onParentModelChanged(parentModel: any, filterChangedEvent?: FilterChangedEvent): void;
    getPlaceholder(): string;
    setKeyFilter(): void;
    isNumberValueInvalid(value: any, inputElement: HTMLInputElement): boolean;
    getDefaultType(colType?: ColumnTypes): {
        key: FilterMatchModes;
        title: string;
        sign: string;
    };
    getTypes(colType?: ColumnTypes): {
        key: FilterMatchModes;
        title: string;
        sign: string;
    }[];
    static ɵfac: i0.ɵɵFactoryDef<TextFloatingFilterComponent>;
    static ɵcmp: i0.ɵɵComponentDefWithMeta<TextFloatingFilterComponent, "ng-component", never, {}, {}, never>;
}
