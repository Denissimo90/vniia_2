import { HttpClient } from '@angular/common/http';
import { BaseService } from '../http/base.service';
import { AuthService } from '../auth/auth.service';
import { EventBusService } from '../events/eventbus.service';
import { Dictionary } from '../../ui/dictionary/Dictionary';
import { PageResponse } from '../PageResponse';
import { PageQuery } from '../PageQuery';
import * as i0 from "@angular/core";
export declare class DictionaryService extends BaseService {
    protected httpClient: HttpClient;
    protected authService: AuthService;
    protected bus: EventBusService;
    constructor(httpClient: HttpClient, authService: AuthService, bus: EventBusService);
    searchLocalDictionary(pageQuery: PageQuery, key: string, url?: string): Promise<PageResponse<Dictionary>>;
    searchDictionary(pageQuery: PageQuery, key: string, filter: string, filterParams: {
        [key: string]: string;
    }, url?: string): Promise<PageResponse<Dictionary>>;
    getMetaInf(key: string): Promise<any>;
    getViewValue(id: number, key: string): Promise<any>;
    static ɵfac: i0.ɵɵFactoryDef<DictionaryService>;
    static ɵprov: i0.ɵɵInjectableDef<DictionaryService>;
}
