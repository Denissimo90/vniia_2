export declare class TableExtensionField {
    name: string;
    caption: string;
    type: string;
    comment: string;
    options: {
        [key: string]: string;
    };
    constructor(json?: any);
    get textFieldName(): string;
}
