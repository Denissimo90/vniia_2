import { EventEmitter } from '@angular/core';
import { IHeaderParams } from 'ag-grid-community';
import { IHeaderAngularComp } from 'ag-grid-angular';
import * as i0 from "@angular/core";
export declare class CheckboxHeaderComponent implements IHeaderAngularComp {
    params: IHeaderParams;
    isChecked: boolean;
    colId: string;
    type: any;
    checkboxClick: EventEmitter<any>;
    agInit(params: IHeaderParams): void;
    onChange(value: any): void;
    static ɵfac: i0.ɵɵFactoryDef<CheckboxHeaderComponent>;
    static ɵcmp: i0.ɵɵComponentDefWithMeta<CheckboxHeaderComponent, "ng-component", never, {}, { "checkboxClick": "checkboxClick"; }, never>;
}
