import { OnDestroy } from '@angular/core';
import { IHeaderParams } from 'ag-grid-community';
import { IHeaderAngularComp } from 'ag-grid-angular';
import { TriStateCheckbox } from 'primeng';
import * as i0 from "@angular/core";
export declare class TriStateCheckboxHeaderComponent implements IHeaderAngularComp, OnDestroy {
    private params;
    private nodesFilter;
    private updateCheckedStateListener;
    private updateTimerId;
    isChecked: boolean;
    checkbox: TriStateCheckbox;
    agInit(params: IHeaderParams): void;
    bindEvents(): void;
    unbindEvents(): void;
    ngOnDestroy(): void;
    updateCheckedStateWithDebounce(): void;
    updateCheckedState(): void;
    onChange(event: any): void;
    static ɵfac: i0.ɵɵFactoryDef<TriStateCheckboxHeaderComponent>;
    static ɵcmp: i0.ɵɵComponentDefWithMeta<TriStateCheckboxHeaderComponent, "ng-component", never, {}, {}, never>;
}
