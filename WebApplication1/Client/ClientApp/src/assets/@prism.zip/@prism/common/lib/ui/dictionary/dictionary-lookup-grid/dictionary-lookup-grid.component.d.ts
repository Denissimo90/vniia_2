import { EventEmitter, OnInit } from '@angular/core';
import { LookupBaseComponent } from '../../lookup/lookup-base.componet';
import { Column } from '../../table/column';
import { DictionaryService } from '../../../services/dictionary/dictionary.service';
import { LazyLoadEvent } from '../../table2/table2.component';
import * as i0 from "@angular/core";
export declare class DictionaryLookupGridComponent extends LookupBaseComponent implements OnInit {
    private dictionaryService;
    selectedDictionaryRow: any;
    key: string;
    global: boolean;
    textField: string;
    filter: string;
    filterParams: {
        [key: string]: string;
    };
    query: string;
    url: string;
    rowDoubleClick: EventEmitter<any>;
    cellKeyDown: EventEmitter<any>;
    _header: string;
    columns: Column[];
    constructor(dictionaryService: DictionaryService);
    get selectedValue(): any;
    get header(): string;
    ngOnInit(): Promise<void>;
    onLoad(event: LazyLoadEvent): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDef<DictionaryLookupGridComponent>;
    static ɵcmp: i0.ɵɵComponentDefWithMeta<DictionaryLookupGridComponent, "app-dictionary-lookup-grid", never, { "key": "key"; "global": "global"; "textField": "textField"; "filter": "filter"; "filterParams": "filterParams"; "query": "query"; "url": "url"; }, { "rowDoubleClick": "rowDoubleClick"; "cellKeyDown": "cellKeyDown"; }, never>;
}
