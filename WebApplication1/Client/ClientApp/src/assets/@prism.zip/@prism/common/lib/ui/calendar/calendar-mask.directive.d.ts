import { AfterViewInit } from '@angular/core';
import { Calendar } from 'primeng/calendar';
import * as i0 from "@angular/core";
export declare class CalenderMaskDirective implements AfterViewInit {
    private calendar;
    private mask;
    constructor(calendar: Calendar);
    enableMask: boolean;
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDef<CalenderMaskDirective>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<CalenderMaskDirective, "p-calendar:not([rPCalendarMask])", never, { "enableMask": "enableMask"; }, {}, never>;
}
