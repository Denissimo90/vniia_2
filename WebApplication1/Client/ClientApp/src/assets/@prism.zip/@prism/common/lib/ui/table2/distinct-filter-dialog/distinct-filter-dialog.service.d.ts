import { DialogService } from '../../dialog/dialog.service';
import { Column as AgColumn, GridApi } from 'ag-grid-community';
import { DistinctFilterService } from './distinct-filter.service';
import * as i0 from "@angular/core";
export declare class DistinctFilterDialogService extends DistinctFilterService {
    private dialogService;
    constructor(dialogService: DialogService);
    showFilterDialog(api: GridApi, agColumn: AgColumn): void;
    static ɵfac: i0.ɵɵFactoryDef<DistinctFilterDialogService>;
    static ɵprov: i0.ɵɵInjectableDef<DistinctFilterDialogService>;
}
