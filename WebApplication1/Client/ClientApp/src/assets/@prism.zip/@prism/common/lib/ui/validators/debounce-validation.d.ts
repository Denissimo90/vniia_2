import { AbstractControl, AsyncValidatorFn, ValidationErrors } from '@angular/forms';
export declare function debounceValidation(control: AbstractControl, validatorFn: AsyncValidatorFn, options?: {
    debounceTime?: number;
    resolveOnEmpty?: boolean;
}): Promise<ValidationErrors | null>;
