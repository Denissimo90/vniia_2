import { ServeFileType } from './file-viewer.component';
import { DialogService } from '../dialog/dialog.service';
import { HttpHeaders, HttpResponse } from '@angular/common/http';
import { FileLoadService } from './file-load.service';
import * as i0 from "@angular/core";
export declare class FileViewerService {
    private dialogService;
    private fileLoadService;
    constructor(dialogService: DialogService, fileLoadService: FileLoadService);
    showOrSaveFile(response: HttpResponse<Blob>, serveType: ServeFileType, filename?: string, onHide?: any): Promise<void>;
    getFleName(headers: HttpHeaders): string;
    getMediaType(response: HttpResponse<Blob>): Promise<any>;
    getPdfVersionNumber(response: HttpResponse<Blob>): Promise<number>;
    getUserAgentMap(): Map<string, string>;
    static ɵfac: i0.ɵɵFactoryDef<FileViewerService>;
    static ɵprov: i0.ɵɵInjectableDef<FileViewerService>;
}
