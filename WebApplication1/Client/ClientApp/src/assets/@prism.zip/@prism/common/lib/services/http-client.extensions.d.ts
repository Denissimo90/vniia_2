import { Observable } from 'rxjs';
import { PageQuery } from './PageQuery';
import { PageResponse } from './PageResponse';
declare module '@angular/common/http/' {
    interface HttpClient {
        /**
         * Execute request and return body
         */
        requestData<R>(req: HttpRequest<any>): Observable<R>;
        /**
         * Add export parameters to request, execute and return blob
         */
        requestExport(req: HttpRequest<any>, exportColumns: any[]): Observable<Blob>;
        postPageQuery<R>(url: string, query: PageQuery, options?: {
            headers?: HttpHeaders;
            params?: HttpParams;
            withCredentials?: boolean;
        }): Observable<PageResponse<R>>;
    }
}
