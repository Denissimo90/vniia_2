import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthService } from '../auth/auth.service';
import { EventBusService } from '../events/eventbus.service';
import * as i0 from "@angular/core";
export declare class BaseService {
    protected http: HttpClient;
    protected authService: AuthService;
    protected bus: EventBusService;
    static httpOptions: {
        headers: HttpHeaders;
    };
    get httpOptions(): Object;
    constructor(http: HttpClient, authService: AuthService, bus: EventBusService);
    protected handleError<T>(error: any, operation?: string, result?: T): T;
    static ɵfac: i0.ɵɵFactoryDef<BaseService>;
    static ɵprov: i0.ɵɵInjectableDef<BaseService>;
}
