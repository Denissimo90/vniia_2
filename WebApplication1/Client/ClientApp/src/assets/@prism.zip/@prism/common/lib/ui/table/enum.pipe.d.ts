import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class EnumPipe implements PipeTransform {
    transform(value: any, args?: any): any;
    static ɵfac: i0.ɵɵFactoryDef<EnumPipe>;
    static ɵpipe: i0.ɵɵPipeDefWithMeta<EnumPipe, "enum">;
}
