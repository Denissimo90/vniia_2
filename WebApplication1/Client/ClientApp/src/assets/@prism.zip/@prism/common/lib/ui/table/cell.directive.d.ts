import { TableComponent } from './table.component';
import { Column } from './column';
import * as i0 from "@angular/core";
export declare class Cell {
    private table;
    private local;
    constructor(table: TableComponent, local: string);
    cellContext: {
        col: Column;
        rowData: any;
        rowIndex: number;
        isSelected: boolean;
    };
    get col(): Column;
    get rowData(): any;
    get rowIndex(): number;
    get value(): any;
    get isSelected(): boolean;
    get text(): string;
    get icon(): string;
    static ɵfac: i0.ɵɵFactoryDef<Cell>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<Cell, "app-table td[cellContext]", ["cell"], { "cellContext": "cellContext"; }, {}, never>;
}
