import { ElementRef, TemplateRef } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import * as i0 from "@angular/core";
export declare class CustomDetailComponent implements ICellRendererAngularComp {
    template: TemplateRef<ElementRef>;
    params: any;
    agInit(params: any): void;
    refresh(params: any): boolean;
    static ɵfac: i0.ɵɵFactoryDef<CustomDetailComponent>;
    static ɵcmp: i0.ɵɵComponentDefWithMeta<CustomDetailComponent, "app-detail-cell-renderer", never, {}, {}, never>;
}
