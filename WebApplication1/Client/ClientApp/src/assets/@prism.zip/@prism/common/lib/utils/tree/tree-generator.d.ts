export declare const generateDataTree: (data: any[], itemInizialization: Function, ...fields: any[]) => any;
export declare const logAsJson: (value: any) => void;
export declare const testTreeGenerator: () => void;
