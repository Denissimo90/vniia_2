import { ElementRef } from '@angular/core';
export declare class PositionService {
    /**
     * Provides read-only equivalent of jQuery's position function:
     * http://api.jquery.com/position/
     */
    static position(element: ElementRef): {
        width: number;
        height: number;
        top: number;
        left: number;
    };
    /**
     * Provides read-only equivalent of jQuery's offset function:
     * http://api.jquery.com/offset/
     */
    static offset(element: ElementRef): {
        width: number;
        height: number;
        top: number;
        left: number;
    };
    /**
     * Provides coordinates for the targetEl in relation to hostEl
     */
    static positionElements(host: ElementRef, target: ElementRef, positionStr: any, appendToBody: any): {
        top: number;
        left: number;
    };
    private static getStyle;
    /**
     * Checks if a given element is statically positioned
     * @param nativeEl - raw DOM element
     */
    private static isStaticPositioned;
    /**
     * returns the closest, non-statically positioned parentOffset of a given element
     * @param nativeEl
     */
    private static parentOffsetEl;
}
