import { ErrorHandler, NgZone } from '@angular/core';
import { EventBusService } from '../events/eventbus.service';
import * as i0 from "@angular/core";
export declare class GlobalErrorHandler implements ErrorHandler {
    private bus;
    private zone;
    constructor(bus: EventBusService, zone: NgZone);
    handleError(ex: any): void;
    static ɵfac: i0.ɵɵFactoryDef<GlobalErrorHandler>;
    static ɵprov: i0.ɵɵInjectableDef<GlobalErrorHandler>;
}
