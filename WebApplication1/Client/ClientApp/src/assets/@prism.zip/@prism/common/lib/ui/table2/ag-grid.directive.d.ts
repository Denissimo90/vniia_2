import { AfterContentInit, AfterViewInit } from '@angular/core';
import { AgGridColumn, AgGridAngular } from 'ag-grid-angular';
import * as i0 from "@angular/core";
export declare class AgGridAutoGroupColumn extends AgGridColumn {
    static ɵfac: i0.ɵɵFactoryDef<AgGridAutoGroupColumn>;
    static ɵcmp: i0.ɵɵComponentDefWithMeta<AgGridAutoGroupColumn, "ag-grid-auto-group-column", never, {}, {}, never>;
}
export declare class AgGridDirective implements AfterContentInit, AfterViewInit {
    private grid;
    column: AgGridAutoGroupColumn;
    private _loading;
    constructor(grid: AgGridAngular);
    ngAfterContentInit(): void;
    ngAfterViewInit(): void;
    get loading(): boolean;
    set loading(val: boolean);
    static ɵfac: i0.ɵɵFactoryDef<AgGridDirective>;
    static ɵdir: i0.ɵɵDirectiveDefWithMeta<AgGridDirective, "ag-grid-angular", never, { "loading": "loading"; }, {}, ["column"]>;
}
