import {AfterViewInit, Directive, ElementRef, NgZone, OnDestroy} from '@angular/core';
import {NgControl} from '@angular/forms';
import {Subscription} from 'rxjs';

@Directive({
  selector: '[ngModel], [formControl]'
})
export class ValidationMessageDirective implements AfterViewInit, OnDestroy {
  private errorRowDiv: HTMLDivElement;
  private errorDiv: HTMLDivElement;
  private sub: Subscription;

  constructor(el: ElementRef, control: NgControl, ngZone: NgZone) {
    this.sub = control.statusChanges.subscribe(() => {
      const formRow = el.nativeElement.closest('.form-row');
      if (formRow) {
        if (control.pending) {
          return;
        }
        if (this.errorRowDiv) {
          this.errorRowDiv.classList.remove('form-error-row-show');
          this.errorDiv.innerHTML = '';
        }
        if (control.dirty && control.invalid) {
          let error = '';
          let ind = 0;
          for (const errCode in control.errors) {
            if (errCode == 'required') {
              //
            } else {
              error += (ind == 0 ? '' : '<br/>') + control.errors[errCode];
            }
            ind++;
          }
          if (error) {
            if (!this.errorRowDiv) {
              this.errorRowDiv = document.createElement('div');
              this.errorRowDiv.classList.add('form-row', 'form-error-row');

              const labelDiv = document.createElement('div');
              this.errorRowDiv.appendChild(labelDiv);

              this.errorDiv = document.createElement('div');
              this.errorDiv.classList.add('validation-error');
              this.errorRowDiv.appendChild(this.errorDiv);
            }

            formRow.after(this.errorRowDiv);
            window.getComputedStyle(this.errorDiv).opacity; // force reset css animations

            this.errorDiv.innerHTML = '<i class="fa fa-exclamation-triangle"></i> ' + error;
            this.errorRowDiv.classList.add('form-error-row-show');
          }
        }
      }
    });
  }

  ngAfterViewInit(): void {
  }

  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }
}
