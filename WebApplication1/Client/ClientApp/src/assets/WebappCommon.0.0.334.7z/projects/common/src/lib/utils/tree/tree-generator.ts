export const generateDataTree = (data: any[], itemInizialization: Function, ...fields: any[]) => {
  // генерация дерева
  // создадим рут левел и пробежимся по data
  const tree = data.reduce((result, type) => {
    // напихаем в рут все ветки
    ((root, treePath) => {
      // обработаем все ветки, исходя из последовательностей fields
      // ключ может быть только типом string, ENUM работают сами,
      // для сложных объектов переопределите метод toString() возвращающий уникальный индекс объекта
      fields.reduce((treeItem, fieldName) => {
        const key = (treePath[fieldName]);
        // если ветки не было, создадим новую
        treeItem.childrens[key] = treeItem.childrens[key] || getTreeItem(key, itemInizialization, treePath, fieldName);
        return treeItem.childrens[key];
      }, root);
    })(result, type);
    return result;
    // начало дерева root
  }, getTreeItem('root'));
  return tree;
};

// функция генерации элемента дерева
const getTreeItem = (key, itemInizialization?, origin?, field?) => {
  const result = {
    value: key,
    origin: origin,
    field: field,
    childrens: {},
    items: () => (Object.keys(result.childrens) as Array<any>).map( (e) => result.childrens[e] ),
    // функция вывода конкретной ветки по ее индексам, getItemsByLevels(0,1,0) покажет ветку 4 уровня см testTreeGenerator
    getItemsByLevels: (...args: any[]) => {
      let root = result;
      args.forEach((element, index, array) => {
        root = !!array ? root.items()[array[index]] : root;
      });
      return root.items();
    }
  };
  if (!!itemInizialization) { itemInizialization(result); }
  return result;
};

export const logAsJson = (value: any) => {
  //console.log(JSON.stringify(value));
};

export const testTreeGenerator = () => {
  const arr = [];
  arr.push({isOutside: true,  type: 'paper',  state: 'copy',      title: 'aaaacopy'});
  arr.push({isOutside: false, type: 'paper',  state: 'dublicate', title: 'aaaadublicate'});
  arr.push({isOutside: true,  type: 'device', state: 'copy',      title: 'bbbbcopy'});
  arr.push({isOutside: false, type: 'device', state: 'copy',      title: 'bbbbdublicate'});
  arr.push({isOutside: true,  type: 'paper',  state: 'dublicate', title: 'ccccdublicate'});
  arr.push({isOutside: true,  type: 'list',   state: 'copy',      title: 'ddddcopy'});
  arr.push({isOutside: true,  type: 'paper',  state: 'copy',      title: 'aaaacopy2'});
  arr.push({isOutside: false, type: 'paper',  state: 'dublicate', title: 'aaaadublicate2'});
  arr.push({isOutside: true,  type: 'device', state: 'copy',      title: 'bbbbcopy2'});
  arr.push({isOutside: false, type: 'device', state: 'copy',      title: 'bbbbdublicate2'});
  arr.push({isOutside: true,  type: 'paper',  state: 'dublicate', title: 'ccccdublicate2'});
  arr.push({isOutside: true,  type: 'list',   state: 'copy',      title: 'ddddcopy2'});

  const tree = generateDataTree(arr, (e) => { }, 'isOutside', 'type', 'state', 'title');
  logAsJson(tree.getItemsByLevels());
  logAsJson(tree.getItemsByLevels(0));
  logAsJson(tree.getItemsByLevels(0, 0));
  logAsJson(tree.getItemsByLevels(0, 0, 0));
};
