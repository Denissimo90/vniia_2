import {Component, Input, OnInit} from '@angular/core';
import {ControlContainer, NgForm} from '@angular/forms';
import {EntityConfigService} from '../../../../services/entity-config/entity-config.service';
import {FileViewerService} from '../../../file-viewer/file-viewer.service';
import {HttpClient, HttpParams} from '@angular/common/http';
import {ServeFileType} from '../../../file-viewer/file-viewer.component';


@Component({
  selector: 'app-extension-attributes',
  templateUrl: './extension-attributes.component.html',
  styleUrls: ['./extension-attributes.component.css'],
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }]
})
export class ExtensionAttributesComponent implements OnInit {
  private _entity: {extension: any};

  get entity(): {extension: any} {
    if (this._entity.extension == null) {
      this._entity.extension = {};
    }
    return this._entity;
  }

  @Input() set entity(entity: {extension: any}) {
    this._entity = entity;
  }

  @Input() entityName: string;

  @Input() extraFields = [];

  constructor(private entityConfigService: EntityConfigService,
              private fileViewerService: FileViewerService,
              private httpClient: HttpClient,
              private ngForm: NgForm) { }

  ngOnInit() {
    if (this.entityName) {
      this.extraFields = this.entityConfigService.getEntityExtension(this.entityName);
    }
    if (this.extraFields) {
      this.extraFields.forEach(f => {
        if (f.type === 'bool') {
          this.entity.extension[f.name] = this.entity.extension[f.name] ? this.entity.extension[f.name] : false;
        }
      });
    }
  }

  onSelectFile(fieldName: string) {
    this.ngForm.controls[fieldName]?.markAsPending({emitEvent: true});
    this.entity.extension[fieldName] = null;
  }

  onUploadFile(fieldName: string, result: string) {
    this.ngForm.controls[fieldName]?.updateValueAndValidity();
    this.entity.extension[fieldName] = result;
  }

  onUploadError(fieldName: string) {
    this.ngForm.controls[fieldName]?.updateValueAndValidity();
  }

  getFileName(fieldName: string) {
    return this.entity.extension[fieldName] ? this.entity.extension[fieldName].split('/')[1] : '';
  }

  async downloadFile(fieldName: string, url: string) {
    const parts = this.entity.extension[fieldName].split('/');
    const data = await this.httpClient
      .get(`${url}/${parts[0]}/${parts[1]}`,
        {observe: 'response', responseType: 'blob', params: new HttpParams()}).toPromise();
    await this.fileViewerService.showOrSaveFile(data, ServeFileType.VIEW);
  }
}
