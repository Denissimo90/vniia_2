import {AgFrameworkComponent} from 'ag-grid-angular';
import {FilterChangedEvent, IFloatingFilter, IFloatingFilterParams} from 'ag-grid-community';
import {Component, ViewChild} from '@angular/core';
import {Calendar} from 'primeng/calendar';
import {DateFilterComponent} from './date-filter.component';
import {localeColumnFilterModes, columnTypeFilterMatchModes, getFilterModesTitle} from '../table2.component';
import {FilterMatchModes} from 'ag-grid-community/dist/lib/main';

export interface IDateFloatingFilterComponentParams extends IFloatingFilterParams {
  type?: { key: FilterMatchModes, title: string, sign: string };
}

@Component({
  template: `
    <div style="display:flex; width: 100%; height: 100%; flex-direction: row">
      <div style="flex: auto; width: 100%; overflow: hidden; display: flex; align-items: center; justify-content: left">
        <p-calendar *ngIf="this.params.type.key !== 'between'"
                    #calendar
                    class="filter-calendar"
                    appendTo="body"
                    dateFormat="dd.mm.yy"
                    yearRange="2000:2030"
                    utcDate
                    [(ngModel)]="calendarValue"
                    [showIcon]="true"
                    [monthNavigator]="true"
                    [yearNavigator]="true"
                    [showOnFocus]="false"
                    [showButtonBar]="true"
                    [ngStyle]="{width: '100%'}"
                    [style]="{width: '100%'}"
                    [inputStyle]="{border: 'none',color: '#3d60a1ff'}"
                    (onClose)="onCloseCalendar()"
                    (onSelect)="onSelectCalendar($event)"
                    (onClearClick)="onClearCalendar()"
                    (keypress)="onKeyPress($event)"
        ></p-calendar>
        <p-calendar *ngIf="this.params.type.key === 'between'"
                    #calendar
                    class="filter-calendar"
                    appendTo="body"
                    dateFormat="dd.mm.yy"
                    yearRange="2000:2030"
                    utcDate
                    selectionMode="range"
                    [(ngModel)]="calendarValue"
                    [showIcon]="true"
                    [monthNavigator]="true"
                    [yearNavigator]="true"
                    [showOnFocus]="false"
                    [showButtonBar]="true"
                    [ngStyle]="{width: '100%'}"
                    [style]="{width: '100%'}"
                    [inputStyle]="{border: 'none',color: '#3d60a1ff'}"
                    (onClose)="onCloseCalendar()"
                    (onSelect)="onSelectCalendar($event)"
                    (onClearClick)="onClearCalendar()"
                    (keypress)="onKeyPress($event)"
                    (onFocus)="onRangeFocus()"
                    (onBlur)="onRangeBlur()"
        >
        </p-calendar>
      </div>
      <button
        class="filter-button"
        (click)="filterMenu.toggle($event)"
      >
        {{ params.type.sign || this.types['between'].sign }}
      </button>
      <p-menu #filterMenu [popup]="true" appendTo="body">
        <p-menu-item *ngFor="let type of this.types"
                     [label]="getFilterModesTitle(type)"
                     (command)="applyFilterMode(type.key)"></p-menu-item>
      </p-menu>
    </div>
  `,
  styles: [`
    .filter-button {
      padding: 1px;
      font-size: 10.5px;
      width: 38px;
      white-space: normal;
      word-wrap: break-word;
      line-height: 11px;
      border: 0;
      border-left: 1px solid #c8c8c8;
      background-color: transparent;
      color: #3d60a1;
      flex: none;
    }

    .filter-button:hover {
      background-color: #83b9ff;
      cursor: pointer;
    }

    .filter-calendar ::ng-deep ::-webkit-input-placeholder {
      color: #3d60a1ff;
    }

    .filter-calendar ::ng-deep ::-moz-placeholder {
      color: #3d60a1ff;
    }

    .filter-calendar ::ng-deep :-moz-placeholder {
      color: #3d60a1ff;
    }

    .filter-calendar ::ng-deep :-ms-input-placeholder {
      color: #3d60a1ff;
    }

    .filter-calendar ::ng-deep .ui-datepicker-trigger {
      border: none !important;
      background: transparent !important;
      color: #3d60a199;
    }

    .filter-calendar ::ng-deep .ui-datepicker-trigger:hover {
      color: #3d60a1ff;
    }

    .filter-calendar ::ng-deep .ui-datepicker-trigger:active {
      color: #3d60a1ff;
    }
  `]
})
export class DateFloatingFilterComponent
  implements IFloatingFilter, AgFrameworkComponent<IDateFloatingFilterComponentParams> {

  @ViewChild('calendar')
  calendar: Calendar;

  params?: IDateFloatingFilterComponentParams;
  types: { key: FilterMatchModes, title: string, sign: string }[];
  calendarValue: Date | Date[];

  getFilterModesTitle = getFilterModesTitle;

  agInit(params: IDateFloatingFilterComponentParams): void {
    this.params = params;
    this.params.type = {key: 'between', ...localeColumnFilterModes.between};
    const colType = params.column.getColDef().type as string;
    this.types = [];
    if (colType) {
      const matchTypes: FilterMatchModes[] = columnTypeFilterMatchModes[colType];
      this.types = matchTypes.map((type: FilterMatchModes) => {
        return {key: type, title: localeColumnFilterModes[type].title, sign: localeColumnFilterModes[type].sign};
      });
    }
  }

  onParentModelChanged(parentModel: any, filterChangedEvent?: FilterChangedEvent): void {
    if (!parentModel) {
      this.calendarValue = null;
    } else {
      if (parentModel.type === 'between') {
        this.calendarValue = parentModel.filter.split(',').map(dateStr => {
          if (!!dateStr) {
            return new Date(dateStr);
          }
          return null;
        });
      } else {
        this.calendarValue = new Date(parentModel.filter);
      }
    }
  }

  applyFilterMode(typeKey: FilterMatchModes) {
    if (this.params.type.key !== typeKey && (typeKey === 'between' || this.params.type.key === 'between')) {
      if (typeKey === 'between') {
        if (this.calendarValue && !(this.calendarValue instanceof Array)) {
          this.calendarValue = [this.calendarValue, null];
        } else {
          this.calendarValue = null;
        }
      } else {
        if (this.calendarValue instanceof Array) {
          if (this.calendarValue[0]) {
            this.calendarValue = this.calendarValue[0];
          }
        } else {
          this.calendarValue = null;
        }
      }
    }
    this.params.type = this.types.find(type => type.key === typeKey);
    if (this.calendarValue) {
      this.apply();
    }
  }

  onKeyPress(event: KeyboardEvent) {
    if (event.key === 'Enter') {
      this.apply();
    }
  }

  onCloseCalendar() {
    if (this.calendarValue) {
      this.apply();
    }
  }

  onClearCalendar() {
    this.calendarValue = null;
    this.apply();
  }

  onRangeFocus() {
    this.calendar.placeholder = 'дд.мм.гггг - дд.мм.гггг';
  }

  onRangeBlur() {
    this.calendar.placeholder = '';
  }

  onSelectCalendar(changeDate: Date) {
    if (this.params.type.key === 'between') {
      if (!!this.calendarValue[0] && !!this.calendarValue[1]) {
        this.calendar.hideOverlay();
        return;
      }
      return;
    }
    this.calendar.hideOverlay();
  }

  apply() {
    this.params.parentFilterInstance(filterInstance => {
      if (filterInstance) {
        const simpleFilter = (<any>filterInstance) as DateFilterComponent;
        simpleFilter.onFloatingFilterChanged(this.params.type.key, this.calendarValue);
      }
    });
  }
}
