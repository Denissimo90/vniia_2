import {ErrorHandler, Injectable, NgZone} from '@angular/core';
import {EventBusService} from '../events/eventbus.service';
import {HTTPErrors, HttpEventbusEvent} from '../events/http.eventbus.event';
import {HttpErrorResponse} from '@angular/common/http';
import {PromiseCanceled} from '../../ui/helper/cancellation-token';

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {
  constructor(private bus: EventBusService, private zone: NgZone) {
  }

  handleError(ex: any): void {
    if (ex.rejection) {
      ex = ex.rejection;
    }
    if (ex instanceof HttpErrorResponse) {
      if (ex.error instanceof ProgressEvent
        || ex.status == HTTPErrors.TYPE_BAD_GATEWAY) {
        console.error(ex);
      } else {
        this.zone.run(() => {
          if (ex.status == HTTPErrors.TYPE_INTERNAL_SERVER_ERROR) {
            console.error(ex);
          }
          if (ex.error) {
            this.bus.emit(new HttpEventbusEvent(ex.status, (ex.error.message || ex.error.error_description), ex.error.code));
          } else {
            this.bus.emit(new HttpEventbusEvent(ex.status, ex.message));
          }
        });
      }
    } else if (ex instanceof PromiseCanceled) {
      // ignore
    } else {
      console.error(ex);
    }
  }
}
