import {AfterViewInit, Directive} from '@angular/core';
import {HorizontalSplitPaneComponent} from './horizontal-split-pane.component';

@Directive({
    selector: 'horizontal-split-pane'
  })
export class HorizontalSplitPaneFix implements AfterViewInit {
    constructor(private pane: HorizontalSplitPaneComponent) {
    }

    ngAfterViewInit(): void {
        if (this.pane.secondaryToggledOff) {
            this.pane.primaryComponent.nativeElement.style.height = "100%";
        }
    }
}
