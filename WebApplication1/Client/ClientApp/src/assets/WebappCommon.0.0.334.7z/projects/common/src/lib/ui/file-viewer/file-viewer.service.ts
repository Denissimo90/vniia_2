import {Injectable} from '@angular/core';
import {FileViewerComponent, ServeFileType} from './file-viewer.component';
import {DialogService} from '../dialog/dialog.service';
import {HttpHeaders, HttpResponse} from '@angular/common/http';
import {FileLoadService} from './file-load.service';
import * as FileSaver from 'file-saver';

@Injectable({
  providedIn: 'root'
})
export class FileViewerService {

  constructor(
    private dialogService: DialogService,
    private fileLoadService: FileLoadService
  ) {
  }

  async showOrSaveFile(response: HttpResponse<Blob>, serveType: ServeFileType, filename?: string, onHide?: any) {

    filename = filename || this.getFleName(response.headers);
    const mediaType: string = await this.getMediaType(response);

    if (mediaType) {
      // update mediaType for files, from fileserver etc...
      const body = response.body.slice(0, response.body.size, mediaType);
      const headers = response.headers.set('Content-Type', [mediaType + ';charset=UTF-8'])
        .set('Content-Disposition', 'inline; filename="' + filename + '"');
      if (!!headers['lazyInit']) {
        headers['lazyInit'].forEach(function (init) {
          return headers['init'](init);
        });
        headers['lazyInit'] = null;
      }
      if (!!headers['lazyUpdate']) {
        headers['lazyUpdate'].forEach(function (update) {
          return headers['applyUpdate'](update);
        });
        headers['lazyUpdate'] = null;
      }
      response = await response.clone({headers: headers, body: body});
    } else {
      const re = /(?:\.([^.]+))?$/;
      const extention = re.exec(filename)[1];
      // do something with extension
      switch (extention) {
        case 'exe':
          break;
      }
    }

    switch (serveType) {
      case ServeFileType.VIEW:
        switch (mediaType) {
          case 'application/pdf':
            const pdfVersion = await this.getPdfVersionNumber(response);
            const firefoxVersion = this.getUserAgentMap().get('Firefox');

            if (pdfVersion && pdfVersion > 1.5 && firefoxVersion) {
              const versionNumber = parseFloat(firefoxVersion);
              if (!isNaN(versionNumber) && versionNumber < 53.0) {
                FileSaver.saveAs(response.body, decodeURIComponent(filename));
                break;
              }
            }

          // tslint:disable-next-line:no-switch-case-fall-through
          case 'image/jpg':
          case 'image/jpeg':
          case 'image/png':
          case 'image/bmp':
          case 'image/gif':
          case 'image/tif':
          case 'image/tiff':
            const dialog = this.dialogService.createDialog(FileViewerComponent);
            dialog.init(response.body, mediaType, filename);
            dialog.visible = true;
            dialog.onHide.subscribe(() => {
              if (!!onHide) {
                onHide();
              }
            });
            break;
          default:
            FileSaver.saveAs(response.body, decodeURIComponent(filename));
            break;
        }
        break;

      case ServeFileType.SAVE:
      default:
        FileSaver.saveAs(response.body, decodeURIComponent(filename));
        break;
    }
  }

  getFleName(headers: HttpHeaders) {
    let result = 'empty';

    const contentDisposition = headers.get('Content-Disposition');
    try {
      const filename = contentDisposition.split(';')[1].trim().split('=')[1];
      result = filename.replace(/"/g, '');
    } catch (e) {
    }
    return decodeURI(result).replace(/\+/g, ' ');
  }

  async getMediaType(response: HttpResponse<Blob>) {
    let result = null;

    const contentDisposition = response.headers.get('Content-Type');
    try {
      result = contentDisposition.split(';')[0];
    } catch (e) {
    }

    if (!result || result.toLowerCase().indexOf('application/json') >= 0) {
      // try get filetype by first four bytes
      const data: any = await this.fileLoadService.readFileAsync(response.body);
      const arr = (new Uint8Array(data).subarray(0, 4));

      let header = '';
      let hex: string;
      for (let i = 0; i < arr.length; i++) {
        hex = arr[i].toString(16);
        while (hex.length < 2) {
          hex = '0' + hex;
        }
        header += hex;
      }
      console.log('file header: ' + header);

      const headersRegexMap: Map<string, string[]> = new Map<string, string[]>();
      headersRegexMap.set('application/pdf', ['^25504446$']);
      headersRegexMap.set('image/tiff', ['^(4d4d|4949).{0,2}2a.{0,2}$']);
      headersRegexMap.set('image/png', ['^89504e47$']);
      headersRegexMap.set('image/jpeg', ['^ffd8ffe0$', '^ffd8ffe1$', '^ffd8ffe2$', '^ffd8ffe3$', '^ffd8ffe8$']);
      headersRegexMap.set('image/gif', ['^47494638$']);

      for (const key of Array.from(headersRegexMap.keys())) {
        for (const pattern of headersRegexMap.get(key)) {
          if (header.match(pattern)) {
            return key;
          }
        }
      }

      return response.body.type;
    } else {
      return result;
    }
  }

  async getPdfVersionNumber(response: HttpResponse<Blob>) {
    const data: any = await this.fileLoadService.readFileAsync(response.body);
    const arr = (new Uint8Array(data).subarray(5, 9));
    const version = parseFloat(String.fromCharCode(...Array.from(arr)));
    return isNaN(version) ? null : version;
  }

  getUserAgentMap() {
    const agentVersionMap: Map<string, string> = new Map<string, string>();
    const agents = window.navigator.userAgent.match(/\w+\/[.0-9]+/g);
    agents.forEach(agent => {
      const elems = agent.split('/');
      agentVersionMap.set(elems[0], elems[1]);
    });
    return agentVersionMap;
  }


}
