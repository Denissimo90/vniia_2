import {Injectable} from '@angular/core';
import {DistinctFilterService} from './distinct-filter.service';
import {Column, GridApi} from 'ag-grid-community';

@Injectable()
export class DistinctFilterDummyService extends DistinctFilterService {
  get isEnabled() { return false; }
  showFilterDialog(api: GridApi, agColumn: Column) {}
}
