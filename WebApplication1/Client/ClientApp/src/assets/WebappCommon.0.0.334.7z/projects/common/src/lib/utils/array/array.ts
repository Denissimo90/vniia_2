export function replaceArrayElement(arr: any[], element: any, newElement: any): boolean {
  if (!arr || !element || !newElement) return false;
  const ind = arr.indexOf(element);
  if (ind >= 0) {
    arr[ind] = newElement;
    return true;
  }

  return false;
}
