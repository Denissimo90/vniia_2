import {AfterContentInit, AfterViewInit, Component, ContentChild, Directive, Input} from '@angular/core';
import {AgGridColumn, AgGridAngular} from 'ag-grid-angular';

@Component({
  selector: 'ag-grid-auto-group-column',
  template: ''
})
export class AgGridAutoGroupColumn extends AgGridColumn {
}

@Directive({
  selector: 'ag-grid-angular'
})
export class AgGridDirective implements AfterContentInit, AfterViewInit {
  @ContentChild(AgGridAutoGroupColumn) public column: AgGridAutoGroupColumn;

  private _loading = false;

  constructor(private grid: AgGridAngular) {
  }

  ngAfterContentInit() {
    // commented  because autoGroupColumnDef -> go to table.html
    // this.grid.autoGroupColumnDef = this.column;
    this.loading = this._loading;
  }

  ngAfterViewInit(): void {
    this.loading = this._loading;
  }

  get loading(): boolean {
    return this._loading;
  }

  @Input() set loading(val: boolean) {
    this._loading = val;
    if (this.grid && this.grid.api) {
      if (this._loading) {
        this.grid.api.showLoadingOverlay();
      } else {
        this.grid.api.hideOverlay();
      }
    }
  }
}
