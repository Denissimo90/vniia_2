import {Directive, forwardRef, Input} from '@angular/core';
import {AbstractControl, NG_VALIDATORS, ValidationErrors, Validator} from '@angular/forms';

@Directive({
  selector: '[appInvalidIf]',
  providers: [
    { provide: NG_VALIDATORS, useExisting: forwardRef(() => InvalidIfDirective), multi: true }
  ]
})
export class InvalidIfDirective implements Validator { 
  private _appInvalidIf: boolean;
  private onValidatorChange: () => void;

  constructor() { }

  @Input()
  get appInvalidIf(): boolean {
    return this._appInvalidIf;
  }
  set appInvalidIf(value: boolean) {
    this._appInvalidIf = value;
    setTimeout(() => {
      if (this.onValidatorChange) {
        this.onValidatorChange();
      }
    });
  }

  @Input() appInvalidIfMessage: string;

  validate(control: AbstractControl): ValidationErrors | null {
    return this._appInvalidIf ? { 'appInvalidIf': this.appInvalidIfMessage || 'Неверное значение' } : null;
  }
  
  registerOnValidatorChange(fn: () => void): void {
    this.onValidatorChange = fn;
  }
}
