import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {DistinctFilterDialogComponent} from './distinct-filter-dialog.component';

describe('DistinctFilterDialogComponent', () => {
  let component: DistinctFilterDialogComponent;
  let fixture: ComponentFixture<DistinctFilterDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DistinctFilterDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DistinctFilterDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
