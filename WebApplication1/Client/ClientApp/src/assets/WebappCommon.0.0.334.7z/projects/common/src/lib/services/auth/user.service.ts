import {EventEmitter, Injectable} from '@angular/core';
import {AuthService} from './auth.service';
import {User} from './User';
import {UserEmployment} from './UserEmployment';
import {HttpClient} from '@angular/common/http';
import {ConfigurationService} from '../config/configuration.service';

@Injectable({providedIn: 'root'})
export class UserService {
  private static readonly STORAGE_KEY = 'User-Personal-Number';

  private _personalNumber: string;
  private _employments: UserEmployment[];
  private _personalNumberChange = new EventEmitter<string>();

  constructor(private auth: AuthService, private configService: ConfigurationService,
              private httpClient: HttpClient) {
  }

  get exist(): boolean {
    return !!this.auth.user;
  }

  get roles(): any {
    return this.user.roles;
  }

  get username(): string {
    return this.user.username;
  }

  get name(): string {
    return this.user.name;
  }

  get employeeId(): string {
    return this.user.employeeId;
  }

  get personId(): number {
    return this.user.personId;
  }

  get depnum(): string {
    return this.user.depnum;
  }

  get description(): string {
    return this.user.description;
  }

  get shortname(): string {
    return this.user.shortname;
  }

  get user() {
    return this.auth.user
      ? this.auth.user
      : new User(null, 'nonauthorized', null, null, null, null, null, false, []);
  }

  get roleKeys(): Array<string> {
    return Object.keys(this.roles);
  }

  get employments(): UserEmployment[] {
    return this._employments;
  }

  get employment(): UserEmployment {
    return this._employments
      ? this._employments.find(p => p.personalNumber == this._personalNumber)
      : new UserEmployment();
  }

  get personalNumber(): string {
    return this._personalNumber;
  }

  get personalNumberChange(): EventEmitter<string> {
    return this._personalNumberChange;
  }

  get personalNumberEmptyAndRequired(): boolean {
    return this.exist && this._employments.length > 1 && !localStorage.getItem(this.getStorageKey());
  }

  async init(): Promise<void> {
    if (this.exist) {
      window.addEventListener('storage', e => {
        if (e.key == this.getStorageKey()) {
          this._personalNumber = e.newValue;
          if (!this._personalNumber && this._employments.length > 0) {
            this._personalNumber = this._employments[0].personalNumber;
          }
          this.personalNumberChange.emit(this._personalNumber);
        }
      });

      this._personalNumber = localStorage.getItem(this.getStorageKey());
      this._employments = !!this.configService.config.offlineMode ? [] : await this.getPersonals();

      if (this._personalNumber) {
        if (this._employments.findIndex(p => p.personalNumber == this._personalNumber) < 0) {
          this._personalNumber = null;
          localStorage.removeItem(this.getStorageKey());
        }
      }
      if (!this._personalNumber && this._employments.length > 0) {
        this._personalNumber = this._employments[0].personalNumber;
      }
    }
    return;
  }

  select(personal: UserEmployment) {
    localStorage.setItem(this.getStorageKey(), personal.personalNumber);
    this._personalNumber = personal.personalNumber;
    this.personalNumberChange.emit(this._personalNumber);
  }

  private getPersonals(): Promise<UserEmployment[]> {
    return this.httpClient.get<UserEmployment[]>('/user/employments').toPromise();
  }

  private getStorageKey() {
    return this.configService.storagePrefix + UserService.STORAGE_KEY + this.personId;
  }
}
