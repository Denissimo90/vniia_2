export enum CustomHeaders {
  CHECKBOX = 'checkboxHeaderComponent',
  TRI_STATE_CHECKBOX = 'triStateCheckboxHeaderComponent'
}
