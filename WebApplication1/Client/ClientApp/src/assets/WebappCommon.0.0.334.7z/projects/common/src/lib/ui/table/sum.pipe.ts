import {Inject, LOCALE_ID, Pipe, PipeTransform} from '@angular/core';
import {DecimalPipe} from '@angular/common';

@Pipe({
  name: 'sum'
})
export class SumPipe implements PipeTransform {
  constructor(@Inject(LOCALE_ID) private _local: string) {
  }

  transform(value: any, args?: any): any {
    return value ? new DecimalPipe(this._local).transform(value, "1.2-2") : value;
  }

}
