import {Component} from '@angular/core';
import {FilterChangedEvent, IFloatingFilter, IFloatingFilterParams, TextFilter} from 'ag-grid-community';
import {AgFrameworkComponent} from 'ag-grid-angular';
import {Subject} from 'rxjs';
import {debounceTime, repeat, takeUntil} from 'rxjs/operators';
import {columnTypeFilterMatchModes, localeColumnFilterModes, getFilterModesTitle} from '../table2.component';
import {ColumnTypes, FilterMatchModes} from 'ag-grid-community/dist/lib/main';

export interface TextFloatingFilterParams extends IFloatingFilterParams {
  type?: { key: FilterMatchModes, title: string, sign: string };
}

@Component({
  template: `
    <div style="display: flex; height: 100%">
      <input #inputElement
             style="flex: 1; height: 100%; border: 0; padding: 7px"
             type="text"
             [(ngModel)]="value"
             (ngModelChange)="valueChanged()"
             [pKeyFilter]="keyFilter"
             [placeholder]="getPlaceholder()"
             (keydown)="onKeyDown($event)"
             (blur)="onBlur()"
             [appInvalidIf]="isNumberValueInvalid(value, inputElement)"
             [disabled]="type?.key == 'isNull' || type?.key == 'isNotNull'"/>
      <button
        class="filter-button"
        (click)="filterMenu.toggle($event)"
      >
        {{ type.sign || getDefaultType().sign }}
      </button>
      <p-menu #filterMenu
              [popup]="true"
              appendTo="body"
      >
        <p-menu-item *ngFor="let type of this.types"
                     [label]="getFilterModesTitle(type)"
                     (command)="applyFilterMode(type.key)"
        ></p-menu-item>
      </p-menu>
    </div>`,
  styles: [`
    input:focus {
      outline: none;
    }

    .filter-button {
      padding: 1px;
      font-size: 10.5px;
      width: 38px;
      white-space: normal;
      word-wrap: break-word;
      line-height: 11px;
      border: 0;
      border-left: 1px solid #c8c8c8;
      background-color: transparent;
      color: #3d60a1;
    }

    .filter-button:hover {
      background-color: #83b9ff;
      cursor: pointer;
    }
  `]
})
export class TextFloatingFilterComponent
  implements IFloatingFilter, AgFrameworkComponent<TextFloatingFilterParams> {
  params: TextFloatingFilterParams;
  public currentValue: string;
  value: string;
  type: { key: FilterMatchModes, title: string, sign: string };

  debounceVal = new Subject<string>();
  val = new Subject<string>();

  keyFilter: RegExp = /.*/;
  numberValidPattern: RegExp = /^(-?\d+(?:\.\d+)?)((?:(:-?\d+(?:\.\d+)?))?|(?:(,\d+(?:\.\d+)?)+))$/;
  isInvalid = false;

  types: { key: FilterMatchModes, title: string, sign: string }[] = [];
  getFilterModesTitle = getFilterModesTitle;


  get isNumberColumn(): boolean {
    return this.params?.column.getColDef().type == 'number';
  }

  agInit(params: TextFloatingFilterParams): void {
    this.params = params;
    this.currentValue = '';
    this.value = '';

    this.types = this.getTypes();
    this.type = this.getDefaultType();
    const colType = params.column.getColDef().type as ColumnTypes;
    if (colType) {
      this.types = this.getTypes(colType);
      this.type = this.getDefaultType(colType);
    }

    this.debounceVal
      .pipe(debounceTime((<any>this.params).debounceMs ?? 500))
      .pipe(takeUntil(this.val))
      .pipe(repeat())
      .subscribe(val => {
        if (this.currentValue != val) {
          this.apply();
        }
      });
    this.val
      .subscribe(val => {
        if (this.currentValue != val) {
          this.apply();
        }
      });
    this.setKeyFilter();
  }

  valueChanged() {
    this.debounceVal.next(this.value);
  }

  applyFilterMode(type: FilterMatchModes) {
    const oldType = {...this.type};
    const newType = this.types.find(findType => findType.key === type);
    this.type = newType;
    this.setKeyFilter();
    if (newType.key == 'isNull' || newType.key == 'isNotNull') {
      this.value = '-';
      this.apply();
    } else if (oldType.key == 'isNull' ||
      oldType.key == 'isNotNull' ||
      oldType.key == 'in' ||
      oldType.key == 'between') {
      this.value = '';
      this.apply();
    } else if (this.value != '' || this.value != this.currentValue) {
      this.apply();
    }
  }

  onKeyDown(event) {
    if (event.keyCode === 13) {
      this.val.next(this.value);
    }
  }

  onBlur() {
    this.val.next(this.value);
  }

  apply() {
    if (this.isInvalid) {
      return;
    }
    this.currentValue = this.value;
    this.params.parentFilterInstance(filterInstance => {
      if (filterInstance) {
        const textFilter = filterInstance as TextFilter;
        textFilter.onFloatingFilterChanged(this.type.key || (this.isNumberColumn ? 'equals' : 'contains'), this.currentValue);
      }
    });
  }

  onParentModelChanged(parentModel: any, filterChangedEvent?: FilterChangedEvent): void {
    if (!parentModel) {
      this.value = '';
      this.currentValue = '';
    } else {
      this.value = parentModel.filter;
      this.currentValue = parentModel.filter;
      this.type = this.types.find(findType => findType.key === parentModel.type);
    }
  }

  getPlaceholder(): string {
    switch (this.type?.key) {
      case 'in':
        return this.isNumberColumn ? 'например: 1,2,3' : 'например: аб,вг,гд';
      case 'between':
        return this.isNumberColumn ? 'например: 1:5' : 'например: 1-5';
      default:
        return '';
    }
  }

  setKeyFilter() {
    if (this.isNumberColumn) {
      switch (this.type?.key) {
        case 'in':
          this.keyFilter = /^[0-9]*[-.,]?$/;
          break;
        case 'between':
          this.keyFilter = /^[0-9]*[-.:]?$/;
          break;
        default:
          this.keyFilter = /^[0-9]*[-.]?$/;
          break;
      }
    }

  }

  isNumberValueInvalid(value, inputElement: HTMLInputElement) {
    if (this.type?.key !== 'isNull' && this.type?.key !== 'isNotNull') {
      if (!this.isNumberColumn || !value || this.numberValidPattern.test(value)) {
        inputElement.style.border = '0';
        return this.isInvalid = false;
      } else {
        inputElement.style.border = '1px solid red';
        return this.isInvalid = true;
      }
    }
  }

  getDefaultType(colType?: ColumnTypes): { key: FilterMatchModes, title: string, sign: string } {
    if (colType) {
      switch (colType) {
        case 'number':
          return {key: 'equals', ...localeColumnFilterModes.equals};
        default:
          return {key: 'contains', ...localeColumnFilterModes.contains};
      }
    }
    return {key: 'contains', ...localeColumnFilterModes.contains};
  }

  getTypes(colType?: ColumnTypes): { key: FilterMatchModes, title: string, sign: string }[] {
    let matchTypes: FilterMatchModes[] = columnTypeFilterMatchModes['string'];

    if (colType && columnTypeFilterMatchModes[colType]) {
      matchTypes = columnTypeFilterMatchModes[colType];
    }

    return matchTypes.map((type: FilterMatchModes) => {
      return {key: type, title: localeColumnFilterModes[type].title, sign: localeColumnFilterModes[type].sign};
    });
  }
}
