import {
  AfterContentInit,
  Component,
  ContentChildren,
  ElementRef,
  EventEmitter,
  Inject,
  Input,
  LOCALE_ID,
  OnChanges,
  OnDestroy,
  OnInit,
  Output,
  QueryList,
  Renderer2,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import {TextFloatingFilterComponent} from './filters/text-floating-filter.component';
import {DropdownFloatingFilterComponent} from './filters/dropdown-floating-filter.component';
import {DropdownFilterComponent} from './filters/dropdown-filter.component';
import {Column} from '../table/column';
import {AgGridAngular} from 'ag-grid-angular';
import {
  CellClassParams,
  CellClickedEvent,
  CellValueChangedEvent,
  ColDef,
  Column as AgGridColumn,
  ColumnApi,
  GetContextMenuItemsParams,
  GetMainMenuItemsParams,
  GridApi,
  ICellRendererParams, IFilterParams,
  IServerSideDatasource,
  IServerSideGetRowsParams,
  ITooltipParams,
  MenuItemDef,
  NavigateToNextCellParams,
  ProcessRowParams,
  RowNode,
  TextFilter,
  ValueFormatterParams,
  ValueFormatterService
} from 'ag-grid-community';
import {DatePipe} from '@angular/common';
import {SumPipe} from '../table/sum.pipe';
import * as Color from 'color';
import * as FontSize from 'calculate-size';
import {ConfigurationService} from '../../services/config/configuration.service';
import {FilterMetadata, PageQuery, SortMeta} from '../../services/PageQuery';
import {MenuItem} from 'primeng/api';
import {DistinctFilterService} from './distinct-filter-dialog/distinct-filter.service';
import {LoadingCellRenderer} from './loading-cell-renderer';
import {GroupCellRendererParams} from 'ag-grid-community/dist/lib/rendering/cellRenderers/groupCellRenderer';
import {CheckboxHeaderComponent} from './custom-headers/checkbox-header.component';
import {TriStateCheckboxHeaderComponent} from './custom-headers/tri-state-checkbox-header.component';
import {CustomDetailComponent} from './row-details/custom-detail.component';
import {DateFloatingFilterComponent} from './filters/date-floating-filter.component';
import {DateFilterComponent} from './filters/date-filter.component';
import {ColumnTypes, FilterMatchModes} from 'ag-grid-community/dist/lib/main';
import {Subscription} from 'rxjs';

declare module 'ag-grid-community/dist/lib/main' {
  interface IServerSideGetRowsParams {
    context?: any;
  }

  interface ColDef {
    col?: Column;
  }

  interface CellClassParams {
    style?: any;
  }

  type ColumnTypes = 'bool' | 'date' | 'dateTime' | 'dateYear' | 'sum' | 'enum' | 'group' | 'custom' | 'string' | 'number';

  type FilterMatchModes =
    'equals'
    | 'contains'
    | 'startsWith'
    | 'isNull'
    | 'isNotNull'
    | 'in'
    | 'gt'
    | 'goe'
    | 'lt'
    | 'loe'
    | 'between';

}

const columnTypeFilterMatchModes: { [key in ColumnTypes]: FilterMatchModes[] } = {
  bool: ['equals', 'isNotNull', 'isNull'],
  date: ['equals', 'gt', 'goe', 'lt', 'loe', 'between'],
  dateTime: ['equals', 'gt', 'goe', 'lt', 'loe', 'between'],
  dateYear: ['equals', 'gt', 'goe', 'lt', 'loe', 'between'],
  sum: ['equals', 'gt', 'goe', 'lt', 'loe', 'between'],
  enum: ['equals', 'isNotNull', 'isNull'],
  group: ['equals', 'contains', 'startsWith', 'in', 'isNotNull', 'isNull'],
  custom: ['equals', 'contains', 'startsWith', 'in', 'isNotNull', 'isNull'],
  string: ['equals', 'contains', 'startsWith', 'in', 'isNotNull', 'isNull'],
  number: ['equals', 'gt', 'goe', 'lt', 'loe', 'in', 'between', 'isNotNull', 'isNull']
};

export {columnTypeFilterMatchModes};

const localeColumnFilterModes: { [key in FilterMatchModes]: { title: string, sign: string } } = {
  equals: {title: 'равно', sign: '='},
  contains: {title: 'содержит', sign: '..абв..'},
  startsWith: {title: 'начинается с', sign: 'абв..'},
  isNull: {title: 'не задано', sign: 'не задано'},
  isNotNull: {title: 'задано', sign: 'задано'},
  in: {title: 'одно из', sign: 'a,2,в'},
  gt: {title: 'больше', sign: '>'},
  goe: {title: 'больше или равно', sign: '>='},
  lt: {title: 'меньше', sign: '<'},
  loe: {title: 'меньше или равно', sign: '<='},
  between: {title: 'между', sign: '[n..m]'},
};
const getFilterModesTitle = (localFilterMode: { title: string, sign: string }): string => {
  return `${localFilterMode.sign} (${localFilterMode.title})`;
};
export {localeColumnFilterModes, getFilterModesTitle};

export class LazyLoadEvent {
  readonly first?: number;
  readonly rows?: number;
  readonly multiSortMeta?: SortMeta[];
  readonly filters?: {
    [s: string]: FilterMetadata;
  };
  readonly exportColumns?: any[];
  readonly distinctColumn?: string;
  readonly successCallback: (rowsThisBlock: any[], lastRow?: number) => void;
  // Callback to call when the request fails.
  readonly failCallback: () => void;
  readonly parentNode?: RowNode;
  readonly findRowQuery?: string;

  constructor(options: {
    first?: number;
    rows?: number;
    multiSortMeta?: SortMeta[];
    filters?: {
      [s: string]: FilterMetadata;
    };
    exportColumns?: any[];
    distinctColumn?: string;
    successCallback: (rowsThisBlock: any[], lastRow?: number) => void;
    failCallback: () => void;
    parentNode?: RowNode,
    findRowQuery?: string;
  }) {
    this.first = options.first;
    this.rows = options.rows;
    this.multiSortMeta = options.multiSortMeta;
    this.filters = options.filters;
    this.exportColumns = options.exportColumns;
    this.distinctColumn = options.distinctColumn;
    this.successCallback = options.successCallback;
    this.failCallback = options.failCallback;
    this.parentNode = options.parentNode;
    this.findRowQuery = options.findRowQuery;
  }

  get pageQuery(): PageQuery {
    return new PageQuery({
      first: this.first,
      rows: this.rows,
      sorts: this.multiSortMeta,
      filters: this.filters,
      exportColumns: this.exportColumns,
      distinctColumn: this.distinctColumn,
      findRowQuery: this.findRowQuery
    });
  }
}

export class DataSource implements IServerSideDatasource {
  constructor(private table: Table2Component) {
  }

  getRows(params: IServerSideGetRowsParams): void {
    const filters = {};
    for (const key in params.request.filterModel) {
      if (params.request.filterModel.hasOwnProperty(key)) {
        filters[key] = {value: params.request.filterModel[key].filter, matchMode: params.request.filterModel[key].type};
      }
    }
    const event = new LazyLoadEvent({
      first: params.request.startRow,
      rows: params.request.endRow - params.request.startRow,
      multiSortMeta: params.request.sortModel.map(f => ({
        field: f.colId,
        order: f.sort === 'desc' ? -1 : f.sort === 'asc' ? 1 : 0
      })),
      filters: filters,
      parentNode: params.parentNode,
      successCallback: (data: any[], lastRow?: number) => {
        if (!!lastRow && data?.length === 0) {
          lastRow = 0;
        }
        params.successCallback(data, lastRow);
        this.table.restoreFocusIfNeeded();
        if (this.table.keepSelectionAfterFilter) {
          this.table.updateSelection();
        }
        this.table.isLazyLoading = false;
      },
      failCallback: () => {
        if (params.hasOwnProperty('failCallback')) {
          params.failCallback();
        }
        this.table.isLazyLoading = false;
      },
      exportColumns: params.context ? params.context.exportColumns : null,
      distinctColumn: params.context ? params.context.distinctColumn : null,
      findRowQuery: params.context ? params.context.findRowQuery : null
    });
    this.table.onLazyLoad.emit(event);
    this.table.isLazyLoading = true;
  }
}

@Component({
  selector: 'app-table2',
  templateUrl: './table2.component.html',
  styleUrls: ['./table2.component.css']
})
export class Table2Component implements OnInit, OnDestroy, AfterContentInit, OnChanges {
  gridApi: GridApi;
  columnApi: ColumnApi;

  private loadingSettings = false;
  private initialSate: any;
  private keepSelection;
  private saveFocus = false;
  private calculateFontSize = FontSize.default;
  private tooltipsIntervalIdsHash: Map<any, any> = new Map<any, any>();
  private prevFocusRowIndex = -1;
  private resizeHeaderTimerId;
  private subscriptions: Subscription[] = [];
  isSummaryRowPicked = false;
  summaryRow: any;
  summaryColAggregateMap = new Map<string, string>();
  allSummaryResultsMap = new Map<string, Map<string, number>>();
  colIdsWithCalculatedSummary = [];

  @Input() disableSummaryRow = false;
  @Input() value: any[];
  @Input() loading = false;
  @Input() totalRecords;
  @Input() lazy = false;
  @Input() deltaRowDataMode = false;
  @Input() selectionMode = 'single';
  @Input() suppressCellSelection = false;
  @Input() suppressRowTransform = false;
  @Input() checkboxSelection = false;
  @Input() defaultSortEnabled = true;
  @Input() defaultSortModel: SortMeta[];
  @Input() defaultFilterEnabled = true;
  @Input() getRowId;
  @Input() filter;
  @Input() settingsKey;
  @Input() rowHeight = 32;
  @Input() headerHeight = 36;
  @Input() selection: any;
  @Input() enableTooltips = true;
  @Input() contextMenuExtension: MenuItem[] = [];
  @Input() keepSelectionAfterFilter = false;
  @Input() frameworkComponents;
  @Input() getDataPath: (data: any) => string[];
  @Input() isServerSideGroup: (data: any) => boolean;
  @Input() getServerSideGroupKey: (data: any) => any;
  @Input() groupDefaultExpanded;
  @Input() cacheBlockSize = 100;
  @Input() maxBlocksInCache = 20;
  @Input() suppressRowClickSelection: boolean = null;
  @Input() embedFullWidthRows = true;
  @Input() masterDetail = false;
  @Input() isRowMaster: (data: any) => boolean;
  @Input() detailCellRenderer: string;
  @Input() detailCellRendererParams;
  @Input() detailRowHeight: number;
  @Input() wrapHeaderText = false;
  @Input() headerVerticalPadding = 15;
  @Input() pivotMode = false;
  @Input() suppressAggFuncInHeader = false;

  @Input() get showGroupsCount() {
    return !this.autoGroupColumnDef.cellRendererParams.suppressCount;
  }

  set showGroupsCount(value) {
    this.autoGroupColumnDef.cellRendererParams.suppressCount = !value;
  }

  @Input() stopEditingWhenGridLosesFocus = true;
  @Input() processSecondaryColDef: ((colDef: ColDef) => any);
  @Input() processSecondaryColGroupDef: ((colDef: ColDef) => any);
  @Input() pivotColumnGroupTotals: String;
  @Output() selectionChange = new EventEmitter<any>();
  @Output() rowDoubleClicked = new EventEmitter();
  @Output() cellClicked = new EventEmitter<any>();
  @Output() cellDoubleClicked = new EventEmitter<any>();
  @Output() onLazyLoad = new EventEmitter<LazyLoadEvent>();
  @Output() onGetIndicatorStyle = new EventEmitter<any>();
  @Output() onGetRowStyle = new EventEmitter<any>();
  @Output() cellKeyDown = new EventEmitter<any>();
  @Output() onDataSourceReady = new EventEmitter<any>();
  @Output() modelUpdated = new EventEmitter<any>();
  @Output() rowSelected = new EventEmitter<any>();
  @Output() filterChanged = new EventEmitter<any>();
  @Output() cellEditingStarted = new EventEmitter<any>();

  columns: Column[];
  filterString = '';
  focused = false;
  exporting = false;
  isLazyLoading = false;

  @ViewChild(AgGridAngular) grid: AgGridAngular;
  @ContentChildren(Column) cols: QueryList<Column>;

  components = {
    agLoadingCellRenderer: LoadingCellRenderer
  };

  tableFrameworkComponents = {
    textFloatingFilter: TextFloatingFilterComponent,
    dropdownFilter: DropdownFilterComponent,
    dropdownFloatingFilter: DropdownFloatingFilterComponent,
    checkboxHeaderComponent: CheckboxHeaderComponent,
    triStateCheckboxHeaderComponent: TriStateCheckboxHeaderComponent,
    customDetailComponent: CustomDetailComponent,
    dateFilter: DateFilterComponent,
    dateFloatingFilter: DateFloatingFilterComponent
  };

  columnTypes: { [key in ColumnTypes]: any } = {
    'bool': {},
    'date': {},
    'dateTime': {},
    'dateYear': {},
    'sum': {},
    'enum': {},
    'group': {},
    'custom': {},
    'string': {},
    'number': {}
  };

  localeText = {
    filterOoo: 'Фильтр...',

    // enterprise menu
    pinColumn: 'Закрепить колонку',
    autosizeThiscolumn: 'Автоподбор ширины',
    autosizeAllColumns: 'Автоподбор ширины (все колонки)',
    resetColumns: 'Сбросить настройки',
    expandAll: 'Развернуть все',
    collapseAll: 'Свернуть все',

    // enterprise menu pinning
    pinLeft: 'Закрепить слева',
    pinRight: 'Закрепить справа',
    noPin: 'Открепить',

    valueAggregation: 'Агрегирующие функции',
    group: 'Группа',

    // standard menu
    copy: 'Копировать',
    copyWithHeaders: 'Копировать с заголовками',
    paste: 'Вставить',

    // other
    loadingOoo: 'Загрузка...'
  };

  autoGroupColumnDef = {
    cellRendererParams: {
      suppressCount: false
    }
  };

  processRowPostCreate = (params: ProcessRowParams) => {
    // отключение выделения свернутых нод с шифтом
    const node = params.node;
    const selectThisNode = node.selectThisNode.bind(node);
    node.selectThisNode = (value: boolean) => {
      const oldSelectable = node.selectable;
      if (value) {
        let parent = node.parent;
        while (parent != null && parent.level >= 0) {
          if (!parent.expanded) {
            node.selectable = false;
            break;
          }
          parent = parent.parent;
        }
      }
      const res = selectThisNode(value);
      node.selectable = oldSelectable;
      return res;
    };
  };

  boolRenderer = (e: ICellRendererParams) => {
    if (e.value == null) {
      return '';
    }
    if (e.value) {
      return '<i class="far fa-check-square"></i>';
    }
    return '<i class="far fa-square"></i>';
  };

  dateFormatter = (e: ValueFormatterParams) => {
    if (e.value == null) {
      return '';
    }
    return new DatePipe(this.local).transform(e.value, 'dd.MM.yyyy');
  };

  dateTimeFormatter = (e: ValueFormatterParams) => {
    if (e.value == null) {
      return '';
    }
    return new DatePipe(this.local).transform(e.value, 'dd.MM.yyyy HH:mm:ss');
  };

  dateYearFormatter = (e: ValueFormatterParams) => {
    if (e.value == null) {
      return '';
    }
    return new DatePipe(this.local).transform(e.value, 'yyyy');
  };

  sumFormatter = (e: ValueFormatterParams) => {
    if (e.value == null) {
      return '';
    }
    return new SumPipe(this.local).transform(e.value);
  };

  loadingCellRenderer = (e: ICellRendererParams) => {
    return e.data ? '' : '<span class="fa fa-spinner fa-spin"></span>';
  };

  fullWidthCellRenderer = (e: GroupCellRendererParams) => {
    if (!e.pinned && e.data.__deleted) {
      return '<div style="margin: 5px">' + e.data.__deleted + '</div>';
    }
    return '';
  };

  indicatorStyle = (params: CellClassParams) => {
    this.onGetIndicatorStyle.emit(params);
    return Object.assign({backgroundColor: '#fbfbfb', overflow: 'visible'}, params.style);
  };

  rowStyle = (params: any) => {
    this.onGetRowStyle.emit(params);
    const style = Object.assign({}, params.style);
    if (params.node.rowIndex % 2 === 0) {
      const bg = style.backgroundColor || style['background-color'];
      if (bg) {
        delete (style['background-color']);
        style.backgroundColor = new Color(bg).clearer(0.2).rgbaString();
      }
    }
    return style;
  };

  cellStyle = (params: CellClassParams) => {
    params.colDef.col.onGetColumnStyle.emit(params);
    let style = {};
    if (params.colDef.type == 'bool') {
      style = Object.assign(style, {'text-align': 'center'});
    } else if (params.colDef.type == 'custom') {
      style = Object.assign(style, params.colDef.col.customCellRendererStyle(params));
    } else if (params.colDef.type == 'sum' || params.colDef.type == 'number') {
      style = Object.assign(style, {'text-align': 'right'});
    }
    if (!!params.colDef.rowSpan) {
      if (params.colDef.rowSpan({
        node: params.node,
        data: params.data,
        colDef: params.colDef,
        column: params['column'],
        api: this.gridApi,
        columnApi: this.columnApi,
        context: params.context
      }) > 1) {
        style = Object.assign(style, {
            'background-color': '#FFF',
            'color': '#000',
            'display': 'flex',
            'flex-direction': 'column',
            'justify-content': 'center',
            'border-right': '1px solid #c8c8c8 !important',
            'border-bottom': '1px solid #c8c8c8 !important'
          }
        );
      }
    }
    style = Object.assign(style, params.style);
    return style;
  };

  isFullWidthCell = (node: RowNode) => {
    return node.data && node.data.__deleted;
  };

  getCellTooltip = (params: ITooltipParams) => {
    if (this.enableTooltips) {
      return params.valueFormatted == null ? params.value : params.valueFormatted;
    }
  };

  get availableColumns(): Column[] {
    return this.settingsKey ? this.columns.filter(c => c.available) : this.columns;
  }

  constructor(
    @Inject(LOCALE_ID) private local: string,
    private configService: ConfigurationService,
    private renderer2: Renderer2,
    public distinctFilterService: DistinctFilterService,
    public el: ElementRef) {
  }

  ngOnInit() {
    if (this.el.nativeElement.addEventListener) {
      this.el.nativeElement.addEventListener('focus', e => {
        this.focused = e.target.className.indexOf('ag-cell') >= 0;
      }, true);
      this.el.nativeElement.addEventListener('blur', e => {
        this.focused = false;
      }, true);
    }
    if (this.frameworkComponents) {
      this.tableFrameworkComponents = {...this.tableFrameworkComponents, ...this.frameworkComponents};
    }
  }

  ngOnDestroy() {
    this.gridApi = null;
    for (const sub of this.subscriptions) {
      sub.unsubscribe();
    }
  }

  ngAfterContentInit() {
    this.columns = this.cols.toArray();
    for (const col of this.columns) {
      let sub = col.layoutChange.subscribe(() => {
        if (this.gridApi && !this.settingsKey) {
          this.columnApi.getAllColumns()
            .filter(c => c.getColDef().col === col)
            .forEach(c => {
              c.getColDef().lockVisible = !col.available;
              this.columnApi.setColumnVisible(c, col.visible && col.available);
            });
        }
      });
      this.subscriptions.push(sub);

      sub = col.headerChange.subscribe(() => {
        if (this.gridApi) {
          this.columnApi.getAllColumns()
            .filter(c => c.getColDef().col === col)
            .forEach(c => {
              c.getColDef().headerName = col.header;
            });
          this.gridApi.refreshHeader();
        }
      });
      this.subscriptions.push(sub);
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['selection']) {
      setTimeout(() => this.updateSelection());
    } else if (changes['filter']) {
      setTimeout(() => this.gridApi && this.gridApi.refreshHeader());
    } else if (changes['settingsKey']) {
      setTimeout(() => this.reloadColumns());
    }
  }

  onRowSelected(event) {
    this.rowSelected.emit(event);
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.columnApi = params.columnApi;
    this.initialSate = this.columnApi.getColumnState();
    this.loadSettings();
    this.updateSelection();
    this.setDefaultSortModel();
    if (this.lazy) {
      this.gridApi.setServerSideDatasource(new DataSource(this));
    }
    this.gridApi.setPopupParent(document.body);

    this.updateAllTooltips();
    if (this.wrapHeaderText) {
      this.makeHeaderTextMultiline();
      this.resizeHeader(this.headerVerticalPadding);
    }
    this.onDataSourceReady.emit(this.gridApi);
    (!this.lazy && !this.disableSummaryRow) ? this.generateContextMenuForSummary() : null;
  }

  reload(restoreFocus = false) {
    if (this.gridApi) {
      this.gridApi.purgeServerSideCache([]);
      this.saveFocus = restoreFocus;
      if (!restoreFocus) {
        this.gridApi.deselectAll();
      }
    }
  }

  reloadGroup(route?: string[]) {
    this.gridApi.purgeServerSideCache(route);
  }

  reloadColumns() {
    if (this.gridApi && this.grid && this.grid.columns) {
      const filterModel = this.gridApi.getFilterModel();
      const sortModel = this.gridApi.getSortModel();
      this.gridApi.setColumnDefs([]);
      this.gridApi.setColumnDefs(this.grid.columns.map(c => c.toColDef()));
      this.initialSate = this.columnApi.getColumnState();
      this.loadSettings();
      this.gridApi.setFilterModel(filterModel);
      this.gridApi.setSortModel(sortModel);

      this.updateAllTooltips();
    }
  }

  exportToExcel(exportedColumns?: string[], customFilter?: any, customSort?: any) {
    if (this.lazy) {
      if (!this.exporting) {
        this.exporting = true;
        const cols = this.columnApi.getAllGridColumns()
          .filter(c => c.getColDef().field && (exportedColumns ? exportedColumns.includes(c.getColDef().field) : c.isVisible()))
          .map(c => ({
            header: c.getColDef().headerName,
            field: c.getColDef().field,
            type: c.getColDef().type,
            enum: c.getColDef().refData,
            width: c.getActualWidth()
          }));
        const ds = <DataSource>(<any>this.gridApi.getModel()).datasource;
        const params: IServerSideGetRowsParams = {
          request: {
            startRow: 0,
            endRow: 10000,
            sortModel: (customSort ? customSort : this.gridApi.getSortModel()),
            filterModel: (customFilter ? customFilter : this.gridApi.getFilterModel()),
            rowGroupCols: [],
            valueCols: [],
            pivotCols: [],
            pivotMode: false,
            groupKeys: []
          },
          successCallback: () => {
            console.log('exported');
            this.exporting = false;
          },
          failCallback: () => {
            console.log('export fail');
            this.exporting = false;
          },
          parentNode: null,
          context: {exportColumns: cols}
        };
        ds.getRows(params);
      }
    } else {
      this.gridApi.exportDataAsExcel({
        fileName: 'export.xlsx',
        exportMode: 'xlsx',
        processCellCallback: e => {
          if (e.column.getColDef().type == 'bool') {
            return e.value == null ? '' : e.value ? '1' : '0';
          } else if (e.column.getColDef().type == 'enum') {
            return e.value
              ? (e.column.getColDef().refData && e.column.getColDef().refData[e.value]
                ? e.column.getColDef().refData[e.value]
                : ('[' + e.value + ']'))
              : '';
          } else if (e.column.getColDef().valueFormatter) {
            const valueFormatterService = <ValueFormatterService>(<any>e.api).rowRenderer.beans.valueFormatterService;
            return valueFormatterService.formatValue(e.column, e.node, null, e.value);
          }
          return e.value;
        }
      });
    }
  }

  addRow(rowData: any) {
    this.addRowInternal(rowData);
  }


  private addRowInternal(rowData: any, attempt = 0) {
    const rowCount = (<any>this.gridApi).serverSideRowModel.rootNode
      .childrenCache.getVirtualRowCount();
    if (rowCount > 0) {
      this.gridApi.ensureIndexVisible(rowCount - 1);
    }
    let lastPageLoaded = false;
    if (rowCount == 0 || this.gridApi.getDisplayedRowAtIndex(rowCount - 1)?.data) {
      lastPageLoaded = true;
    }
    if (!lastPageLoaded) {
      if (attempt < 50) {
        setTimeout(() => {
          this.addRowInternal(rowData, attempt + 1);
        }, 100);
      }
      return;
    }
    (<any>this.gridApi).serverSideRowModel.rootNode.childrenCache
      .setVirtualRowCount(rowCount + 1);
    this.gridApi.getDisplayedRowAtIndex(rowCount)
      .setDataAndId(rowData, (rowCount).toString());

    const node = this.gridApi.getDisplayedRowAtIndex(rowCount);
    node.setSelected(true, true);
    this.gridApi.ensureIndexVisible(rowCount);
  }

  updateRow(oldData: any, newData: any) {
    this.gridApi.forEachNode(node => {
      if (node.data == oldData) {
        node.setData(newData);
        this.gridApi.ensureNodeVisible(node);
      }
    });
  }

  updateRows(rows: any[]) {
    const nodes = [];
    for (const row of rows) {
      const id = this.getRowId(row);
      const node = this.gridApi.getRowNode(id);
      if (node) {
        node.setData(row);
        nodes.push(node);
      }
    }
    if (nodes.length > 0) {
      this.gridApi.ensureIndexVisible(nodes[0].rowIndex);
      this.gridApi.refreshCells({rowNodes: nodes, force: true});
    }
  }

  removeRows(rows: any[], message: string) {
    const nodes = [];
    for (const row of rows) {
      this.gridApi.forEachNode(node => {
        if (node.data == row) {
          node.data.__deleted = message;
          node.setRowSelectable(false);
          nodes.push(node);
        }
      });
    }
    this.gridApi.redrawRows({
      rowNodes: nodes
    });
    // this.gridApi.purgeServerSideCache([]);
  }

  removeRowsById(ids: any, message: string) {
    const nodes = [];
    for (const id of ids) {
      const node = this.gridApi.getRowNode(id);
      if (node) {
        node.data.__deleted = message;
        node.setRowSelectable(false);
        nodes.push(node);
      }
    }
    this.gridApi.redrawRows({
      rowNodes: nodes
    });
    // this.gridApi.purgeServerSideCache([]);
  }

  scrollToTop() {
    this.gridApi.ensureIndexVisible(0, 'top');
  }

  setFilterModel(model) {
    this.gridApi.setFilterModel(model);
  }

  addNewRowFilter(field: string, value: string, rowData: any = null) {
    let model = this.gridApi.getFilterModel();
    let filter = value;
    if (model && model[field] && model[field].type == 'in') {
      filter = model[field].filter + ',' + filter;
    }
    model = {};
    model[field] = {filter: filter, type: 'in'};
    this.keepSelection = true;
    this.gridApi.setFilterModel(model);

    if (rowData) {
      this.gridApi.updateRowData({
        add: [rowData],
        addIndex: 0
      });
      this.gridApi.forEachNode(node => {
        if (node.rowIndex == 0) {
          node.setSelected(true, true);
        }
      });
    }
  }

  async findAndSelectRow(field: string, value: any): Promise<boolean> {
    return new Promise(async (resolve, reject) => {
      const ds = <any>(<any>this.gridApi.getModel()).datasource;
      const params = {
        request: {
          startRow: 0,
          endRow: 1,
          sortModel: this.gridApi.getSortModel(),
          filterModel: this.gridApi.getFilterModel(),
          rowGroupCols: [],
          valueCols: [],
          pivotCols: [],
          pivotMode: false,
          groupKeys: []
        },
        successCallback: (res, rowIndex) => {
          if (rowIndex >= 0) {
            let rowCount = (<any>this.gridApi).serverSideRowModel.rootNode.childrenCache
              .getVirtualRowCount();
            if (rowIndex + 1 > rowCount) {
              rowCount = rowIndex + 1;
            }

            const initialRowCount = (<any>this.gridApi).serverSideRowModel.rootNode.childrenCache
              .cacheParams.initialRowCount;

            (<any>this.gridApi).serverSideRowModel.rootNode.childrenCache
              .cacheParams.initialRowCount = rowCount;

            this.gridApi.purgeServerSideCache();

            (<any>this.gridApi).serverSideRowModel.rootNode.childrenCache
              .cacheParams.initialRowCount = initialRowCount;

            this.gridApi.ensureIndexVisible(rowIndex, 'middle');
            const sub = this.modelUpdated.subscribe(e => {
              this.gridApi.ensureIndexVisible(rowIndex, 'middle');
              const node = this.gridApi.getDisplayedRowAtIndex(rowIndex);
              if (node) {
                if (node.data) {
                  if (node.data[field] === value) {
                    sub.unsubscribe();
                    node.setSelected(true, true);
                    resolve(true);
                  } else {
                    let checkedRows = 0;
                    for (let i = -50; i <= 50; i++) {
                      const node2 = this.gridApi.getDisplayedRowAtIndex(rowIndex + i);
                      if (!node2 || node2.data) {
                        checkedRows++;
                      }
                      if (node2 && node2.data && node2.data[field] === value) {
                        sub.unsubscribe();
                        node2.setSelected(true, true);
                        this.gridApi.ensureIndexVisible(rowIndex + i, 'middle');
                        resolve(true);
                        break;
                      }
                    }
                    if (checkedRows === 21) {
                      sub.unsubscribe();
                      resolve(false);
                    }
                  }
                }
              } else {
                sub.unsubscribe();
                resolve(false);
              }
            });
          } else {
            this.gridApi.purgeServerSideCache();
            resolve(false);
          }
        },
        failCallback: () => {
          reject();
        },
        parentNode: null,
        context: {findRowQuery: field + ' = ' + value}
      };
      ds.getRows(params);
    });
  }

  onSelectionChanged(e) {
    const selectedRows = this.gridApi.getSelectedRows()
      .filter(r => !r.__deleted);
    let changed = false;
    if (this.selectionMode === 'single') {
      const selection = selectedRows.length > 0 ? selectedRows[0] : null;
      if (this.selection != selection) {
        changed = true;
        this.selection = selection;
      }
    } else {
      const selection = this.selection == null ? [] : this.selection;
      if (selection.length != selectedRows.length) {
        changed = true;
      } else {
        for (let i = 0; i < selection.length; i++) {
          if (selection[i] != selectedRows[i]) {
            changed = true;
            break;
          }
        }
      }
      if (changed) {
        this.selection = selectedRows;
      }
    }
    if (changed) {
      this.selectionChange.emit(this.selection);
    }
  }

  onCellClicked(event: CellClickedEvent) {
    if (this.lazy
      && this.getServerSideGroupKey
      && event.node
      && (event.node.level == 0
        || (this.selectionMode == 'multiple' && (<MouseEvent>event.event).shiftKey))) {
      if (this.selectionMode == 'single') {
        event.node.setSelected(true, true);
      } else if (this.selectionMode == 'multiple') {
        if ((<MouseEvent>event.event).shiftKey && this.prevFocusRowIndex >= 0) {
          let startIndex = this.prevFocusRowIndex;
          let endIndex = event.node.rowIndex;
          if (startIndex > endIndex) {
            endIndex = startIndex;
            startIndex = event.node.rowIndex;
          }
          this.gridApi.forEachNode(n => {
            if (n.rowIndex >= startIndex && n.rowIndex <= endIndex) {
              n.setSelected(true, false);
            }
          });
        } else if ((<MouseEvent>event.event).ctrlKey) {
          event.node.setSelected(!event.node.isSelected(), false);
        } else {
          event.node.setSelected(true, true);
        }
      }
    }
    this.cellClicked.emit(event);
  }

  onCellDoubleClicked(event) {
    this.cellDoubleClicked.emit(event);
  }

  onCellEditingStarted(event) {
    this.cellEditingStarted.emit(event);
  }

  updateSelection() {
    if (this.gridApi) {
      this.prevFocusRowIndex = this.gridApi.getFocusedCell()?.rowIndex;

      const hasSelection = this.selection && (this.selectionMode === 'single' || this.selection.length > 0);
      this.gridApi.forEachNode(node => {
        if (node.data) {
          if (this.selectionMode === 'single') {
            if (this.getRowId) {
              node.setSelected(hasSelection && this.getRowId(this.selection) == this.getRowId(node.data));
            } else {
              node.setSelected(hasSelection && this.selection === node.data);
            }
          } else {
            if (this.getRowId) {
              node.setSelected(hasSelection
                && (<any[]>this.selection.map(v => v && this.getRowId(v).toString()))
                  .indexOf(this.getRowId(node.data).toString()) >= 0);
            } else {
              node.setSelected(hasSelection && (<any[]>this.selection).indexOf(node.data) >= 0);
            }
          }
        }
      });
    }
  }

  onColumnMoved() {
    if (!this.loadingSettings) {
      this.saveSettings();
    }
  }

  onColumnResized(event: any) {
    this.updateColumnTooltip(event.column);
    if (!this.loadingSettings) {
      this.saveSettings();
    }
    if (this.wrapHeaderText) {
      this.resizeHeaderWithDebounce(this.headerVerticalPadding);
    }
  }

  displayedColumnsWidthChanged(event: any) {
    console.log('displayedColumnsWidthChanged', event, Math.random());
  }

  onColumnVisible() {
    if (!this.loadingSettings) {
      this.saveSettings();
    }
  }

  onColumnPinned() {
    if (!this.loadingSettings) {
      this.saveSettings();
    }
    if (this.wrapHeaderText) {
      this.makeHeaderTextMultiline();
      this.resizeHeader(this.headerVerticalPadding);
    }
  }

  onBodyScroll(event: any) {
    if (event.direction === 'horizontal' && this.wrapHeaderText) {
      this.makeHeaderTextMultiline();
      this.resizeHeaderWithDebounce(this.headerVerticalPadding);
    }
  }

  onFilterChanged() {
    if (this.keepSelectionAfterFilter) {
    } else if (this.keepSelection) {
      this.keepSelection = false;
    } else {
      this.gridApi.deselectAll();
    }
    const filters = {};
    const filterModel = this.gridApi.getFilterModel();
    if (filterModel) {
      for (const key in filterModel) {
        if (filterModel.hasOwnProperty(key)) {
          filters[key] = {value: filterModel[key].filter, matchMode: filterModel[key].type};
        }
      }
    }
    let filterString = '';
    for (const prop in filters) {
      if (filters.hasOwnProperty(prop)) {
        if (filterString) {
          filterString += ' и ';
        }
        filterString +=
          `'${this.getColumnHeader(prop)}' ${getFilterModesTitle(localeColumnFilterModes[filters[prop].matchMode])}`;
        const mode = filters[prop].matchMode;
        const withValue = mode != 'isNull' && mode != 'isNotNull';
        if (withValue) {
          const enumFilter = this.columnApi.getColumn(prop).getColDef().filterParams.enum;
          let filtersPropValue = filters[prop].value;
          const colType = this.columnApi.getColumn(prop).getColDef().type as ColumnTypes;
          if (colType === 'date' || colType === 'dateTime' || colType === 'dateYear') {
            const arr = filtersPropValue.split(',');
            filtersPropValue = arr.map(item => new Date(item).toLocaleDateString().replace('Invalid Date', '...')).join(' - ');
          }
          filterString += enumFilter ? ` '${enumFilter.find(f => f.value == filtersPropValue) ?
            enumFilter.find(f => f.value == filtersPropValue).label : `${filtersPropValue}`}'` : ` '${filtersPropValue}'`;
        }
      }
    }
    this.filterString = filterString;
    this.filterChanged.emit();
  }

  onCellValueChanged(e: CellValueChangedEvent) {
    const col = e.colDef.col;
    col.cellValueChanged.emit(e);
  }

  onKeyDown(event) {
    if (this.focused) {
      this.cellKeyDown.emit(event);
    }
  }

  onModelUpdated(event) {
    this.modelUpdated.emit(event);
    this.isSummaryRowPicked ? !this.lazy ? this.getSummaryRow() : null : null;
  }

  onSortChanged(event) {
    const currentModel = event.api.getSortModel();
    const fixedSorts = this.defaultSortModel ? this.defaultSortModel.filter(s => s.fixed) : [];
    const unusedFixedSorts = [];

    for (const sort of fixedSorts) {
      if (!event.api.getSortModel().find(s => s.colId == sort.field)) {
        unusedFixedSorts.push(this.mapSortMetaToGridSortModel(sort));
      }
    }

    if (unusedFixedSorts.length > 0) {
      event.api.setSortModel(unusedFixedSorts.concat(currentModel));
    }
  }

  getColumnHeader(colId: string) {
    return this.columnApi.getColumn(colId).getColDef().headerName;
  }

  getColumnTooltip(col: AgGridColumn) {
    const cellCpacings = 50;
    if (!this.enableTooltips) {
      return null;
    }
    if (col.getUserProvidedColDef().headerTooltip) {
      return col.getUserProvidedColDef().headerTooltip;
    }
    const width = this.calculateFontSize(col.getColDef().headerName, {font: 'Tahoma', fontSize: '12pt'}).width + cellCpacings;
    const result = col.getActualWidth() <= width ? col.getColDef().headerName : null;
    // console.log(col.getActualWidth(), width, col.getColDef().headerName, result);
    return result;
  }

  updateColumnTooltip(column: AgGridColumn) {
    if (this.tooltipsIntervalIdsHash.has(column)) {
      clearTimeout(this.tooltipsIntervalIdsHash.get(column));
    }
    this.tooltipsIntervalIdsHash.set(column, setTimeout(() => {
      if (!this.gridApi || !column || !column.getColDef() || !column.getColDef().field) {
        return;
      }
      const oldTooltip = column.getColDef().headerTooltip;
      column.getColDef().headerTooltip = this.getColumnTooltip(column);
      if (oldTooltip != column.getColDef().headerTooltip) {
        this.gridApi.refreshHeader();
      }
      this.tooltipsIntervalIdsHash.delete(column);
      if (this.wrapHeaderText) {
        this.makeHeaderTextMultiline();
      }
    }, 500));
  }

  updateAllTooltips() {
    this.columnApi.getAllColumns().forEach(c => {
      this.updateColumnTooltip(c);
    });
  }

  getValueFormatter(col: Column) {
    return !!col.valueFormatter ? col.valueFormatter
      : col.type == 'date' ? this.dateFormatter
        : col.type == 'dateTime' ? this.dateTimeFormatter
          : col.type == 'dateYear' ? this.dateYearFormatter
            : col.type == 'sum' ? this.sumFormatter
              : null;
  }

  getCellRenderer(col: Column) {
    return !!col.customCellRenderer ? col.customCellRenderer
      : col.type == 'group' ? 'agGroupCellRenderer'
        : col.type == 'bool' ? this.boolRenderer
          : null;
  }

  getComparator(col: Column) {
    if (col.type == 'date' || col.type == 'dateTime' || col.type == 'dateYear') {
      return (a: Date, b: Date) => a.valueOf() - b.valueOf();
    }
    if (col.type == 'number') {
      return (a: number, b: number) => a - b;
    }
    return false;
  }

  getFilter(col: Column) {
    if (this.defaultFilterEnabled) {
      if (col.filterAvailable) {
        switch (col.type) {
          case 'enum':
            return 'dropdownFilter';
          case 'bool' :
            return 'dropdownFilter';
          case 'date':
            return 'dateFilter';
          case 'dateTime':
            return 'dateFilter';
          case 'dateYear' :
            return 'dateFilter';
          default:
            return 'agTextColumnFilter';
        }
      }
      return false;
    }
    return false;
  }

  getFilterParams(col: Column): any {
    return {
      newRowsAction: 'keep',
      filterOptions: columnTypeFilterMatchModes[col.type] || columnTypeFilterMatchModes['string'],
      textFormatter: TextFilter.DEFAULT_FORMATTER,
      textCustomComparator: (filter: FilterMatchModes, value: any, filterText: string) => {
        if (col.type == 'number') {
          const num = Number(value);
          switch (filter) {
            case 'gt':
              return num > Number(filterText);
            case 'goe':
              return num >= Number(filterText);
            case 'lt':
              return num < Number(filterText);
            case 'loe':
              return num <= Number(filterText);
            case 'between': {
              const values: string[] = filterText.split(':');
              const valLo = Number(values[0]);
              const valHi = Number(values[1]);
              if (valLo && valHi) {
                return num >= valLo && num <= valHi;
              }
              if (valLo) {
                return num >= valLo;
              }
              return false;
            }
          }
        }

        value = TextFilter.DEFAULT_LOWERCASE_FORMATTER(value);
        filterText = TextFilter.DEFAULT_LOWERCASE_FORMATTER(filterText);
        if (filter == 'in') {
          return filterText.split(',').map(v => v.trim()).includes(value);
        }
        if (filter == 'isNull') {
          return value == null || value == '';
        }
        if (filter == 'isNotNull') {
          return value != null && value != '';
        }
        return TextFilter.DEFAULT_COMPARATOR(filter, value, filterText);
      },
      enum: col.filterOptions,
      values: [],
      suppressRemoveEntries: true,
      suppressSorting: true
    };
  }

  getFloatingFilter(col: Column) {
    switch (col.type as ColumnTypes) {
      case 'enum':
        return 'dropdownFloatingFilter';
      case 'bool' :
        return 'dropdownFloatingFilter';
      case 'date':
        return 'dateFloatingFilter';
      case 'dateTime':
        return 'dateFloatingFilter';
      case 'dateYear' :
        return 'dateFloatingFilter';
      default:
        return 'textFloatingFilter';
    }
  }

  getFloatingFilterParams(col: Column) {
    return col.type == 'enum' ? {suppressFilterButton: true, enum: col.filterOptions}
      : col.type == 'bool' ? {suppressFilterButton: true, enum: col.filterOptions}
        : {suppressFilterButton: true, debounceMs: 3000};
  }

  getTooltipField(col: Column) {
    return this.enableTooltips ? (!!col.tooltipField ? col.tooltipField : null) : null;
  }

  clearFilterAll() {
    this.gridApi.setFilterModel(null);
  }

  getSettingsStorageKey() {
    return this.configService.config.clientId + '-table-' + this.settingsKey;
  }

  saveSettings() {
    if (this.settingsKey) {
      const columnState = JSON.stringify(this.columnApi.getColumnState());
      localStorage.setItem(this.getSettingsStorageKey(), columnState);
    }
  }

  loadSettings() {
    if (this.settingsKey) {
      this.loadingSettings = true;
      const loadedState: any[] = JSON.parse(localStorage.getItem(this.getSettingsStorageKey()));
      if (loadedState) {
        const curState: any[] = this.columnApi.getColumnState();
        const loadedStateIds = loadedState.map(c => c.colId);
        const newStates = curState.filter(c => loadedStateIds.indexOf(c.colId) < 0);
        this.columnApi.setColumnState(loadedState.concat(newStates));
      }
      this.loadingSettings = false;
    }
  }

  getContextMenuItems = (params: GetContextMenuItemsParams) => {
    let contextMenuExtensionWithSummaryRow = this.contextMenuExtensionWithSummaryRow();
    const defaultItems = ['copy', 'copyWithHeaders', 'paste'] as (string | MenuItemDef)[];
    if (contextMenuExtensionWithSummaryRow && contextMenuExtensionWithSummaryRow.length > 0) {
      defaultItems.push('separator');
      for (const menu of contextMenuExtensionWithSummaryRow) {
        defaultItems.push(
          {
            name: menu.label,
            icon: menu.icon ? `<span class="${menu.icon}" style="height: auto"></span>` : '',
            disabled: menu.disabled,
            subMenu: menu.items ? this.getSubMenu(params, menu.items) : null,
            action: () => menu.command(params.node)
          }
        );
      }
    }
    return defaultItems;
  };

  getSubMenu = (params: GetContextMenuItemsParams, menuItems: any) => {
    const subItems = [] as (string | MenuItemDef)[];
    for (const menu of menuItems) {
      subItems.push(
        {
          name: menu.label,
          icon: menu.icon ? `<span class="${menu.icon}" style="height: auto"></span>` : '',
          disabled: menu.disabled,
          subMenu: menu.items ? this.getSubMenu(params, menu.items) : null,
          action: () => {
            menu.command ? menu.command(params.node) : null;
          }
        }
      );
    }
    return subItems;
  };


  getMainMenuItems = (params: GetMainMenuItemsParams) => {
    const defaultItems = <Array<string | MenuItemDef>>params.defaultItems;
    const a = defaultItems[0];
    defaultItems[params.defaultItems.indexOf('resetColumns')] = {
      name: 'Сбросить настройки',
      action: () => {
        params.columnApi.setColumnState(this.initialSate);
        localStorage.removeItem(this.getSettingsStorageKey());
      }
    };
    if (params.column.getColId() === '0') {
      return params.defaultItems.filter(i => i !== 'autoSizeThis');
    } else {
      defaultItems.unshift('separator');
      defaultItems.unshift({
        name: 'Очистить фильтр',
        disabled: !this.defaultFilterEnabled || params.column.getColDef().filter === false,
        icon: '<span class="ag-icon ag-icon-cross"></span>',
        action: () => {
          const filterComponent = params.api.getFilterInstance(params.column.getColId());
          filterComponent.setModel(null);
          params.api.onFilterChanged();
        }
      });
      if (this.distinctFilterService.isEnabled) {
        defaultItems.unshift({
          name: 'Фильтр (подбор значений из колонки)',
          disabled: this.defaultFilterEnabled ?
            params.column.getColDef().filter === false
            || params.column.getColDef().type == 'date'
            || params.column.getColDef().type == 'dateTime'
            || params.column.getColDef().type == 'dateYear'
            || params.column.getColDef().type == 'bool'
            || params.column.getColDef().type == 'custom'
            || this.lazy === false
            : true,
          icon: '<span class="ag-icon ag-icon-filter"></span>',
          action: () => {
            this.distinctFilterService.showFilterDialog(params.api, params.column);
          }
        });
      }

      defaultItems.push('separator');
      defaultItems.push({
        name: 'По возрастанию',
        icon: '<span class="ag-icon ag-icon-asc"></span>',
        disabled: !params.column.getColDef().sortable,
        action: () => {
          const model = params.api.getSortModel();
          params.api.setSortModel(model.concat([{colId: params.column.getColId(), sort: 'asc'}]));
        }
      });
      defaultItems.push({
        name: 'По убыванию',
        icon: '<span class="ag-icon ag-icon-desc"></span>',
        disabled: !params.column.getColDef().sortable,
        action: () => {
          const model = params.api.getSortModel();
          params.api.setSortModel(model.concat([{colId: params.column.getColId(), sort: 'desc'}]));
        }
      });
      defaultItems.push({
        name: 'Очистить сортировку',
        icon: '<span class="ag-icon ag-icon-cross"></span>',
        disabled: !this.defaultSortEnabled || this.defaultSortModel?.find(s => s.field == params.column.getColId())?.fixed,
        action: () => {
          const model = params.api.getSortModel();
          const newModel = model.filter(s => s.colId !== params.column.getColId());
          if (newModel.length === 0 && this.defaultSortModel) {
            this.setDefaultSortModel();
          } else {
            params.api.setSortModel(newModel);
          }
        }
      });
      return params.defaultItems;
    }
  };

  navigateToNextCell = (params: NavigateToNextCellParams) => {
    let previousCell = params.previousCellPosition;
    const suggestedNextCell = params.nextCellPosition;

    const KEY_UP = 38;
    const KEY_DOWN = 40;
    const KEY_LEFT = 37;
    const KEY_RIGHT = 39;

    switch (params.key) {
      case KEY_DOWN:
        if (previousCell.rowIndex + 1 < this.gridApi.getModel().getRowCount()) {
          if (!this.checkboxSelection) {
            if (!params.event.shiftKey) {
              this.gridApi.deselectAll();
            }
            previousCell = params.previousCellPosition;
            // set selected cell on current cell + 1
            this.gridApi.forEachNode((node) => {
              if (previousCell.rowIndex + 1 === node.rowIndex) {
                node.setSelected(true);
              }
            });
          }
        }
        return suggestedNextCell;
      case KEY_UP:
        if (previousCell.rowIndex - 1 >= 0) {
          if (!this.checkboxSelection) {
            if (!params.event.shiftKey) {
              this.gridApi.deselectAll();
            }
            previousCell = params.previousCellPosition;
            // set selected cell on current cell - 1
            this.gridApi.forEachNode((node) => {
              if (previousCell.rowIndex - 1 === node.rowIndex) {
                node.setSelected(true);
              }
            });
          }
        }
        return suggestedNextCell;
      case KEY_LEFT:
      case KEY_RIGHT:
        return suggestedNextCell;
      default:
        throw new Error('this will never happen, navigation is always on of the 4 keys above');
    }
  };

  restoreFocusIfNeeded() {
    if (this.saveFocus) {
      const cell = this.gridApi.getFocusedCell();
      if (cell) {
        this.gridApi.setFocusedCell(cell.rowIndex, cell.column.getColId());
      }
      this.saveFocus = false;
    }
  }

  setDefaultSortModel() {
    if (this.defaultSortModel?.length > 0) {
      this.gridApi.setSortModel(this.defaultSortModel.map(m => this.mapSortMetaToGridSortModel(m)));
    }
  }

  mapSortMetaToGridSortModel(sort: SortMeta): { colId: string, sort: string } {
    return {colId: sort.field, sort: sort.order < 0 ? 'desc' : 'asc'};
  }

  resizeHeaderWithDebounce(padding: number) {
    if (this.resizeHeaderTimerId) {
      clearTimeout(this.resizeHeaderTimerId);
    }
    this.resizeHeaderTimerId = setTimeout(() => {
      this.resizeHeader(padding);
    }, 30);
  }

  resizeHeader(padding) {
    const maxHeaderHeight = Math.max(...Array.from(document.querySelectorAll('.ag-header-cell-text'))
      .map(text => text.clientHeight));
    this.gridApi.setHeaderHeight(maxHeaderHeight + padding);
  }

  private makeHeaderTextMultiline() {
    document.querySelectorAll('.ag-header-cell-text').forEach(el => {
      this.renderer2.setStyle(el, 'overflow', 'visible');
      this.renderer2.setStyle(el, 'white-space', 'normal');
      this.renderer2.setStyle(el, 'overflow-wrap', 'break-word');
    });
  }

  generateContextMenuForSummary() {
    this.contextMenuExtension.push(
      {
        label: 'Открыть итоговую строку',
        title: 'OpenAggMenu',
        command: () => {
          this.isSummaryRowPicked = true;
          this.getSummaryRow();
        }
      },
      {
        label: 'Закрыть итоговую строку',
        title: 'CloseAggMenu',
        command: () => {
          this.isSummaryRowPicked = false;
          this.gridApi.setPinnedBottomRowData(null);
        }
      },
      {
        label: 'Агрегирующие функции',
        title: 'AggMenu',
        items: [
          {
            label: 'Сумма',
            title: 'Sum',
            command: () => {
              this.summaryColAggregateMap.set(this.gridApi.getFocusedCell().column.getColId(), 'Sum');
              this.showPickedFuncInSummaryRow(this.gridApi.getFocusedCell().column.getColId(), 'Sum');
            }
          },
          {
            label: 'Среднее значение',
            title: 'Avg',
            command: () => {
              this.summaryColAggregateMap.set(this.gridApi.getFocusedCell().column.getColId(), 'Avg');
              this.showPickedFuncInSummaryRow(this.gridApi.getFocusedCell().column.getColId(), 'Avg');
            }
          },
          {
            label: 'Максимальное значение',
            title: 'Max',
            command: () => {
              this.summaryColAggregateMap.set(this.gridApi.getFocusedCell().column.getColId(), 'Max');
              this.showPickedFuncInSummaryRow(this.gridApi.getFocusedCell().column.getColId(), 'Max');
            }
          },
          {
            label: 'Минимальное значение',
            title: 'Min',
            command: () => {
              this.summaryColAggregateMap.set(this.gridApi.getFocusedCell().column.getColId(), 'Min');
              this.showPickedFuncInSummaryRow(this.gridApi.getFocusedCell().column.getColId(), 'Min');
            }
          },
          {
            label: 'Убрать столбец из итоговой строки',
            title: 'Del',
            command: () => {
              this.summaryColAggregateMap.delete(this.gridApi.getFocusedCell().column.getColId());
              this.summaryRow[this.gridApi.getFocusedCell().column.getColId()] = null;
              this.gridApi.setPinnedBottomRowData(Array.of(this.summaryRow));
            }
          }
        ]
      })
    ;
  }

  contextMenuExtensionWithSummaryRow() {
    let contextMenuExtensionWithSummaryRow = this.contextMenuExtension;
    if (this.isSummaryRowPicked) {
      contextMenuExtensionWithSummaryRow = contextMenuExtensionWithSummaryRow.filter(e => e.title != 'OpenAggMenu');
      if (!this.colIdsWithCalculatedSummary.includes(this.gridApi.getFocusedCell().column.getColId())) {
        contextMenuExtensionWithSummaryRow = contextMenuExtensionWithSummaryRow.filter(menu => menu.title != 'AggMenu');
      } else {
        contextMenuExtensionWithSummaryRow.forEach(extension => {
            if (extension.title == 'AggMenu') {
              extension.items.forEach(item => {
                if (item['title'] == this.summaryColAggregateMap.get(this.gridApi.getFocusedCell().column.getColId())) {
                  item['icon'] = 'pi pi-check';
                } else {
                  item['icon'] = null;
                }
              });
            }
          }
        );
      }
    } else {
      contextMenuExtensionWithSummaryRow = contextMenuExtensionWithSummaryRow.filter(e => e.title != 'CloseAggMenu' && e.title != 'AggMenu');
    }
    return contextMenuExtensionWithSummaryRow;
  }

  async getSummaryRow() { //инициируем итоговую строку, по дефолту все результаты в виде суммы//если пользователь открыл-закрыл-открыл строку, то ничего грузить не нужно
    await this.calculateSummaryRow(true);
    this.setSummaryDefaultResults();
    this.highlightPinnedRow();
    this.gridApi.setPinnedBottomRowData(Array.of(this.summaryRow));
  }

  async calculateSummaryRow(isInit: boolean) {
    let filteredRows = [];
    filteredRows = await this.getAllTableRowsForSummary();
    this.generateAllSummaryResultsMap(filteredRows);
    this.generateAvailableColumnsToSummaryRow();
    this.redrawSummaryRow();
  }

  async getAllTableRowsForSummary() {
    let filteredRows = [];
    if (!this.lazy) {
      this.gridApi.forEachNodeAfterFilter(node => filteredRows.push(node.data));
    }
    if (filteredRows.length > 0) {
      this.summaryRow = new filteredRows[0].constructor; //присваиваем итоговой строке соответствующий класс
    }
    return filteredRows;
  }

  generateAllSummaryResultsMap(nodes: any[]) {
    const allColumns = this.recursiveColumnsSearch(this.columns);
    allColumns.forEach(currentColumn => {
      this.allSummaryResultsMap.set(currentColumn.field, this.aggFuncCalculating(nodes, currentColumn));
    });
  }

  recursiveColumnsSearch(columnList: Column[]) {
    const result = [];
    columnList.forEach(column => {
      if (column.children.length > 0) {
        this.recursiveColumnsSearch(column.children).forEach(e => result.push(e));
      }
      else{
        result.push(column);
      }
    });
    return result;
  }

  generateAvailableColumnsToSummaryRow() {
    this.colIdsWithCalculatedSummary = [];
    this.allSummaryResultsMap.forEach((v, k) => {
      v != null ? this.colIdsWithCalculatedSummary.push(k) : null;
    });
  }

  redrawSummaryRow() {
    this.summaryColAggregateMap.forEach((v, k) => {
      this.summaryRow[k] = this.allSummaryResultsMap?.get(k)?.get(v);
    });
    this.gridApi.setPinnedBottomRowData(Array.of(this.summaryRow));
  }

  setSummaryDefaultResults() {
    this.allSummaryResultsMap.forEach((value, columnName) => {
      if (value != null) {
        this.summaryRow[columnName] = 0;
        this.summaryRow[columnName] = value.get('Sum');
        this.summaryColAggregateMap.set(columnName, 'Sum');
      }
    });
  }

  showPickedFuncInSummaryRow(columnName: string, aggregateFunc: string) {
    this.summaryRow[columnName] = 0;
    switch (aggregateFunc) {
      case 'Sum':
        this.summaryRow[columnName] = this.allSummaryResultsMap.get(columnName).get('Sum');
        break;
      case 'Avg':
        this.summaryRow[columnName] = this.allSummaryResultsMap.get(columnName).get('Avg');
        break;
      case 'Max':
        this.summaryRow[columnName] = this.allSummaryResultsMap.get(columnName).get('Max');
        break;
      case 'Min':
        this.summaryRow[columnName] = this.allSummaryResultsMap.get(columnName).get('Min');
        break;
    }
    this.gridApi.setPinnedBottomRowData(Array.of(this.summaryRow));
  }

  aggFuncCalculating(nodes: any[], column: Column) {
    const columnName = column.field;
    const isDisableSummaryRowCalculating = column.isDisableSummaryRowCalculating;
    let isAvailableNodeType = true;
    let countOfNumberTypes = 0;
    nodes.forEach(node => {
      typeof node[columnName] == 'string' ? isAvailableNodeType = false : null;
      typeof node[columnName] == 'number' ? countOfNumberTypes++ : null;
    });
    (countOfNumberTypes == 0) ? isAvailableNodeType = false : null;
    if (isAvailableNodeType && !isDisableSummaryRowCalculating) {
      let sum = 0;
      let avg = 0;
      let max = -1;
      let min = Number.MAX_VALUE;
      let countNotNullItems = 0;
      nodes.forEach(node => {
        if (node[columnName] != null) {
          countNotNullItems++;
          sum += node[columnName];
          node[columnName] > max ? max = node[columnName] : max = max;
          node[columnName] < min ? min = node[columnName] : min = min;
        }
      });
      avg = sum / countNotNullItems;
      sum = parseFloat(sum.toFixed(2));
      avg = parseFloat(avg.toFixed(2));
      return new Map([['Sum', sum], ['Avg', avg], ['Max', max], ['Min', min]]);
    }
    return null;
  }

  highlightPinnedRow() {
    this.grid.gridOptions.getRowStyle = function (params) {
      if (params.node.rowPinned === 'bottom') {
        return {'background-color': '#c6ddf5'};
      }
    };
  }
}
