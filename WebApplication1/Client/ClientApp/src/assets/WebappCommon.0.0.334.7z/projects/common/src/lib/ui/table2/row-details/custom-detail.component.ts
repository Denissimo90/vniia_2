import {Component, ElementRef, TemplateRef} from '@angular/core';
import {ICellRendererAngularComp} from 'ag-grid-angular';

@Component({
  selector: 'app-detail-cell-renderer',
  template: `
    <ng-container *ngTemplateOutlet="template; context: {$implicit: params}"></ng-container>`
})
export class CustomDetailComponent implements ICellRendererAngularComp {
  template: TemplateRef<ElementRef>;
  params;

  agInit(params: any): void {
    if (params.template) {
      this.template = params.template;
    } else {
      console.warn('You need to use detailCellRendererParams.template for detail view');
    }
    this.params = params;
  }

  refresh(params: any): boolean {
    return false;
  }
}
