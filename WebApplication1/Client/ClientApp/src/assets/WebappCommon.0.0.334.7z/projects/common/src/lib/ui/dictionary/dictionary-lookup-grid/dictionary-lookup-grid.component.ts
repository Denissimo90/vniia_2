import {Component, EventEmitter, forwardRef, Input, OnInit, Output} from '@angular/core';
import {LookupBaseComponent} from '../../lookup/lookup-base.componet';
import {Column} from '../../table/column';
import {DictionaryService} from '../../../services/dictionary/dictionary.service';
import {LazyLoadEvent} from '../../table2/table2.component';

@Component({
  selector: 'app-dictionary-lookup-grid',
  templateUrl: './dictionary-lookup-grid.component.html',
  providers: [
    {provide: LookupBaseComponent, useExisting: forwardRef(() => DictionaryLookupGridComponent)}
  ]
})
export class DictionaryLookupGridComponent extends LookupBaseComponent implements OnInit {
  selectedDictionaryRow: any;
  @Input() key: string;
  @Input() global = false;
  @Input() textField: string;
  @Input() filter: string;
  @Input() filterParams: { [key: string]: string };
  @Input() query: string;
  @Input() url: string;
  @Output() rowDoubleClick = new EventEmitter();
  @Output() cellKeyDown = new EventEmitter();

  _header = 'Справочник';
  columns: Column[];

  constructor(private dictionaryService: DictionaryService) {
    super();
  }

  get selectedValue(): any {
    return this.selectedDictionaryRow;
  }

  get header(): string {
    return this._header;
  }

  async ngOnInit() {
    if (this.global) {
      const dictionary = await this.dictionaryService.getMetaInf(this.key);
      const columns = dictionary.columns;
      if (dictionary.header) {
        this._header = dictionary.header;
      }
      this.columns = columns.map(c => Column.create(c.field, c.header, c.type));
    } else {
      this.columns = [
        Column.create('code', 'Код'),
        Column.create('value', 'Значение')
      ];
    }
  }

  async onLoad(event: LazyLoadEvent) {
    const filters = {...event.filters};
    if (this.query) {
      filters['@query'] = {value: this.query};
    }
    try {
      if (this.global) {
        const dictionaries = await this.dictionaryService.searchDictionary(
          event.pageQuery.clone({filters: filters}),
          this.key,
          this.filter,
          this.filterParams,
          this.url
        );
        event.successCallback(dictionaries.items, dictionaries.total);
      } else {
        const dictionaries = await this.dictionaryService.searchLocalDictionary(
          event.pageQuery.clone({filters: filters}),
          this.key,
          this.url
        );
        event.successCallback(dictionaries.items, dictionaries.total);
      }
    } catch (e) {
      event.failCallback();
      throw e;
    }
  }
}


