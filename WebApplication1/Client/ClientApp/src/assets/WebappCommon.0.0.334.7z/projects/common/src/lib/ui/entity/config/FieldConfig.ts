export class FieldConfig {
  name: string;
  visible: () => boolean;
  required: () => boolean;
  readonly: () => boolean;
}
