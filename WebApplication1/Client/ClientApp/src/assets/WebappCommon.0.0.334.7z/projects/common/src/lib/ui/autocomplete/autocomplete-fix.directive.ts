import {Directive} from '@angular/core';
import {AutoComplete} from 'primeng/autocomplete';

@Directive({
  selector: 'p-autoComplete'
})
export class AutocompleteFixDirective {
  constructor(autocomplete: AutoComplete) {
    const onOverlayAnimationDone = autocomplete.onOverlayAnimationDone.bind(autocomplete);
    autocomplete.onOverlayAnimationDone = e => {
      if (!autocomplete.forceSelection) {
        onOverlayAnimationDone(e);
      }
    };

    const onOverlayHide = function() {
      this.unbindDocumentClickListener();
      this.unbindDocumentResizeListener();
      this.overlay = null;
      this.onHide.emit({}); // patching for this line, original: this.onHide.emit(event)
    };
    autocomplete.onOverlayHide = onOverlayHide.bind(autocomplete);
  }
}
