export enum DetailCellRenderer {
  CUSTOM = 'customDetailComponent'
}
