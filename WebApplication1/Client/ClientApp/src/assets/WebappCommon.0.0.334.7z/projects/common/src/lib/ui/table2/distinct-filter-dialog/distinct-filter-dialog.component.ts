import {Component, EventEmitter, OnInit, Output, ViewChild} from '@angular/core';
import {DialogComponent} from '../../dialog/dialog.component';
import {Column} from '../../table/column';
import {Events, IServerSideGetRowsParams, RowNode} from 'ag-grid-community';
import {LazyLoadEvent, Table2Component} from '../table2.component';
import {Dialog} from 'primeng/dialog';
import {DistinctFilterService} from './distinct-filter.service';
import {DistinctFilterDummyService} from './distinct-filter-dummy.service';

@Component({
  selector: 'lib-distinct-filter-dialog',
  templateUrl: './distinct-filter-dialog.component.html',
  styleUrls: ['./distinct-filter-dialog.component.css'],
  providers: [{
    provide: DistinctFilterService,
    useClass: DistinctFilterDummyService
  }]
})
export class DistinctFilterDialogComponent extends DialogComponent implements OnInit {
  column: Column;
  selection: any[];
  loader: (e: IServerSideGetRowsParams) => void;
  initialFilter: string;

  getRowId = (row) => this.getValue(row);

  @Output() result = new EventEmitter<string[]>();

  @ViewChild('dialog') dialog: Dialog;
  @ViewChild('table') table: Table2Component;

  constructor() {
    super();
  }

  ngOnInit() {
  }

  init(column: Column, loader: (e: IServerSideGetRowsParams) => void, initialFilter: string) {
    this.column = column;
    this.loader = loader;
    this.initialFilter = initialFilter;
    this.visible = true;
  }

  onLoad(e: LazyLoadEvent) {
    const filters = {};
    for (const key in e.filters) {
      if (e.filters.hasOwnProperty(key)) {
        filters[key] = { filter: e.filters[key].value, type: e.filters[key].matchMode };
      }
    }
    const params: IServerSideGetRowsParams = {
      request: {
        startRow: e.first,
        endRow: e.first + e.rows,
        sortModel: e.multiSortMeta.map(f => ({
          colId: f.field,
          order: f.order === -1 ? 'desc' : f.order === 1 ? 'asc' : ''
        })),
        filterModel: filters,
        rowGroupCols: [],
        valueCols: [],
        pivotCols: [],
        pivotMode: false,
        groupKeys: []
      },
      successCallback: e.successCallback,
      failCallback: e.failCallback,
      parentNode: null,
      context: { distinctColumn: this.column.field }
    };
    this.loader(params);
  }

  apply() {
    this.result.emit(this.selection.map(row => this.getValue(row)));
    this.visible = false;
  }

  getValue(row: any) {
    const props = this.column.field.split('.');
    return props.reduce((prev, curr) => prev && prev[curr], row);
  }

  cancel() {
    this.visible = false;
  }

  onDataSourceReady(api) {
    if (this.initialFilter) {
      const selection = [];
      this.initialFilter.split(',').forEach(value => {
        const rowData = {};
        let curObj = rowData;
        const parts = this.column.field.split('.');
        for (let i = 0; i < parts.length; i++) {
          const field = parts[i];
          if (i == parts.length - 1) {
            curObj[field] = value;
          } else {
            curObj[field] = {};
          }
          curObj = curObj[field];
        }
        selection.push(rowData);
      });
      this.selection = selection;
      selection.forEach(dataRow => {
        const node = new RowNode();
        node.id = this.getValue(dataRow);
        node.daemon = true;
        node.level = 0;
        node.setSelectedInitialValue(true);
        node.data = dataRow;
        const event = {
          type: Events.EVENT_ROW_SELECTED,
          api: api,
          node: node
        }
        api.selectionController.eventService.dispatchEvent(event);
      });
    }
  }

  onresize(e) {
    if (this.dialog.maximized) {
      return;
    }
    setTimeout(() => {
      if (this.dialog.container) {
        this.dialog.container.style.left = 'unset';
        this.dialog.container.style.top = 'unset';
      }
    });
  }
}
