import {Injectable, Injector} from '@angular/core';
import {HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest} from '@angular/common/http';
import {Observable} from 'rxjs';
import {HTTPErrors, HttpEventbusEvent} from '../events/http.eventbus.event';
import {AuthService} from '../auth/auth.service';
import {from, Subject, throwError} from 'rxjs';
import {catchError, switchMap} from 'rxjs/operators';
import {EventBusService} from '../events/eventbus.service';

@Injectable()
export class RequestInterceptorService implements HttpInterceptor {

  constructor(private injector: Injector, private bus: EventBusService) {
  }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const authService: AuthService = this.injector.get(AuthService);

    if (authService.getAccessToken()) {
      request = this.addToken(request, authService.getAccessToken());
    }
    return next.handle(request).pipe(
      catchError((err: HttpErrorResponse) => {
        const subject = new Subject<HttpEvent<any>>();
        if (err.error instanceof Blob) {
          const reader = new FileReader();
          reader.onload = e => {
            const clonedErr = {...err};
            const el = e.target || e.srcElement;
            clonedErr.error = err.error.type === "application/json"
              ? JSON.parse(el['result'])
              : el['result'];
            subject.error(new HttpErrorResponse(clonedErr));
          };
          reader.onerror = e => {
            subject.error(err);
          };
          reader.readAsText(err.error);
          return subject.pipe(
            catchError((err: HttpErrorResponse) => {
              return this.handleError(request, next, err);
            })
          );
        } else if (err.error instanceof ArrayBuffer) {
          const clonedErr = {...err};
          clonedErr.error = JSON.parse(String.fromCharCode.apply(null, new Uint8Array(err.error)));
          return this.handleError(request, next, new HttpErrorResponse(clonedErr));
        }
        return this.handleError(request, next, err);
      }));
  }

  handleError(request: HttpRequest<any>, next: HttpHandler, err: HttpErrorResponse): Observable<HttpEvent<any>> {
    if (err.error instanceof ProgressEvent) {
      this.bus.emit(new HttpEventbusEvent(HTTPErrors.TYPE_NETWROK_IO_ERROR, err.message));
    } else {
      switch (err.status) {
        case HTTPErrors.TYPE_BAD_REQUEST: {
          if (err.error && err.error.error === 'invalid_grant') {
            return this.login(request, next, false);
          }
          break;
        }
        case HTTPErrors.TYPE_UNAUTHORIZED: {
          return this.login(request, next, true);
        }
        case HTTPErrors.TYPE_BAD_GATEWAY: {
          this.bus.emit(new HttpEventbusEvent(HTTPErrors.TYPE_BAD_GATEWAY, err.error.message));
          break;
        }
      }
    }
    return throwError(err);
  }

  addToken(req: HttpRequest<any>, token: string): HttpRequest<any> {
    if (!token) {return req; }
    return req.clone({ setHeaders: { Authorization: 'Bearer ' + token } });
  }

  login(req: HttpRequest<any>, next: HttpHandler, tryRefreshToken: boolean): Observable<HttpEvent<any>> {
    const authService: AuthService = this.injector.get(AuthService);
    return from(authService.login(tryRefreshToken)).pipe(
      switchMap(res => {
        return next.handle(this.addToken(req, authService.getAccessToken()));
      }));
  }
}
