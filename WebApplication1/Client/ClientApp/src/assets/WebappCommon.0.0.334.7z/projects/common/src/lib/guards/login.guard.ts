import {Injectable} from '@angular/core';
import {Location} from '@angular/common';
import {ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot} from '@angular/router';
import {AuthService} from '../services/auth/auth.service';
import {ConfigurationService} from '../services/config/configuration.service';

@Injectable()
export class LoginGuard implements CanActivate {
  constructor(private authService: AuthService,
              private location: Location,
              private configurationService: ConfigurationService) {
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean> | boolean {
    if (!this.authService.isLoggedIn() && !!this.configurationService.config.auth) {
      const redirectUri = window.location.origin + this.location.prepareExternalUrl(state.url);
      return this.authService.login(true, redirectUri);
    }
    return true;
  }
}
