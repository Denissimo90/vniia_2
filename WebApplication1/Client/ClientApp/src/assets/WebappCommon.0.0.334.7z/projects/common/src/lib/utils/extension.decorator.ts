export function Extension(ctr: any) {
  return function(target: any, propertyKey: string, descriptor: PropertyDescriptor) {
    const originalFunc = descriptor.value;

    ctr.prototype[propertyKey] = function(...args) {
      return originalFunc(this, ...args);
    };
  };
}
