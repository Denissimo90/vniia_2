import { Component, OnInit } from '@angular/core';
import { DialogComponent } from '@prism/common';

@Component({
  selector: 'app-test-dialog',
  templateUrl: './test-dialog.component.html',
  styleUrls: ['./test-dialog.component.css']
})
export class TestDialogComponent extends DialogComponent implements OnInit {

  cities1 = [
      {label:'Select City', value:null},
      {label:'New York', value:{id:1, name: 'New York', code: 'NY'}},
      {label:'Rome', value:{id:2, name: 'Rome', code: 'RM'}},
      {label:'London', value:{id:3, name: 'London', code: 'LDN'}},
      {label:'Istanbul', value:{id:4, name: 'Istanbul', code: 'IST'}},
      {label:'Paris', value:{id:5, name: 'Paris', code: 'PRS'}}
  ];

  selectedCity1;

  constructor() {
    super();
  }

  ngOnInit(): void {
  }

  show() {
    this.loading = true;
    setTimeout(() => {
      this.loading = false;
    }, 800);
  }
}
