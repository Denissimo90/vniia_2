import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {NgModule} from '@angular/core';
import {CommonModule as AngularCommonModule} from '@angular/common';
import {RouterModule} from '@angular/router';
import {HttpClientModule} from '@angular/common/http';
import {AppComponent} from './app.component';
import {CommonModule} from '@prism/common';
import {FormsModule} from '@angular/forms';
import {TestDialogComponent} from './test-dialog/test-dialog.component';
import {DialogModule} from 'primeng/dialog';
import {ButtonModule} from 'primeng/button';
import {InputTextModule} from 'primeng/inputtext';
import {DropdownModule} from 'primeng/dropdown';
import {ToolbarModule} from 'primeng/toolbar';
import {SampleDialogComponent} from './sample-dialog/sample-dialog.component';
import {InputNumberModule} from '@prism/common';
import { TableShowcaseComponent } from './table-showcase/table-showcase.component';
import { TableDetailComponent } from './table-detail/table-detail.component';
import {CheckboxModule} from 'primeng/checkbox';
import { TableTreeComponent } from './table-tree/table-tree.component';

@NgModule({
  declarations: [
    AppComponent,
    TestDialogComponent,
    SampleDialogComponent,
    TableShowcaseComponent,
    TableDetailComponent,
    TableTreeComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    BrowserAnimationsModule,
    HttpClientModule,
    AngularCommonModule,
    RouterModule.forRoot([
      { path: 'table', component: TableShowcaseComponent },
      { path: 'table-detail', component: TableDetailComponent },
      { path: 'table-tree', component: TableTreeComponent },
      { path: '**', redirectTo: 'table' }
    ]),
    CommonModule.forRoot(),
    DialogModule,
    ButtonModule,
    InputTextModule,
    DropdownModule,
    ToolbarModule,
    InputNumberModule,
    CheckboxModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
