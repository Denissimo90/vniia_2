import { Component, OnInit } from '@angular/core';
import {CellValueChangedEvent, RowSpanParams} from 'ag-grid-community';
import {ConfigurationService, DialogService, LazyLoadEvent} from '@prism/common';
import {NGXLogger} from 'ngx-logger';
import {SampleDialogComponent} from '../sample-dialog/sample-dialog.component';

@Component({
  selector: 'app-table-showcase',
  templateUrl: './table-showcase.component.html',
  styleUrls: ['./table-showcase.component.css']
})
export class TableShowcaseComponent implements OnInit {

  constructor(private logger: NGXLogger,
              private configurationService: ConfigurationService,
              private dialogService: DialogService) { }

  title = 'showcase';
  pnumber = 0.02;
  data: any[];
  random = Math.random;

  dictValues;

  cellClassRules = {
    'show-cell' : true
  };

  col2EditorParams = () => ({
    values: this.dictValues,
    formatValue: value => value.text
  })

  rowSpan = (parameters: RowSpanParams) => {
    return parameters.node.rowIndex == 0 || parameters.node.rowIndex == 5 || parameters.node.rowIndex == 10 ? 5 : 1;
  }

  ngOnInit(): void {
  }

  onLoad(event: LazyLoadEvent) {
    console.log(event);

    this.dictValues = [
      {id: 1, text: '123'},
      {id: 2, text: '321'},
      {id: 3, text: '333'},
      {id: 4, text: '444'}
    ];

    this.logger.info('loading data', 'condtition: ' + this.configurationService.config.condition);
    const data = [];
    for (let i = 0; i < 100; i++) {
      const col2Id = Math.floor(Math.random() * 4) + 1;
      data.push({
        col1: i,
        col2: this.dictValues.filter(r => r.id == col2Id)[0],
        col3: 'asdasdasd' + (i < 5 ? '1234' : ''),
        hint: 'Тултип для ячейки ' + (i < 5 ? '0' : i)
      });
    }
    this.data = data;
    event.successCallback(data, 100);
  }

  highlightCells(e: any) {
    if (e.value < 2) {
      e.style = {'background-color': 'green'};
    } else if (e.value > 1 && e.value < 4) {
      e.style = {'background-color': 'blue'};
    } else if (e.value < 6) {
      e.style = {'background-color': 'red'};
    } else if (e.data.col1 == 0) {
      e.style = {'background-color': '#FC0'};
    }
  }

  onCol2ValueChanged(e: CellValueChangedEvent) {
    if (e.oldValue.id != e.newValue.id) {
      console.log(e.data);
      console.log(e.newValue);
    }
  }

  run() {
    const dialog = this.dialogService.createDialog(SampleDialogComponent);
  }
}
