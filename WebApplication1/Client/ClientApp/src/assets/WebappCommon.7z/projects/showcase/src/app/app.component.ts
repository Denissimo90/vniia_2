import {Component} from '@angular/core';
import {NGXLogger} from 'ngx-logger';
import {ConfigurationService, LazyLoadEvent} from '@prism/common';
import {CellValueChangedEvent, RowSpanParams} from 'ag-grid-community';
import {MenuItem} from 'primeng/api/menuitem';
import {DialogService} from '@prism/common';
import {TestDialogComponent} from './test-dialog/test-dialog.component';
import {SampleDialogComponent} from './sample-dialog/sample-dialog.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  constructor(private logger: NGXLogger,
              private configurationService: ConfigurationService,
              private dialogService: DialogService) {
  }

  mainMenu: MenuItem[] = [
    {label: 'Таблица', routerLink: 'table'},
    {label: 'Таблица (master-detail)', routerLink: 'table-detail'},
    {label: 'Дерево', routerLink: 'table-tree'},
    {label: 'Диалог', command: () => this.showTestDialog()}
  ];

  showTestDialog() {
    const dialog = this.dialogService.createDialog(TestDialogComponent);
    dialog.show();
  }
}
