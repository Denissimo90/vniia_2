import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-table-tree',
  templateUrl: './table-tree.component.html',
  styleUrls: ['./table-tree.component.css']
})
export class TableTreeComponent implements OnInit {
  items = [
    {col1: '1', col2: 'sdsdv'},
    {col1: '1/1', col2: 'wevlw;ve'},
    {col1: '1/1/1', col2: 'csdcsdcdsc;ve'},
    {col1: '1/1/1/1', col2: 'csdcsdc;'},
    {col1: '1/1/1/2', col2: 'ffsefwefwef;'},
    {col1: '1/1/1/2/1', col2: 'ffsefwefwef;'},
    {col1: '1/2', col2: 'rveverv'},
    {col1: '2', col2: 'ererrvre'}
  ];

  getDataPath = (row) => row.col1.split('/');

  constructor() { }

  ngOnInit(): void {
  }

}
