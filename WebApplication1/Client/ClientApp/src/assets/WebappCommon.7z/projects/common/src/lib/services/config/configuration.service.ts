import {Inject, Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {NgxLoggerLevel} from 'ngx-logger';
import {APP_ENV} from '../../app.env';

export interface Config {
  condition: string;
  api: string;
  auth: string;
  clientId: string;
  version: string;
  serverLoggingUrl: string;
  serverLogLevel: NgxLoggerLevel;
  logLevel: NgxLoggerLevel;
  offlineMode: boolean;
  restConfig: boolean;
  noLogo: boolean;
  noInformationMenu: boolean;
  noLogsMenu: boolean;
}

@Injectable({providedIn: 'root'})
export class ConfigurationService {

  private _config: any;

  constructor(private http: HttpClient, @Inject(APP_ENV) private env: String) {
  }

  get config(): Config {
    return this._config;
  }

  appendConfig(config: any) {
    this._config = {...this._config, ...config};
  }

  async getRestConfig(uri: string): Promise<void> {
    try {
      const data = <any>await this.http.get(uri).toPromise();
      this.appendConfig(data);
      this._config.offlineMode = false;
    } catch (e) {
      console.log(e);
      this._config.offlineMode = true;
    }
  }

  get storagePrefix(): string {
    return this.config ? (this.config.clientId + '-') : '';
  }

  async init(): Promise<void> {
    this._config = <Config>await this.http.get(
      'config' + (this.env ? ('.' + this.env) : '') + '.json?' + new Date()
    ).toPromise();

    if (!this._config.api && !this._config.offlineMode) {
      throw new Error('config file must contain "api" field with api server url or set offlineMode to "true"');
    }

    if (this._config.restConfig === null) {
      throw new Error('config file must contain "restConfig" field');
    }

    if (!this._config.offlineMode && !!this._config.api && !!this._config.restConfig) {
      await this.getRestConfig(this._config.api + '/config/front-end');
    }

    if (!this._config.offlineMode) {
      if (!this._config.clientId) {
        throw new Error('config file must contain "clientId" field');
      }
      if (!this._config.version) {
        throw new Error('config file must contain "version" field');
      }
      if (this._config.serverLogLevel !== null && this._config.serverLogLevel !== NgxLoggerLevel.OFF && !this._config.serverLoggingUrl) {
        throw new Error('config file must contain "serverLoggingUrl" field if "serverLogLevel" not equals "OFF"');
      }
      if (this._config.logLevel === null) {
        throw new Error('config file must contain "logLevel" field');
      }
      if (this._config.condition === null) {
        throw new Error('config file must contain "condition" field');
      }
    }

  }

}
