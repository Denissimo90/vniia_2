import {AfterViewInit, Directive, HostListener, Input, OnInit} from '@angular/core';
import {Dialog} from 'primeng/dialog';
import {DialogService} from './dialog.service';

@Directive({
  selector: 'p-dialog'
})
export class DialogExtDirective implements OnInit, AfterViewInit {
  private loadingElem: HTMLElement;
  private _loading = false;
  private dialogClose;
  private shown;
  private iframe;
  private resizeListener;

  get loading(): boolean {
    return this._loading;
  }

  @HostListener('document:keyup', ['$event'])
  closeDialogs(event) {
    if (event.key === 'Escape') {
      if ((this.dialog.el.nativeElement.parentElement.localName === this.dialogService.openDialogs[this
        .dialogService.openDialogs.length - 1].dialog.el.nativeElement.parentElement.localName)) {
        this.dialog.close(event);
      }
    }
  }

  @HostListener('onHide')
  onHiding() {
    this.dialogService.openDialogs.pop();
  }

  @Input() set loading(val: boolean) {
    if (this._loading !== val) {
      this._loading = val;
      this.updateLoadingElement();
      if (this.shown) {
        if (this._loading) {
          this.disableDialog();
        } else {
          this.enableDialog();
        }
      }
    }
  }

  constructor(private dialog: Dialog, private dialogService: DialogService) {
  }

  ngOnInit() {
    this.dialogClose = this.dialog.close;
    this.dialog.focusOnShow = false;
  }

  ngAfterViewInit() {
    this.loadingElem = this.createLoadingElement();

    this.dialog.onShow.subscribe(() => {
      this.shown = true;

      this.dialog.contentViewChild.nativeElement.parentNode.appendChild(this.loadingElem);

      if (this._loading) {
        this.disableDialog();
      } else {
        this.enableDialog();
      }
      this.updateLoadingElement();
      this.bindResizeEventListener();
      setTimeout(() => {
        this.setFocus();
      });
    });
    this.dialog.onHide.subscribe(() => {
      this.shown = false;
      this.loadingElem.parentNode.removeChild(this.loadingElem);

      this.unbindResizeEventListener();
    });
  }

  setFocus() {
    (document.activeElement as HTMLElement)?.blur();
    const afElements = this.dialog.contentViewChild.nativeElement.querySelectorAll('[autofocus]');
    if (afElements.length > 0) {
      for (const el of afElements) {
        if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
          if (!el.disabled && !el.hidden) {
            el.focus();
            return;
          }
        }
        for (const input of el.getElementsByTagName('input')) {
          if (input && !input.disabled && !el.hidden) {
            input.focus();
            return;
          }
        }
      }
    }

    for (const el of this.dialog.contentViewChild.nativeElement.getElementsByTagName('input')) {
      if (!el.disabled && !el.hidden) {
        el.focus();
        return;
      }
    }

    this.dialog.headerViewChild.nativeElement.getElementsByClassName('ui-dialog-titlebar-close')[0]?.focus();
  }

  disableDialog() {
    this.dialog.close = e => {
    };
  }

  enableDialog() {
    this.dialog.close = this.dialogClose;
  }

  updateLoadingElement() {
    if (this.loadingElem) {
      this.loadingElem.style.display = this._loading ? 'initial' : 'none';
    }
  }

  createLoadingElement(): HTMLElement {
    const el = document.createElement('app-dialog-loading');
    el.innerHTML = `
    <div tabindex="-1" style="background: rgba(200,200,200,0.5);
        position: absolute; left:0; top:0; bottom: 0; right: 0; z-index: 9999;
        display: flex; justify-content: center; align-items: center;">
      <div style="justify-content: center;font-size: 40px;">
        <i class="fa fa-circle-notch fa-spin"></i>
      </div>
    </div>`;
    return el;
  }

  bindResizeEventListener() {
    const iframe = document.createElement('iframe');
    iframe.id = 'hacky-scrollbar-resize-listener';
    iframe.style.cssText = 'width: 0; background-color: transparent; margin: 0; padding: 0; overflow: hidden; border-width: 0; position: absolute; height: 100%;';

    const self = this;
    // Register our event when the iframe loads
    iframe.onload = function () {
      // The trick here is that because this iframe has 100% height
      // it should fire a window resize event when anything causes it to
      // resize (even scrollbars on the outer element)
      if (!self.dialog.resizable) {
        self.center();
      }
      self.resizeListener = function () {
        if (!self.dialog.resizable) {
          self.center();
        }
      };
      iframe.contentWindow.addEventListener('resize', self.resizeListener);
    };

    // Stick the iframe somewhere out of the way
    this.dialog.container.appendChild(iframe);
    this.iframe = iframe;
  }

  unbindResizeEventListener() {
    if (this.iframe.contentWindow) {
      this.iframe.contentWindow.removeEventListener('resize', this.resizeListener);
      this.iframe.parentNode.removeChild(this.iframe);
    }
  }

  center() {
    this.dialog.container.style.left = 'unset';
    this.dialog.container.style.top = 'unset';
  }
}
