export enum MessageServiceKey {
  OK = 'MESSAGE_SERVICE_OK_KEY'
}