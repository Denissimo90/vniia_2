import {Component, ElementRef, Input, OnDestroy, OnInit, TemplateRef, ViewChild} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {AuthService} from '../../services/auth/auth.service';
import {MenuItem} from 'primeng/api';
import {ConfigurationService} from '../../services/config/configuration.service';
import {EventBusService, HandlerRegistration} from '../../services/events/eventbus.service';
import {UserService} from '../../services/auth/user.service';
import * as FileSaver from 'file-saver';
import {DialogService} from '../../ui/dialog/dialog.service';
import {Dialog} from 'primeng/dialog';
import {UserEmployment} from '../../services/auth/UserEmployment';
import {ToolbarTemplate} from './ToolbarTemplate';

@Component({
  selector: 'app-toolbar',
  templateUrl: './toolbar.component.html',
  styleUrls: ['./toolbar.component.css']
})

export class ToolbarComponent implements OnInit, OnDestroy {
  employments: UserEmployment[];
  userPersonalNumber: string;
  logsMenuArr: MenuItem[];
  informationMenuArr: MenuItem[];
  private handlers: HandlerRegistration[] = [];
  public version;
  showPrivileges = false;


  @Input() name: String;
  @Input() showVersion = true;
  @Input() logoSrc: String = 'assets/logo.svg';
  @Input() mainMenuItems: MenuItem[];
  @Input() informationMenuEx: MenuItem[];
  @Input() toolbarTemplate: ToolbarTemplate;

  @ViewChild('userSelectDialog') userSelectDialog: Dialog;

  constructor(public user: UserService, private http: HttpClient,
              private authService: AuthService,
              public configService: ConfigurationService,
              protected bus: EventBusService,
              protected dialog: DialogService) {
    this.version = this.configService.config.version;
  }

  async ngOnInit() {
    this.logsMenuArr = [
      {
        icon: 'fa fa-download', label: 'Основные',
        command: () => {
          this.saveLogFile('/user/main_log', 'main.log');
        }
      },
      {
        icon: 'fa fa-download', label: 'PLM',
        command: () => {
          this.saveLogFile('/user/plm_log', 'plm.log');
        }
      },
      {
        icon: 'fa fa-download', label: 'Пользовательские',
        command: () => {
          this.saveLogFile('/user/users_log', 'users.log');
        }
      }];

    this.informationMenuArr = [
      {
        label: 'Справка',
        icon: 'fa fa-book',
        routerLink: 'reference'
      }
    ];

    this.user.personalNumberChange.subscribe(val => {
      this.userPersonalNumber = val;
    });
    this.userPersonalNumber = this.user.personalNumber;
    this.employments = this.user.employments;
  }

  ngOnDestroy() {
    this.unsuscribeHandlers();
  }

  unsuscribeHandlers() {
    this.handlers.forEach(handlerRegistration => handlerRegistration.unregister());
  }

  onMenuClick(event: any, menuItem: MenuItem, subMenu: any) {
    if (menuItem.command) {
      menuItem.command(menuItem);
    } else if (subMenu) {
      subMenu.toggle(event);
    }
  }

  getInformationMenu(): MenuItem[] {
    return [].concat(this.informationMenuArr).concat(!!this.informationMenuEx ? this.informationMenuEx : []);
  }

  login() {
    this.authService.login();
  }

  logOut() {
    this.authService.logout();
  }

  async saveLogFile(uri: string, fileName: string): Promise<void> {
    if (!!uri) {
      const data = await this.http
        .get(uri, {responseType: 'blob'})
        .toPromise();
      const file: File = new File([data], fileName);
      FileSaver.saveAs(file, fileName);
    }
  }

  selectPersonal(personal: any) {
    this.user.select(personal);
  }
}
