import {Directive, forwardRef, Input, OnChanges, SimpleChanges} from '@angular/core';
import {AbstractControl, NG_VALIDATORS, Validator} from '@angular/forms';

@Directive({
  selector: '[requiredIf]',
  providers: [
    { provide: NG_VALIDATORS, useExisting: forwardRef(() => RequiredIfDirective), multi: true }
  ]
})
export class RequiredIfDirective implements Validator, OnChanges {

  constructor() {}

  private _requiredIf: boolean;
  @Input() get requiredIf(): boolean {return this._requiredIf; }
  set requiredIf(value: boolean) {
    this._requiredIf = value;
    if (this._onChange) { this._onChange(); }
  }

  private _onChange: () => void;

  validate(c: AbstractControl) {
    if (c.status === 'VALID' && this.requiredIf) { return {requiredIf: {condition: this.requiredIf}}; }
    return null;
  }

  registerOnChange(fn: any): void {this._onChange = fn; }
  registerOnValidatorChange(fn: () => void): void { this._onChange = fn; }

  ngOnChanges(changes: SimpleChanges): void {
    if ('requiredIf' in changes) {
      if (this._onChange) { this._onChange(); }
    }
  }
}
