import {Directive, ElementRef, EventEmitter, HostListener, Input, Output, Optional} from '@angular/core';
import {MessageService} from 'primeng';
import {NgForm} from '@angular/forms';

@Directive({
  selector: 'button[appSubmitForm],button[appValidateForm],p-button[appSubmitForm],p-button[appValidateForm]'
})
export class ButtonFormValidateDirective {

  constructor(private button: ElementRef,
              @Optional() private form: NgForm,
              @Optional() private messageService: MessageService) {
  }

  @Input() appValidateForm: NgForm;
  @Input() appValidateMessageService: MessageService;
  @Output() appSubmitForm = new EventEmitter<Event>();

  @HostListener('click', ['$event'])
  onClick($event: Event) {
    const form = this.appValidateForm || this.form;
    if (form?.invalid) {
      Object.values(form.controls).forEach(c => {
        if (c.invalid) {
          c.markAsDirty();
          c.updateValueAndValidity({ emitEvent: true });
        }
      });
      const messageService = this.appValidateMessageService || this.messageService;
      if (messageService) {
        this.messageService.add({
          severity: 'error',
          summary: 'Ошибка',
          detail: 'Заполните обязательные поля и проверьте корректность значений'
        });
      }
      return;
    }
    if (this.appSubmitForm) {
      this.appSubmitForm.emit($event);
    }
  }
}
