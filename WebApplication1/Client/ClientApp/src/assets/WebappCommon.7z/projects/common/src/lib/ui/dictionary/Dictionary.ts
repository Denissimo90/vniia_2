export class Dictionary {
 id: number;
 dictionaryKey: number;
 code: string;
 value: string;
 archive: boolean;
}
