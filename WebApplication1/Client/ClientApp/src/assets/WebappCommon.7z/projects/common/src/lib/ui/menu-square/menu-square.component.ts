import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import {MenuItem} from 'primeng/api';
import * as Color from 'color';

export type ExtendedMenuItems = ExtendedMenuItem[];

export interface ExtendedMenuItemGroup {
  title: string;
  color?: string;
}

export interface ExtendedMenuItem extends MenuItem {
  squareMenuLabel?: string;
  squareMenuIcon?: string;
  squareMenuColor?: string;
  squareMenuGroup?: ExtendedMenuItemGroup;
  items?: ExtendedMenuItems;
}

export type SquareMenuGroups = SquareMenuGroup[];

export interface SquareMenuGroup {
  title: string;
  lines: SquareMenuItem[][];
  items: SquareMenuItem[];
}

export type SquareMenuItems = SquareMenuItem[];

export interface SquareMenuItem {
  label?: string;
  color?: string;
  hoverColor?: string;
  icon?: string;
  url?: string;
}

export type SquareMenuNumCol = 1 | 2 | 3 | 4 | 6 | 12;

@Component({
  selector: 'app-menu-square',
  templateUrl: './menu-square.component.html',
  styleUrls: ['./menu-square.component.css']
})
export class MenuSquareComponent implements OnInit {

  @Input('items')
  items: ExtendedMenuItems;

  @Input('colNum')
  colNum: SquareMenuNumCol;

  @Input('baseColor')
  baseColor: string;

  @Input('useRouterLink')
  useRouterLink: boolean;

  hovers: { [key: string]: boolean } = {};

  squareMenu: { groups: SquareMenuGroup[] } = {groups: []};

  ngOnInit(): void {
    this.squareMenu.groups = this.getSquareMenuGroups();
    for (let i = 0; i < this.squareMenu.groups.length; i++) {
      this.squareMenu.groups[i].lines = this.getSquareMenuItemLines(this.squareMenu.groups[i].items);
    }
  }

  mouseOver(item: SquareMenuItem) {
    this.hovers[item.url] = true;
  }

  mouseOut(item: SquareMenuItem) {
    this.hovers[item.url] = false;
  }

  onClick(item: SquareMenuItem, event: MouseEvent) {
    if (!!item['url']) {
      if (event.ctrlKey) {
        window.open(item['url']);
      } else {
        window.open(item['url'], '_self');
      }
    }
  }

  getSquareMenuGroups(): SquareMenuGroups {
    const squareMenuGroups: SquareMenuGroups = [];
    const groups = [];
    for (const menuGroup of this.items.filter(item => !!item.squareMenuGroup).map(item => item.squareMenuGroup)) {
      const findGroupIndex = groups.findIndex((group) => group.title === menuGroup.title);
      if (findGroupIndex == -1) {
        groups.push(menuGroup);
      } else {
        if (menuGroup.color !== groups[findGroupIndex].color && menuGroup.color && !groups[findGroupIndex].color) {
          groups[findGroupIndex].color = menuGroup.color;
        }
      }
    }
    for (const group of groups) {
      squareMenuGroups.push(
        {
          lines: [],
          title: group.title,
          items: [...this.items]
            .filter(item => item.squareMenuGroup.title === group.title)
            .map(item => {
              return {
                label: item.squareMenuLabel || item.label,
                color: item.squareMenuColor || group.color || this.baseColor || '#3d60a1',
                hoverColor: new Color(item.squareMenuColor || group.color || this.baseColor || '#3d60a1').lighten(0.5).hexString(),
                icon: item.squareMenuIcon || item.icon,
                url: item.routerLink || item.url
              };
            })
        }
      );
    }
    return squareMenuGroups;
  }

  getSquareMenuItemLines(items: SquareMenuItems): SquareMenuItems[] {
    const columnNumbers = this.colNum || 3;
    const lines: SquareMenuItems[] = [];
    let line: SquareMenuItems = [];
    let itemCount: number = columnNumbers;
    for (const item of items) {
      line.push(item);
      itemCount--;
      if (itemCount === 0) {
        lines.push(line);
        line = [];
        itemCount = columnNumbers;
      }
    }
    lines.push(line);
    lines.forEach((modLine, index, array) => {
      if (modLine.length < columnNumbers && modLine.length > 1) {
        const emptyItems = new Array<SquareMenuItem>(columnNumbers - modLine.length).fill({});
        modLine.splice(Math.round(modLine.length / 2), 0, ...emptyItems);
      }
    });
    return lines;
  }
}
