import {ElementRef, TemplateRef} from '@angular/core';

export class ToolbarTemplate {
  leftExtension: TemplateRef<ElementRef>;
  rightExtension: TemplateRef<ElementRef>;
  leftTemplate: TemplateRef<ElementRef>;
  rightTemplate: TemplateRef<ElementRef>;
}
