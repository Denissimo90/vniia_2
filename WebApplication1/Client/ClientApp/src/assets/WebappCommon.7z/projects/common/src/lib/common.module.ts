import {APP_INITIALIZER, ErrorHandler, LOCALE_ID, ModuleWithProviders, NgModule} from '@angular/core';
import {CommonModule as AngularCommonModule, registerLocaleData} from '@angular/common';
import localRu from '@angular/common/locales/ru';
import {HTTP_INTERCEPTORS, HttpClientModule} from '@angular/common/http';

import {APP_ENV} from './app.env';

import {TableModule as PrimeTableModule} from 'primeng/table';
import {ContextMenuModule} from 'primeng/contextmenu';
import {InputTextModule} from 'primeng/inputtext';
import {ButtonModule} from 'primeng/button';
import {DialogModule} from 'primeng/dialog';
import {PaginatorModule} from 'primeng/paginator';
import {TriStateCheckboxModule} from 'primeng/tristatecheckbox';
import {PickListModule} from 'primeng/picklist';
import {BlockUIModule} from 'primeng/blockui';
import {PanelModule} from 'primeng/panel';
import {MenuModule} from 'primeng/menu';
import {TieredMenuModule} from 'primeng/tieredmenu';
import {ToolbarModule} from 'primeng/toolbar';
import {OverlayPanelModule} from 'primeng/overlaypanel';
import {CardModule} from 'primeng/card';
import {FileUploadModule} from 'primeng/fileupload';
import {LoggerModule} from 'ngx-logger';
import {OAuthModule} from 'angular-oauth2-oidc';
import {AgGridModule} from 'ag-grid-angular';
import {DropdownModule} from 'primeng/dropdown';
import {AutoCompleteModule} from 'primeng/autocomplete';
import {CalendarModule} from 'primeng/calendar';
import {CheckboxModule} from 'primeng/checkbox';
import {KeyFilterModule} from 'primeng/keyfilter';
import {TooltipModule} from 'primeng/tooltip';
import {ToastModule} from 'primeng/toast';
import {ConfirmationService, MessageService} from 'primeng/api';
import {ConfirmDialogModule} from 'primeng/confirmdialog';

import {ConfigurationService} from './services/config/configuration.service';
import {AuthService} from './services/auth/auth.service';
import {UserService} from './services/auth/user.service';
import {EventBusService} from './services/events/eventbus.service';
import {ApiInterceptorService} from './services/http/api-interceptor.service';
import {RequestInterceptorService} from './services/http/request-interceptor.service';
import {PersonalNumberInterceptorService} from './services/http/personal-number-interceptor.service';
import {DateInterceptorService} from './services/http/date-interceptor.service';
import {LoginGuard} from './guards/login.guard';
import {GlobalErrorHandler} from './services/error/global-error.handler';
import {DialogService} from './ui/dialog/dialog.service';
import './services/http-client.extensions';
import {ToolbarComponent} from './ui/toolbar/toolbar.component';
import {RootComponent} from './ui/root/root.component';
import {TableComponent} from './ui/table/table.component';
import {Table2Component} from './ui/table2/table2.component';
import {Column} from './ui/table/column';
import {Cell} from './ui/table/cell.directive';
import {SumPipe} from './ui/table/sum.pipe';
import {BoolPipe} from './ui/table/bool.pipe';
import {EnumPipe} from './ui/table/enum.pipe';
import {LookupComponent} from './ui/lookup/lookup.component';
import {ProgressPanelComponent} from './ui/progress-panel/progress-panel.component';
import {FileViewerComponent} from './ui/file-viewer/file-viewer.component';
import {SizeableTreeDirective} from './ui/tree/sizeable-tree.directive';
import {AutocompleteFixDirective} from './ui/autocomplete/autocomplete-fix.directive';
import {CalendarDirective} from './ui/calendar/calendar.directive';
import {CalendarUtcDateDirective} from './ui/calendar/calendar-utc-date.directive';
import {DialogExtDirective} from './ui/dialog/dialog-ext.directive';
import {DialogBreakpointsDirective} from './ui/dialog/dialog-breakpoints.directive';
import {TableFrozenFixDirective} from './ui/table/table-frozen-fix.directive';
import {HorizontalSplitPaneFix} from './ui/splitter/horizontal-split-pane-fix.directive';
import {PDataViewDirective} from './ui/data-view/p-data-view.directive';
import {PFileUploadDirective} from './ui/p-file-upload/p-file-upload.directive';
import {TextFloatingFilterComponent} from './ui/table2/filters/text-floating-filter.component';
import {DropdownFilterComponent} from './ui/table2/filters/dropdown-filter.component';
import {DropdownFloatingFilterComponent} from './ui/table2/filters/dropdown-floating-filter.component';
import {RequiredIfDirective} from './ui/required-if/required-if.directive';
import {MenuDirective} from './ui/menu/menu.directive';
import {MenuItemDirective} from './ui/menu/menu-item.directive';
import {AgGridAutoGroupColumn, AgGridDirective} from './ui/table2/ag-grid.directive';
import {AgGridColumnDirective} from './ui/table2/ag-grid-column.directive';
import {BaseService} from './services/http/base.service';
import {EntityConfigService} from './services/entity-config/entity-config.service';
import {DictionaryService} from './services/dictionary/dictionary.service';
import {EntityConfigDirective} from './ui/entity/config/entity-config.directive';
import {FieldConfigDirective} from './ui/entity/extension/field-config.directive';
import {DictionaryLookupComponent} from './ui/dictionary/dictionary-lookup/dictionary-lookup.component';
import {ExtensionAttributesComponent} from './ui/entity/extension/extension-attributes/extension-attributes.component';
import {SpinnerDirective} from './ui/spinner/spinner.directive';
import {DictionaryLookupGridComponent} from './ui/dictionary/dictionary-lookup-grid/dictionary-lookup-grid.component';
import {InvalidIfDirective} from './ui/validators/invalid-if.directive';
import {PKeyFilterNumDirective} from './ui/validators/p-key-filter-num.directive';
import {DistinctFilterDialogComponent} from './ui/table2/distinct-filter-dialog/distinct-filter-dialog.component';
import {DistinctFilterService} from './ui/table2/distinct-filter-dialog/distinct-filter.service';
import {DistinctFilterDialogService} from './ui/table2/distinct-filter-dialog/distinct-filter-dialog.service';
import {ScrollPanelModule} from 'primeng/scrollpanel';
import {HorizontalSplitSeparatorComponent} from './ui/splitter/horizontal-split-pane-separator.component';
import {VerticalSplitSeparatorComponent} from './ui/splitter/vertical-split-pane-separator.component';
import {HorizontalSplitPaneComponent} from './ui/splitter/horizontal-split-pane.component';
import {VerticalSplitPaneComponent} from './ui/splitter/vertical-split-pane.component';
import {SplitSeparatorComponent} from './ui/splitter/split-pane-separator.component';
import {SplitPaneComponent} from './ui/splitter/split-pane.component';
import {ValidateDirective} from './ui/validators/validate.directive';
import {ValidationMessageDirective} from './ui/validators/validation-message.directive';
import {CalenderMaskDirective} from './ui/calendar/calendar-mask.directive';
import {CheckboxHeaderComponent} from './ui/table2/custom-headers/checkbox-header.component';
import {TriStateCheckboxHeaderComponent} from './ui/table2/custom-headers/tri-state-checkbox-header.component';
import {InputDirective} from './ui/input/input.directive';
import {InputNumberDirective} from './ui/inputnumber/input-number.directive';
import {ButtonDirective} from './ui/button/button.directive';
import {ButtonFormValidateDirective} from './ui/button/button-form-validate.directive';
import {CustomDetailComponent} from './ui/table2/row-details/custom-detail.component';
import {ModuleRegistry} from 'ag-grid-community';
import {ClipboardModule} from './ui/table2/clipboard/clipboardModule.js';
import {InputTextareaModule} from 'primeng';
import {MultiSelectModule} from 'primeng/multiselect';
import {TooltipExtDirective} from './ui/tooltip/tooltip.directive';
import {TextareaDirective} from './ui/textarea/textarea.directive';
import {DateFloatingFilterComponent, IDateFloatingFilterComponentParams} from './ui/table2/filters/date-floating-filter.component';
import {DateFilterComponent} from './ui/table2/filters/date-filter.component';
import {MenuSquareComponent} from './ui/menu-square/menu-square.component';

export function initializer(authConfigurationService: ConfigurationService, authService: AuthService) {
  return async () => {
    ModuleRegistry.register(ClipboardModule);
    registerLocaleData(localRu);
    await authConfigurationService.init();
    await authService.init();
  };
}

// @dynamic
@NgModule({
  declarations: [
    ToolbarComponent,
    RootComponent,
    TableComponent,
    SumPipe,
    BoolPipe,
    EnumPipe,
    Column,
    Cell,
    LookupComponent,
    ProgressPanelComponent,
    FileViewerComponent,
    SizeableTreeDirective,
    AutocompleteFixDirective,
    CalendarDirective,
    CalendarUtcDateDirective,
    DialogExtDirective,
    DialogBreakpointsDirective,
    TableFrozenFixDirective,
    HorizontalSplitPaneFix,
    PDataViewDirective,
    PFileUploadDirective,
    RequiredIfDirective,
    MenuDirective,
    MenuItemDirective,
    AgGridDirective,
    AgGridAutoGroupColumn,
    AgGridColumnDirective,
    Table2Component,
    TextFloatingFilterComponent,
    DropdownFilterComponent,
    DropdownFloatingFilterComponent,
    EntityConfigDirective,
    FieldConfigDirective,
    DictionaryLookupComponent,
    ExtensionAttributesComponent,
    SpinnerDirective,
    DictionaryLookupGridComponent,
    InvalidIfDirective,
    PKeyFilterNumDirective,
    DistinctFilterDialogComponent,
    HorizontalSplitPaneComponent,
    VerticalSplitPaneComponent,
    HorizontalSplitSeparatorComponent,
    VerticalSplitSeparatorComponent,
    SplitSeparatorComponent,
    SplitPaneComponent,
    ValidateDirective,
    ValidationMessageDirective,
    CalenderMaskDirective,
    CheckboxHeaderComponent,
    TriStateCheckboxHeaderComponent,
    InputDirective,
    InputNumberDirective,
    ButtonDirective,
    ButtonFormValidateDirective,
    CustomDetailComponent,
    TooltipExtDirective,
    TextareaDirective,
    DateFilterComponent,
    DateFloatingFilterComponent,
    MenuSquareComponent,
  ],
    imports: [
        OAuthModule.forRoot(),
        LoggerModule.forRoot(null),
        AngularCommonModule,
        HttpClientModule,
        PrimeTableModule,
        ContextMenuModule,
        InputTextModule,
        InputTextareaModule,
        ButtonModule,
        DialogModule,
        PaginatorModule,
        TriStateCheckboxModule,
        PickListModule,
        BlockUIModule,
        PanelModule,
        MenuModule,
        TieredMenuModule,
        ToolbarModule,
        OverlayPanelModule,
        CardModule,
        FileUploadModule,
        ScrollPanelModule,
        // SplitPaneModule,
        AgGridModule.withComponents([
            TextFloatingFilterComponent,
            DropdownFilterComponent,
            DropdownFloatingFilterComponent,
            CheckboxHeaderComponent,
            TriStateCheckboxHeaderComponent,
            CustomDetailComponent,
          DateFilterComponent,
            DateFloatingFilterComponent
        ]),
        DropdownModule,
        TooltipModule,
        ToastModule,
        ConfirmDialogModule,
        CheckboxModule,
        CalendarModule,
        AutoCompleteModule,
        KeyFilterModule,
        MultiSelectModule
    ],
  exports: [
    ToolbarComponent,
    RootComponent,
    TableComponent,
    SumPipe,
    BoolPipe,
    EnumPipe,
    Column,
    Cell,
    LookupComponent,
    ProgressPanelComponent,
    SizeableTreeDirective,
    AutocompleteFixDirective,
    CalendarDirective,
    CalendarUtcDateDirective,
    DialogExtDirective,
    DialogBreakpointsDirective,
    TableFrozenFixDirective,
    HorizontalSplitPaneFix,
    PDataViewDirective,
    PFileUploadDirective,
    RequiredIfDirective,
    FileViewerComponent,
    MenuDirective,
    MenuItemDirective,
    AgGridDirective,
    AgGridAutoGroupColumn,
    Table2Component,
    TextFloatingFilterComponent,
    DropdownFilterComponent,
    DropdownFloatingFilterComponent,
    DateFilterComponent,
    DateFloatingFilterComponent,
    EntityConfigDirective,
    FieldConfigDirective,
    DictionaryLookupComponent,
    ExtensionAttributesComponent,
    SpinnerDirective,
    InvalidIfDirective,
    PKeyFilterNumDirective,
    HorizontalSplitPaneComponent,
    VerticalSplitPaneComponent,
    ValidateDirective,
    ValidationMessageDirective,
    CalenderMaskDirective,
    InputDirective,
    InputNumberDirective,
    ButtonDirective,
    ButtonFormValidateDirective,
    TooltipExtDirective,
    TextareaDirective,
    MenuSquareComponent,
  ],
  entryComponents: [DistinctFilterDialogComponent]
})
export class CommonModule {
  public static forRoot(env?: String): ModuleWithProviders<CommonModule> {
    return {
      ngModule: CommonModule,
      providers: [
        {
          provide: APP_ENV,
          useValue: env
        },
        {
          provide: LOCALE_ID,
          useValue: 'ru'
        },
        {
          provide: ErrorHandler,
          useClass: GlobalErrorHandler
        },
        {
          provide: HTTP_INTERCEPTORS,
          useClass: ApiInterceptorService,
          multi: true
        },
        {
          provide: HTTP_INTERCEPTORS,
          useClass: RequestInterceptorService,
          multi: true
        },
        {
          provide: HTTP_INTERCEPTORS,
          useClass: PersonalNumberInterceptorService,
          multi: true
        },
        {
          provide: HTTP_INTERCEPTORS,
          useClass: DateInterceptorService,
          multi: true
        },
        {
          provide: APP_INITIALIZER,
          useFactory: initializer,
          deps: [ConfigurationService, AuthService],
          multi: true
        },
        {
          provide: DistinctFilterService,
          useClass: DistinctFilterDialogService
        },
        ConfigurationService,
        AuthService,
        UserService,
        EventBusService,
        LoginGuard,
        BaseService,
        EntityConfigService,
        DictionaryService,
        MessageService,
        DialogService,
        ConfirmationService
      ]
    };
  }
}
