export abstract class LookupBaseComponent {
  selectedValue: any;
  header: string;
}
