export class PageQuery {
  readonly first?: number;
  readonly rows?: number;
  readonly sorts?: SortMeta[];
  readonly filters?: {
    [s: string]: FilterMetadata;
  };
  readonly query?: string;
  readonly exportColumns?: any[];
  readonly distinctColumn?: string;
  readonly findRowQuery?: string;

  constructor(options: {
    first?: number;
    rows?: number;
    sorts?: SortMeta[];
    filters?: {
      [s: string]: FilterMetadata;
    };
    query?: string;
    exportColumns?: any[];
    distinctColumn?: string;
    findRowQuery?: string;
  }) {
    this.first = options.first;
    this.rows = options.rows;
    this.sorts = options.sorts;
    this.filters = options.filters;
    this.query = options.query;
    this.exportColumns = options.exportColumns;
    this.distinctColumn = options.distinctColumn;
    this.findRowQuery = options.findRowQuery;
  }

  clone(overrides: {
    first?: number;
    rows?: number;
    sorts?: SortMeta[];
    filters?: {
      [s: string]: FilterMetadata;
    };
    query?: string;
    exportColumns?: any[];
    distinctColumn?: string;
    findRowQuery?: string;
  }): PageQuery {
    return new PageQuery(Object.assign({}, this, overrides));
  }
}

export interface SortMeta {
  field: string;
  order?: number;
  fixed?: boolean;
}

export interface FilterMetadata {
  value?: any;
  matchMode?: string;
}
