import {Directive, DoCheck} from '@angular/core';
import {Tooltip} from 'primeng';

@Directive({
  selector: '[pTooltip]'
})
export class TooltipExtDirective implements DoCheck {
  constructor(private tooltip: Tooltip) {
  }

  ngDoCheck(): void {
    if (this.tooltip.active && this.tooltip.tooltipEvent === 'hover'
        && this.tooltip.el?.nativeElement?.disabled === true) {
      this.tooltip.hide();
    }
  }
}
