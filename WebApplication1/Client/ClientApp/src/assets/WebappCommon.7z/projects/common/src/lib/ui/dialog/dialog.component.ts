import {AfterContentInit, EventEmitter, Input, Output, ViewChild} from '@angular/core';
import {Dialog} from 'primeng/dialog';
import {DialogExtDirective} from './dialog-ext.directive';

export class DialogComponent implements AfterContentInit {
  private _shown = false;

  get visible() {
    return this.dialog.visible;
  }
  @Input() set visible(visible: boolean) {
    this.dialog.visible = visible;
    this.visibleChange.emit(this.visible);
    if (visible) {
      this.showInternal();
    } else {
      this.hideInternal();
    }
  }

  get loading() {
    return this.dialogExt.loading;
  }
  @Input() set loading(loading: boolean) {
    this.dialogExt.loading = loading;
  }

  get shown(): boolean {
    return this._shown;
  }

  @Output() visibleChange = new EventEmitter<boolean>();
  @Output() onShow = new EventEmitter<void>();
  @Output() onHide = new EventEmitter<void>();

  @ViewChild(Dialog, {static: true}) dialog: Dialog;
  @ViewChild(DialogExtDirective, {static: true}) dialogExt: DialogExtDirective;

  ngAfterContentInit() {
    this._shown = !!this.dialog.visible;
    this.dialog.visibleChange.subscribe(visible => {
      this.visible = visible;
    });
    this.dialog.modal = true;
    this.dialog.resizable = false;
  }

  private showInternal() {
    this._shown = true;
    this.onShow.emit(null);
  }

  private hideInternal() {
    let timeout = parseInt(this.dialog.transitionOptions, 10);
    if (isNaN(timeout) || !isFinite(timeout)) {
      timeout = 0;
    }
    setTimeout(() => {
      this._shown = false;
      this.onHide.emit(null);
    }, timeout);
  }
}
