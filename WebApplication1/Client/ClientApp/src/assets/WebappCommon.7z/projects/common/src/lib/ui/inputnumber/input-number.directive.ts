import {ChangeDetectorRef, Directive, Input, OnInit} from '@angular/core';
import {InputNumber} from './inputnumber';

@Directive({
  selector: 'p-inputNumber'
})
export class InputNumberDirective implements OnInit {
  @Input() locale = 'ru-RU';
  @Input() useGrouping = false;
  @Input() minFractionDigits: number;

  constructor(private inputNumber: InputNumber,
              private changeDetectorRef: ChangeDetectorRef) {
  }

  ngOnInit(): void {
    this.inputNumber.locale = this.locale;
    this.inputNumber.useGrouping = this.useGrouping;
    if (this.locale === 'ru-RU') {
      this.inputNumber._decimal = /[,.]/g;
      this.inputNumber.getDecimalExpression = () => this.getRussianDecimalExpression();
    }
    this.minFractionDigits = this.inputNumber.minFractionDigits;
    this.inputNumber.insert = (event, text, sign = {isDecimalSign: false, isMinusSign: false}) =>
      this.insert(event, text, sign);
    this.inputNumber.onInputKeyDown = (event) => this.onInputKeyDown(event);
    this.inputNumber.insertText = (value, text, start, end) => this.insertText(value, text, start, end);
  }

  // bypass for Russian locale
  getRussianDecimalExpression() {
    return new RegExp('[,.]', 'g');
  }

  insert(event, text, sign = {isDecimalSign: false, isMinusSign: false}) {
    const selectionStart = this.inputNumber.input.nativeElement.selectionStart;
    const selectionEnd = this.inputNumber.input.nativeElement.selectionEnd;
    const inputValue = this.inputNumber.input.nativeElement.value.trim();
    const decimalCharIndex = inputValue.search(this.inputNumber._decimal);
    this.inputNumber._decimal.lastIndex = 0;
    const minusCharIndex = inputValue.search(this.inputNumber._minusSign);
    this.inputNumber._minusSign.lastIndex = 0;
    let newValueStr;

    if (sign.isMinusSign) {
      if (selectionStart === 0) {
        newValueStr = inputValue;
        if (minusCharIndex === -1 || selectionEnd !== 0) {

          newValueStr = this.inputNumber.insertText(inputValue, text, 0, selectionEnd);
        }
        this.inputNumber.updateValue(event, newValueStr, text, 'insert');
      }
    } else if (sign.isDecimalSign) {
      if (decimalCharIndex > 0 && selectionStart === decimalCharIndex) {
        this.inputNumber.updateValue(event, inputValue, text, 'insert');
      } else if (decimalCharIndex > selectionStart && decimalCharIndex < selectionEnd) {
        newValueStr = this.inputNumber.insertText(inputValue, text, selectionStart, selectionEnd);
        this.inputNumber.updateValue(event, newValueStr, text, 'insert');
      }
    } else {
      const maxFractionDigits = this.inputNumber.numberFormat.resolvedOptions().maximumFractionDigits;

      if (decimalCharIndex > 0 && selectionStart > decimalCharIndex) {
        const resultingFractionDigits = selectionStart + text.length - (decimalCharIndex + 1) - (selectionEnd - selectionStart);
        if (resultingFractionDigits <= maxFractionDigits) {
          newValueStr = inputValue.slice(0, selectionStart) + text + inputValue.slice(selectionEnd);
          if (resultingFractionDigits > this.inputNumber.minFractionDigits) {
            this.setMinFractionDigits(resultingFractionDigits);
          }

        }

      } else {
        newValueStr = this.inputNumber.insertText(inputValue, text, selectionStart, selectionEnd);
        if ((decimalCharIndex > 0 && (selectionStart < decimalCharIndex && selectionEnd > decimalCharIndex)) || !inputValue) {
          const newDecimalCharIndex = newValueStr.search(this.inputNumber._decimal);
          this.inputNumber._decimal.lastIndex = 0;
          if (newDecimalCharIndex === -1) {
            this.setMinFractionDigits(this.minFractionDigits);
          } else {
            const newFractionLength = newValueStr.length - (newDecimalCharIndex + 1);
            this.setMinFractionDigits(
              newFractionLength <= this.minFractionDigits ? this.minFractionDigits :
                (newFractionLength >= this.inputNumber.maxFractionDigits ? this.inputNumber.maxFractionDigits :
                  newFractionLength));
          }
        }
      }
      const operation = selectionStart !== selectionEnd ? 'range-insert' : 'insert';
      this.inputNumber.updateValue(event, newValueStr, text, operation);
    }
  }

  onInputKeyDown(event) {
    this.inputNumber.lastValue = event.target.value;
    if (event.shiftKey || event.altKey) {
      this.inputNumber.isSpecialChar = true;
      return;
    }

    const selectionStart = event.target.selectionStart;
    const selectionEnd = event.target.selectionEnd;
    const inputValue = event.target.value;
    let newValueStr = null;

    if (event.altKey) {
      event.preventDefault();
    }

    switch (event.which) {
      // up
      case 38:
        this.inputNumber.spin(event, 1);
        event.preventDefault();
        break;

      // down
      case 40:
        this.inputNumber.spin(event, -1);
        event.preventDefault();
        break;

      // left
      case 37:
        if (!this.inputNumber.isNumeralChar(inputValue.charAt(selectionStart - 1))) {
          event.preventDefault();
        }
        break;

      // right
      case 39:
        if (!this.inputNumber.isNumeralChar(inputValue.charAt(selectionStart))) {
          event.preventDefault();
        }
        break;

      // backspace
      case 8: {
        event.preventDefault();

        const decimalCharIndex = inputValue.search(this.inputNumber._decimal);
        this.inputNumber._decimal.lastIndex = 0;

        if (selectionStart === selectionEnd) {
          const deleteChar = inputValue.charAt(selectionStart - 1);

          if (this.inputNumber.isNumeralChar(deleteChar)) {
            if (this.inputNumber._group.test(deleteChar)) {
              this.inputNumber._group.lastIndex = 0;
              newValueStr = inputValue.slice(0, selectionStart - 2) + inputValue.slice(selectionStart - 1);
            } else if (this.inputNumber._decimal.test(deleteChar)) {
              this.inputNumber._decimal.lastIndex = 0;
              this.inputNumber.input.nativeElement.setSelectionRange(selectionStart - 1, selectionStart - 1);
            } else if (decimalCharIndex > 0 && selectionStart > decimalCharIndex) {

              if (this.inputNumber.minFractionDigits > this.minFractionDigits) {
                this.setMinFractionDigits(this.inputNumber.minFractionDigits - 1);
                newValueStr = inputValue.slice(0, selectionStart - 1) + inputValue.slice(selectionStart);
              } else {
                newValueStr = inputValue.slice(0, selectionStart - 1) + '0' + inputValue.slice(selectionStart);
              }
            } else if (decimalCharIndex > 0 && decimalCharIndex === 1) {
              newValueStr = inputValue.slice(0, selectionStart - 1) + '0' + inputValue.slice(selectionStart);
              newValueStr = this.inputNumber.parseValue(newValueStr) > 0 ? newValueStr : '';
            } else {
              newValueStr = inputValue.slice(0, selectionStart - 1) + inputValue.slice(selectionStart);
            }
          }

          this.inputNumber.updateValue(event, newValueStr, null, 'delete-single');
        } else {

          newValueStr = this.inputNumber.deleteRange(inputValue, selectionStart, selectionEnd);
          if (decimalCharIndex > 0 && selectionStart > decimalCharIndex) {
            this.setMinFractionDigits(this.inputNumber.minFractionDigits - (selectionEnd - selectionStart) > this.minFractionDigits
              ? this.inputNumber.minFractionDigits - (selectionEnd - selectionStart) : this.minFractionDigits);
          } else if (decimalCharIndex > 0 && (selectionStart < decimalCharIndex && selectionEnd > decimalCharIndex)) {
            this.setMinFractionDigits(this.minFractionDigits);
          }
          this.inputNumber.updateValue(event, newValueStr, null, 'delete-range');
        }

        break;
      }

      // del
      case 46: {
        event.preventDefault();

        const decimalCharIndex = inputValue.search(this.inputNumber._decimal);
        this.inputNumber._decimal.lastIndex = 0;

        if (selectionStart === selectionEnd) {
          const deleteChar = inputValue.charAt(selectionStart);

          if (this.inputNumber.isNumeralChar(deleteChar)) {
            if (this.inputNumber._group.test(deleteChar)) {
              this.inputNumber._group.lastIndex = 0;
              newValueStr = inputValue.slice(0, selectionStart) + inputValue.slice(selectionStart + 2);
            } else if (this.inputNumber._decimal.test(deleteChar)) {
              this.inputNumber._decimal.lastIndex = 0;
              this.inputNumber.input.nativeElement.setSelectionRange(selectionStart + 1, selectionStart + 1);
            } else if (decimalCharIndex > 0 && selectionStart > decimalCharIndex) {

              if (this.inputNumber.minFractionDigits > this.minFractionDigits) {
                this.setMinFractionDigits(this.inputNumber.minFractionDigits - 1);
                newValueStr = inputValue.slice(0, selectionStart) + inputValue.slice(selectionStart + 1);
              } else {
                newValueStr = inputValue.slice(0, selectionStart) + '0' + inputValue.slice(selectionStart + 1);
              }

            } else if (decimalCharIndex > 0 && decimalCharIndex === 1) {
              newValueStr = inputValue.slice(0, selectionStart) + '0' + inputValue.slice(selectionStart + 1);
              newValueStr = this.inputNumber.parseValue(newValueStr) > 0 ? newValueStr : '';
            } else {
              newValueStr = inputValue.slice(0, selectionStart) + inputValue.slice(selectionStart + 1);
            }
          }

          this.inputNumber.updateValue(event, newValueStr, null, 'delete-back-single');
        } else {
          newValueStr = this.inputNumber.deleteRange(inputValue, selectionStart, selectionEnd);
          if (decimalCharIndex > 0 && selectionStart > decimalCharIndex) {
            this.setMinFractionDigits(this.inputNumber.minFractionDigits - (selectionEnd - selectionStart) > this.minFractionDigits
              ? this.inputNumber.minFractionDigits - (selectionEnd - selectionStart) : this.minFractionDigits);
          } else if (decimalCharIndex > 0 && (selectionStart < decimalCharIndex && selectionEnd > decimalCharIndex)) {
            this.setMinFractionDigits(this.minFractionDigits);
          }
          this.inputNumber.updateValue(event, newValueStr, null, 'delete-range');
        }
        break;
      }

      default:
        break;
    }
  }

  insertText(value, text, start, end) {
    const textSplit = text.split('.');

    if (!value) {
      return this.inputNumber.formatValue(text);
    }

    if (textSplit.length === 2) {
      const decimalCharIndex = value.slice(start, end).search(this.inputNumber._decimal);
      this.inputNumber._decimal.lastIndex = 0;
      return (decimalCharIndex > 0) ? value.slice(0, start) + this.inputNumber.formatValue(text) + value.slice(end) : value;
    } else if ((end - start) === value.length) {
      return this.inputNumber.formatValue(text);
    } else if (start === 0) {
      return text + value.slice(end);
    } else if (end === value.length) {
      return value.slice(0, start) + text;
    } else {
      return value.slice(0, start) + text + value.slice(end);
    }
  }

  setMinFractionDigits(value) {
    this.inputNumber.minFractionDigits = value;
    this.changeDetectorRef.detectChanges();
  }
}
