import {Directive, forwardRef, Input} from '@angular/core';
import {
  AbstractControl,
  AsyncValidator, AsyncValidatorFn,
  NG_ASYNC_VALIDATORS,
  ValidationErrors, Validator, ValidatorFn,
} from '@angular/forms';
import {Observable} from 'rxjs';
import {debounceValidation} from './debounce-validation';

@Directive({
  selector: '[appValidate]',
  providers: [
    {provide: NG_ASYNC_VALIDATORS, useExisting: forwardRef(() => ValidateDirective), multi: true}
  ]
})
export class ValidateDirective implements AsyncValidator {
  private onValidatorChangeFn;
  private _changeDetect;
  private debounceIntervalId;

  @Input('appValidate')
  validator: ValidatorFn | AsyncValidatorFn;

  @Input('appValidateDebounce')
  debounce = false;

  @Input('appValidateDebounceTime')
  debounceTime = 500;

  @Input('appValidateChangeDetect')
  get changeDetect(): any {
    return this._changeDetect;
  }
  set changeDetect(value) {
    if (this.onValidatorChangeFn) {
      this._changeDetect = value;
      this.onValidatorChangeFn();
    }
  }

  validate(control: AbstractControl): Promise<ValidationErrors | null>
      | Observable<ValidationErrors | null>
      | null {
    if (this.debounce
      && this.validator
      && this.debounceTime > 0) {
      return debounceValidation(control, () => this.validateInternal(control),
        {debounceTime: this.debounceTime});
    }
    return this.validateInternal(control);
  }

  private validateInternal(control: AbstractControl): Promise<ValidationErrors | null>
      | Observable<ValidationErrors | null>
      | null {
    if (!this.validator) {
      return new Promise((resolve) => resolve(null));
    }
    const res = this.validator(control);
    if (res instanceof Promise) {
      return res;
    } else if (res instanceof Observable) {
      return (<Observable<ValidationErrors | null>>res).toPromise();
    }
    return new Promise((resolve) => resolve(res));
  }

  registerOnValidatorChange?(fn: () => void): void {
    this.onValidatorChangeFn = fn;
  }
}
