import {Extension} from '../../utils/extension.decorator';

declare global {
  export interface Promise<T> {
    autoCancel(token: CancellationToken): Promise<T>;
  }
}

export class PromiseCanceled implements Error {
  private isPromiseCanceled = true;
  readonly name = 'PromiseCanceled';
  readonly message = 'PROMISE CANCELLED';
}

export class CancellationToken {
  private promise: Promise<any>;
  private reject;

  @Extension(Promise)
  static autoCancel<T>(promise: Promise<T>, token: CancellationToken): Promise<T | Promise<T>> {
    return Promise.race([promise, token.next()]);
  }

  next(): Promise<any> {
    this.cancel();
    this.promise = new Promise((resolve, reject) => {
      this.reject = reject;
    });
    return this.promise;
  }

  cancel() {
    if (this.reject) {
      this.reject(new PromiseCanceled());
    }
  }
}
