import {Directive, HostListener, Input} from '@angular/core';
import {InputTextarea} from 'primeng';

@Directive({
  selector: 'textarea [pInputTextarea]'
})
export class TextareaDirective {
  private oldValue: string;
  private oldWidth: number;

  @Input() emptyStringEqualsNull = true;

  constructor(private input: InputTextarea) {
    const resize = this.input.resize.bind(this.input);
    this.input.resize = event => {
      if (this.input.el.nativeElement.value != this.oldValue
        || this.input.el.nativeElement.clientWidth != this.oldWidth) {
        resize(event);
        this.oldValue = this.input.el.nativeElement.value;
        this.oldWidth = this.input.el.nativeElement.clientWidth;
      }
    };
  }

  @HostListener('change', ['$event'])
  onChange(event) {
    if (this.emptyStringEqualsNull) {
      if (event.target.value === '') {
        this.input.ngModel.valueAccessor.writeValue(null);
        this.input.ngModel.viewToModelUpdate(null);
      }
    }
  }
}
