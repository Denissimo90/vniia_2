import { Module, ModuleNames } from 'ag-grid-community';
import { ClipboardService } from './clipboardService';

export const ClipboardModule: Module = {
    moduleName: ModuleNames.ClipboardModule,
    beans: [ClipboardService]
};
