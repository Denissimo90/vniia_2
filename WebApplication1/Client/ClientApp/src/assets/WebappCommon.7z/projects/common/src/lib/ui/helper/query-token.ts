export class QueryToken {
  private value = Number.MAX_VALUE;

  next(): QueryToken {
    const token = new QueryToken();
    if (this.value === Number.MAX_VALUE) {
      this.value = 0;
    }
    token.value = ++this.value;
    return token;
  }

  equals(token: QueryToken): boolean {
    return this.value === token.value;
  }
}
