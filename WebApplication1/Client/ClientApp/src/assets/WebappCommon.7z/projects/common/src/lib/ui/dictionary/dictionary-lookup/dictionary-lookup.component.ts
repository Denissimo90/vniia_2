import {AfterViewInit, Component, forwardRef, Input, OnInit, QueryList, ViewChild, ViewChildren} from '@angular/core';
import {LookupBaseComponent} from '../../lookup/lookup-base.componet';
import {ControlValueAccessor, NG_VALUE_ACCESSOR} from '@angular/forms';
import {DictionaryService} from '../../../services/dictionary/dictionary.service';
import {Dialog} from 'primeng/dialog';
import {AutoComplete} from 'primeng/autocomplete';
import {DictionaryLookupGridComponent} from '../dictionary-lookup-grid/dictionary-lookup-grid.component';
import {CancellationToken} from '../../helper/cancellation-token';
import {PageQuery} from '../../../services/PageQuery';

@Component({
  selector: 'app-dictionary-lookup',
  templateUrl: './dictionary-lookup.component.html',
  styleUrls: ['./dictionary-lookup.component.css'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => DictionaryLookupComponent),
      multi: true
    }
  ]
})
export class DictionaryLookupComponent extends LookupBaseComponent implements OnInit, AfterViewInit, ControlValueAccessor {

  constructor(private dictionaryService: DictionaryService) {
    super();
  }

  @Input() global = true;
  @Input() key;
  @Input() view;
  @Input() textField: string;
  @Input() display: boolean;
  @Input() style: any;
  @Input() readonly: boolean;
  @Input() count = 15;
  @Input() searchMode = 'startsWith';
  @Input() filter: string;
  @Input() filterParams: { [key: string]: string };
  @Input() query: string;
  @Input() sortField: string;
  @Input() url: string;

  grid: DictionaryLookupGridComponent;
  onChange: any;
  suggestions = [];
  loading = false;
  token = new CancellationToken();
  inputText: string;

  @ViewChild('autocomplete', {static: true}) autocomplete: AutoComplete;
  @ViewChild('dialog') dialog: Dialog;
  @ViewChildren('grid') gridQuery: QueryList<DictionaryLookupGridComponent>;

  ngOnInit() {
  }

  ngAfterViewInit() {
    this.gridQuery.changes.subscribe(() => {
      const grid = this.gridQuery.first;
      setTimeout(() => {
        this.grid = grid;
      });
    });
  }

  writeValue(obj: any): void {
    this.autocomplete.writeValue(obj);
  }

  registerOnChange(fn: any): void {
    this.onChange = fn;
    this.autocomplete.registerOnChange(this.onChange);
  }

  registerOnTouched(fn: any): void {
    this.autocomplete.registerOnTouched(fn);
  }

  setValue(value: any) {
    this.writeValue(value);
    this.onChange(value);
  }

  showForm() {
    this.display = true;
  }

  setDisabledState(isDisabled: boolean): void {
    this.autocomplete.setDisabledState(isDisabled);
  }

  async searchLocalDictionary(event: any, dictKey: string) {
    const filters = {};
    filters['value'] = {matchMode: this.searchMode, value: event.query};
    if (this.query) {
      filters['@query'] = {value: this.query};
    }
    this.suggestions = (await this.dictionaryService.searchLocalDictionary(
      new PageQuery({
        first: 0,
        rows: this.count,
        sorts: [{field: 'value'}],
        filters: filters
      }),
      dictKey,
      this.url).autoCancel(this.token)).items;
    this.inputText = event.query;
  }

  async getElementByPressEnter(keyEvent: any) {
    if (keyEvent.key == 'Enter') {
      let fetchingElement;
      let compareLine;
      this.sortField ? compareLine = this.sortField : compareLine = this.textField;
      this.suggestions.forEach(e => {
        e[compareLine].toString().toLowerCase() == this.inputText.toString().toLowerCase() ? fetchingElement = e : e;
      });
      if (fetchingElement) {
        this.autocomplete.inputFieldValue = fetchingElement[this.textField];
        this.autocomplete.value = fetchingElement;
        this.select(this.autocomplete.value);
      }
      this.autocomplete.hide();
    }
  }

  async searchDictionary(event: any, dictKey: string, dictField: string) {
    const filters = {};
    filters[dictField] = {matchMode: this.searchMode, value: event.query};
    if (this.query) {
      filters['@query'] = {value: this.query};
    }
    this.suggestions = (await this.dictionaryService.searchDictionary(
      new PageQuery({
        first: 0,
        rows: this.count,
        sorts: this.sortField ? [{field: this.sortField}] : [{field: dictField}],
        filters: filters
      }),
      dictKey,
      this.filter,
      this.filterParams,
      this.url).autoCancel(this.token)).items;
    this.inputText = event.query;
  }

  onresize(e) {
    if (this.dialog.maximized) {
      return;
    }
    setTimeout(() => {
      if (this.dialog.container) {
        this.dialog.container.style.left = 'unset';
        this.dialog.container.style.top = 'unset';
      }
    });
  }

  async select(value) {
    this.loading = true;
    if (this.view) {
      this.setValue(await this.dictionaryService.getViewValue(value.id, this.view));
    } else {
      this.setValue(value);
    }
    this.display = false;
    this.loading = false;
  }

  onGridKeyDown(key) {
    if (key.key === 'Enter' && this.grid.selectedValue) {
      this.select(this.grid.selectedValue);
      key.preventDefault();
      key.stopPropagation();
    }
  }
}


